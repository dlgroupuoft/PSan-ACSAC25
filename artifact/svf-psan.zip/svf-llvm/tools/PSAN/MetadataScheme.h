#ifndef METADATASCHEME_H
#define METADATASCHEME_H

#include <llvm/Support/raw_ostream.h>
#include <llvm/ADT/StringMap.h>
#include <llvm/ADT/SmallSet.h>
#include <llvm/ADT/DenseSet.h>
#include <llvm/ADT/SetVector.h>
#include <llvm/Transforms/Utils/Cloning.h>
#include <llvm/IR/Function.h>
#include <llvm/IR/Module.h>
#include <llvm/IR/Instruction.h>
#include <llvm/IR/LLVMContext.h>

#include "InstrumentOptions.h"

namespace PSan {

// this is the base class for Out-of-Band metadata scheme implementation interface
// to abstract away the instrumentation schemes from the metadata scheme, the metadata scheme only manages an abstract chunk of memory for metadata
// the instrumentation manager will manage the loading and storing of metadata from this chunk of memory,
// while the metadata scheme will manage the allocation and mapping
class MetadataSchemeBase {
protected:
  // base info
  llvm::LLVMContext& ctx;
  const PSan::InstrumentationOptions& options;
  const std::size_t mdsize;
  const std::size_t mdsize_p2; // log2(mdsize) suitable for size calculation
  const std::size_t mdalign;
  llvm::Module* dstModule;
public:
  MetadataSchemeBase(llvm::LLVMContext& ctx, const PSan::InstrumentationOptions& options, std::size_t mdsize, std::size_t mdalign, llvm::Module* dstModule);
  virtual ~MetadataSchemeBase() = default;

  // by default, metadata memory chunk is zero-initialized
  // if the following function is called with a non-zero value, the memory chunk will be initialized with the given value
  virtual void setMetadataMemoryInitializer(llvm::Constant* initializer) = 0;

  // if something needs to be done after all the instrumentation (e.g., linking in runtime library functions),
  // this is the place to do it
  virtual void finalize() {}

  // metadata read/write for scalars
  // the getMetadataAddressFor* functions will return the address for loading/storing of the metadata
  // after the metadata is loaded/stored, the releaseMetadataAddressFor* functions will be called to release the address (if needed)
  virtual llvm::Value* getMetadataAddressForMDLoad(llvm::Value* addr, llvm::Instruction* insertBefore) = 0;
  virtual llvm::Value* getMetadataAddressForMDStore(llvm::Value* addr, llvm::Instruction* insertBefore) = 0;
  virtual void releaseMetadataAddressForMDLoad(llvm::Value* addr, llvm::Value* mdaddr, llvm::Instruction* insertBefore) {}
  virtual void releaseMetadataAddressForMDStore(llvm::Value* addr, llvm::Value* mdaddr, llvm::Instruction* insertBefore) {}
  // the versions for vector types
  // the default implementation will call the scalar versions for each element
  // but since the metadata scheme probably have a more efficient way to handle vector types due to the locality, it can override these functions
  virtual llvm::SmallVector<llvm::Value*> getMetadataAddressForMDLoadVector(llvm::Value* addr, unsigned numElements, llvm::Instruction* insertBefore);
  virtual llvm::SmallVector<llvm::Value*> getMetadataAddressForMDStoreVector(llvm::Value* addr, unsigned numElements, llvm::Instruction* insertBefore);
  virtual void releaseMetadataAddressForMDLoadVector(llvm::Value* addr, llvm::SmallVector<llvm::Value*>& mdaddrs, llvm::Instruction* insertBefore);
  virtual void releaseMetadataAddressForMDStoreVector(llvm::Value* addr, llvm::SmallVector<llvm::Value*>& mdaddrs, llvm::Instruction* insertBefore);

  // metadata set/clear/copy
  // mdrealloc is called for realloc(); it should copy metadata if possible, or just clear metadata at dest if not
  virtual void mdmemset(llvm::Value* addr, llvm::Value* len, llvm::Instruction* insertBefore) = 0;
  virtual void mdmemcpy(llvm::Value* dst, llvm::Value* src, llvm::Value* len, llvm::Instruction* insertBefore) = 0;
  virtual void mdmemmove(llvm::Value* dst, llvm::Value* src, llvm::Value* len, llvm::Instruction* insertBefore) = 0;
  virtual void mdrealloc(llvm::CallBase* reallocCall) = 0;

  // metadata initialization for global variables
  // this function will be called exactly once
  // if there are any global variable containing pointers, the metadata scheme should store the metadata for these pointers in the metadata memory
  // the tuple contains (1) the address of the pointer, (2) the metadata initializer, and (3) (optionally) a global variable holding the metadata initializer
  virtual void handleGlobalMetadataInit(const llvm::SmallVector<std::tuple<llvm::Constant*, llvm::Constant*, llvm::GlobalVariable*>>& info) {}
protected:
  // helper functions that derived class can use

  // helper for implementing handleGlobalMetadataInit()
  // gvmdinit should be an empty function that the runtime initialization routine will call
  // info contains the metadata initializers for pointer-type values in global variables
  // this function will populate the body of gvmdinit to copy the metadata initializers to the metadata memory
  void populateGlobalMetadataInit(llvm::Function* gvmdinit, const llvm::SmallVector<std::tuple<llvm::Constant*, llvm::Constant*, llvm::GlobalVariable*>>& info, bool isSkipZeroInit = false);
};

class TwoLevelTrieMetadataScheme : public MetadataSchemeBase {
public:
  TwoLevelTrieMetadataScheme(llvm::LLVMContext& ctx, const PSan::InstrumentationOptions& options, std::size_t mdsize, std::size_t mdalign, llvm::Module* dstModule);

  virtual void setMetadataMemoryInitializer(llvm::Constant* initializer) override;
  virtual llvm::Value* getMetadataAddressForMDLoad(llvm::Value* addr, llvm::Instruction* insertBefore) override;
  virtual llvm::Value* getMetadataAddressForMDStore(llvm::Value* addr, llvm::Instruction* insertBefore) override;

  virtual void mdmemset(llvm::Value* addr, llvm::Value* len, llvm::Instruction* insertBefore) override;
  virtual void mdmemcpy(llvm::Value* dst, llvm::Value* src, llvm::Value* len, llvm::Instruction* insertBefore) override;
  virtual void mdmemmove(llvm::Value* dst, llvm::Value* src, llvm::Value* len, llvm::Instruction* insertBefore) override;
  virtual void mdrealloc(llvm::CallBase* reallocCall) override;

  virtual void finalize() override;
  virtual void handleGlobalMetadataInit(const llvm::SmallVector<std::tuple<llvm::Constant*, llvm::Constant*, llvm::GlobalVariable*>>& info) override;
private:
  llvm::Value* call_getmdaddr(llvm::Value* addr, llvm::Instruction* insertBefore);
  void call_mdmemset(llvm::Value* addr, llvm::Value* len, llvm::Instruction* insertBefore);
  void call_mdmemcpymove(llvm::Value* dst, llvm::Value* src, llvm::Value* len, llvm::Instruction* insertBefore, llvm::Function* func);
private:
  llvm::PointerType* i8PtrTy = nullptr;
  llvm::IntegerType* i64Ty = nullptr;
  llvm::Function* func_getmdaddr = nullptr;
  llvm::Function* func_mdmemset = nullptr;
  llvm::Function* func_mdmemcpy = nullptr;
  llvm::Function* func_mdmemmove = nullptr;
  llvm::Function* func_mdrealloc = nullptr;
  llvm::Function* func_gvmdinit = nullptr;
  llvm::Function* func_realloc_get_old_size = nullptr;
};

} // namespace PSan

#endif // METADATASCHEME_H
