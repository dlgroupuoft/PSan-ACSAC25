#include "psan.h"
#include "FastDebugDumper.h"

#include "SVF-LLVM/LLVMUtil.h"
#include "SVF-LLVM/SVFIRBuilder.h"
#include "WPA/WPAPass.h"
#include "Util/CommandLine.h"
#include "Util/Options.h"
#include "SVFIR/SVFIRRW.h"
#include "SVFIR/SVFModule.h"
#include "MemoryModel/PointerAnalysisImpl.h"
#include "WPA/WPAPass.h"
#include "WPA/Andersen.h"
#include "WPA/AndersenPWC.h"
#include "WPA/FlowSensitive.h"
#include "WPA/VersionedFlowSensitive.h"
#include "WPA/TypeAnalysis.h"
#include "WPA/Steensgaard.h"
#include "Graphs/DOTGraphTraits.h"
#include "llvm/IR/InlineAsm.h"

using namespace PSan;
using namespace SVF;
using namespace SVF::SVFUtil;
namespace PSan{
class EPTGBuilder {
  friend class CellNodeTracker;
public:
  EPTGBuilder(llvm::Module* srcModule, llvm::Module* clonedModule,
    SVF::SVFIR* svfir, SVF::PointerAnalysis* pta, SVF::SVFG* svfg,
    llvm::DenseMap<llvm::Value*, llvm::Value*>& taintedClones,
    llvm::DenseMap<llvm::Value*, llvm::Value*>& src2cloned,
    llvm::DenseMap<llvm::Value*, llvm::Value*>& cloned2src,
    llvm::SmallVectorImpl<std::tuple<llvm::Instruction*, unsigned, unsigned>>& sizeOperands,
    StaticStats& stats
  ) : srcModule(srcModule), clonedModule(clonedModule),
      svfir(svfir), pta(pta), svfg(svfg),
      taintedClones(taintedClones),
      src2cloned(src2cloned),
      cloned2src(cloned2src),
      sizeOperands(sizeOperands),
      stats(stats)
  {
    (void) this->src2cloned;
  }
  EPTG* build();
  bool dumpPrunedSVFGForDebugging(const std::string& filename);
private:
  // source data
  llvm::Module* srcModule = nullptr;
  llvm::Module* clonedModule = nullptr;
  SVF::SVFIR* svfir = nullptr;
  SVF::PointerAnalysis* pta = nullptr;
  SVF::SVFG* svfg = nullptr;

  llvm::DenseMap<llvm::Value*, llvm::Value*>& taintedClones;
  llvm::DenseMap<llvm::Value*, llvm::Value*>& src2cloned;
  llvm::DenseMap<llvm::Value*, llvm::Value*>& cloned2src;
  llvm::SmallVectorImpl<std::tuple<llvm::Instruction*, unsigned, unsigned>>& sizeOperands;
  StaticStats& stats;

private:
  // temporary data for graph construction
  // all the llvm::Value* references are from the cloned module
  // (we will translate them to the source module later, when constructing the final EPTG)
  // the taint has the same semantics as the one from the previous stage:
  //   if a pointer expression node is tainted, we cannot mutate the type of its points-to object (but can still widen this tainted pointer)
  //   if a cell is tainted, we cannot mutate its type
  //   if a pointer cell is tainted, we cannot widen this tainted pointer, and cannot mutate what it points to (the pointed cells should also be tainted)
  struct TempNodeBase {
    const std::size_t id = 0;
    bool isTaintedForTypePinning = false;
    explicit TempNodeBase(std::size_t id) : id(id) {}
    void setTainted(const char* msg);
  };
  struct TempCellNode : public TempNodeBase {
    std::size_t leaderID = 0; // if leaderID != id and leaderID != 0, then this node is merged to the leader
    llvm::Type* ty = nullptr;
    std::size_t pointsToCellID = 0; // if this is a pointer cell, this is the cell it points to
    bool isArgumentCell = false;
    explicit TempCellNode(std::size_t id) : TempNodeBase(id) {}
    void setPointsToCell(std::size_t cellID) {
      static DumpEventDecl<std::size_t, std::size_t> pointsToEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
        os << "TmpC#" << data.get<0>() << " -> TmpC#" << data.get<1>() << "\n";
      });
      PSAN_DEBUG(pointsToEvent(id, cellID));
      pointsToCellID = cellID;
    }
    void setTainted(const char* msg);
  };
  struct TempExpressionNode : public TempNodeBase {
    std::size_t pointsToCellID = 0;
    llvm::Value* value = nullptr; // can be null
    SVF::SVFGNode* svfgNode = nullptr; // probably should not be null; if yes, then we will drop the node later on
    bool isMarkedForRemoval = false; // true if it it may pick up value from tainted cell, so it cannot be widened within EPTG
    explicit TempExpressionNode(std::size_t id) : TempNodeBase(id) {}
    void setPointsToCell(std::size_t cellID) {
      static DumpEventDecl<std::size_t, std::size_t> pointsToEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
        os << "TmpE#" << data.get<0>() << " -> TmpC#" << data.get<1>() << "\n";
      });
      PSAN_DEBUG(pointsToEvent(id, cellID));
      pointsToCellID = cellID;
    }
    void markForRemoval() {
      isMarkedForRemoval = true;
    }
    void setTainted(const char* msg);
  };
  struct TempAllocNode : public TempNodeBase {
    std::size_t allocToCellID = 0;
    llvm::Value* value = nullptr;
    explicit TempAllocNode(std::size_t id) : TempNodeBase(id) {}
    void setTainted(const char* msg);
  };
  struct TempLoadEdge {
    std::size_t id = 0;
    std::size_t srcID = 0; // cell node ID
    std::size_t dstID = 0; // expression node ID
  };
  struct TempStoreEdge {
    std::size_t id = 0;
    std::size_t srcID = 0; // expression node ID
    std::size_t dstID = 0; // cell node ID
    llvm::Instruction* backingInst = nullptr; // for debugging
  };
  struct TempCopyEdge {
    std::size_t id = 0;
    std::size_t srcID = 0; // expression node ID
    std::size_t dstID = 0; // expression node ID
  };
  llvm::SmallVector<TempCellNode> cells; // node 0 is invalid
  llvm::SmallVector<TempExpressionNode> expressionNodes;
  llvm::SmallVector<TempAllocNode> allocNodes;
  llvm::SmallVector<TempLoadEdge> loadEdges;
  llvm::SmallVector<TempStoreEdge> storeEdges;
  llvm::SmallVector<TempCopyEdge> copyEdges;
  llvm::DenseMap<std::size_t, llvm::SmallVector<std::size_t>> exprID2loadEdgeIDs;
  llvm::DenseMap<std::size_t, llvm::SmallVector<std::size_t>> exprID2storeEdgeIDs;
  llvm::DenseMap<std::size_t, llvm::SmallVector<std::size_t>> exprID2copyEdgeIDs;

  // this is where all contains edges are stored
  // we keep all key indices here up-to-date (for outgoing contains edge); value indices may be stale (need to check the leader)
  // now we only support a single step for the member position, so we directly use int64_t
  llvm::DenseMap<std::size_t, llvm::DenseMap<int64_t, std::size_t>> cellID2subobjectCellIDs;

  // this mapping is only used after cell points-to are found (which is after the initial graph construction)
  llvm::DenseMap<std::size_t, llvm::DenseSet<std::size_t>> cellID2loadExprNodeIDs;

  llvm::DenseMap<llvm::Value*, std::size_t> value2expressionNodeID;
  llvm::DenseMap<llvm::Value*, std::size_t> value2allocNodeID;
  llvm::DenseMap<std::size_t, std::size_t> exprNodeID2allocNodeID;
  llvm::DenseMap<llvm::Function*, std::size_t> placeholderCallRetCells;
  llvm::DenseMap<llvm::Function*, llvm::DenseMap<int, std::size_t>> functionDefintionCells; // for each function: -1 for the function prototype, 0-N-1 for the arguments, N for the return value, N+1 for the vararg
  llvm::DenseMap<llvm::InlineAsm*, llvm::DenseMap<int, std::size_t>> asmCells;
  llvm::DenseMap<llvm::CallInst*, std::pair<std::size_t, std::size_t>> pendingMergeMemIntrinsicsArgs; // [memcpy/memmove call] -> [dst cell node ID, src cell node ID]

  // when we visit a load from the address side, we create a dummy cell and proceed traversal from there
  // however, if this load is not visited from the value side, we should taint the cell
  // expr node ID -> <isVisitedFromValueSide, isVisitedFromAddressSide>
  llvm::DenseMap<std::size_t, std::pair<bool, bool>> loadExprNodesWithDummyCells;
  // if a null pointer store can reach the loads in loadExprNodesWithDummyCells, we should not taint the cells
  llvm::DenseSet<llvm::LoadInst*> nullReachableLoads;

  // we want to ensure that the type of the cells are consistent
  llvm::SmallVector<llvm::ICmpInst*> ptrIcmps;

  // we want to create placeholder cells for pointer arguments
  // so that if we have stores to these cells, we can make consistent type transforms on the stored values
  llvm::SmallVector<std::size_t> functionArgExprWorklist;

  // data structures to assist SVFG logic debugging
  llvm::DenseMap<std::size_t, SVF::SVFGNode*> loadDummyExprSVFGNodes; // for expr node that loads from dummy cells, what's their SVFG nodes
  llvm::SmallVector<std::size_t> taintedLoadDummyExprNodes;

private:
  // steps in building EPTG
  void buildInitialGraph();
  void addCellPointsTo(SVF::FIFOWorkList<std::size_t>& cellsWithPointsTo);
  void propagateCellPointsTo(SVF::FIFOWorkList<std::size_t>& cellWorklist);
  void runTaintAnalysis();
  void runGraphTransforms();
  EPTG* buildFinalGraph();
private:
  // helper functions
  const SVF::SVFGNode* getSVFGDefNode(llvm::Value* v);
  llvm::Value* getLLVMValueFromSVFGNode(const SVF::SVFGNode*);
  ElementRef<TempExpressionNode> getOrCreateExpressionNode(llvm::Value* value);
  ElementRef<TempCellNode> createCellNode(llvm::Type* ty);
  ElementRef<TempAllocNode> createAllocNode(llvm::Value* value);
  void addContainsEdge(std::size_t srcID, std::size_t dstID, MemberPosition pos);
  void addLoadEdge(std::size_t srcCellID, std::size_t dstExprID);
  void addStoreEdge(std::size_t srcExprID, std::size_t dstCellID, llvm::Instruction* backingInst = nullptr);
  ElementRef<TempExpressionNode> getExpressionNodeAt(std::size_t exprID);
  ElementRef<TempCellNode> getCellNodeAt(std::size_t cellID);
  ElementRef<TempAllocNode> getAllocNodeAt(std::size_t allocID);

  bool isCallShouldBeIgnoredForGraphBuilding(llvm::CallBase* call);
  void handleMemCpyMemMove(llvm::CallBase* call, std::size_t dstCellID, std::size_t srcCellID);
  bool isTypeConsideredCompatibleForMerging(llvm::Type* ty1, llvm::Type* ty2);
  std::size_t createFunctionInterfaceCells(llvm::FunctionType* funcTy, llvm::DenseMap<int, std::size_t>& argIndex2cellID, bool isTainted, llvm::Function* definition = nullptr);
  void traverseSVFGFromAllocation(std::size_t exprNodeID, llvm::Value* v);
  bool tryMergeCells(std::size_t cellID1, std::size_t cellID2, bool shouldTaint);
  std::size_t getOrCreateSubobjectCell(std::size_t parent, MemberPosition pos);
  SVF::SVFGNode* getStoreAddress(SVF::StoreSVFGNode* store);
  bool checkIsLibFunctionToBeSkipped(llvm::Function* callee);
  bool isCalleeSafeToIgnore(llvm::Function* callee);
  std::size_t getLeaderCellID(std::size_t cellID);
  std::size_t getPlaceholderCell(llvm::Function* placeholder);
  bool isValueEquivalentForMemIntrinsics(llvm::Value* operand, llvm::Value* v);
  void addSizeOperandEntry(llvm::Instruction* inst, unsigned ptrOperandIndex, unsigned accessSizeOperandIndex);
  void tryFindSizeOperandsForMemoryOps(llvm::CallBase* call);
  void debugDumpCellEdges(std::size_t cellID, const char* header);
  void propagateExprPointsTo(std::size_t exprID, SVF::FIFOWorkList<std::size_t>& cellWorklist);
};
class CellNodeTracker {
  // when we construct the graph, the cell nodes may be merged and the cell ID may be stale
  // we use this to keep track of the latest cell ID
public:
  CellNodeTracker(EPTGBuilder* parent, std::size_t cellID) : parent(parent), cellID(cellID) {}
  std::size_t get() {
    cellID = parent->getLeaderCellID(cellID);
    return cellID;
  }
  operator std::size_t() {
    return get();
  }
private:
  EPTGBuilder* parent = nullptr;
  std::size_t cellID = 0;
};

} // end namespace PSan

void EPTGBuilder::TempNodeBase::setTainted(const char* msg)
{
  if (isTaintedForTypePinning) {
    return;
  }
  static DumpEventDecl<std::size_t, const char*> taintEvent([](llvm::raw_ostream& os, const EventData<std::size_t, const char*>& data) {
    os << "TmpN#" << data.get<0>() << " Tainted: " << data.get<1>() << "\n";
  });
  PSAN_DEBUG(taintEvent(id, msg));
  isTaintedForTypePinning = true;
}

void EPTGBuilder::TempCellNode::setTainted(const char* msg)
{
  if (isTaintedForTypePinning) {
    return;
  }
  if (leaderID != 0 && leaderID != id) {
    psan_unreachable("calling setTainted() on a non-leader cell");
  }
  static DumpEventDecl<std::size_t, const char*> taintEvent([](llvm::raw_ostream& os, const EventData<std::size_t, const char*>& data) {
    os << "TmpC#" << data.get<0>() << " Tainted: " << data.get<1>() << "\n";
  });
  PSAN_DEBUG(taintEvent(id, msg));
  isTaintedForTypePinning = true;
}

void EPTGBuilder::TempExpressionNode::setTainted(const char* msg)
{
  if (isTaintedForTypePinning) {
    return;
  }
  static DumpEventDecl<std::size_t, const char*, std::size_t> taintEvent([](llvm::raw_ostream& os, const EventData<std::size_t, const char*, std::size_t>& data) {
    os << "TmpE#" << data.get<0>() << " Tainted: " << data.get<1>() << "\n";
    std::size_t pointsToCell = data.get<2>();
    if (pointsToCell != 0) {
      os << "  --> TmpC#" << pointsToCell << "\n";
    }
  });
  PSAN_DEBUG(taintEvent(id, msg, pointsToCellID));
  isTaintedForTypePinning = true;
}
void EPTGBuilder::TempAllocNode::setTainted(const char* msg)
{
  if (isTaintedForTypePinning) {
    return;
  }
  static DumpEventDecl<std::size_t, const char*> taintEvent([](llvm::raw_ostream& os, const EventData<std::size_t, const char*>& data) {
    os << "TmpA#" << data.get<0>() << " Tainted: " << data.get<1>() << "\n";
  });
  PSAN_DEBUG(taintEvent(id, msg));
  isTaintedForTypePinning = true;
}

bool EPTGBuilder::dumpPrunedSVFGForDebugging(const std::string& filename)
{
  // in this function we dump a graph for SVFG with only nodes related to the tainting of dummy cells due to loads
  // we start from the SVFG nodes for the load expression nodes, and find all SVFG nodes that can reach them
  if (taintedLoadDummyExprNodes.empty()) {
    return false;
  }
  llvm::DenseSet<SVF::SVFGNode*> visited;
  llvm::SmallVector<SVF::SVFGNode*> worklist;
  for (std::size_t exprNode : taintedLoadDummyExprNodes) {
    auto iter = loadDummyExprSVFGNodes.find(exprNode);
    if (iter == loadDummyExprSVFGNodes.end()) {
      psan_unreachable("Expr node loading dummy cells did not register SVFG node?");
    }
    visited.insert(iter->second);
    worklist.push_back(iter->second);
  }
  auto addToWorklist = [&](SVF::SVFGNode* node) -> bool {
    if (visited.insert(node).second) {
      worklist.push_back(node);
      return true;
    }
    return false;
  };
  while (!worklist.empty()) {
    SVF::SVFGNode* node = worklist.back();
    worklist.pop_back();
    for (auto iter = node->InEdgeBegin(), iterEnd = node->InEdgeEnd(); iter != iterEnd; ++iter) {
      const SVF::SVFGEdge* edge = *iter;
      addToWorklist(edge->getSrcNode());
    }
  }
  debugDumpSVFG(filename, svfg, visited);
  return true;
}

GraphConstructionResults PSan::step3_graph_construction(llvm::Module* srcModule, llvm::Module* clonedModule, llvm::ValueToValueMapTy& srcMapping, llvm::DenseMap<llvm::Value*, llvm::Value*>& taintedClones, StaticStats& stats, llvm::StringRef dumpNamePrefix, bool dumpGraphs)
{
  GraphConstructionResults result;
  SVFModule* svfModule = LLVMModuleSet::getLLVMModuleSet()->buildSVFModule(*clonedModule);

  SVFIRBuilder builder(svfModule);
  SVFIR* pag = builder.build();
  SVF::PointerAnalysis* pta = new SVF::AndersenWaveDiff(pag);
  pta->analyze();
  result.svfgBuilder = new SVFGBuilder(true);
  SVFG *svfg = result.svfgBuilder->buildPTROnlySVFG((BVDataPTAImpl*)pta);
  stats.setTime(stats.s3_svfAnalysisTime);
  if (dumpGraphs) {
    std::string svfgName = dumpNamePrefix.str() + "_svfg";
    svfg->dump(svfgName);
  }

  for (auto iter = srcMapping.begin(), end = srcMapping.end(); iter != end; ++iter) {
    if (!iter->second.pointsToAliveValue()) {
      const llvm::Value* srcValue = iter->first;
      static DumpEventDecl<llvm::Value*> deadValueEvent([](llvm::raw_ostream& os, const EventData<llvm::Value*>& data) {
        os << "Value becomes dead: " << data.get<0>() << "\n";
      });
      PSAN_DEBUG(deadValueEvent(const_cast<llvm::Value*>(srcValue)));
      continue;
    }
    if (llvm::isa<llvm::MetadataAsValue>(iter->first)) {
      // we don't care about metadata
      continue;
    }
    llvm::Value* srcValue = const_cast<llvm::Value*>(iter->first);
    llvm::Value* clonedValue = const_cast<llvm::Value*>(static_cast<const llvm::Value*>(iter->second));
    auto p1 = result.cloned2src.insert(std::make_pair(clonedValue, srcValue));
    if (!p1.second) {
      if (!step2_pruning_isPlaceholderCall(clonedValue)) {
        psan_unreachable("cloned value already exists in the map");
      }
    }
    auto p2 = result.src2cloned.insert(std::make_pair(srcValue, clonedValue));
    if (!p2.second) {
      psan_unreachable("source value already exists in the map");
    }
  }
  EPTGBuilder eptgBuilder(srcModule, clonedModule, pag, pta, svfg, taintedClones, result.src2cloned, result.cloned2src, result.sizeOperands, stats);
  EPTG* eptg = eptgBuilder.build();
  stats.setTime(stats.s3_finishTime);
  if (dumpGraphs) {
    std::string eptgName = dumpNamePrefix.str() + "_eptg";
    eptg->dump(eptgName);
    std::string prunedSVFGName = dumpNamePrefix.str() + "_svfg_pruned";
    eptgBuilder.dumpPrunedSVFGForDebugging(prunedSVFGName);
  }

  result.svfir = pag;
  result.pta = pta;
  result.svfg = svfg;
  result.eptg = eptg;
  return result;
}

const SVF::SVFGNode* EPTGBuilder::getSVFGDefNode(llvm::Value* v)
{
  SVF::SVFValue* value = SVF::LLVMModuleSet::getLLVMModuleSet()->getSVFValue(v);
  if (!value)
    return nullptr;
  if (!svfir->hasValueNode(value)) {
    return nullptr;
  }
  auto pagNodeID = svfir->getValueNode(value);
  auto* pagNode = svfir->getGNode(pagNodeID);
  return svfg->getDefSVFGNode(pagNode);
}

llvm::Value* EPTGBuilder::getLLVMValueFromSVFGNode(const SVF::SVFGNode* node)
{
  // some SVFG nodes are carrying values not representing the pointer
  // we will let them return nullptr
  const SVFValue* value = node->getValue();
  if (!value)
    return nullptr;
  if (SVFUtil::isa<SVF::SVFFunction>(value)) {
    // if the value is a function, we want to exclude known cases where the SVFG node's value does not belong to the actual value
    if (SVFUtil::isa<SVF::FormalRetSVFGNode>(node)) {
      return nullptr;
    }
    // if this is an IntraPHI, we check if it is for the return node
    // we still want to correctly handle intraphi for function pointers
    if (const SVF::IntraPHISVFGNode* intraphi = SVFUtil::dyn_cast<SVF::IntraPHISVFGNode>(node)) {
      // if this IntraPHI only has one outgoing edge to a FormalRetSVFGNode, then it is for the return node
      // we first get the unique outgoing edge
      const SVF::SVFGEdge* edge = nullptr;
      for (auto iter = intraphi->OutEdgeBegin(), iterEnd = intraphi->OutEdgeEnd(); iter != iterEnd; ++iter) {
        const SVF::SVFGEdge* e = *iter;
        if (edge) {
          edge = nullptr;
          break;
        }
        edge = e;
      }
      // now check if this edge goes to a FormalRetSVFGNode
      if (edge) {
        if (SVFUtil::isa<SVF::FormalRetSVFGNode>(edge->getDstNode())) {
          return nullptr;
        }
      }
    }
  }
  return getLLVMValue(const_cast<SVFValue*>(value));
}

ElementRef<EPTGBuilder::TempExpressionNode> EPTGBuilder::getOrCreateExpressionNode(llvm::Value* value)
{
  auto it = value2expressionNodeID.find(value);
  if (it != value2expressionNodeID.end()) {
    return ElementRef<TempExpressionNode>::get(expressionNodes, it->second);
  }
  if (llvm::StoreInst* store = llvm::dyn_cast<llvm::StoreInst>(value)) {
    (void) store;
    psan_unreachable("store instruction should not be used for expression node");
  }
  std::size_t id = expressionNodes.size();
  expressionNodes.push_back(TempExpressionNode(id));
  TempExpressionNode& node = expressionNodes.back();
  node.value = value;
  if (taintedClones.find(value) != taintedClones.end()) {
    node.setTainted("new expr node tainted from previous step");
  }
  value2expressionNodeID[value] = id;
  static DumpEventDecl<std::size_t, llvm::Value*, bool> exprEvent([](llvm::raw_ostream& os, const EventData<std::size_t, llvm::Value*, bool>& data) {
    os << "New TmpE#" << data.get<0>() << ": " << data.get<1>();
    if (data.get<2>()) {
      os << " [Tainted]";
    }
    os << "\n";
  });
  PSAN_DEBUG(exprEvent(id, value, node.isTaintedForTypePinning));
  return ElementRef<TempExpressionNode>(expressionNodes, node);
}

ElementRef<EPTGBuilder::TempExpressionNode> EPTGBuilder::getExpressionNodeAt(std::size_t exprID)
{
  return ElementRef<TempExpressionNode>::get(expressionNodes, exprID);
}

ElementRef<EPTGBuilder::TempCellNode> EPTGBuilder::createCellNode(llvm::Type* ty)
{
  std::size_t id = cells.size();
  cells.push_back(TempCellNode(id));
  TempCellNode& cell = cells.back();
  cell.ty = ty;
  static DumpEventDecl<std::size_t, llvm::Type*> cellEvent([](llvm::raw_ostream& os, const EventData<std::size_t, llvm::Type*>& data) {
    os << "New TmpC#" << data.get<0>() << ": " << data.get<1>() << "\n";
  });
  PSAN_DEBUG(cellEvent(id, ty));
  return ElementRef<TempCellNode>(cells, cell);
}

ElementRef<EPTGBuilder::TempCellNode> EPTGBuilder::getCellNodeAt(std::size_t cellID)
{
  return ElementRef<TempCellNode>::get(cells, cellID);
}

ElementRef<EPTGBuilder::TempAllocNode> EPTGBuilder::createAllocNode(llvm::Value* value)
{
  std::size_t id = allocNodes.size();
  allocNodes.push_back(TempAllocNode(id));
  TempAllocNode& node = allocNodes.back();
  node.value = value;
  if (taintedClones.find(value) != taintedClones.end()) {
    node.setTainted("new alloc node tainted from previous step");
  }
  value2allocNodeID[value] = id;
  static DumpEventDecl<std::size_t, llvm::Value*, bool> allocEvent([](llvm::raw_ostream& os, const EventData<std::size_t, llvm::Value*, bool>& data) {
    os << "New TmpA#" << data.get<0>() << ": " << data.get<1>();
    if (data.get<2>()) {
      os << " [Tainted]";
    }
    os << "\n";
  });
  PSAN_DEBUG(allocEvent(id, value, node.isTaintedForTypePinning));
  return ElementRef<TempAllocNode>(allocNodes, node);
}

ElementRef<EPTGBuilder::TempAllocNode> EPTGBuilder::getAllocNodeAt(std::size_t allocID)
{
  return ElementRef<TempAllocNode>::get(allocNodes, allocID);
}

void EPTGBuilder::addContainsEdge(std::size_t srcID, std::size_t dstID, MemberPosition pos)
{
  // both cells should not be merged
  ElementRef<TempCellNode> srcCell = getCellNodeAt(srcID);
  ElementRef<TempCellNode> dstCell = getCellNodeAt(dstID);
  if (!(srcCell->leaderID == 0 || srcCell->leaderID == srcID)) {
    psan_unreachable("addContainsEdge(): src cell is merged");
  }
  if (!(dstCell->leaderID == 0 || dstCell->leaderID == dstID)) {
    psan_unreachable("addContainsEdge(): dst cell is merged");
  }
  if (pos.size() > 1) {
    psan_unreachable("contains edge with more than one step");
  }
  static DumpEventDecl<std::size_t, std::size_t, int64_t> containsEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t, int64_t>& data) {
    os << "Contains: TmpC#" << data.get<0>() << " -> TmpC#" << data.get<1>() << " at [" << data.get<2>() << "]\n";
  });
  PSAN_DEBUG(containsEvent(srcID, dstID, pos.front()));

  cellID2subobjectCellIDs[srcID][pos.front()] = dstID;
}

void EPTGBuilder::addLoadEdge(std::size_t srcCellID, std::size_t dstExprID)
{
  std::size_t id = loadEdges.size();
  loadEdges.push_back(TempLoadEdge{id, srcCellID, dstExprID});
  exprID2loadEdgeIDs[dstExprID].push_back(id);
  static DumpEventDecl<std::size_t, std::size_t> loadEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
    os << "Load: TmpC#" << data.get<0>() << " -> TmpE#" << data.get<1>() << "\n";
  });
  PSAN_DEBUG(loadEvent(srcCellID, dstExprID));
}

void EPTGBuilder::addStoreEdge(std::size_t srcExprID, std::size_t dstCellID, llvm::Instruction* backingInst)
{
  std::size_t id = storeEdges.size();
  storeEdges.push_back(TempStoreEdge{id, srcExprID, dstCellID, backingInst});
  exprID2storeEdgeIDs[srcExprID].push_back(id);
  static DumpEventDecl<std::size_t, std::size_t> storeEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
    os << "Store: TmpE#" << data.get<0>() << " -> TmpC#" << data.get<1>() << "\n";
  });
  PSAN_DEBUG(storeEvent(srcExprID, dstCellID));
}

bool EPTGBuilder::isCallShouldBeIgnoredForGraphBuilding(llvm::CallBase* call)
{
  // we should return true if the function call does not affect graph building.
  // to be specific, we return true if:
  // 1. the function does not produce a pointer
  // 2. the function is a function we know (it is a library function) that does not cause side effect other than possibly dereferencing the input argument pointer
  //    for example, the function does not modify the point-to object

  if (llvm::CallInst* callinst = llvm::dyn_cast<llvm::CallInst>(call)) {
    switch (callinst->getIntrinsicID())
    {
    default: break;
    case llvm::Intrinsic::memset:
    case llvm::Intrinsic::memset_inline:
    case llvm::Intrinsic::memset_element_unordered_atomic:
    case llvm::Intrinsic::memcpy:
    case llvm::Intrinsic::memcpy_inline:
    case llvm::Intrinsic::memcpy_element_unordered_atomic:
    case llvm::Intrinsic::memmove:
    case llvm::Intrinsic::memmove_element_unordered_atomic:
      // they should be handled during traversal
      return true;
    case llvm::Intrinsic::lifetime_start:
    case llvm::Intrinsic::lifetime_end:
      return true;
    }
  }

  llvm::Function* callee = call->getCalledFunction();
  // if there is no fixed callee, the caller of this function should handle the case
  if (!callee)
    return false;

  if (!callee->getBasicBlockList().empty())
    return false;

  // if the callee does not affect graph building (i.e., it is a pure user that we can trivially handle), we also return true
  // TODO list functions that we want to handle here
  // goes into some function
  bool isRecognizedToIgnore = llvm::StringSwitch<bool>(callee->getName())
    .Case("free", true)
    .Default(false);
  if (isRecognizedToIgnore)
    return true;

  return false;
}

bool EPTGBuilder::isTypeConsideredCompatibleForMerging(llvm::Type* ty1, llvm::Type* ty2)
{
  // return true if we can do memcpy/memmove between these two types without tainting the cells
  // if the types does not match but this function return true, it means we don't need to merge the cells due to memcpy/memmove
  if (ty1 == ty2)
    return true;
  if (ty1->isIntegerTy() && ty2->isIntegerTy())
    return true;
  return false;
}

void EPTGBuilder::handleMemCpyMemMove(llvm::CallBase* call, std::size_t dstCellID, std::size_t srcCellID)
{
  // this function is called before the graph initialization is done
  // we try to merge the cells pointed by the dst & src pointers of calls to memcpy/memmove
  std::size_t dstCell = getLeaderCellID(dstCellID);
  std::size_t srcCell = getLeaderCellID(srcCellID);
  if (dstCell == srcCell) {
    return;
  }
  // we need to find the most "appropriate" cell to merge
  // at this moment, both cells should be the "top-most" cell of the nesting hierarchy
  // however, say if we are copying a buffer in the beginning of a struct, we don't want to merge the entire struct with the buffer
  // so we may need to go down the hierarchy to find the smallest cell that covers the copy/move range
  // step 1: find the copy/movement size from the call arguments
  // if it is not a constant, the size of merged cell should be as large as possible
  // if it is a constant, the size of the merged cell should be the smallest that covers this constant size
  std::size_t transferSize = 0;
  // for now, both memcpy and memmove has their size operand at the same position
  llvm::Value* sizeValue = call->getArgOperand(2);
  if (llvm::ConstantInt* cint = llvm::dyn_cast<llvm::ConstantInt>(sizeValue)) {
    transferSize = cint->getZExtValue();
  }
  // step 2: find the smallest cell that covers the copy/movement range
  // umm to be conservative, if we cannot find the constant transfer size, we just merge the entire cells
  if (transferSize == 0) {
    tryMergeCells(dstCell, srcCell, false);
    return;
  }
  // we first get a list of candidate <size, cell id> for each cell
  // we then walk through the list to find the most appropriate cell
  const llvm::DataLayout& layout = clonedModule->getDataLayout();
  auto getCandidateList = [&](std::size_t toplevelCell) -> llvm::SmallVector<std::pair<llvm::TypeSize, std::size_t>> {
    llvm::SmallVector<std::pair<llvm::TypeSize, std::size_t>> result;
    ElementRef<TempCellNode> toplevelCellNode = getCellNodeAt(toplevelCell);
    auto toplevelCellSize = layout.getTypeAllocSize(toplevelCellNode->ty);
    result.push_back(std::make_pair(toplevelCellSize, toplevelCell));
    if (toplevelCellSize < transferSize) {
      return result;
    }
    llvm::Type* curType = toplevelCellNode->ty;
    std::size_t curParentCell = toplevelCell;
    while(true) {
      llvm::Type* childType = curType;
      unsigned numZeros = 0;
      if (llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(curType)) {
        llvm::Type* nextChildType = sTy->getElementType(0);
        auto maxChildSize = layout.getTypeAllocSize(nextChildType);
        if (maxChildSize >= transferSize) {
          childType = nextChildType;
          numZeros += 1;
        }
      }
      // if the child is an array, we want to go down the hierarchy one step further (i.e., merge the cell representing the array element)
      // but when we check whether the child is large enough, we still use the size of the entire array
      while (llvm::ArrayType* aTy = llvm::dyn_cast<llvm::ArrayType>(childType)) {
        childType = aTy->getElementType();
        numZeros += 1;
      }
      if (numZeros > 0) {
        // we consider the child cell as applicable
        MemberPosition::PositionType pos(numZeros, 0);
        std::size_t childCell = getOrCreateSubobjectCell(curParentCell, MemberPosition(pos));
        llvm::Type* childCellType = getCellNodeAt(childCell)->ty;
        if (childCellType != childType) {
          psan_unreachable("child cell type mismatch");
        }
        auto childSize = layout.getTypeAllocSize(childType);
        result.push_back(std::make_pair(childSize, childCell));
        if (childSize < transferSize) {
          break;
        }
        curType = childType;
        curParentCell = childCell;
      } else {
        // not a valid aggregate type
        break;
      }
    }
    return result;
  };
  auto dstCandidateList = getCandidateList(dstCell);
  auto srcCandidateList = getCandidateList(srcCell);
  if (dstCandidateList.empty() || srcCandidateList.empty()) {
    // they should at least have the toplevel cell
    psan_unreachable("empty candidate list");
  }
  std::size_t dstIndex = 0;
  std::size_t srcIndex = 0;
  while (dstIndex < dstCandidateList.size() && srcIndex < srcCandidateList.size()) {
    auto& dstCandidate = dstCandidateList[dstIndex];
    auto& srcCandidate = srcCandidateList[srcIndex];
    ElementRef<TempCellNode> dstCandidateNode = getCellNodeAt(dstCandidate.second);
    ElementRef<TempCellNode> srcCandidateNode = getCellNodeAt(srcCandidate.second);
    if (isTypeConsideredCompatibleForMerging(dstCandidateNode->ty, srcCandidateNode->ty)) {
      if (dstCandidateNode->ty == srcCandidateNode->ty) {
        tryMergeCells(dstCandidate.second, srcCandidate.second, false);
      }
      return;
    }
    // ok, the types are not compatible
    // we skip the larger type
    if (dstCandidate.first > srcCandidate.first) {
      dstIndex += 1;
    } else {
      srcIndex += 1;
    }
  }
  // if we reach here, we cannot find a compatible cell
  // just taint both cells
  getCellNodeAt(dstCell)->setTainted("memcpy/move incompatible types");
  getCellNodeAt(srcCell)->setTainted("memcpy/move incompatible types");
}

std::size_t EPTGBuilder::createFunctionInterfaceCells(llvm::FunctionType* funcTy, llvm::DenseMap<int, std::size_t>& argIndex2cellID, bool isTainted, llvm::Function* definition)
{
  std::size_t funcCellID = 0;
  {
    // after we create another cell, the reference here can be dangling
    // so we limit the scope of the reference here
    ElementRef<TempCellNode> funcCell = createCellNode(funcTy);
    funcCellID = funcCell->id;
    if (isTainted) {
      funcCell->setTainted("function cell taint requested");
    }
  }
  auto createFunctionInterfaceChild = [&](llvm::Type* ty, unsigned index) -> std::size_t {
    ElementRef<TempCellNode> cell = createCellNode(ty);
    if (isTainted) {
      cell->setTainted("function interface member cell taint requested");
    }
    cell->isArgumentCell = true;
    addContainsEdge(funcCellID, cell->id, MemberPosition::getWithSingleIndex(index));
    return cell->id;
  };
  argIndex2cellID[-1] = funcCellID;
  for (unsigned i = 0, n = funcTy->getNumParams(); i < n; ++i) {
    llvm::Type* argTy = funcTy->getParamType(i);
    if (argTy->isPointerTy()) {
      std::size_t cellID = createFunctionInterfaceChild(argTy, i);
      argIndex2cellID[i] = cellID;
      if (definition && !definition->isDeclaration()) {
        llvm::Argument* arg = definition->getArg(i);
        ElementRef<TempExpressionNode> node = getOrCreateExpressionNode(arg);
        addLoadEdge(cellID, node->id);
        functionArgExprWorklist.push_back(node->id);
      }
    }
  }
  llvm::Type* retTy = funcTy->getReturnType();
  if (retTy->isPointerTy()) {
    argIndex2cellID[funcTy->getNumParams()] = createFunctionInterfaceChild(retTy, funcTy->getNumParams());
  }
  if (funcTy->isVarArg()) {
    unsigned index = funcTy->getNumParams() + 1;
    llvm::Type* varargTy = llvm::Type::getInt8PtrTy(clonedModule->getContext());
    argIndex2cellID[index] = createFunctionInterfaceChild(varargTy, index);
  }
  return funcCellID;
}

std::size_t EPTGBuilder::getOrCreateSubobjectCell(std::size_t parent, MemberPosition pos)
{
  // now we always break the member position into single index and create all subobjects along the way
  // this simplifies the code, ensuring that each contains edge is at most one step away from the parent
  if (pos.empty()) {
    psan_unreachable("getOrCreateSubobjectCell(): empty member position");
  }
  llvm::Type* parentTy = nullptr;
  {
    ElementRef<TempCellNode> parentCell = getCellNodeAt(parent);
    parentTy = parentCell->ty;
    if (!(parentCell->leaderID == 0 || parentCell->leaderID == parent)) {
      psan_unreachable("getOrCreateSubobjectCell(): parent cell is merged");
    }
  }


  // step 1: get the subobject at one step away
  MemberPosition singleIndexPos = MemberPosition::getWithSingleIndex(pos.front());
  auto returnSubobject = [&](std::size_t singleStepChild) -> std::size_t {
    if (pos.size() == 1) {
      return singleStepChild;
    }
    return getOrCreateSubobjectCell(singleStepChild, pos.dropPrefix(singleIndexPos));
  };

  auto iter = cellID2subobjectCellIDs.find(parent);
  if (iter != cellID2subobjectCellIDs.end()) {
    // check if there is already the object
    auto iter2 = iter->second.find(pos.front());
    if (iter2 != iter->second.end()) {
      std::size_t child = getLeaderCellID(iter2->second);
      return returnSubobject(child);
    }
  }

  // ok, no such subobject exist yet; create one
  llvm::Type* subTy = MemberPosition::getTypeAtPos(parentTy, singleIndexPos);
  ElementRef<TempCellNode> subCell = createCellNode(subTy);
  // move all the affected contains edges from the parent to the subobject
  static DumpEventDecl<std::size_t, std::size_t, int64_t> subobjectEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t, int64_t>& data) {
    os << "New subobject for TmpC#" << data.get<0>() << " at [" << data.get<2>() << "]: TmpC#" << data.get<1>() << "\n";
  });
  PSAN_DEBUG(subobjectEvent(parent, subCell->id, singleIndexPos.front()));
  addContainsEdge(parent, subCell->id, singleIndexPos);
  return returnSubobject(subCell->id);
}

EPTG* EPTGBuilder::build(){
  // here we build the EPTG with:
  // (1) all cell node merging completed
  // (2) value flow edges in SVFG incorporated into the EPTG so that we don't need to use the SVFG afterwards
  // (3) all llvm::Value* references corresponds to the source IR instead of the cloned one
  // we do this by:
  // (1) use temporary data to hold the graph representation and do the merging
  // (2) translate the temporary data to the final EPTG

  // insert the invalid node 0
  cells.push_back(TempCellNode(0));

  // now start the algorithm
  buildInitialGraph();
  stats.setTime(stats.s3_initialConstructionTime);
  runGraphTransforms();
  SVF::FIFOWorkList<std::size_t> cellWorklist;
  addCellPointsTo(cellWorklist);
  propagateCellPointsTo(cellWorklist);
  runTaintAnalysis();
  return buildFinalGraph();
}

void EPTGBuilder::buildInitialGraph()
{
  // walk through all functions and global variables, and build alloc nodes
  // first, walk through all functions and build interface objects
  for (llvm::Function& F : *clonedModule) {
    // first, check if it is a placeholder function
    if (step2_pruning_isPlaceholderFunction(&F)) {
      continue;
    }
    // otherwise, we create a cell node for the function, and each pointer-type argument and return value
    // if the function is a declaration, we just taint all the cells
    // all the members has a single member index
    // say the function has N arguments, then argument 0 to N-1 has index 0 to N-1
    // the return value has index N
    // if the function is variadic, then the vararg argument has index N+1
    bool isTainted = F.isDeclaration() || taintedClones.find(&F) != taintedClones.end();
    llvm::FunctionType* funcTy = F.getFunctionType();
    llvm::DenseMap<int, std::size_t> argIndex2cellID;
    std::size_t funcCellID = createFunctionInterfaceCells(funcTy, argIndex2cellID, isTainted, &F);
    functionDefintionCells.insert(std::make_pair(&F, std::move(argIndex2cellID)));
    // create the alloc and expr node
    ElementRef<TempAllocNode> allocNode = createAllocNode(&F);
    allocNode->allocToCellID = funcCellID;
    ElementRef<TempExpressionNode> node = getOrCreateExpressionNode(&F);
    node->setPointsToCell(funcCellID);
    traverseSVFGFromAllocation(node->id, &F);
  }
  // now walk through all global variables
  for (llvm::GlobalVariable& G : clonedModule->globals()) {
    if (G.getName().startswith("llvm.")) {
      // llvm intrinsic globals should not affect our analysis
      continue;
    }
    llvm::Type* ty = G.getValueType();
    ElementRef<TempCellNode> cell = createCellNode(ty);
    ElementRef<TempAllocNode> allocNode = createAllocNode(&G);
    allocNode->allocToCellID = cell->id;
    ElementRef<TempExpressionNode> node = getOrCreateExpressionNode(&G);
    node->setPointsToCell(cell->id);
    auto iterInsert = exprNodeID2allocNodeID.insert(std::make_pair(node->id, allocNode->id));
    if (!iterInsert.second) {
      psan_unreachable("expression node already associated with an alloc node?");
    }
    if (!G.hasInitializer()) {
      // taint all the nodes
      cell->setTainted("extern gv");
      node->setTainted("extern gv");
      allocNode->setTainted("extern gv");
    }
    traverseSVFGFromAllocation(node->id, &G);
  }

  // now walk through all instructions and build alloc nodes for local variables and dynamic allocations
  for (llvm::Function& F : *clonedModule) {
    for (llvm::BasicBlock& B : F) {
      for (llvm::Instruction& I : B) {
        if (llvm::AllocaInst* allocaInst = llvm::dyn_cast<llvm::AllocaInst>(&I)) {
          llvm::Type* ty = allocaInst->getAllocatedType();
          ElementRef<TempCellNode> cell = createCellNode(ty);
          ElementRef<TempAllocNode> allocNode = createAllocNode(allocaInst);
          allocNode->allocToCellID = cell->id;
          ElementRef<TempExpressionNode> node = getOrCreateExpressionNode(allocaInst);
          node->setPointsToCell(cell->id);
          auto iterInsert = exprNodeID2allocNodeID.insert(std::make_pair(node->id, allocNode->id));
          if (!iterInsert.second) {
            psan_unreachable("expression node already associated with an alloc node?");
          }
          traverseSVFGFromAllocation(node->id, allocaInst);
        }
        else if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(&I)) {
          if (!isCallShouldBeIgnoredForGraphBuilding(call)) {
            // we want to find if this is a dynamic allocator call
            // we may see indirect function calls; use the SVFG to find the possible callee
            // if this is not an allocator call, we still need to do the following things:
            // 1. if the call passes pointers, we create stores of the pointer value into the abstract object
            // 2. if the call returns a pointer, we create loads of the pointer from the abstract object
            llvm::Value* calleeValue = call->getCalledOperand();
            assert(calleeValue);
            bool isAllocatorCallFlag = false;
            llvm::Function* allocatorForAttr = nullptr;
            llvm::DenseSet<llvm::Function*> callees;
            auto connectCallParamRetEdges = [this](llvm::CallBase* call, llvm::DenseMap<int, std::size_t>& argIndex2cellID, unsigned numParams) {
              // parameters first
              unsigned numArgs = std::min(call->arg_size(), numParams);
              for (unsigned i = 0, n = numArgs; i < n; ++i) {
                auto iterArg = argIndex2cellID.find(i);
                if (iterArg == argIndex2cellID.end())
                  continue;
                llvm::Value* argValue = call->getArgOperand(i);
                ElementRef<TempExpressionNode> node = getOrCreateExpressionNode(argValue);
                addStoreEdge(node->id, iterArg->second, call);
              }
              // then the return value
              if (call->getType()->isPointerTy()) {
                auto iterRet = argIndex2cellID.find(numParams);
                if (iterRet != argIndex2cellID.end()) {
                  ElementRef<TempExpressionNode> node = getOrCreateExpressionNode(call);
                  addLoadEdge(iterRet->second, node->id);
                }
              }
            };
            if (llvm::Function* calledFunction = llvm::dyn_cast<llvm::Function>(calleeValue)) {
              if (isAllocatorCall(call)) {
                // if this is an allocator call, we don't care about other cases
                isAllocatorCallFlag = true;
                allocatorForAttr = calledFunction;
              } else {
                if (step2_pruning_isPlaceholderFunction(calledFunction)) {
                  // if this is a placeholder call, we check whether it is a pointer-type return value
                  // if yes, we create a load from the placeholder cell
                  // otherwise we just ignore it
                  // UPDATE: to make sure the downstream users of the placeholder values are not lost,
                  // the placeholder call should be treated as an allocation
                  llvm::Type* retTy = calledFunction->getReturnType();
                  if (retTy->isPointerTy()) {
                    std::size_t cellID = getPlaceholderCell(calledFunction);
                    ElementRef<TempExpressionNode> node = getOrCreateExpressionNode(call);
                    addLoadEdge(cellID, node->id);
                    std::size_t pointsToCell = getCellNodeAt(cellID)->pointsToCellID;
                    if (pointsToCell == 0) {
                      psan_unreachable("pointer-type placeholder cell should have points-to cell");
                    }
                    node->setPointsToCell(pointsToCell);
                    traverseSVFGFromAllocation(node->id, call);
                  }
                  continue;
                }
                // this is not a placeholder call
                callees.insert(calledFunction);
              }
            } else if (llvm::InlineAsm* asmCallee = llvm::dyn_cast<llvm::InlineAsm>(calleeValue)) {
              // assembly code is treated as blackbox
              auto iter = asmCells.find(asmCallee);
              if (iter == asmCells.end()) {
                llvm::DenseMap<int, std::size_t> argIndex2cellID;
                std::size_t cellID = createFunctionInterfaceCells(asmCallee->getFunctionType(), argIndex2cellID, true);
                (void) cellID;
                auto p = asmCells.insert(std::make_pair(asmCallee, std::move(argIndex2cellID)));
                iter = p.first;
              }
              connectCallParamRetEdges(call, iter->second, asmCallee->getFunctionType()->getNumParams());
            } else {
              // this is an indirect call
              llvm::PointerType* ptrTy = llvm::cast<llvm::PointerType>(calleeValue->getType());
              if (!getPointerElementType(ptrTy)->isFunctionTy()) {
                psan_unreachable("indirect call with non-function pointer");
              }
              // use SVF to find possible callees
              // if any of them is an allocator, consider this call as an allocation
              // (we will merge abstract objects within a single point-to set later on,
              // so it is okay to create extra objects)
              SVF::CallICFGNode* callNode = pta->getICFG()->getCallICFGNode(getSVFInstruction(call));
              // we can have indirect call sites without indirect call target when the parent function is never getting called
              // e.g., when all call sites to the parent function has inlined the current function containing the indirect call sites
              if (pta->getPTACallGraph()->hasIndCSCallees(callNode)) {
                const auto& callDestinations = pta->getPTACallGraph()->getIndCSCallees(callNode);
                for (const SVF::SVFFunction* callee : callDestinations) {
                  llvm::Function* func = getLLVMFunction(const_cast<SVF::SVFFunction*>(callee));
                  if (isAllocatorCallee(func)) {
                    isAllocatorCallFlag = true;
                    allocatorForAttr = func;
                  } else {
                    callees.insert(func);
                  }
                }
              } else {
                // no possible candidates
                // just do nothing here
              }
            }
            assert((allocatorForAttr != nullptr) == isAllocatorCallFlag);
            if (isAllocatorCallFlag && call->getType()->isPointerTy()) {
              ElementRef<TempAllocNode> alloc = createAllocNode(call);

              // if we can find a bitcast as the only user from this call, we directly create concrete object for the bitcasted type
              // if there are other users but (1) the current point-to type is i8, (2) there is only one bitcast user, we also set the root ptr
              // (we may have memset, etc using the i8* before cast)
              llvm::Value* rootPtrToUse = call;
              if (call->hasOneUse()) {
                llvm::User* u = call->use_begin()->getUser();
                if (llvm::BitCastInst* cast = llvm::dyn_cast<llvm::BitCastInst>(u)) {
                  assert (cast->getOperand(0) == call);
                  rootPtrToUse = cast;
                }
              } else if (getPointerElementType(call->getType())->isIntegerTy(8)) {
                llvm::BitCastInst* firstBC = nullptr;
                for (const auto& u : call->uses()) {
                  llvm::User* user = u.getUser();
                  if (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(user)) {
                    if (firstBC) {
                      // we got more than one casts
                      firstBC = nullptr;
                      break;
                    } else {
                      firstBC = bc;
                    }
                  }
                }
                if (firstBC) {
                  rootPtrToUse = firstBC;
                }
              }
              ElementRef<TempCellNode> cell = createCellNode(getPointerElementType(rootPtrToUse->getType()));
              alloc->allocToCellID = cell->id;
              ElementRef<TempExpressionNode> expr = getOrCreateExpressionNode(rootPtrToUse);
              expr->setPointsToCell(cell->id);
              // if the root pointer is not the call itself, here we register the call to map to this concrete pointer as well
              if (rootPtrToUse != call) {
                value2allocNodeID[rootPtrToUse] = alloc->id;
                value2expressionNodeID[call] = expr->id;
              }
              auto iterInsert = exprNodeID2allocNodeID.insert(std::make_pair(expr->id, alloc->id));
              if (!iterInsert.second) {
                psan_unreachable("expression node already associated with an alloc node?");
              }
              traverseSVFGFromAllocation(expr->id, rootPtrToUse);
            } else if (!isAllocatorCallFlag) {
              // add load/store edges to function parameters and return values
              for (llvm::Function* callee : callees) {
                auto iter = functionDefintionCells.find(callee);
                assert(iter != functionDefintionCells.end());
                auto& argIndex2cellID = iter->second;
                connectCallParamRetEdges(call, argIndex2cellID, callee->getFunctionType()->getNumParams());
              }
            }
          } else {
            // if this is a memset/memcpy/memmove, we collect the size operand for later updates
            tryFindSizeOperandsForMemoryOps(call);
          }
        }
        else if (llvm::ReturnInst* ret = llvm::dyn_cast<llvm::ReturnInst>(&I)) {
          llvm::Value* retVal = ret->getReturnValue();
          if (retVal && retVal->getType()->isPointerTy()) {
            llvm::Function* func = ret->getFunction();
            auto iter = functionDefintionCells.find(func);
            assert(iter != functionDefintionCells.end());
            auto& argIndex2cellID = iter->second;
            auto iterRet = argIndex2cellID.find(func->getFunctionType()->getNumParams());
            assert(iterRet != argIndex2cellID.end());
            ElementRef<TempExpressionNode> node = getOrCreateExpressionNode(retVal);
            addStoreEdge(node->id, iterRet->second, ret);
            static DumpEventDecl<std::size_t, std::size_t, llvm::Value*> returnEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t, llvm::Value*>& data) {
              os << "Return: TmpE#" << data.get<0>() << " -> TmpC#" << data.get<1>() << ": " << data.get<2>() << "\n";
            });
            PSAN_DEBUG(returnEvent(node->id, iterRet->second, retVal));
            /*
            SVF::NodeID storeNodeID = 0;
            if (const SVF::SVFGNode* node = getSVFGDefNode(retVal)) {
              // check if there is an outgoing edge to a FormalRetSVFGNode or ActualRetPHI
              // if there is, that's the node id
              // we may have an IntraPHISVFGNode in the middle
              auto isReturnNode = [](SVF::SVFGNode* dest) -> bool {
                if (SVF::FormalRetSVFGNode* retNode = SVFUtil::dyn_cast<SVF::FormalRetSVFGNode>(dest)) {
                  (void) retNode;
                  return true;
                }
                if (SVF::InterPHISVFGNode* aret = SVFUtil::dyn_cast<SVF::InterPHISVFGNode>(dest)) {
                  if (aret->isActualRetPHI()) {
                    return true;
                  }
                }
                return false;
              };
              for (auto iter = node->OutEdgeBegin(), iterEnd = node->OutEdgeEnd(); iter != iterEnd; ++iter) {
                auto* edge = *iter;
                SVF::SVFGNode* dest = edge->getDstNode();
                if (isReturnNode(dest)) {
                  storeNodeID = dest->getId();
                  break;
                }
                if (SVF::IntraPHISVFGNode* phi = SVFUtil::dyn_cast<SVF::IntraPHISVFGNode>(dest)) {
                  if (phi->getInEdges().size() == 1) {
                    // this phi should only pick up our value
                    for (auto iter = phi->OutEdgeBegin(), iterEnd = phi->OutEdgeEnd(); iter != iterEnd; ++iter) {
                      auto* edge = *iter;
                      SVF::SVFGNode* dest = edge->getDstNode();
                      if (isReturnNode(dest)) {
                        storeNodeID = dest->getId();
                        break;
                      }
                    }
                    if (storeNodeID > 0) {
                      break;
                    }
                  }
                }
              }
            }
            */
            //ptr->addStoreDestination(ptrObj->getBinding(), *this, storeNodeID, ret);
          }
        }
        else if (llvm::ICmpInst* icmp = llvm::dyn_cast<llvm::ICmpInst>(&I)) {
          // if this icmp is comparing two pointers and it is not comparing one value with null, we put it in ptrIcmps
          // later on, we will ensure that the two pointers share the points-to cell
          // to speed things up, we also do not add icmps whose pointer operand does not point to types containing pointers (so no type change possible)
          llvm::Value* lhs = icmp->getOperand(0);
          llvm::Value* rhs = icmp->getOperand(1);
          llvm::PointerType* lhsTy = llvm::dyn_cast<llvm::PointerType>(lhs->getType());
          if (lhsTy && rhs->getType()->isPointerTy() && !llvm::isa<llvm::ConstantPointerNull>(lhs) && !llvm::isa<llvm::ConstantPointerNull>(rhs)) {
            // because lhs and rhs should have the same type, we only need to check one of them
            if (isTypeContainPointer(getPointerElementType(lhsTy))) {
              ptrIcmps.push_back(icmp);
            }
          }
        }
      }
    }
  }

  // now all the code has been walked through
  // if there are any unhandled memcpy/memmove left, we handle them here
  for (auto iter = pendingMergeMemIntrinsicsArgs.begin(), iterEnd = pendingMergeMemIntrinsicsArgs.end(); iter != iterEnd; ++iter) {
    std::size_t cellID1 = iter->second.first;
    std::size_t cellID2 = iter->second.second;
    if (cellID1 != 0 && cellID2 != 0) {
      // this should already be handled, so skip it
      continue;
    }
    // at least one of the two operands should be tainted, so we will taint the other
    if (cellID1 != 0) {
      std::size_t leader = getLeaderCellID(cellID1);
      getCellNodeAt(leader)->setTainted("leftover memcpy/move");
    }
    if (cellID2 != 0) {
      std::size_t leader = getLeaderCellID(cellID2);
      getCellNodeAt(leader)->setTainted("leftover memcpy/move");
    }
  }
  pendingMergeMemIntrinsicsArgs.clear();

  // if there are pointer arguments that does not have pointer arguments, we create dummy points-to cells for them
  // they are probably some leftover dead code being inlined and it is perfectly fine to transform their types
  for (std::size_t argExprNodeID : functionArgExprWorklist) {
    ElementRef<TempExpressionNode> node = getExpressionNodeAt(argExprNodeID);
    if (node->pointsToCellID == 0) {
      // create the points-to cell and start traversal
      static DumpEventDecl<std::size_t> dummyArgCellEvent([](llvm::raw_ostream& os, const EventData<std::size_t>& data) {
        os << "Creating dummy points-to cell: TmpE#" << data.get<0>() << "\n";
      });
      PSAN_DEBUG(dummyArgCellEvent(node->id));
      llvm::Argument* arg = llvm::cast<llvm::Argument>(node->value);
      llvm::Type* cellType = getPointerElementType(arg->getType());
      ElementRef<TempCellNode> cell = createCellNode(cellType);
      node->setPointsToCell(cell->id);
      if (node->isTaintedForTypePinning) {
        cell->setTainted("dummy points-to");
      }
      traverseSVFGFromAllocation(node->id, arg);
    }
  }
  functionArgExprWorklist.clear();

  // handle load expr nodes with dummy cells
  for (auto& p : loadExprNodesWithDummyCells) {
    std::size_t exprID = p.first;
    bool isVisitedFromValueSide = p.second.first;
    bool isVisitedFromAddressSide = p.second.second;
    if (!isVisitedFromValueSide && !isVisitedFromAddressSide) {
      psan_unreachable("load expression node not visited from both sides");
    }
    if (isVisitedFromValueSide && isVisitedFromAddressSide) {
      // we don't need to do anything here
      continue;
    }
    // make this before the assertions for better debugging
    ElementRef<TempExpressionNode> node = getExpressionNodeAt(exprID);
    // so we are only dealing with loads visited from the address side
    if (node->pointsToCellID == 0) {
      if (node->isTaintedForTypePinning) {
        // maybe it is a load from vaarg
        continue;
      }
      psan_unreachable("load expression node without points-to cell");
    }
    // if we did not visit this node from the address side,
    // we probably decided that some pointers upstream are tainted and there is no point to continue
    // so we only look for exclusion case if we visited from the address side
    if (isVisitedFromAddressSide) {
      // now check for exclusion
      if (llvm::LoadInst* load = llvm::dyn_cast<llvm::LoadInst>(node->value)) {
        if (nullReachableLoads.count(load)) {
          // this node is reachable from a null pointer; we can still transform the points-to cell type
          static DumpEventDecl<std::size_t, std::size_t> nullReachableEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
            os << "Load reachable from null store: TmpE#" << data.get<0>() << " -> TmpC#" << data.get<1>() << "\n";
          });
          PSAN_DEBUG(nullReachableEvent(node->id, node->pointsToCellID));
          continue;
        }
      }
    }

    static DumpEventDecl<std::size_t, std::size_t> taintLoadDummyEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
      os << "Tainting load dummy cell: TmpE#" << data.get<0>() << " -> TmpC#" << data.get<1>() << "\n";
    });
    PSAN_DEBUG(taintLoadDummyEvent(node->id, node->pointsToCellID));
    std::size_t leaderPointsTo = getLeaderCellID(node->pointsToCellID);
    ElementRef<TempCellNode> cell = getCellNodeAt(leaderPointsTo);
    cell->setTainted("load expr dummy node");
    taintedLoadDummyExprNodes.push_back(node->id);
  }
  loadExprNodesWithDummyCells.clear();

  for (llvm::ICmpInst* icmp : ptrIcmps) {
    llvm::Value* lhs = icmp->getOperand(0);
    llvm::Value* rhs = icmp->getOperand(1);
    // retrieve the points-to cell ID for the two operands immediately after getting the expression node reference
    // (otherwise me may have dangling references)
    ElementRef<TempExpressionNode> lhsNode = getOrCreateExpressionNode(lhs);
    std::size_t lhsCellID = lhsNode->pointsToCellID;
    ElementRef<TempExpressionNode> rhsNode = getOrCreateExpressionNode(rhs);
    std::size_t rhsCellID = rhsNode->pointsToCellID;
    if (lhsCellID == 0 || rhsCellID == 0 || lhsCellID == rhsCellID) {
      continue;
    }
    tryMergeCells(lhsCellID, rhsCellID, false);
  }
  ptrIcmps.clear();

  // taint special functions
  // for now, just main()
  if (llvm::Function* mainFunc = clonedModule->getFunction("main")) {
    auto iter = functionDefintionCells.find(mainFunc);
    if (iter != functionDefintionCells.end()) {
      auto& argIndex2cellID = iter->second;
      auto iterFunc = argIndex2cellID.find(-1);
      assert(iterFunc != argIndex2cellID.end());
      getCellNodeAt(iterFunc->second)->setTainted("tainting main function cells");
    }
  }
}

std::size_t EPTGBuilder::getLeaderCellID(std::size_t cellID)
{
  ElementRef<TempCellNode> cell = getCellNodeAt(cellID);
  while (cell->leaderID != 0 && cell->leaderID != cell->id) {
    cell = getCellNodeAt(cell->leaderID);
  }
  return cell->id;
}

std::size_t EPTGBuilder::getPlaceholderCell(llvm::Function* placeholder)
{
  auto iter = placeholderCallRetCells.find(placeholder);
  if (iter != placeholderCallRetCells.end()) {
    return iter->second;
  }
  assert (step2_pruning_isPlaceholderFunction(placeholder));
  llvm::Type* retTy = placeholder->getReturnType();
  ElementRef<TempCellNode> cell = createCellNode(retTy);
  cell->setTainted("placeholder");
  placeholderCallRetCells.insert(std::make_pair(placeholder, cell->id));
  // make a copy here, since the cell reference may be invalidated after creating a new cell
  std::size_t curCellIndex = cell->id;
  if (llvm::PointerType* ptrTy = llvm::dyn_cast<llvm::PointerType>(retTy)) {
    // if we have a pointer-type placeholder, we also create the dummy points-to object here and taint it
    llvm::Type* pointsToTy = getPointerElementType(ptrTy);
    ElementRef<TempCellNode> pointsToCell = createCellNode(pointsToTy);
    pointsToCell->setTainted("placeholder points-to");
    getCellNodeAt(curCellIndex)->setPointsToCell(pointsToCell->id);
  }
  return curCellIndex;
}

EPTG* EPTGBuilder::buildFinalGraph()
{
  // step 1: create all EPTG nodes
  llvm::DenseMap<std::size_t, AllocEPTGNode*> allocNodeMap; // temp alloc node ID -> EPTG node
  llvm::DenseMap<std::size_t, CellEPTGNode*> cellNodeMap; // temp cell node ID -> EPTG node
  llvm::DenseMap<std::size_t, ExpressionEPTGNode*> exprNodeMap; // temp expr node ID -> EPTG node
  auto getCellNode = [&](std::size_t cellID) -> CellEPTGNode* {
    // here we directly map to the leader cell node
    std::size_t realCellID = getLeaderCellID(cellID);
    auto iter = cellNodeMap.find(realCellID);
    assert(iter != cellNodeMap.end());
    return iter->second;
  };
  auto getExpressionNode = [&](std::size_t exprID) -> ExpressionEPTGNode* {
    // we may not have entry for tainted expression nodes using placeholder values
    auto iter = exprNodeMap.find(exprID);
    if (iter != exprNodeMap.end())
      return iter->second;
    return nullptr;
  };
  std::function<llvm::Value*(llvm::Value*)> getSrcValue = [&](llvm::Value* v) -> llvm::Value* {
    // check if the value is from the cloned module
    llvm::Module* parentModule = nullptr;
    if (llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(v)) {
      parentModule = instr->getFunction()->getParent();
    } else if (llvm::GlobalVariable* gv = llvm::dyn_cast<llvm::GlobalVariable>(v)) {
      parentModule = gv->getParent();
    } else if (llvm::Function* func = llvm::dyn_cast<llvm::Function>(v)) {
      parentModule = func->getParent();
    } else if (llvm::Argument* arg = llvm::dyn_cast<llvm::Argument>(v)) {
      parentModule = arg->getParent()->getParent();
    }
    if (parentModule && parentModule != clonedModule) {
      psan_unreachable("We only accept values from cloned module");
    }
    if (step2_pruning_isPlaceholderCall(v)) {
      // these placeholder calls are just for debugging; the related node must be tainted
      return nullptr;
    }
    auto iter = cloned2src.find(v);
    if (iter != cloned2src.end()) {
      return iter->second;
    }
    // we may have tainted arguments not in cloned2src but is in taintedClones
    // we still want to return the original value here
    if (llvm::Argument* arg = llvm::dyn_cast<llvm::Argument>(v)) {
      llvm::Function* parentFunc = arg->getParent();
      auto iter = cloned2src.find(parentFunc);
      if (iter != cloned2src.end()) {
        llvm::Function* srcFunc = llvm::cast<llvm::Function>(iter->second);
        if (srcFunc->getName() != parentFunc->getName()) {
          psan_unreachable("Function name mismatch");
        }
        return srcFunc->getArg(arg->getArgNo());
      }
    }
    // if the value is tainted and still in the cloned module, we should have it in taintedClones
    {
      auto iterTainted = taintedClones.find(v);
      if (iterTainted != taintedClones.end()) {
        return iterTainted->second;
      }
    }
    // check if the value is a constexpr that is not registered during cloning
    if (llvm::ConstantExpr* cexpr = llvm::dyn_cast<llvm::ConstantExpr>(v)) {
      // we handle bitcast and getelementptr here
      switch (cexpr->getOpcode()) {
      default: psan_unreachable("Unsupported constant expression");
      case llvm::Instruction::BitCast:
      case llvm::Instruction::GetElementPtr: {
        // we only need to update the first operand
        llvm::SmallVector<llvm::Constant*> operands;
        for (llvm::Value* op : cexpr->operands()) {
          llvm::Constant* constoperand = llvm::cast<llvm::Constant>(op);
          if (operands.empty()) {
            // this is the first
            llvm::Value* srcOp = getSrcValue(constoperand);
            llvm::Constant* casted = llvm::cast<llvm::Constant>(srcOp);
            operands.push_back(casted);
          } else {
            operands.push_back(constoperand);
          }
        }
        llvm::Constant* newCexpr = cexpr->getWithOperands(operands);
        return newCexpr;
      } break;
      }
    }
    if (llvm::isa<llvm::UndefValue>(v) || llvm::isa<llvm::ConstantPointerNull>(v)) {
      return v;
    }
    psan_unreachable("Cannot find the original value in source IR");
  };
  // TODO do not add tainted node to the final graph
  EPTG* graph = new EPTG(srcModule);
  SVF::NodeID currentNodeID = 1; // 0 reserved for the invalid node
  // first, create all cell nodes
  llvm::SmallVector<std::pair<std::size_t, std::size_t>> cellPointsToEdges;
  for (std::size_t i = 1, n = cells.size(); i < n; ++i) {
    ElementRef<TempCellNode> tempNode = getCellNodeAt(i);
    // skip merged cell nodes
    if (tempNode->leaderID != 0 && tempNode->leaderID != tempNode->id)
      continue;
    SVF::NodeID eptgID = currentNodeID++;
    CellEPTGNode* node = new CellEPTGNode(eptgID, tempNode->ty);
    node->setDebugIndex(i);
    stats.S3_CellNodeCount.increment(tempNode->isTaintedForTypePinning);
    if (tempNode->isTaintedForTypePinning) {
      node->setIsTainted(true);
    }
    if (tempNode->isArgumentCell) {
      node->setFlag(CellEPTGNode::FLAG_ARGCELL);
    }
    cellNodeMap.insert(std::make_pair(tempNode->id, node));
    graph->addEPTGNode(node);
    static DumpEventDecl<std::size_t, std::size_t, bool, bool> cellEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t, bool, bool>& data) {
      os << "CellNode C#" << data.get<0>() << ": TmpC#" << data.get<1>();
      if (data.get<2>()) {
        os << " [Tainted]";
      }
      if (data.get<3>()) {
        os << " [Arg]";
      }
      os << "\n";
    });
    PSAN_DEBUG(cellEvent(eptgID, i, tempNode->isTaintedForTypePinning, tempNode->isArgumentCell));
    if (tempNode->pointsToCellID != 0) {
      cellPointsToEdges.push_back(std::make_pair(tempNode->id, getLeaderCellID(tempNode->pointsToCellID)));
    }
  }
  // also add the points-to edges between cell nodes
  for (const auto& p : cellPointsToEdges) {
    CellEPTGNode* srcNode = getCellNode(p.first);
    CellEPTGNode* dstNode = getCellNode(p.second);
    PointsToEPTGEdge* edge = new PointsToEPTGEdge(srcNode, dstNode);
    graph->addEPTGEdge(edge);
  }
  // then the alloc nodes and expression nodes
  for (std::size_t i = 0, n = allocNodes.size(); i < n; ++i) {
    ElementRef<TempAllocNode> tempNode = getAllocNodeAt(i);
    SVF::NodeID eptgID = currentNodeID++;
    llvm::Value* allocValue = getSrcValue(tempNode->value);
    AllocEPTGNode* node = new AllocEPTGNode(eptgID, allocValue);
    node->setDebugIndex(i);
    if (tempNode->isTaintedForTypePinning) {
      node->setIsTainted(true);
    }
    allocNodeMap.insert(std::make_pair(tempNode->id, node));
    graph->addEPTGNode(node);
    // we directly add the alloc edges here, since all the cell nodes are already created
    CellEPTGNode* cellNode = getCellNode(tempNode->allocToCellID);
    AllocEPTGEdge* edge = new AllocEPTGEdge(node, cellNode);
    graph->addEPTGEdge(edge);
  }
  for (std::size_t i = 0, n = expressionNodes.size(); i < n; ++i) {
    ElementRef<TempExpressionNode> tempNode = getExpressionNodeAt(i);
    static DumpEventDecl<std::size_t, const char*> exprDroppedEvent([](llvm::raw_ostream& os, const EventData<std::size_t, const char*>& data) {
      os << "TmpE#" << data.get<0>() << " dropped: " << data.get<1>() << "\n";
    });
    if (tempNode->isMarkedForRemoval) {
      PSAN_DEBUG(exprDroppedEvent(tempNode->id, "marked for removal"));
      continue;
    }
    llvm::Value* exprValue = getSrcValue(tempNode->value);
    // skip nodes without source value (they are probably using placeholders)
    if (!exprValue) {
      PSAN_DEBUG(exprDroppedEvent(tempNode->id, "no source value"));
      continue;
    }
    SVF::NodeID eptgID = currentNodeID++;
    ExpressionEPTGNode* node = new ExpressionEPTGNode(eptgID, exprValue, tempNode->svfgNode);
    static DumpEventDecl<std::size_t, std::size_t, llvm::Value*> exprEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t, llvm::Value*>& data) {
      os << "ExprNode E#" << data.get<0>() << ": TmpE#" << data.get<1>() << ": " << data.get<2>() << "\n";
    });
    PSAN_DEBUG(exprEvent(eptgID, i, exprValue));
    node->setDebugIndex(i);
    if (tempNode->isTaintedForTypePinning) {
      node->setIsTainted(true);
    }
    if (llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(exprValue)) {
      annotateInstr(instr, "psan_eptg_expr", eptgID);
    }
    exprNodeMap.insert(std::make_pair(tempNode->id, node));
    graph->addEPTGNode(node);
    // we directly add points-to edges here, since all the cell nodes are already created
    if (tempNode->pointsToCellID != 0) {
      CellEPTGNode* cellNode = getCellNode(tempNode->pointsToCellID);
      PointsToEPTGEdge* edge = new PointsToEPTGEdge(node, cellNode);
      graph->addEPTGEdge(edge);
    }
  }
  // step 2: create all EPTG edges
  // since we already created alloc edges, we only need to create the other edges by walking through their temporary edge lists
  // we may have duplicated store and copy edges and we need to skip them
  for (auto& p : cellID2subobjectCellIDs) {
    std::size_t fromCellID = getLeaderCellID(p.first);
    CellEPTGNode* fromNode = getCellNode(fromCellID);
    for (auto& p2 : p.second) {
      std::size_t toCellID = getLeaderCellID(p2.second);
      CellEPTGNode* toNode = getCellNode(toCellID);
      ContainsEPTGEdge* edge = new ContainsEPTGEdge(fromNode, toNode);
      edge->setMemberPosition(p2.first);
      graph->addEPTGEdge(edge);
    }
  }
  llvm::DenseMap<CellEPTGNode*, llvm::DenseSet<ExpressionEPTGNode*>> loadEdgeUniquingMap;
  for (const auto& edge : loadEdges) {
    CellEPTGNode* srcNode = getCellNode(edge.srcID);
    ExpressionEPTGNode* dstNode = getExpressionNode(edge.dstID);
    if (!dstNode) {
      // probably a tainted expression node
      static DumpEventDecl<std::size_t, std::size_t> loadDroppedEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
        os << "load edge dropped: TmpC#" << data.get<0>() << " -> TmpE#" << data.get<1>() << "\n";
      });
      PSAN_DEBUG(loadDroppedEvent(edge.srcID, edge.dstID));
      continue;
    }
    auto& map = loadEdgeUniquingMap[srcNode];
    if (map.find(dstNode) != map.end()) {
      static DumpEventDecl<std::size_t, std::size_t> loadDroppedEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
        os << "Skipping duplicated load edge: #" << data.get<0>() << " -> #" << data.get<1>() << "\n";
      });
      PSAN_DEBUG(loadDroppedEvent(srcNode->getId(), dstNode->getId()));
      continue;
    }
    map.insert(dstNode);
    LoadEPTGEdge* eptgEdge = new LoadEPTGEdge(srcNode, dstNode);
    graph->addEPTGEdge(eptgEdge);
    static DumpEventDecl<std::size_t, std::size_t, std::size_t, std::size_t> loadEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t, std::size_t, std::size_t>& data) {
      os << "Load: C#" << data.get<0>() << " -> E#" << data.get<1>() << " <== TmpC#" << data.get<2>() << " -> TmpE#" << data.get<3>() << "\n";
    });
    PSAN_DEBUG(loadEvent(srcNode->getId(), dstNode->getId(), edge.srcID, edge.dstID));
  }
  llvm::DenseMap<CellEPTGNode*, llvm::DenseSet<ExpressionEPTGNode*>> storeEdgeUniquingMap;
  for (const auto& edge : storeEdges) {
    ExpressionEPTGNode* srcNode = getExpressionNode(edge.srcID);
    if (!srcNode) {
      // probably a tainted expression node
      continue;
    }
    CellEPTGNode* dstNode = getCellNode(edge.dstID);
    auto& map = storeEdgeUniquingMap[dstNode];
    if (map.find(srcNode) != map.end()) {
      static DumpEventDecl<std::size_t, std::size_t> storeDroppedEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
        os << "Skipping duplicated store edge: #" << data.get<0>() << " -> #" << data.get<1>() << "\n";
      });
      PSAN_DEBUG(storeDroppedEvent(srcNode->getId(), dstNode->getId()));
      continue;
    }
    map.insert(srcNode);
    StoreEPTGEdge* eptgEdge = new StoreEPTGEdge(srcNode, dstNode);
    eptgEdge->setBackingInst(edge.backingInst);
    graph->addEPTGEdge(eptgEdge);
  }
  llvm::DenseMap<ExpressionEPTGNode*, llvm::DenseSet<ExpressionEPTGNode*>> copyEdgeUniquingMap;
  for (const auto& edge : copyEdges) {
    ExpressionEPTGNode* srcNode = getExpressionNode(edge.srcID);
    ExpressionEPTGNode* dstNode = getExpressionNode(edge.dstID);
    if (!srcNode || !dstNode) {
      continue;
    }
    auto& map = copyEdgeUniquingMap[srcNode];
    if (map.find(dstNode) != map.end()) {
      static DumpEventDecl<std::size_t, std::size_t> copyDroppedEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
        os << "Skipping duplicated copy edge: #" << data.get<0>() << " -> #" << data.get<1>() << "\n";
      });
      PSAN_DEBUG(copyDroppedEvent(srcNode->getId(), dstNode->getId()));
      continue;
    }
    map.insert(dstNode);
    CopyEPTGEdge* eptgEdge = new CopyEPTGEdge(srcNode, dstNode);
    graph->addEPTGEdge(eptgEdge);
  }
  return graph;
}

namespace {

struct SVFGTraversalStackEntry {
  std::size_t exprNodeID = 0;
  llvm::Value* value = nullptr;
  const SVF::SVFGNode* svfgNode = nullptr;
  const SVF::NodeBS* cpts = nullptr;
};

} // end anonymous namespace

void EPTGBuilder::debugDumpCellEdges(std::size_t cellID, const char* header)
{
  if (isNoDebugPrint())
    return;
  std::size_t leaderID = getLeaderCellID(cellID);
  ElementRef<TempCellNode> cell = getCellNodeAt(leaderID);
  static DumpEventDecl<const char*, std::size_t, std::size_t, std::size_t, bool> dumpEvent([](llvm::raw_ostream& os, const EventData<const char*, std::size_t, std::size_t, std::size_t, bool>& data) {
    std::size_t  cellID = data.get<1>();
    std::size_t leaderID = data.get<2>();
    std::size_t pointsToCellID = data.get<3>();
    bool isTainted = data.get<4>();
    os << data.get<0>() << " TmpC#" << cellID;
    if (cellID != leaderID) {
      os << " (leader: " << leaderID << ")";
    }
    if (isTainted) {
      os << " [T]";
    }
    if (pointsToCellID != 0) {
      os << " -> TmpC#" << pointsToCellID;
    }
    os << "\n";
  });
  dumpEvent(header, cellID, leaderID, getLeaderCellID(cell->pointsToCellID), cell->isTaintedForTypePinning);
  auto iter = cellID2subobjectCellIDs.find(leaderID);
  if (iter != cellID2subobjectCellIDs.end()) {
    static DumpEventDecl<int64_t, std::size_t> dumpContainsEvent([](llvm::raw_ostream& os, const EventData<int64_t, std::size_t>& data) {
      os << "  Contains: [" << data.get<0>() << "] -> TmpC#" << data.get<1>() << "\n";
    });
    for (auto& p : iter->second) {
      dumpContainsEvent(p.first, getLeaderCellID(p.second));
    }
  }
}

bool EPTGBuilder::tryMergeCells(std::size_t cellID1, std::size_t cellID2, bool shouldTaint)
{
  static DumpEventDecl<std::size_t, std::size_t, bool> mergeEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t, bool>& data) {
    os << "tryMergeCells: TmpC#" << data.get<0>() << " and TmpC#" << data.get<1>() << (data.get<2>()? " [T]" : "") << "\n";
  });
  PSAN_DEBUG(mergeEvent(cellID1, cellID2, shouldTaint));
  // return false if the merge failed and the cells are tainted
  // return true if the merge succeeded AND the cells are not tainted
  std::size_t leader1 = getLeaderCellID(cellID1);
  std::size_t leader2 = getLeaderCellID(cellID2);
  ElementRef<TempCellNode> dstCell = getCellNodeAt(leader1);
  ElementRef<TempCellNode> srcCell = getCellNodeAt(leader2);
  if (dstCell->isArgumentCell != srcCell->isArgumentCell) {
    psan_unreachable("Merging argument cell with non-argument cell");
  }
  shouldTaint |= dstCell->isTaintedForTypePinning || srcCell->isTaintedForTypePinning;
  bool isTypeMatch = true;
  if (leader1 != leader2) {
    if (srcCell->ty != dstCell->ty) {
      isTypeMatch = false;
    }
  } else {
    // the two cells are already merged
    static DumpEventDecl<std::size_t> alreadyMergedEvent([](llvm::raw_ostream& os, const EventData<std::size_t>& data) {
      os << "  Already merged: TmpC#" << data.get<0>() << "\n";
    });
    PSAN_DEBUG(alreadyMergedEvent(leader1));
    return !shouldTaint;
  }
  if (isTypeMatch) {
    // we can do the merge
    if (srcCell->id > dstCell->id) {
      std::swap(srcCell, dstCell);
    }
    PSAN_DEBUG(debugDumpCellEdges(srcCell->id, "[1]"));
    PSAN_DEBUG(debugDumpCellEdges(dstCell->id, "[2]"));
    if (srcCell->leaderID != 0) {
      srcCell->leaderID = srcCell->id;
    }
    dstCell->leaderID = srcCell->id;
    if (shouldTaint) {
      srcCell->setTainted("merge cell: taint requested");
    }

    // try to merge cells connected with contains edges
    llvm::DenseMap<int64_t, std::size_t> srcContainsEdges;
    llvm::DenseMap<int64_t, std::size_t> dstContainsEdges;
    {
      auto iter = cellID2subobjectCellIDs.find(srcCell->id);
      if (iter != cellID2subobjectCellIDs.end()) {
        srcContainsEdges.swap(iter->second);
        cellID2subobjectCellIDs.erase(iter);
      }
    }
    {
      auto iter = cellID2subobjectCellIDs.find(dstCell->id);
      if (iter != cellID2subobjectCellIDs.end()) {
        dstContainsEdges.swap(iter->second);
        cellID2subobjectCellIDs.erase(iter);
      }
    }
    // if one of them is empty, we don't need to do anything
    if (srcContainsEdges.empty()) {
      cellID2subobjectCellIDs[srcCell->id].swap(dstContainsEdges);
    } else if (dstContainsEdges.empty()) {
      cellID2subobjectCellIDs[srcCell->id].swap(srcContainsEdges);
    } else {
      // we need to do the merge
      for (auto& p : dstContainsEdges) {
        auto iter = srcContainsEdges.find(p.first);
        if (iter == srcContainsEdges.end()) {
          srcContainsEdges.insert(std::make_pair(p.first, p.second));
        } else {
          // we need to merge the two cells
          tryMergeCells(iter->second, p.second, shouldTaint);
          iter->second = getLeaderCellID(iter->second);
        }
      }
      cellID2subobjectCellIDs[srcCell->id].swap(srcContainsEdges);
    }

    // now try to merge the points-to edge
    if (srcCell->pointsToCellID == 0) {
      srcCell->setPointsToCell(dstCell->pointsToCellID);
    } else if (dstCell->pointsToCellID != 0) {
      // both cells have an existing points-to edge
      // if one of the points-to cell is tainted, we taint the other one as well
      std::size_t srcPointsToCellID = getLeaderCellID(srcCell->pointsToCellID);
      std::size_t dstPointsToCellID = getLeaderCellID(dstCell->pointsToCellID);
      if (srcPointsToCellID != dstPointsToCellID) {
        ElementRef<TempCellNode> srcPointsToCell = getCellNodeAt(srcPointsToCellID);
        ElementRef<TempCellNode> dstPointsToCell = getCellNodeAt(dstPointsToCellID);
        if (srcPointsToCell->isTaintedForTypePinning || dstPointsToCell->isTaintedForTypePinning) {
          srcPointsToCell->setTainted("merging with tainted cell");
          dstPointsToCell->setTainted("merging with tainted cell");
        } else {
          // try to merge the points-to target cells
          // if the merge failed, both of the points-to targets should be tainted and we are fine with this, so do nothing
          if (tryMergeCells(srcPointsToCellID, dstPointsToCellID, shouldTaint)) {
            srcCell->setPointsToCell(getLeaderCellID(srcPointsToCellID));
          }
        }
      }
    }
    PSAN_DEBUG(debugDumpCellEdges(srcCell->id, "[O]"));

    if (!cellID2loadExprNodeIDs.empty()) {
      // we may need to update the load edges
      auto iter2 = cellID2loadExprNodeIDs.find(dstCell->id);
      if (iter2 != cellID2loadExprNodeIDs.end()) {
        llvm::DenseSet<std::size_t> exprNodeIDs;
        exprNodeIDs.swap(iter2->second);
        cellID2loadExprNodeIDs.erase(iter2);
        auto iter1 = cellID2loadExprNodeIDs.find(srcCell->id);
        if (iter1 != cellID2loadExprNodeIDs.end()) {
          iter1->second.insert(exprNodeIDs.begin(), exprNodeIDs.end());
        } else {
          cellID2loadExprNodeIDs.insert(std::make_pair(srcCell->id, std::move(exprNodeIDs)));
        }
      }
    }

    return !shouldTaint;
  } else {
    // we cannot do the merge; taint both cells
    static DumpEventDecl<llvm::Type*, llvm::Type*> typeMismatchEvent([](llvm::raw_ostream& os, const EventData<llvm::Type*, llvm::Type*>& data) {
      os << "  Type mismatch: " << data.get<0>() << " != " << data.get<1>() << "\n";
    });
    PSAN_DEBUG(typeMismatchEvent(srcCell->ty, dstCell->ty));
    srcCell->setTainted("merging with type-incompatible cell");
    dstCell->setTainted("merging with type-incompatible cell");
    return false;
  }
}

SVF::SVFGNode* EPTGBuilder::getStoreAddress(SVF::StoreSVFGNode* store)
{
  llvm::Value* storedValue = getLLVMValue(store->getValue());

  // if the store is from global variable initialization, the storedValue is directly the stored value
  // if the store is backed by instruction, storedValue will be the llvm::StoreInst
  if (llvm::StoreInst* storeInst = llvm::dyn_cast<llvm::StoreInst>(storedValue)) {
    storedValue = storeInst->getValueOperand();
  }

  SVF::SVFGNode* srcNode = nullptr;
  for (auto iter = store->InEdgeBegin(), iterEnd = store->InEdgeEnd(); iter != iterEnd; ++iter) {
    SVF::SVFGEdge* edge = *iter;
    // there should be at most two direct edges, one for address and one for value
    if (!edge->isDirectVFGEdge())
      continue;

    SVF::SVFGNode* curSrcNode = edge->getSrcNode();
    llvm::Value* curSrcValue = getLLVMValue(curSrcNode->getValue());
    if (!curSrcValue) {
      // if the value being stored is not a pointer, we can have no input values (e.g., a double from floating-point instr)
      if (!storedValue->getType()->isPointerTy()) {
        continue;
      }
      // if we store a null pointer, curSrcNode->getValue() will return null
      assert(SVFUtil::isa<SVF::NullPtrSVFGNode>(curSrcNode));
      if (llvm::isa<const llvm::ConstantPointerNull>(storedValue)) {
        continue;
      }
    } else if (curSrcValue == storedValue) {
      continue;
    }

    assert(srcNode == nullptr);
    srcNode = curSrcNode;
  }
  return srcNode;
}

bool EPTGBuilder::checkIsLibFunctionToBeSkipped(llvm::Function* callee) {
  if (auto* func = SVF::LLVMModuleSet::getLLVMModuleSet()->getSVFFunction(callee)) {
    if (ExtAPI::getExtAPI()->get_type(func) != SVF::ExtAPI::extType::EFT_NULL) {
      return true;
    }
  }
  return false;
}

bool EPTGBuilder::isCalleeSafeToIgnore(llvm::Function* callee) {
  switch (callee->getIntrinsicID())
  {
  default: break;
  case llvm::Intrinsic::memset_element_unordered_atomic:
  case llvm::Intrinsic::memset_inline:
  case llvm::Intrinsic::memset:
  case llvm::Intrinsic::memcpy_element_unordered_atomic:
  case llvm::Intrinsic::memcpy_inline:
  case llvm::Intrinsic::memcpy:
  case llvm::Intrinsic::memmove_element_unordered_atomic:
  case llvm::Intrinsic::memmove:
    return true;
  case llvm::Intrinsic::not_intrinsic: {
    return checkIsLibFunctionToBeSkipped(callee);
  } break;
  }
  return false;
}

void EPTGBuilder::traverseSVFGFromAllocation(std::size_t exprNodeID, llvm::Value* v)
{
  // the start expr node should represent some kind of allocations
  // in this function, we traverse the SVFG from the corresponding starting nodes
  // so that all pointers (expression nodes) pointing to this allocation has their points-to edge set
  // starting from the start SVFG node, we keep traversing through the outgoing edges:
  // 1. if the destination node is a normal copy, we just add a copy edge from the expr to the destination
  // 2. if the destination node is a GEP, we update the points-to object so that the expr points to the GEP's points-to object
  //    if the GEP goes out of bound (the first index is not zero), we taint the cell.
  //    (If there is a inheritance relationships, we may have OOB GEP on base class followed by a cast and then load/store to access derived class data)
  //    (It is too challenging to handle this case for now, so we just avoid inline metadata scheme for these objects)
  // 3. if the destination node is a cast, we check whether the cast is compatible, and will taint the cell if not compatible
  static DumpEventDecl<std::size_t, llvm::Value*> traverseEvent([](llvm::raw_ostream& os, const EventData<std::size_t, llvm::Value*>& data) {
    os << "traverseSVFGFromAllocation(): TmpE#" << data.get<0>() << ": " << data.get<1>() << "\n";
  });
  PSAN_DEBUG(traverseEvent(exprNodeID, v));
  llvm::SmallPtrSet<const SVF::SVFGNode*, 8> allVisited;
  llvm::SmallVector<SVFGTraversalStackEntry> worklist;
  auto addToWorklist = [&](std::size_t exprNodeID, llvm::Value* v, const SVF::SVFGNode* svfgNode) {
    // TODO corrections for SVFGNode
    // just assume it is correct now
    static DumpEventDecl<std::size_t, std::size_t, llvm::Value*> addEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t, llvm::Value*>& data) {
      os << "  Adding to worklist: TmpE#" << data.get<0>() << " -> SVFG#" << data.get<1>() << " " << data.get<2>() << "\n";
    });
    PSAN_DEBUG(addEvent(exprNodeID, svfgNode->getId(), v));
    auto res = allVisited.insert(svfgNode);
    if (!res.second) {
      return;
    }
    allVisited.insert(svfgNode);
    const SVF::NodeBS* cpts = nullptr;
    if (auto* mrsvfgNode = SVFUtil::dyn_cast<SVF::MRSVFGNode>(svfgNode)) {
      cpts = &mrsvfgNode->getPointsTo();
    }

    SVFGTraversalStackEntry entry;
    entry.exprNodeID = exprNodeID;
    entry.value = v;
    entry.svfgNode = svfgNode;
    entry.cpts = cpts;
    worklist.push_back(entry);
  };
  auto addCopyEdge = [this](std::size_t fromExprNodeID, std::size_t toExprNodeID) {
    TempCopyEdge edge;
    edge.id = copyEdges.size();
    edge.srcID = fromExprNodeID;
    edge.dstID = toExprNodeID;
    copyEdges.push_back(edge);
    exprID2copyEdgeIDs[fromExprNodeID].push_back(edge.id);
    exprID2copyEdgeIDs[toExprNodeID].push_back(edge.id);
    static DumpEventDecl<std::size_t, std::size_t> copyEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
      os << "  Copy edge: TmpE#" << data.get<0>() << " -> TmpE#" << data.get<1>() << "\n";
    });
    PSAN_DEBUG(copyEvent(fromExprNodeID, toExprNodeID));
  };
  addToWorklist(exprNodeID, v, getSVFGDefNode(v));
  while (!worklist.empty()) {
    SVFGTraversalStackEntry entry = worklist.pop_back_val();
    std::size_t exprNodeID = entry.exprNodeID;
    llvm::Value* v = entry.value;
    const SVF::SVFGNode* svfgNode = entry.svfgNode;
    const SVF::NodeBS* cpts = entry.cpts;
    (void) cpts;
    bool shouldTaintThisPointer = false;
    bool shouldTaintPointsToValue = false;
    // TODO update the taint flags above
    // we taint the points-to cell if there is a type error in the cell
    // we taint this pointer if we went through load/store edges with a tainted cell
    (void) shouldTaintThisPointer;

    CellNodeTracker pointsToCell(this, getExpressionNodeAt(exprNodeID)->pointsToCellID);
    static DumpEventDecl<std::size_t, std::size_t> visitEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
      os << "  Visiting TmpE#" << data.get<0>() << " -> TmpC#" << data.get<1>() << "\n";
    });
    PSAN_DEBUG(visitEvent(exprNodeID, pointsToCell.get()));
    assert (pointsToCell.get() != 0);
    llvm::SmallPtrSet<const SVF::SVFGNode*, 8> visitedNode;
    std::deque<const SVF::SVFGNode*> memberNodeWorkList;
    auto addAsMemberSVFGNode = [&](const SVF::SVFGNode* dstNode) -> void {
      auto res = visitedNode.insert(dstNode);
      if (!res.second) {
        return;
      }
      memberNodeWorkList.push_back(dstNode);
    };
    auto handleAsCopy = [&](const SVF::SVFGNode* dstNode, bool isDirectCopy) -> void {
      // first, if this is an MRSVFGNode, we save the points-to set if none is saved yet
      if (const MRSVFGNode* mrnode = SVFUtil::dyn_cast<const MRSVFGNode>(dstNode)) {
        if (!cpts) {
          cpts = &mrnode->getPointsTo();
        }
      }
      // if the destination is a store and we are from the data, treat the destination as a member even if it has a distinct llvm value
      if (SVFUtil::isa<SVF::StoreSVFGNode>(dstNode) && isDirectCopy) {
        addAsMemberSVFGNode(dstNode);
        return;
      }
      std::size_t dstExprNodeID = 0;
      llvm::Value* dstValue = getLLVMValueFromSVFGNode(dstNode);
      if (dstValue) {
        ElementRef<TempExpressionNode> dstExprNode = getOrCreateExpressionNode(dstValue);
        dstExprNodeID = dstExprNode->id;
        if (shouldTaintThisPointer) {
          dstExprNode->setTainted("traversal from tainted pointer (copy1)");
        }
        if (dstExprNodeID == exprNodeID) {
          // we are copying to the same node
          addAsMemberSVFGNode(dstNode);
          return;
        }
        if (isDirectCopy) {
          addCopyEdge(exprNodeID, dstExprNodeID);
        }
        // if this copy is a bitcast, check if we have a bitcast on function pointer
        // indirect calls does not appear in SVFG as user nodes,
        // so whenever we have a bitcast on function pointer, we must conservatively taint the cell
        if (dstValue->getType()->isPointerTy() && getPointerElementType(dstValue->getType())->isFunctionTy()) {
          shouldTaintPointsToValue = true;
        }
        // if this copy is a formal argument, we should add a store edge to the cell representing the argument
        if (llvm::Argument* arg = llvm::dyn_cast<llvm::Argument>(dstValue)) {
          auto iter = functionDefintionCells.find(arg->getParent());
          if (iter != functionDefintionCells.end()) {
            auto iterCell = iter->second.find(arg->getArgNo());
            if (iterCell != iter->second.end()) {
              std::size_t argCell = getLeaderCellID(iterCell->second);
              addStoreEdge(exprNodeID, argCell);
            }
          }
        }
      } else {
        // there is no backing LLVM value for this node
        // consider it as a member of the source node
        addAsMemberSVFGNode(dstNode);
        return;
      }
      // ok, now the dest node has a discrete expression node
      // if the dest expression node does not have a points-to cell, we copy it over
      // otherwise, we try to merge or taint the points-to cell
      ElementRef<TempExpressionNode> dstExprRef = getExpressionNodeAt(dstExprNodeID);
      std::size_t dstPointsToCell = dstExprRef->pointsToCellID;
      bool shouldContinueTraversal = false;
      if (dstPointsToCell == 0) {
        // the dest node does not have a points-to cell
        // we just copy the points-to cell from the source node
        dstExprRef->setPointsToCell(pointsToCell);
        shouldContinueTraversal = true;
        if (shouldTaintPointsToValue) {
          getCellNodeAt(pointsToCell)->setTainted("traversal from tainted pointer (copy2)");
        }
      } else {
        // the dest node has a points-to cell
        // we try to merge the points-to cell
        if (!tryMergeCells(pointsToCell, dstPointsToCell, shouldTaintPointsToValue)) {
          shouldTaintPointsToValue = true;
        }
      }
      if (shouldContinueTraversal) {
        addToWorklist(dstExprNodeID, dstValue, dstNode);
      }
    };
    auto handleGEPNodeFromGVInitializer = [this](GepSVFGNode* gepNode, const llvm::GlobalVariable* gv) -> MemberPosition {
      (void) this;
      llvm::Type* valueType = gv->getValueType();
      if (valueType->isSingleValueType()) {
        return MemberPosition();
      }
      // first, get the flattened index
      // we can only do "blind" flattening here; the type of gepVal can be incorrect
      // (e.g., an i32 field has the gep result of i8** instead of i32*)
      const SVF::PAGEdge* gepEdge = gepNode->getPAGEdge();
      SVF::GepValVar* gepVal = SVFUtil::cast<SVF::GepValVar>(gepEdge->getDstNode());
      auto index = gepVal->getConstantFieldIdx();
      static DumpEventDecl<const SVF::SVFGNode*> gepEvent([](llvm::raw_ostream& os, const EventData<const SVF::SVFGNode*>& data) {
        os << "Handling GEP node from GV initializer: " << data.get<0>() << "\n";
      });
      PSAN_DEBUG(gepEvent(gepNode));
      // now try to recover the series of index from the info above
      MemberPosition result;
      llvm::Type* curTy = valueType;
      SymbolTableInfo* info = SymbolTableInfo::SymbolInfo();
      while (true) {
        if (llvm::ArrayType* aTy = llvm::dyn_cast<llvm::ArrayType>(curTy)) {
          llvm::Type* elementTy = aTy->getElementType();
          auto elementCount = info->getNumOfFlattenElements(getSVFType(elementTy));
          index = index % elementCount;
          curTy = elementTy;
          result.push_back(0);
          continue;
        }
        if (llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(curTy)) {
          bool isMemberFound = false;
          for (unsigned i = 0, n = sTy->getNumElements(); i < n; ++i) {
            llvm::Type* elementTy = sTy->getElementType(i);
            auto elementCount = info->getNumOfFlattenElements(getSVFType(elementTy));
            if (index >= static_cast<decltype(index)>(elementCount)) {
              // this element is before the one we want
              index -= elementCount;
            } else {
              // this is the one we look for
              curTy = elementTy;
              result.push_back(i);
              isMemberFound = true;
              break;
            }
          }
          assert (isMemberFound);
          continue;
        }
        if (curTy->isSingleValueType()) {
          // we have reached the end
          break;
        }
        psan_unreachable("Unhandled type in GEP node from GV initializer");
      }
      return result;
    };
    auto visitPointerLoad = [&](std::size_t loadExprNodeID, bool isFromAddrSide, SVF::LoadSVFGNode* loadNode) -> void {
      auto iter = loadExprNodesWithDummyCells.find(loadExprNodeID);
      if (iter == loadExprNodesWithDummyCells.end()) {
        auto p = loadExprNodesWithDummyCells.insert(std::make_pair(loadExprNodeID, std::make_pair(false, false)));
        assert (p.second && "Unexpected insertion failure");
        iter = p.first;
        loadDummyExprSVFGNodes.insert(std::make_pair(loadExprNodeID, loadNode));
      }
      if (isFromAddrSide) {
        iter->second.second = true;
      } else {
        iter->second.first = true;
      }
    };
    auto handlePointerStoreNull = [&](SVF::StoreSVFGNode* store) -> void {
      // identify all pointer loads that may pick up the stored null pointer,
      // and consider them as having been visited from value side
      SVF::FIFOWorkList<SVF::SVFGNode*> worklist;
      llvm::DenseSet<SVF::SVFGNode*> visitedNodes;
      worklist.push(store);
      visitedNodes.insert(store);
      while (!worklist.empty()) {
        SVF::SVFGNode* node = worklist.pop();
        for (auto iter = node->OutEdgeBegin(), iterEnd = node->OutEdgeEnd(); iter != iterEnd; ++iter) {
          SVF::SVFGEdge* edge = *iter;
          if (edge->isDirectVFGEdge()) {
            psan_unreachable("Not expecting direct edge among nodes after store");
          }
          SVF::SVFGNode* dstNode = edge->getDstNode();
          if (SVF::LoadSVFGNode* load = SVFUtil::dyn_cast<SVF::LoadSVFGNode>(dstNode)) {
            if (llvm::Value* loadNodeDefValue = getLLVMValue(load->getValue())) {
              // if there is no backed load instruction, this is likely created by special library functions (e.g., memcpy()) and should be ignored
              if (llvm::LoadInst* loadInst = llvm::dyn_cast<llvm::LoadInst>(loadNodeDefValue)) {
                nullReachableLoads.insert(loadInst);
              }
            }
          } else {
            // check if the destination node corresponds to a memory region
            if (SVFUtil::isa<SVF::MRSVFGNode>(dstNode) && visitedNodes.insert(dstNode).second) {
              worklist.push(dstNode);
            }
          }
        }
      }
    };
    addAsMemberSVFGNode(svfgNode);
    while (!memberNodeWorkList.empty()) {
      const SVFGNode* node = memberNodeWorkList.front();
      memberNodeWorkList.pop_front();
      assert(visitedNode.contains(node));
      static DumpEventDecl<const SVF::SVFGNode*> fromEvent([](llvm::raw_ostream& os, const EventData<const SVF::SVFGNode*>& data) {
        os << "    From: " << data.get<0>() << "\n";
      });
      PSAN_DEBUG(fromEvent(node));
      for (auto iter = node->OutEdgeBegin(), iterEnd = node->OutEdgeEnd(); iter != iterEnd; ++iter) {
        SVFGEdge* edge = *iter;
        SVFGNode* dstNode = edge->getDstNode();
        bool isDirectEdge = edge->isDirectVFGEdge();
        static DumpEventDecl<const SVF::SVFGNode*, bool> toEvent([](llvm::raw_ostream& os, const EventData<const SVF::SVFGNode*, bool>& data) {
          os << "      To: " << data.get<0>() << (data.get<1>()? " [DirectEdge]" : " [IndirectEdge]") << "\n";
        });
        PSAN_DEBUG(toEvent(dstNode, isDirectEdge));
        // if the node is MRSVFGNode, check whether the points-to set matches
        // ignore the edges that the points-to set does not match
        if (MRSVFGNode* mrnode = SVFUtil::dyn_cast<MRSVFGNode>(dstNode)) {
          if (cpts && !mrnode->getPointsTo().intersects(*cpts)) {
            static DumpEventDecl<> skipEvent("        Points-to set does not match; skip\n");
            PSAN_DEBUG(skipEvent());
            continue;
          }
        }
        if (GepSVFGNode* gepNode = SVFUtil::dyn_cast<GepSVFGNode>(dstNode)) {
          assert(isDirectEdge && v);
          llvm::Value* gepValue = getLLVMValue(gepNode->getValue());
          MemberPosition pos = MemberPosition::get(gepNode);
          // if this gep is from a memory intrinsics (memcpy, memset, etc.):
          // (1) if it is a memset, we need to ignore it
          // (2) if it is a memcpy/memmove, we check whether we have visited this call from both sides; if yes, we start the special handling
          bool isHandled = false;
          if (llvm::CallInst* call = llvm::dyn_cast<llvm::CallInst>(gepValue)) {
            auto iterEntry = pendingMergeMemIntrinsicsArgs.find(call);
            if (iterEntry == pendingMergeMemIntrinsicsArgs.end()) {
              // we create the entry here
              switch (call->getIntrinsicID())
              {
              case llvm::Intrinsic::not_intrinsic: psan_unreachable("Not an intrinsic call but is having GEPSVFGNode");
              default: psan_unreachable("Unhandled intrinsic call generating GEPSVFGNode");
              case llvm::Intrinsic::memset:
              case llvm::Intrinsic::memset_inline:
              case llvm::Intrinsic::memset_element_unordered_atomic:
                // do not need to do anything for them
                isHandled = true;
                break;
              case llvm::Intrinsic::memcpy:
              case llvm::Intrinsic::memcpy_inline:
              case llvm::Intrinsic::memcpy_element_unordered_atomic:
              case llvm::Intrinsic::memmove:
              case llvm::Intrinsic::memmove_element_unordered_atomic:
                auto r = pendingMergeMemIntrinsicsArgs.insert(std::make_pair(call, std::make_pair(0,0)));
                assert (r.second);
                iterEntry = r.first;
                break;
              }
            } else if (iterEntry->second.first != 0 && iterEntry->second.second != 0) {
              // we have visited this call from both sides
              // just skip it
              isHandled = true;
            }
            if (!isHandled) {
              // both memcpy and memmove has the dest as operand 0 and src as operand 1
              llvm::Value* dstValue = call->getArgOperand(0);
              llvm::Value* srcValue = call->getArgOperand(1);
              bool isUsed = false;
              if (dstValue == v || isValueEquivalentForMemIntrinsics(dstValue, v)) {
                if (iterEntry->second.first != 0 && iterEntry->second.first != pointsToCell) {
                  tryMergeCells(iterEntry->second.first, pointsToCell, false);
                }
                iterEntry->second.first = pointsToCell;
                isUsed = true;
              }
              if (srcValue == v || isValueEquivalentForMemIntrinsics(srcValue, v)) {
                if (iterEntry->second.second != 0 && iterEntry->second.second != pointsToCell) {
                  tryMergeCells(iterEntry->second.second, pointsToCell, false);
                }
                iterEntry->second.second = pointsToCell;
                isUsed = true;
              }
              if (!isUsed) {
                psan_unreachable("Cannot find the corresponding call arg in the memory intrinsic");
              } else {
                // if both cells are found, we run the merge
                if (iterEntry->second.first != 0 && iterEntry->second.second != 0) {
                  handleMemCpyMemMove(call, iterEntry->second.first, iterEntry->second.second);
                }
                isHandled = true;
              }
            }
          }
          // special handling where the gepValue is a GlobalVariable
          // if gepValue is a global variable, SVFG is creating a GEP node for the initializer
          // there will be stores to the GEP'd pointer, and is no special handling is made (pos will be empty),
          // we will get assertion failure (type mismatch) when handling the store
          // since SVF creates separate GEP nodes for initializers of distinct struct members (but just one node for entire array),
          // we can be sure there is a single correct pos
          if (llvm::GlobalVariable* gv = llvm::dyn_cast<llvm::GlobalVariable>(gepValue)) {
            assert (pos.empty());
            pos = handleGEPNodeFromGVInitializer(gepNode, gv);
            // need to populate a more sane gepValue so that it does not conflict with others
            llvm::SmallVector<llvm::Constant*, 8> indices;
            llvm::IntegerType* i32Ty = llvm::Type::getInt32Ty(clonedModule->getContext());
            llvm::IntegerType* i64Ty = llvm::Type::getInt64Ty(clonedModule->getContext());
            indices.push_back(llvm::ConstantInt::get(i64Ty, 0));
            for (unsigned i : pos) {
              indices.push_back(llvm::ConstantInt::get(i32Ty, i));
            }
            gepValue = llvm::ConstantExpr::getGetElementPtr(gv->getValueType(), gv, indices);
          }
          static DumpEventDecl<std::string, bool> gepPosEvent([](llvm::raw_ostream& os, const EventData<std::string, bool>& data) {
            os << "          GEP pos " << data.get<0>() << " [" << (data.get<1>()? "H" : "N") << "]\n";
          });
          PSAN_DEBUG(gepPosEvent(pos.toString(), isHandled));
          if (!pos.empty()) {
            ElementRef<TempExpressionNode> derivedPtr = getOrCreateExpressionNode(const_cast<llvm::Value*>(gepValue));
            if (exprNodeID == derivedPtr->id) {
              psan_unreachable("GEP sharing expression node with the source node?");
            }
            addCopyEdge(exprNodeID, derivedPtr->id);
            // let's first create the subobject; we can merge later on
            // before that, we need to check if the pointsToCell is having the right type, otherwise trying to get the result type would fail
            llvm::Type* pointsToCellTy = getCellNodeAt(pointsToCell)->ty;
            bool isTypeMatch = true;
            static DumpEventDecl<llvm::Type*, llvm::Type*> typeMismatchEvent([](llvm::raw_ostream& os, const EventData<llvm::Type*, llvm::Type*>& data) {
              os << "          Type mismatch: " << data.get<0>() << " != " << data.get<1>() << "\n";
            });
            if (llvm::GetElementPtrInst* gepInst = llvm::dyn_cast<llvm::GetElementPtrInst>(gepValue)) {
              llvm::Type* srcTy = gepInst->getSourceElementType();
              if (srcTy != pointsToCellTy) {
                isTypeMatch = false;
                PSAN_DEBUG(typeMismatchEvent(srcTy, pointsToCellTy));
              }
            } else if (llvm::ConstantExpr* gepExpr = llvm::dyn_cast<llvm::ConstantExpr>(gepValue)) {
              if (gepExpr->getOpcode() == llvm::Instruction::GetElementPtr) {
                llvm::Type* srcTy = getPointerElementType(gepExpr->getOperand(0)->getType());
                if (srcTy != pointsToCellTy) {
                  isTypeMatch = false;
                  PSAN_DEBUG(typeMismatchEvent(srcTy, pointsToCellTy));
                }
              }
            }
            if (!isTypeMatch) {
              shouldTaintPointsToValue = true;
              getCellNodeAt(pointsToCell)->setTainted("gep type mismatch");
            } else {
              std::size_t newCellID = getOrCreateSubobjectCell(pointsToCell, pos);
              static DumpEventDecl<std::size_t, std::size_t, std::size_t, std::size_t, std::string> subobjectEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t, std::size_t, std::size_t, std::string>& data) {
                os << "          Dest: TmpE#" << data.get<0>() << " [-> TmpC#" << data.get<1>() << "]\n";
                os << "          TmpC#" << data.get<2>() << " <- TmpC#" << data.get<3>() << " at " << data.get<4>() << "\n";
              });
              PSAN_DEBUG(subobjectEvent(derivedPtr->id, derivedPtr->pointsToCellID, newCellID, pointsToCell, pos.toString()));
              if (derivedPtr->pointsToCellID == 0) {
                // we have not visited this GEP before
                derivedPtr->setPointsToCell(newCellID);
                // add to worklist
                addToWorklist(derivedPtr->id, gepValue, gepNode);
              } else {
                // we have visited this GEP before
                // now merge the subobject
                if (!tryMergeCells(newCellID, derivedPtr->pointsToCellID, shouldTaintPointsToValue)) {
                  shouldTaintPointsToValue = true;
                }
              }
            }

          } else {
            if (!isHandled) {
              handleAsCopy(gepNode, isDirectEdge);
            }
          }
        } // end of handling GepSVFGNode
        else if (LoadSVFGNode* loadNode = SVFUtil::dyn_cast<LoadSVFGNode>(dstNode)) {
          llvm::Value* loadNodeDefValue = getLLVMValue(loadNode->getValue());
          // if there is no backed load instruction, this is likely created by special library functions (e.g., memcpy()) and should be ignored
          if (llvm::LoadInst* loadInst = llvm::dyn_cast<llvm::LoadInst>(loadNodeDefValue)) {
            if (isDirectEdge) {
              // we are from the address pointer to the load node
              // if we are loading pointers, create the expr pointer if not present and add upstream edge
              // to make subsequent type transform consistent, if the loaded pointer has no points-to cell yet,
              // we create one and continue the traversal
              if (loadInst->getType()->isPointerTy()) {
                ElementRef<TempExpressionNode> loadedPtr = getOrCreateExpressionNode(loadInst);
                ElementRef<TempCellNode> backingPtr = getCellNodeAt(pointsToCell);
                addLoadEdge(backingPtr->id, loadedPtr->id);
                visitPointerLoad(loadedPtr->id, true, loadNode);
                if (!backingPtr->ty->isPointerTy()) {
                  shouldTaintPointsToValue = true;
                  shouldTaintThisPointer = true;
                  backingPtr->setTainted("loading pointer from non-pointer cell");
                  loadedPtr->setTainted("loading pointer from non-pointer cell");
                } else {
                  if (loadedPtr->pointsToCellID == 0) {
                    llvm::Type* pointsToTy = getPointerElementType(backingPtr->ty);
                    ElementRef<TempCellNode> newcell = createCellNode(pointsToTy);
                    static DumpEventDecl<std::size_t, std::size_t> dummyCellEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
                      os << "          DummyCellForTraversal: Tmp#E" << data.get<0>() << " -> TmpC#" << data.get<1>() << "\n";
                    });
                    PSAN_DEBUG(dummyCellEvent(loadedPtr->id, newcell->id));
                    loadedPtr->setPointsToCell(newcell->id);
                    addToWorklist(loadedPtr->id, loadInst, loadNode);
                  }
                }
              }
            } else {
              // we are from the upstream data, treat as copy
              if (loadInst->getType()->isPointerTy()) {
                handleAsCopy(loadNode, isDirectEdge);
                ElementRef<TempExpressionNode> dstExprNode = getOrCreateExpressionNode(loadInst);
                visitPointerLoad(dstExprNode->id, false, loadNode);
              }
            }
          }
        } // end of handling LoadSVFGNode
        else if (StoreSVFGNode* storeNode = SVFUtil::dyn_cast<StoreSVFGNode>(dstNode)) {
          // we only deal with flows of direct edge
          // we also ignore stores from special function calls (e.g., memcpy())
          llvm::Value* storeNodeValue = getLLVMValue(storeNode->getValue());
          bool isSpecialCallToSkip = false;
          if (llvm::CallInst* call = llvm::dyn_cast<llvm::CallInst>(storeNodeValue)) {
            if (llvm::Function* callee = call->getCalledFunction()) {
              isSpecialCallToSkip = isCalleeSafeToIgnore(callee);
            }
          }
          if (isDirectEdge && !isSpecialCallToSkip) {
            llvm::Value* storedValue = storeNodeValue;
            llvm::Instruction* backingInst = nullptr;
            assert(storedValue);
            if (llvm::StoreInst* storeInst = llvm::dyn_cast<llvm::StoreInst>(storedValue)) {
              storedValue = storeInst->getValueOperand();
              backingInst = storeInst;
            }

            // if we are storing pointers, create the concrete pointer if not present and add downstream edge
            SVF::SVFGNode* addrNode = getStoreAddress(storeNode);
            if (node == addrNode) {
              // we are from the address pointer to the store node
              // no need to continue traversing here since the stored value is irrelevant with the address
              if (storedValue->getType()->isPointerTy()) {
                ElementRef<TempExpressionNode> storedPtr = getOrCreateExpressionNode(storedValue);
                ElementRef<TempCellNode> backingPtr = getCellNodeAt(pointsToCell);
                addStoreEdge(storedPtr->id, backingPtr->id, backingInst);
                if (!backingPtr->ty->isPointerTy()) {
                  shouldTaintPointsToValue = true;
                  shouldTaintThisPointer = true;
                  backingPtr->setTainted("storing pointer to non-pointer cell");
                  storedPtr->setTainted("storing pointer to non-pointer cell");
                }
                // check if we are storing a null pointer
                // if yes, if the pointer is subsequently loaded and used, we still permit changing the type of the cell
                if (llvm::StoreInst* storeInst = llvm::dyn_cast_or_null<llvm::StoreInst>(backingInst)) {
                  if (llvm::ConstantPointerNull* cpn = llvm::dyn_cast<llvm::ConstantPointerNull>(storeInst->getValueOperand())) {
                    if (cpn == storedValue) {
                      handlePointerStoreNull(storeNode);
                    }
                  }
                }
              }
            } else {
              // we are from the upstream data
              handleAsCopy(storeNode, isDirectEdge);
            }
          }
        } // end of handling StoreSVFGNode
        else if (CopySVFGNode* copyNode = SVFUtil::dyn_cast<CopySVFGNode>(dstNode)) {
          llvm::Value* copyNodeValue = getLLVMValue(copyNode->getValue());
          if (!copyNodeValue) {
            // there is no backed instruction
            addAsMemberSVFGNode(copyNode);
            continue;
          }
          if (llvm::CallInst* call = llvm::dyn_cast<llvm::CallInst>(copyNodeValue)) {
            // ignore copy nodes created by special functions (e.g., memcpy())
            switch (call->getIntrinsicID())
            {
            default: psan_unreachable("Unhandled Copy node from call");
            case llvm::Intrinsic::memcpy_element_unordered_atomic:
            case llvm::Intrinsic::memcpy_inline:
            case llvm::Intrinsic::memcpy:
            case llvm::Intrinsic::memmove_element_unordered_atomic:
            case llvm::Intrinsic::memmove:
              // do nothing
              break;
            case llvm::Intrinsic::not_intrinsic: {
              if (llvm::Function* callee = call->getCalledFunction()) {
                assert (checkIsLibFunctionToBeSkipped(callee));
              }
              psan_unreachable("Unhandled Copy node from call");
            } break;
            }
          } else {
            handleAsCopy(copyNode, isDirectEdge);
          }
        } // end of handling CopySVFGNode
        else if (IntraPHISVFGNode* intraphi = SVFUtil::dyn_cast<IntraPHISVFGNode>(dstNode)) {
          // if the IntraPHI has only one outgoing edge to FormalRet, we should directly go to that FormalRet
          // this IntraPHI is likely created to join all the return values but the IntraPHI will have its "value" to be the function
          // this just messes up everything
          // UPDATE: now we consider IntraPHI/FormalRet with function value as a special case, so no need to handle it here
          handleAsCopy(intraphi, isDirectEdge);
        } else if (InterPHISVFGNode* interphi = SVFUtil::dyn_cast<InterPHISVFGNode>(dstNode)) {
          handleAsCopy(interphi, isDirectEdge);
        } else if (FormalRetSVFGNode* fret = SVFUtil::dyn_cast<FormalRetSVFGNode>(dstNode)) {
          handleAsCopy(fret, isDirectEdge);
        } else if (ActualRetSVFGNode* aret = SVFUtil::dyn_cast<ActualRetSVFGNode>(dstNode)) {
          handleAsCopy(aret, isDirectEdge);
        } else if (FormalParmSVFGNode* fparam = SVFUtil::dyn_cast<FormalParmSVFGNode>(dstNode)) {
          handleAsCopy(fparam, isDirectEdge);
        } else if (ActualParmSVFGNode* aparam = SVFUtil::dyn_cast<ActualParmSVFGNode>(dstNode)) {
          handleAsCopy(aparam, isDirectEdge);
        } else if (FormalOUTSVFGNode* fout = SVFUtil::dyn_cast<FormalOUTSVFGNode>(dstNode)) {
          handleAsCopy(fout, isDirectEdge);
        } else if (ActualOUTSVFGNode* aout = SVFUtil::dyn_cast<ActualOUTSVFGNode>(dstNode)) {
          handleAsCopy(aout, isDirectEdge);
        } else if (FormalINSVFGNode* fin = SVFUtil::dyn_cast<FormalINSVFGNode>(dstNode)) {
          handleAsCopy(fin, isDirectEdge);
        } else if (ActualINSVFGNode* ain = SVFUtil::dyn_cast<ActualINSVFGNode>(dstNode)) {
          handleAsCopy(ain, isDirectEdge);
        } else if (IntraMSSAPHISVFGNode* mphi = SVFUtil::dyn_cast<IntraMSSAPHISVFGNode>(dstNode)) {
          handleAsCopy(mphi, isDirectEdge);
        } else {
          {
            auto& os = SVFUtil::outs();
            os << "    Unhandled ";
            if (isDirectEdge) {
              os << "direct";
            } else {
              os << "indirect";
            }
            os << " edge to "<< dstNode->toString() << "\n";
          }
        }
        // Not sure if other types of SVFG node needs handling... leave it as is for now
        visitedNode.insert(dstNode);
      }
      // now all edges are visited
      // if this node is an ActualParam node, we need to check whether we have reached a downstream node
      // if the node does not have outgoing edges, we need to taint the points-to cell
      // (probably passed as indirect call argument that we have no idea what's the callee)
      // sometimes we have intrinsic function calls that create ActualParam nodes
      // we don't want to taint the points-to cell in this case
      if (const SVF::ActualParmSVFGNode* paramNode = SVFUtil::dyn_cast<const ActualParmSVFGNode>(node)) {
        if (node->OutEdgeBegin() == node->OutEdgeEnd() && !step2_pruning_isPlaceholderCall(v)) {
          bool isBenignCall = false;
          if (const SVF::CallICFGNode* callNode = paramNode->getCallSite()) {
            if (const SVF::SVFFunction* callee = SVFUtil::getCallee(callNode->getCallSite())) {
              if (llvm::Function* calleeFunc = getLLVMFunction(callee)) {
                if (!calleeFunc->isDeclaration()) {
                  // if a single value is used in more than one argument, SVFG use one of the ActualParam node to attach all outgoing edges
                  // so if we have an ActualParam without downstream node and the callee is defined, there should be another node having all the outgoing edges
                  // and we can safely ignore this node
                  isBenignCall = true;
                }
                if (isCalleeSafeToIgnore(calleeFunc)) {
                  isBenignCall = true;
                }
              }
            }
          }
          if (!isBenignCall) {
            shouldTaintPointsToValue = true;
            if (std::size_t pointsToCellID = pointsToCell.get()) {
              getCellNodeAt(pointsToCellID)->setTainted("ActualParam without downstream node");
            }
          }
        }
      }
    }
  }
}

bool EPTGBuilder::isValueEquivalentForMemIntrinsics(llvm::Value* operand, llvm::Value* v)
{
  // during the initial graph construction, when we compare whether the value from SVFG is one of the LLVM instruction operand,
  // we may have the value from SVFG to be constantexpr/globals while the actual operands are instructions doing gep/cast.
  // we want to make the comparison work in this case.

  // first, we use some known patterns
  // if v is a global/local variable and the operand is a gep with all zero indices, we consider them equivalent
  if (llvm::GetElementPtrInst* gep = llvm::dyn_cast<llvm::GetElementPtrInst>(operand)) {
    // umm for now even if the gep is not all-zero, we still consider them equivalent
    if (/*gep->hasAllZeroIndices() &&*/ gep->getOperand(0) == v) {
      return true;
    }
  }
  if (llvm::BitCastInst* cast = llvm::dyn_cast<llvm::BitCastInst>(operand)) {
    if (cast->getOperand(0) == v) {
      return true;
    }
  }

  // now some general comparison code
  llvm::User* operandUser = llvm::dyn_cast<llvm::User>(operand);
  llvm::User* valueUser = llvm::dyn_cast<llvm::User>(v);
  if (!operandUser || !valueUser) {
    return false;
  }
  // check whether the operands match
  if (operandUser->getNumOperands() != valueUser->getNumOperands()) {
    return false;
  }
  for (unsigned i = 0, n = operandUser->getNumOperands(); i < n; ++i) {
    llvm::Value* operandOp = operandUser->getOperand(i);
    llvm::Value* valueOp = valueUser->getOperand(i);
    if (operandOp != valueOp) {
      return false;
    }
  }
  // now check the opcode
  auto getOpcode = [](llvm::Value* v) -> unsigned {
    if (llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(v)) {
      return instr->getOpcode();
    }
    if (llvm::ConstantExpr* cexpr = llvm::dyn_cast<llvm::ConstantExpr>(v)) {
      return cexpr->getOpcode();
    }
    return 0;
  };
  unsigned operandOpcode = getOpcode(operand);
  unsigned valueOpcode = getOpcode(v);
  if (operandOpcode == 0 || valueOpcode == 0) {
    return false;
  }
  return operandOpcode == valueOpcode;
}

void EPTGBuilder::addCellPointsTo(SVF::FIFOWorkList<std::size_t>& cellsWithPointsTo)
{
  // in this function, we need to add points-to edges between cell nodes (using the points-to edges from expr nodes to cell nodes)
  // basically we want to enforce a rule: for every load from a cell and every store to a cell, the expression nodes should have a consistent points-to
  // so that if the cell type changes, the types of the expression nodes remain consistent
  llvm::DenseMap<std::size_t, llvm::SmallVector<std::size_t>> cellID2LoadStoreExprNodeIDs;
  for (auto& edge : storeEdges) {
    std::size_t srcExprNode = edge.srcID;
    std::size_t dstCellNode = getLeaderCellID(edge.dstID);
    cellID2LoadStoreExprNodeIDs[dstCellNode].push_back(srcExprNode);
  }
  for (auto& edge : loadEdges) {
    std::size_t srcCellNode = getLeaderCellID(edge.srcID);
    std::size_t dstExprNode = edge.dstID;
    cellID2LoadStoreExprNodeIDs[srcCellNode].push_back(dstExprNode);
  }

  // get points-to edges between cell nodes (index not all fixed yet)
  llvm::DenseMap<std::size_t, std::size_t> pendingPointsToEdges;
  for (auto& p : cellID2LoadStoreExprNodeIDs) {
    std::size_t cellID = p.first;
    llvm::SmallVector<std::size_t>& exprNodeIDs = p.second;
    ElementRef<TempCellNode> cell = getCellNodeAt(cellID);
    assert (!exprNodeIDs.empty());
    llvm::DenseSet<std::size_t> pointsToCells;
    if (cell->pointsToCellID != 0) {
      pointsToCells.insert(getLeaderCellID(cell->pointsToCellID));
    }
    bool isDestCellNodePointer = cell->ty->isPointerTy();
    for (std::size_t exprNodeID : exprNodeIDs) {
      ElementRef<TempExpressionNode> exprNode = getExpressionNodeAt(exprNodeID);
      std::size_t pointsToCellID = exprNode->pointsToCellID;
      if (pointsToCellID == 0) {
        // skip if it has no points-to cell
        continue;
      }
      // we have a points-to cell
      // double check if this is a pointer
      if (!isDestCellNodePointer) {
        // we may have type mismatch if the object type is erased
        // e.g., struct T* ptr = ...; ptr->field = ... ==> *((char*)ptr + offset) = ...
        // we will just taint this cell
        // psan_unreachable("stored cell is not a pointer while the stored value has points-to cell");
        cell->setTainted("stored cell is not a pointer while the stored value has points-to cell");
      } else {
        pointsToCells.insert(getLeaderCellID(pointsToCellID));
      }
    }
    if (pointsToCells.empty())
      continue;
    std::size_t tmpLeader = *pointsToCells.begin();
    pointsToCells.erase(pointsToCells.begin());
    while (!pointsToCells.empty()) {
      // merge the cells
      std::size_t curCellID = *pointsToCells.begin();
      tryMergeCells(tmpLeader, curCellID, false);
      pointsToCells.erase(pointsToCells.begin());
    }
    pendingPointsToEdges[cellID] = getLeaderCellID(tmpLeader);
  }
  // we need to repeat until no more nodes merging is needed
  while (true) {
    bool isChangeMade = false;
    llvm::DenseMap<std::size_t, std::size_t> tmpPointsToEdges;
    for (auto& p : pendingPointsToEdges) {
      std::size_t fromCellID = getLeaderCellID(p.first);
      std::size_t toCellID = getLeaderCellID(p.second);
      auto iter = tmpPointsToEdges.find(fromCellID);
      if (iter == tmpPointsToEdges.end()) {
        tmpPointsToEdges[fromCellID] = toCellID;
      } else {
        std::size_t curToCellID = iter->second;
        if (curToCellID != toCellID) {
          // we need to merge the cells
          isChangeMade = true;
          tryMergeCells(curToCellID, toCellID, false);
        }
      }
    }
    if (!isChangeMade)
      break;
    pendingPointsToEdges.swap(tmpPointsToEdges);
  }
  // now we have the points-to edges between cell nodes
  for (auto& p : pendingPointsToEdges) {
    std::size_t fromCellID = getLeaderCellID(p.first);
    std::size_t toCellID = getLeaderCellID(p.second);
    ElementRef<TempCellNode> fromCell = getCellNodeAt(fromCellID);
    if (fromCellID == toCellID) {
      fromCell->setTainted("points-to to itself");
      continue;
    }
    if (fromCell->pointsToCellID != 0) {
      assert (getLeaderCellID(fromCell->pointsToCellID) == toCellID);
    }
    fromCell->setPointsToCell(toCellID);
    // check if the points-to cell is having a consistent type
    // if not, we need to taint the points-to cell
    ElementRef<TempCellNode> toCell = getCellNodeAt(toCellID);
    if (getPointerElementType(fromCell->ty) != toCell->ty) {
      fromCell->setTainted("pointing-to mismatching cell");
      toCell->setTainted("pointed from mismatching cell");
    }
    cellsWithPointsTo.push(fromCellID);
  }
}

void EPTGBuilder::propagateCellPointsTo(SVF::FIFOWorkList<std::size_t>& cellWorklist)
{
  // Currently, it is possible that a cell has points-to target but pointers load/stored from/to it does not have points-to cell
  // we need to make sure that the points-to cell is propagated to the pointers, otherwise the static types will not match in the subsequent instrumentation
  // and when we propagate the points-to cell along the chain, if a pointer is loaded from Cell A and stored to Cell B and they have different points-to cells,
  // we need to merge the points-to cells of A and B
  // here we just walk through cells with points-tos, find expr loaded from them without points-to, and call propagateExprPointsTo() on the exprs
  for (auto& edge : loadEdges) {
    std::size_t srcCellNode = getLeaderCellID(edge.srcID);
    std::size_t dstExprNode = edge.dstID;
    cellID2loadExprNodeIDs[srcCellNode].insert(dstExprNode);
  }

  while (!cellWorklist.empty()) {
    std::size_t fromCellID = getLeaderCellID(cellWorklist.pop());
    std::size_t toCellID = getLeaderCellID(getCellNodeAt(fromCellID)->pointsToCellID);
    static DumpEventDecl<std::size_t, std::size_t> cellPointsToEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
      os << "Propagating points-to from TmpC#" << data.get<0>() << " [-> TmpC#" << data.get<1>() << "]\n";
    });
    PSAN_DEBUG(cellPointsToEvent(fromCellID, toCellID));
    auto iter = cellID2loadExprNodeIDs.find(fromCellID);
    if (iter != cellID2loadExprNodeIDs.end()) {
      // because we may modify the map during the iteration, we queue the exprs to propagate first
      llvm::SmallVector<std::size_t> exprsToPropagate;
      for (std::size_t exprID : iter->second) {
        ElementRef<TempExpressionNode> exprNode = getExpressionNodeAt(exprID);
        if (exprNode->pointsToCellID == 0) {
          exprNode->setPointsToCell(toCellID);
          if (getCellNodeAt(toCellID)->isTaintedForTypePinning) {
            // no need to propagate the points-to cell if it is tainted
            continue;
          }
          exprsToPropagate.push_back(exprID);
        }
      }
      for (std::size_t expr : exprsToPropagate) {
        propagateExprPointsTo(expr, cellWorklist);
      }
    }
  }
}

void EPTGBuilder::propagateExprPointsTo(std::size_t exprID, SVF::FIFOWorkList<std::size_t>& cellWorklist)
{
  // this function is called from propagateCellPointsTo() to propagate the points-to cell of expression node
  // which does not have points-to before but are loading from a cell node with points-to cell
  // we propagate the points-to cell to the expression node downstream
  SVF::FIFOWorkList<std::size_t> worklist;
  worklist.push(exprID);
  while (!worklist.empty()) {
    std::size_t curExprID = worklist.pop();
    ElementRef<TempExpressionNode> curExprNode = getExpressionNodeAt(curExprID);
    std::size_t curPointsToCellID = getLeaderCellID(curExprNode->pointsToCellID);
    if (curPointsToCellID == 0) {
      psan_unreachable("Expression node should have points-to cell");
    }
    static DumpEventDecl<std::size_t, std::size_t> exprPointsToEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
      os << "  Propagating points-to from TmpE#" << data.get<0>() << " [-> TmpC#" << data.get<1>() << "]\n";
    });
    PSAN_DEBUG(exprPointsToEvent(curExprID, curPointsToCellID));
    // first, handle outgoing copy edges
    auto iter = exprID2copyEdgeIDs.find(curExprID);
    if (iter != exprID2copyEdgeIDs.end()) {
      for (std::size_t copyEdgeID : iter->second) {
        const auto& copyEdge = copyEdges[copyEdgeID];
        if (copyEdge.srcID != curExprID) {
          continue;
        }
        ElementRef<TempExpressionNode> dstExprNode = getExpressionNodeAt(copyEdge.dstID);
        std::size_t targetPointsToCell = getLeaderCellID(curPointsToCellID);
        static DumpEventDecl<std::size_t, std::size_t, llvm::Value*> copyDestEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t, llvm::Value*>& data) {
          os << "    CopyDest TmpE#" << data.get<0>() << " [-> TmpC#" << data.get<1>() << "]: " << data.get<2>() << "\n";
        });
        PSAN_DEBUG(copyDestEvent(dstExprNode->id, targetPointsToCell, dstExprNode->value));
        // if the expression is a GEP, we need to use the subobject as the points-to cell
        if (llvm::Value* v = dstExprNode->value) {
          if (llvm::GetElementPtrInst* gepInst = llvm::dyn_cast<llvm::GetElementPtrInst>(v)) {
            MemberPosition pos = MemberPosition::get(gepInst);
            if (!pos.empty()) {
              ElementRef<TempCellNode> targetCell = getCellNodeAt(targetPointsToCell);
              if (gepInst->getSourceElementType() != targetCell->ty) {
                // we have type mismatch here; taint the points-to cell and exit
                targetCell->setTainted("propagateExprPointsTo: gep type mismatch");
                static DumpEventDecl<llvm::Type*, llvm::Type*> gepTypeMismatchEvent([](llvm::raw_ostream& os, const EventData<llvm::Type*, llvm::Type*>& data) {
                  os << "      Taint for Type mismatch: Expecting " << data.get<0>() << ", got " << data.get<1>() << "\n";
                });
                PSAN_DEBUG(gepTypeMismatchEvent(gepInst->getSourceElementType(), targetCell->ty));
                return;
              }
              targetPointsToCell = getLeaderCellID(getOrCreateSubobjectCell(targetPointsToCell, pos));
              static DumpEventDecl<std::string, std::size_t> subobjectEvent([](llvm::raw_ostream& os, const EventData<std::string, std::size_t>& data) {
                os << "      Subobject at " << data.get<0>() << ": TmpC#" << data.get<1>() << "\n";
              });
              PSAN_DEBUG(subobjectEvent(pos.toString(), targetPointsToCell));
            }
          }
        }
        if (dstExprNode->pointsToCellID == 0) {
          dstExprNode->setPointsToCell(targetPointsToCell);
          worklist.push(copyEdge.dstID);
        } else if (getLeaderCellID(dstExprNode->pointsToCellID) != targetPointsToCell) {
          // we need to merge the points-to cells
          std::size_t dstPointsToCell = getLeaderCellID(dstExprNode->pointsToCellID);
          tryMergeCells(targetPointsToCell, dstPointsToCell, false);
        }
      }
    }
    // next, handle outgoing store edges
    auto iterStore = exprID2storeEdgeIDs.find(curExprID);
    if (iterStore != exprID2storeEdgeIDs.end()) {
      for (std::size_t storeEdgeID : iterStore->second) {
        const auto& storeEdge = storeEdges[storeEdgeID];
        if (storeEdge.srcID != curExprID) {
          continue;
        }
        ElementRef<TempCellNode> dstCellNode = getCellNodeAt(getLeaderCellID(storeEdge.dstID));
        std::size_t dstPointsToCell = getLeaderCellID(dstCellNode->pointsToCellID);
        std::size_t targetPointsToCell = getLeaderCellID(curPointsToCellID);
        static DumpEventDecl<std::size_t, std::size_t> storeDestEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
          os << "    StoreDest TmpC#" << data.get<0>() << " [-> TmpC#" << data.get<1>() << "]\n";
        });
        PSAN_DEBUG(storeDestEvent(dstCellNode->id, dstPointsToCell));
        if (dstCellNode->pointsToCellID == 0) {
          dstCellNode->setPointsToCell(targetPointsToCell);
          cellWorklist.push(dstCellNode->id);
        } else if (dstPointsToCell != targetPointsToCell) {
          // we need to merge the points-to cells
          tryMergeCells(targetPointsToCell, dstPointsToCell, false);
        }
      }
    }
  }
}

void EPTGBuilder::runTaintAnalysis()
{
  // we have a two-stage taint analysis:
  // stage 1: find cells to taint; a cell is tainted if its type cannot be transformed.
  //    before this taint analysis, all the existing taints have the following semantics:
  //      when a cell node is tainted, it means the data represented by the cell cannot undergo type changes, and pointers inside cannot use inline metadata
  //      when an expression node is tainted, it means the points-to cell cannot undergo type changes; the pointer itself (as a value) can still carry metadata
  //      when an alloc node is tainted, it means the allocated object cannot undergo type changes.
  //    however, because the taintedness of alloc node is completely determined by the corresponding cell node, we don't consider taints on them separately
  // stage 2: find expressions to remove; an expression must be removed if it may pick up loaded value from a tainted cell
  //    these pointer expressions cannot be widened within EPTG and should be left outside
  //    the semantics of this removal mark are different from the taints and we mark them separately

  // to unify the indices and simplify the worklists, we map the temporary node ids as follows:
  // assume we have N_e expression nodes and N_c cell nodes
  // then [0, N_e-1] are for expression nodes and [N_e, N_e+N_c-1] are for cell nodes
  std::size_t numExprNodes = expressionNodes.size();
  std::size_t numCellNodes = cells.size();
  SVF::FIFOWorkList<std::size_t> worklist;
  llvm::BitVector tainted(numExprNodes + numCellNodes);

  // just for debugging
  // check that for any merged cells, if any member cell is tainted, the leader cell should be tainted as well
  {
    for (std::size_t i = 1, n = cells.size(); i < n; ++i) {
      std::size_t leader = getLeaderCellID(i);
      if (leader != i) {
        if (getCellNodeAt(i)->isTaintedForTypePinning) {
          if (!getCellNodeAt(leader)->isTaintedForTypePinning) {
            psan_unreachable("Leader cell is not tainted but member cell is tainted");
          }
        }
      }
    }
  }

  // stage 1: find all cells whose type cannot be transformed
  // step 1: go through all nodes and initialize the tainted nodes
  llvm::DenseMap<std::size_t, llvm::SmallVector<std::size_t>> cellID2pointstoEdgeIDs;
  for (std::size_t i = 0; i < numExprNodes; ++i) {
    ElementRef<TempExpressionNode> node = getExpressionNodeAt(i);
    if (node->isTaintedForTypePinning) {
      tainted.set(i);
      worklist.push(i);
    }
    if (node->pointsToCellID != 0) {
      std::size_t cellID = getLeaderCellID(node->pointsToCellID);
      cellID2pointstoEdgeIDs[cellID].push_back(i);
      if (node->isTaintedForTypePinning) {
        getCellNodeAt(cellID)->setTainted("point-from expr tainted");
      }
    }
  }
  for (std::size_t i = 1; i < numCellNodes; ++i) {
    // skip the invalid cell (id = 0)
    ElementRef<TempCellNode> node = getCellNodeAt(i);
    if (node->leaderID != 0 && node->leaderID != i) {
      // also skip the cells already being merged
      continue;
    }
    std::size_t index = numExprNodes + i;
    if (node->isTaintedForTypePinning) {
      tainted.set(index);
      worklist.push(index);
    }
  }
  // just do sanity checks
  for (std::size_t i = 0, numAllocNodes = allocNodes.size(); i < numAllocNodes; ++i) {
    ElementRef<TempAllocNode> node = getAllocNodeAt(i);
    //std::size_t index = numExprNodes + numCellNodes + i;
    // alloc node can be tainted if it is tainted in the previous stage but is preserved in the cloned module
    // so we disable the check below
    /*
    if (node.isTaintedForTypePinning) {
      psan_unreachable("Alloc node should not be tainted");
    }
    */
    assert (node->allocToCellID != 0);
  }

  // step 2: find all nodes to be tainted
  // helper functions to taint nodes (shared by both stages)
  auto tryTaintNode = [&](std::size_t nodeIndex, std::size_t fromIndex) -> void {
    // skip the nodes already being tainted
    if (tainted.test(nodeIndex)) {
      return;
    }
    static DumpEventDecl<std::size_t, std::size_t> taintEvent([numExprNodes](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
      // capture numExprNodes by value
      std::size_t toIndex = data.get<0>();
      std::size_t fromIndex = data.get<1>();
      os << "Tainting ";
      if (toIndex < numExprNodes) {
        os << "TmpE#" << toIndex;
      } else {
        os << "TmpC#" << toIndex - numExprNodes;
      }
      os << " from ";
      if (fromIndex < numExprNodes) {
        os << "TmpE#" << fromIndex;
      } else {
        os << "TmpC#" << fromIndex - numExprNodes;
      }
      os << "\n";
    });
    PSAN_DEBUG(taintEvent(nodeIndex, fromIndex));
    tainted.set(nodeIndex);
    worklist.push(nodeIndex);
  };
  auto tryTaintExpressionNode = [&](std::size_t exprNodeID, std::size_t fromIndex) -> void {
    // we want to avoid tainting expressions that are constants (mainly the null pointer)
    ElementRef<TempExpressionNode> node = getExpressionNodeAt(exprNodeID);
    llvm::Value* value = node->value;
    if (llvm::ConstantPointerNull* ptrnull = llvm::dyn_cast<llvm::ConstantPointerNull>(value)) {
      (void) ptrnull;
      return;
    }
    tryTaintNode(exprNodeID, fromIndex);
  };
  auto tryTaintCellNode = [&](std::size_t cellNodeID, std::size_t fromIndex) -> void {
    cellNodeID = getLeaderCellID(cellNodeID);
    tryTaintNode(numExprNodes + cellNodeID, fromIndex);
  };

  // helper functions to handle worklist entries (unique for stage 1)
  auto propagateTaintForExprNode = [&](std::size_t exprNodeID) -> void {
    // if a pointer expression is tainted, we propagate the taint to cells pointed by this pointer
    // we no longer propagate the taint to other expression nodes with value flow relationships because
    // (1) they should share the same points-to cell if they represent the same pointer value,
    // (2) it currently incorrectly taints parent objects through GEPs
    ElementRef<TempExpressionNode> exprNode = getExpressionNodeAt(exprNodeID);
    if (exprNode->pointsToCellID != 0) {
      tryTaintCellNode(getLeaderCellID(exprNode->pointsToCellID), exprNodeID);
    }
  };
  auto propagateTaintForCellNode = [&](std::size_t cellNodeID) -> void {
    // for cell nodes, we taint:
    // (1) all cell nodes reachable from this one via contains edge
    // (2) all expression nodes pointing to this cell
    // (3) the cell node pointed by this cell
    // we do not taint cells pointing to current cell because it may still be in a type-safe region and can be inlined with metadata
    // here we should only deal with cells not being merged yet
    ElementRef<TempCellNode> cellNode = getCellNodeAt(cellNodeID);
    std::size_t fromIndex = numExprNodes + cellNodeID;
    assert (cellNode->leaderID == 0 || cellNode->leaderID == cellNodeID);
    // traverse the contains edges first
    {
      auto iter = cellID2subobjectCellIDs.find(cellNodeID);
      if (iter != cellID2subobjectCellIDs.end()) {
        const auto& subobjectCellIDs = iter->second;
        for (auto& p : subobjectCellIDs) {
          tryTaintCellNode(p.second, fromIndex);
        }
      }
    }
    // then the points-to edges
    {
      auto iter = cellID2pointstoEdgeIDs.find(cellNodeID);
      if (iter != cellID2pointstoEdgeIDs.end()) {
        const auto& pointstoEdgeIDs = iter->second;
        for (std::size_t pointstoEdgeID : pointstoEdgeIDs) {
          ElementRef<TempExpressionNode> exprNode = getExpressionNodeAt(pointstoEdgeID);
          tryTaintExpressionNode(exprNode->id, fromIndex);
        }
      }
    }
    if (cellNode->pointsToCellID != 0) {
      tryTaintCellNode(cellNode->pointsToCellID, fromIndex);
    }
  };
  // the main loop for stage 1
  while (!worklist.empty()) {
    std::size_t curIndex = worklist.pop();
    if (curIndex < numExprNodes) {
      propagateTaintForExprNode(curIndex);
    } else if (curIndex < numExprNodes + numCellNodes) {
      propagateTaintForCellNode(curIndex - numExprNodes);
    } else {
      // this is an allocation node
      psan_unreachable("Alloc node should not be tainted");
    }
  }
  // write back the taint results
  int nextTainted = tainted.find_first();
  while (nextTainted >= 0) {
    std::size_t taintedIndex = static_cast<std::size_t>(nextTainted);
    if (taintedIndex < numExprNodes) {
      getExpressionNodeAt(taintedIndex)->setTainted("taint propagated");
    } else if (taintedIndex < numExprNodes + numCellNodes) {
      getCellNodeAt(taintedIndex - numExprNodes)->setTainted("taint propagated");
    } else {
      // this is an allocation node
      psan_unreachable("Alloc node should not be tainted");
    }
    nextTainted = tainted.find_next(taintedIndex);
  }
  // before the next stage, we also look at how the taints are propagated to the alloc nodes
  for (auto& p : exprNodeID2allocNodeID) {
    std::size_t exprNodeID = p.first;
    std::size_t allocNodeID = p.second;
    if (tainted.test(exprNodeID)) {
      getAllocNodeAt(allocNodeID)->setTainted("corresponding expr node tainted");
    }
  }
  // stage 2: find all expressions to be removed (they come from values loaded from tainted cells / allocs)
  auto markExpressionNodeForRemoval = [&](std::size_t exprNodeID, std::size_t becauseOfNodeID) -> void {
    // adaptation of tryTaintExpressionNode
    // we want to avoid removing expressions that are constants (mainly the null pointer)
    ElementRef<TempExpressionNode> node = getExpressionNodeAt(exprNodeID);
    llvm::Value* value = node->value;
    if (llvm::ConstantPointerNull* ptrnull = llvm::dyn_cast<llvm::ConstantPointerNull>(value)) {
      (void) ptrnull;
      return;
    }
    // skip the nodes already being marked
    if (node->isMarkedForRemoval) {
      return;
    }
    static DumpEventDecl<std::size_t, std::size_t, bool> removeEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t, bool>& data) {
      os << "  Marking TmpE#" << data.get<0>() << " for removal because of "
        << (data.get<2>()? "TmpC#" : "TmpE#") << data.get<1>() << "\n";
    });
    PSAN_DEBUG(removeEvent(exprNodeID, (becauseOfNodeID >= numExprNodes? becauseOfNodeID - numExprNodes : becauseOfNodeID), becauseOfNodeID >= numExprNodes));
    node->markForRemoval();
    worklist.push(exprNodeID);
  };

  // we find the initial set of tainted expression nodes by going through all the load edges
  for (std::size_t i = 0; i < numExprNodes; ++i) {
    ElementRef<TempExpressionNode> node = getExpressionNodeAt(i);
    auto iter = exprID2loadEdgeIDs.find(node->id);
    if (iter != exprID2loadEdgeIDs.end()) {
      const auto& loadEdgeIDs = iter->second;
      for (std::size_t loadEdgeID : loadEdgeIDs) {
        const auto& edge = loadEdges[loadEdgeID];
        std::size_t fromCell = getLeaderCellID(edge.srcID);
        if (tainted.test(fromCell + numExprNodes)) {
          markExpressionNodeForRemoval(i, fromCell + numExprNodes);
          break;
        }
      }
    }
  }
  // we then propagate the removal mark to all the expression nodes reachable from the already marked ones
  while (!worklist.empty()) {
    std::size_t curIndex = worklist.pop();
    // we should only have expression nodes here
    if (curIndex >= numExprNodes) {
      psan_unreachable("Only expression nodes should be in the worklist");
    }
    auto iter = exprID2copyEdgeIDs.find(curIndex);
    if (iter != exprID2copyEdgeIDs.end()) {
      const auto& copyEdgeIDs = iter->second;
      for (std::size_t copyEdgeID : copyEdgeIDs) {
        const auto& edge = copyEdges[copyEdgeID];
        if (curIndex == edge.srcID) {
          // try to taint the destination expression node
          markExpressionNodeForRemoval(edge.dstID, curIndex);
        }
      }
    }
  }
  // done
}

void EPTGBuilder::addSizeOperandEntry(llvm::Instruction* inst, unsigned ptrOperandIndex, unsigned accessSizeOperandIndex)
{
  auto iter = cloned2src.find(inst);
  if (iter == cloned2src.end()) {
    psan_unreachable("Cannot find the original instruction");
  }
  llvm::Instruction* srcInst = llvm::cast<llvm::Instruction>(iter->second);
  sizeOperands.push_back(std::make_tuple(srcInst, ptrOperandIndex, accessSizeOperandIndex));
}

void EPTGBuilder::tryFindSizeOperandsForMemoryOps(llvm::CallBase* call)
{
  switch (call->getIntrinsicID())
  {
  default: break;
  case llvm::Intrinsic::memmove:
  case llvm::Intrinsic::memmove_element_unordered_atomic:
  case llvm::Intrinsic::memcpy:
  case llvm::Intrinsic::memcpy_element_unordered_atomic: {
    addSizeOperandEntry(call, 0, 2); // dest
    addSizeOperandEntry(call, 1, 2); // src
  } break;
  case llvm::Intrinsic::memset:
  case llvm::Intrinsic::memset_element_unordered_atomic: {
    addSizeOperandEntry(call, 0, 2); // dest
  } break;
  }
}

void EPTGBuilder::runGraphTransforms()
{
  // run some transforms to make subsequent operations easier to handle
  // do nothing for now
}
