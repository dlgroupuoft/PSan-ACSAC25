#ifndef INSTRUMENTATION_H
#define INSTRUMENTATION_H

#include "Graphs/GenericGraph.h"
#include "Graphs/SVFG.h"
#include "Util/ExtAPI.h"
#include "Util/SVFUtil.h"

#include <llvm/Support/raw_ostream.h>
#include <llvm/Support/Alignment.h>
#include <llvm/ADT/StringMap.h>
#include <llvm/ADT/SmallSet.h>
#include <llvm/ADT/DenseSet.h>
#include <llvm/ADT/SetVector.h>
#include <llvm/Transforms/Utils/Cloning.h>
#include <llvm/IR/Function.h>
#include <llvm/IR/Module.h>
#include <llvm/IR/Instruction.h>
#include <llvm/IR/Instructions.h>
#include <llvm/IR/LLVMContext.h>
#include "llvm/IR/Constants.h"

#include "InstrumentOptions.h"

namespace PSan {

class EPTG;

class InstrumentationBase {
  // this is the base class for instrumentation
public:
  InstrumentationBase(llvm::LLVMContext& ctx, llvm::Module& M) : ctx(ctx), M(M) {}
  virtual ~InstrumentationBase() = default;
  void initInstrumentationID(unsigned id);
  unsigned getInstrumentationID() const {return ID;}
  void initCheckRequestCallback(std::function<void(llvm::Instruction*, llvm::Value*, llvm::ArrayRef<llvm::Use*>, std::size_t)> cb) { addCheckRequestMarkFunc = cb; }
  void initInstrumentationFilterCallback(std::function<bool(llvm::Instruction*)> cb) { shouldTestForInstrumentCallback = cb; }

  // set up the graph analysis results
  // only called if we enabled EPTG
  void initGraphAnalysisResults(llvm::DenseMap<llvm::Value*, llvm::Value*>* src2clonedmap, llvm::DenseMap<llvm::Value*, llvm::Value*>* cloned2srcmap,
                                SVF::SVFIR* svfir, SVF::PointerAnalysis* pta, SVF::SVFG* svfg, EPTG* eptg) {
    this->src2clonedmap = src2clonedmap;
    this->cloned2srcmap = cloned2srcmap;
    this->svfir = svfir;
    this->pta = pta;
    this->svfg = svfg;
    this->eptg = eptg;
  }

  // get the in-memory representation of the metadata; metadataStructTy would be populated with the result from createMetadataStructType() below
  llvm::Type* getPointerMetadataTypeInMemory() const { return metadataStructTy;}

  // get in-register representation of the metadata
  const llvm::SmallVector<llvm::Type*>& getPointerMetadataTypesInRegisters() const { return metadataTyInReg; }

  // get metadata for null/undef pointer (values should be constants of type returned by getPointerMetadataTypesInRegisters())
  const llvm::SmallVector<llvm::Value*>& getNullPointerMetadata() const { return nullptrMetadata; }

  // get metadata for unanalyzable pointers (pointers from external libraries, inttoptr, etc.)
  // this metadata should always pass the checks
  const llvm::SmallVector<llvm::Value*>& getUnanalyzablePointerMetadata() const { return unanalyzablePtrMetadata; }

public:
  // subclasses need to provide these

  // run the analysis and call addCheckRequestMark() to request checks
  virtual void analysis() = 0;

  // populate in-register metadata for local variables
  virtual void instrumentMetadataInit(llvm::AllocaInst* alloc, llvm::SmallVectorImpl<llvm::Value*>& md) = 0;

  // populate in-register metadata for global variables and derived constexpr
  virtual void instrumentMetadataInit(llvm::GlobalVariable* gv, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md) = 0;
  virtual void instrumentMetadataInit(llvm::ConstantExpr* gvconstexpr, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md) = 0;

  // populate in-register metadata for constants (e.g., for global variables with constant initializers)
  // if nullptr is returned, the metadata will be zero-initialized
  virtual llvm::Constant* getMetadataInitializerForConstant(llvm::Constant* c) {
    return nullptr;
  }

  // populate in-register metadata for dynamic allocations
  virtual void instrumentMetadataInit(llvm::CallBase* call, llvm::SmallVectorImpl<llvm::Value*>& md) = 0;

  // populate in-register metadata for byval/sret arguments
  // if the argument has byval/sret attribute, we are certain that it points to the beginning of a valid memory region with the specified byvalType
  // so can treat it as an allocation
  virtual void instrumentMetadataInit_ByValArgument(llvm::Argument* arg, llvm::Type* byvalType, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md) {
    (void) arg;
    (void) byvalType;
    (void) insertBefore;
    md = getUnanalyzablePointerMetadata();
  }

  // instrument a check for one or more uses at the specified location
  // checkID is for debugging
  virtual void instrumentCheck(llvm::Instruction* insertBefore, llvm::Value* ptr, const llvm::SmallVectorImpl<llvm::Use*>& uselist, llvm::SmallVectorImpl<llvm::Value*>& md, std::size_t checkID, std::size_t internalID) = 0;

  // instrument a check, just for debugging
  // this may be called before storing pointer metadata, for example.
  // because they are added in addition to requested ones, they don't have internalID
  virtual void instrumentCheck_Debug(llvm::Instruction* insertBefore, llvm::Value* ptr, llvm::SmallVectorImpl<llvm::Value*>& md, std::size_t checkID) {
    (void) insertBefore;
    (void) ptr;
    (void) md;
    (void) checkID;
  }

  // we have a mode that disables any real check (i.e., instrumentCheck() not called)
  // for certain instrumentation that would require doing works other than checking (e.g., temporal checker deallocating lock before free()),
  // they should override this function to do the missing part
  virtual void inspectCheckSiteForNoopCheck(llvm::Instruction* insertBefore, llvm::Value* ptr, const llvm::SmallVectorImpl<llvm::Use*>& uselist, llvm::SmallVectorImpl<llvm::Value*>& md, std::size_t checkID, std::size_t internalID) {
    (void) insertBefore;
    (void) ptr;
    (void) uselist;
    (void) md;
    (void) checkID;
  }

  // add the list of helper functions that may abort
  // if we enable runtime logging, the instrumented program will flush the log before calling into these functions
  // this should at least include the check helpers
  virtual void populateHelperFunctionsThatMayAbort(llvm::SmallVectorImpl<std::string>& functions) {
    (void) functions;
  }

  // handle metadata propagation through GEP; the source metadata vector may be placeholder though (implementation should not inspect the content)
  virtual void handleGEP(llvm::GetElementPtrInst* gep, const llvm::SmallVectorImpl<llvm::Value*>& src, llvm::SmallVectorImpl<llvm::Value*>& dest) {
    createDummyCastAsCopy(dest, src, gep);
  }

protected:
  // derived class must override
  // define in-register representation of the metadata
  virtual llvm::SmallVector<llvm::Type*> createPointerMetadataTypes() const = 0;

  // define metadata for null pointer
  virtual llvm::SmallVector<llvm::Value*> createNullPointerMetadata() const = 0;
  virtual llvm::SmallVector<llvm::Value*> createUnanalyzablePointerMetadata() const { return createNullPointerMetadata(); }

public:
  // subclasses can override

  // prepare the instrumentation after cloning the source module
  // if the instrumentation use helper functions to implement checks, this is the place to add them to the module
  virtual void prepareInstrumentation(const PSan::InstrumentationOptions& options, llvm::Module* dstModule) {
    (void) options;
    this->dstModule = dstModule;
  }

  // if something needs to be done after all the instrumentation (e.g., linking in runtime library functions),
  // this is the place to do it
  virtual void finalize(llvm::Module* dstModule) {(void) dstModule;}

  // create metadata load/store/init from the metadata struct
  // mdaddr is the address of the metadata of type returned by getPointerMetadataTypeInMemory()
  // note that these functions may be called with placeholder metadata, so the instrumentation should handle that

  virtual void emitMetadataLoad(llvm::Instruction* insertBefore, llvm::Value* mdaddr, llvm::SmallVectorImpl<llvm::Value*>& md);
  virtual void emitMetadataStore(llvm::Instruction* insertBefore, llvm::Value* mdaddr, llvm::SmallVectorImpl<llvm::Value*>& md);

protected:
  // derived class can override

  // define the in-memory representation of the metadata
  // this function will only be called once globally, after initInstrumentationID() is called
  // while we expect the metadata is likely a struct with multiple fields, if the instrumentation only needs a single value, it can return a single non-struct type
  // if the instrumentation needs no metadata, it can return nullptr
  virtual llvm::Type* createMetadataStructType();

protected:
  // functions for derived classes

  // add a check at the specified location
  // if the check requires extra metadata, the instrumentation should store the metadata internally and use the internalID to refer to it
  void addCheckRequestMark(llvm::Instruction* insertBefore, llvm::Value* ptr, llvm::ArrayRef<llvm::Use*> uselist, std::size_t internalID) {
    addCheckRequestMarkFunc(insertBefore, ptr, uselist, internalID);
  }

  // simplest case where we add a check immediately before the use
  void addCheckRequestMark(llvm::Use& use, std::size_t internalID = 0) {
    addCheckRequestMark(llvm::cast<llvm::Instruction>(use.getUser()), use.get(), {&use}, internalID);
  }

  // lookup cloned2srcmap to get the value; trap if not found
  llvm::Value* getSrcValue(llvm::Value* cloned);

  // lookup src2clonedmap to get the value; trap if not found
  llvm::Value* getClonedValue(llvm::Value* src);

  void createDummyCastAsCopy(llvm::SmallVectorImpl<llvm::Value*>& dest, const llvm::SmallVectorImpl<llvm::Value*>& src, llvm::Instruction* insertAfter);

  // if the inst has no memory access, return false
  // otherwise, return true, and:
  // (1) add all pointer arguments to ptrArgs (can be more than one if this is a memory intrinsics like memcpy)
  // (2) if the access size is fixed (e.g., load/store), populate fixedAccessSize with the size; otherwise, populate variableAccessSize with the size
  bool hasMemoryAccess(llvm::Instruction* inst, std::uint64_t& fixedAccessSize, llvm::Value*& variableAccessSize, llvm::SmallVectorImpl<llvm::Use*>& ptrArgs);

  std::uint64_t getLoadStoreSize(llvm::Type* ty) {
    auto& layout = M.getDataLayout();
    return layout.getTypeStoreSize(ty);
  };

  llvm::Instruction* getInsertionPointAfter(llvm::Instruction* inst);
  llvm::Value* getAllocationSizeInBytes(llvm::Value* ptr, llvm::Instruction* insertBefore);
  llvm::Value* buildAllocationSize(std::uint64_t size, llvm::Value* numArg, llvm::Instruction* insertBefore);
  llvm::Value* buildAllocationSize(llvm::Value* size, llvm::Value* numArg, llvm::Instruction* insertBefore);
protected:
  // base info
  llvm::LLVMContext& ctx;
  llvm::Module& M; // this is the source module, not the instrumented output module
  llvm::Module* dstModule = nullptr; // this is the instrumented output module

  // from pretransform
  // if the instruction is using a pointer, the instrumenter should call this to decide whether a safety check is needed
  // if the instruction is created by the compiler (instead of the user) and we know it is always safe, the function should return false
  std::function<bool(llvm::Instruction*)> shouldTestForInstrumentCallback;

  // from graph analyses
  // note that all these pointers may be null if we disabled EPTG
  llvm::DenseMap<llvm::Value*, llvm::Value*>* src2clonedmap = nullptr;
  llvm::DenseMap<llvm::Value*, llvm::Value*>* cloned2srcmap = nullptr;
  SVF::SVFIR* svfir = nullptr;
  SVF::PointerAnalysis* pta = nullptr;
  SVF::SVFG* svfg = nullptr;
  EPTG* eptg = nullptr;

  // cached info
  llvm::Type* metadataStructTy = nullptr;
  llvm::SmallVector<llvm::Type*> metadataTyInReg; // in-register representation of the metadata
  llvm::SmallVector<llvm::Value*> nullptrMetadata; // metadata for null/undef pointer
  llvm::SmallVector<llvm::Value*> unanalyzablePtrMetadata; // metadata for unanalyzable pointers

  // to support instrumentation
  unsigned ID = 0;
  std::function<void(llvm::Instruction*, llvm::Value*, llvm::ArrayRef<llvm::Use*>, std::size_t)> addCheckRequestMarkFunc;
};

} // end namespace PSan

#endif // INSTRUMENTATION_H
