#include "llvm/Support/CommandLine.h"
#include "llvm/Support/SourceMgr.h"
#include "llvm/IRReader/IRReader.h"
#include "llvm/Linker/Linker.h"
#include "psan.h"
#include "FastDebugDumper.h"
#include "PPD/PSanPrintDebugger.h"

using namespace PSan;

void PSan::TaintStatPair::print(llvm::raw_ostream& os)
{
  os << Tainted << "/" << Total << " (Tainted/Total)";
}

void PSan::DeltaStatPair::print(llvm::raw_ostream& os)
{
  os << FromValue << "->" << ToValue << " (From->To)";
}

void PSan::EnumStatType::print(llvm::raw_ostream& os)
{
  os << "{";
  bool isFirst = true;
  for (std::size_t i = 0, n = values.size(); i < n; ++i) {
    if (values[i] == 0) {
      continue;
    }
    if (isFirst) {
      isFirst = false;
    } else {
      os << ", ";
    }
    os << names[i] << ": " << values[i];
  }
  os << "}";
}

void PSan::EnumStatType::printJSON(llvm::raw_ostream& os)
{
  os << "{";
  bool isFirst = true;
  // we first write all base stats
  for (std::size_t i = 0, n = values.size(); i < n; ++i) {
    // we write value even it is zero
    if (isFirst) {
      isFirst = false;
    } else {
      os << ", ";
    }
    os << "\"" << names[i] << "\":" << values[i];
  }
  // then we write additional info
  if (isFirst) {
    isFirst = false;
  } else {
    os << ", ";
  }
  os << "\"AdditionalInfo\":{";
  isFirst = true;
  for (std::size_t i = 0, n = additionalInfo.size(); i < n; ++i) {
    const auto& info = additionalInfo[i];
    if (info.empty()) {
      continue;
    }
    if (isFirst) {
      isFirst = false;
    } else {
      os << ", ";
    }
    os << "\"" << names[i] << "\":{";
    bool isFirstInner = true;
    for (const auto& pair : info) {
      if (isFirstInner) {
        isFirstInner = false;
      } else {
        os << ", ";
      }
      os << "\"" << pair.first() << "\":" << pair.second;
    }
    os << "}";
  }
  os << "}}";
}

void PSan::StaticStats::print(llvm::raw_ostream& os)
{
  auto getTimePeriodInMS = [](const TimePointType& start, const TimePointType& finish) -> std::int64_t {
    auto delta = std::chrono::duration_cast<std::chrono::milliseconds>(finish - start);
    return delta.count();
  };
  os << "Stats:\n";

#define TAINT_STAT_PAIR(p) os << "  " #p ": "; p.print(os); os << "\n";
#define DELTA_STAT_PAIR(p) os << "  " #p ": "; p.print(os); os << "\n";
#define COUNT_STAT(p)      os << "  " #p ": " << p << "\n";
#define ENUM_STAT(p)       os << "  " #p ": "; p.print(os); os << "\n";
#define TIME_PERIOD(name, start, finish) os << "  " << name << ": " << getTimePeriodInMS(start, finish) << " ms" << "\n";

STATICSTAT_LIST

#undef TAINT_STAT_PAIR
#undef DELTA_STAT_PAIR
#undef COUNT_STAT
#undef ENUM_STAT
#undef TIME_PERIOD

  os << "Pack:\n";
  os << "{";

  bool isFirst = true;

#define CHECK_FIRST \
  if (isFirst)              \
    isFirst = false;        \
  else                      \
    os << ',';

#define TAINT_STAT_PAIR(p) CHECK_FIRST  os << '"' << #p << "\":\"" << p.Tainted << '/' << p.Total << '"';
#define DELTA_STAT_PAIR(p) CHECK_FIRST  os << '"' << #p << "\":\"" << p.FromValue << "->" << p.ToValue << '"';
#define COUNT_STAT(p) CHECK_FIRST os << '"' << #p << "\":" << p;
#define ENUM_STAT(p) CHECK_FIRST os << '"' << #p << "\":"; p.printJSON(os);
#define TIME_PERIOD(name, start, finish) CHECK_FIRST os << "\"Time_" << name << "\":" << getTimePeriodInMS(start, finish);

STATICSTAT_LIST
#undef TAINT_STAT_PAIR
#undef DELTA_STAT_PAIR
#undef COUNT_STAT
#undef ENUM_STAT
#undef TIME_PERIOD
  os << "}\n";
}

bool PSan::isInstrDominates(llvm::Instruction* upstream, llvm::Instruction* downstream, const llvm::DominatorTree& DT)
{
  llvm::Function* parent = upstream->getFunction();
  if (downstream->getFunction() != parent) {
    return false;
  }
  llvm::BasicBlock* uBB = upstream->getParent();
  llvm::BasicBlock* dBB = downstream->getParent();
  if (uBB == dBB) {
    return upstream->comesBefore(downstream);
  }
  return DT.dominates(uBB, dBB);
}

llvm::Instruction* PSan::getInsertingPointDominatingUses(llvm::Value* def, llvm::Function* useScope, llvm::Instruction* initialHint, const llvm::DominatorTree& DT, const llvm::SmallVectorImpl<llvm::Use*>* uselistOverride)
{
  llvm::Instruction* insertBeforeInst = initialHint;
  auto handleUse = [&](llvm::Use& u) -> void{
    llvm::Instruction* instrUser = llvm::dyn_cast<llvm::Instruction>(u.getUser());
    if (!instrUser) {
      return;
    }
    if (instrUser->getFunction() != useScope) {
      return;
    }

    llvm::Instruction* curPlaceToCheck = insertBeforeInst;
    if (curPlaceToCheck == instrUser) {
      return;
    }
    // if we have a PHI node user, the real use happens at the terminator of the incoming block
    llvm::Instruction* realUserPos = instrUser;
    if (llvm::PHINode* phi = llvm::dyn_cast<llvm::PHINode>(instrUser)) {
      llvm::BasicBlock* incomingBlock = phi->getIncomingBlock(u);
      realUserPos = incomingBlock->getTerminator();
    }
    if (!insertBeforeInst) {
      // the caller did not provide a hint and we just found the first use site
      insertBeforeInst = realUserPos;
      return;
    }
    if (!isInstrDominates(curPlaceToCheck, realUserPos, DT)) {
      // we either need to start determining the new position, or updating it from the current
      llvm::BasicBlock* userBB = realUserPos->getParent();
      llvm::BasicBlock* curBB = curPlaceToCheck->getParent();
      if (curBB == userBB) {
        // in this case the instrUser should not be a phi node
        // (the realUserPos is the terminator of the block and it cannot go before a user in the same block)
        insertBeforeInst = realUserPos;
      } else {
        llvm::BasicBlock* commonAncester = DT.findNearestCommonDominator(curBB, userBB);
        if (commonAncester == userBB) {
          insertBeforeInst = realUserPos;
        } else {
          insertBeforeInst = commonAncester->getTerminator();
        }
      }
    }
  };
  if (uselistOverride) {
    for (llvm::Use* u : *uselistOverride) {
      handleUse(*u);
    }
  } else {
    for (llvm::Use& u : def->uses()) {
      handleUse(u);
    }
  }
  // do not insert before PHI
  while(llvm::isa<llvm::PHINode>(insertBeforeInst)) {
    insertBeforeInst = insertBeforeInst->getNextNode();
  }
  return insertBeforeInst;
}

bool PSan::isPointerCastSafe(llvm::PointerType* fromTy, llvm::PointerType* toTy)
{
  // if we are casting from i8*, assume it is safe
  if (getPointerElementType(fromTy)->isIntegerTy(8)) {
    return true;
  }
  // otherwise, for now we only accept casts to types without pointer
  return !isTypeContainPointer(getPointerElementType(toTy));
}

bool PSan::isTypeContainPointer(llvm::Type* ty)
{
  if (llvm::isa<llvm::PointerType>(ty))
    return true;
  if (llvm::ArrayType* aty = llvm::dyn_cast<llvm::ArrayType>(ty)) {
    return isTypeContainPointer(aty->getElementType());
  }
  if (llvm::StructType* sty = llvm::dyn_cast<llvm::StructType>(ty)) {
    for (unsigned i = 0, n = sty->getNumElements(); i < n; ++i) {
      if (isTypeContainPointer(sty->getElementType(i)))
        return true;
    }
    return false;
  }
  if (llvm::VectorType* vty = llvm::dyn_cast<llvm::VectorType>(ty)) {
    return isTypeContainPointer(vty->getElementType());
  }
  return false;
}

void PSan::annotateInstr(llvm::Instruction* instr, const char* msg)
{
  instr->setMetadata(msg, llvm::MDNode::get(instr->getContext(), {}));
}

void PSan::annotateInstr(llvm::Instruction* instr, const char* msg, std::size_t id)
{
  llvm::Metadata* md = llvm::ConstantAsMetadata::get(llvm::ConstantInt::get(llvm::Type::getInt64Ty(instr->getContext()), id));
  instr->setMetadata(msg, llvm::MDNode::get(instr->getContext(), {md}));
}

bool PSan::isInstrAnnotatedWith(llvm::Instruction* instr, const char* msg)
{
  return instr->getMetadata(msg) != nullptr;
}

bool PSan::isAllocatorCall(llvm::CallBase* call)
{
  if (llvm::Function* callee = call->getCalledFunction()) {
    if (callee->hasFnAttribute(llvm::Attribute::AttrKind::AllocKind)) {
      return true;
    }
  }
  return false;
}
bool PSan::isAllocatorCallee(llvm::Function* callee)
{
  if (callee->hasFnAttribute(llvm::Attribute::AttrKind::AllocKind)) {
    return true;
  }
  return false;
}
bool PSan::isDeallocationCallee(llvm::Function* callee)
{
  auto attr = callee->getFnAttribute(llvm::Attribute::AttrKind::AllocKind);
  if (attr.isValid() && (attr.getValueAsInt() & static_cast<std::uint64_t>(llvm::AllocFnKind::Free))) {
    return true;
  }
  return false;
}

bool PSan::isReallocCallee(llvm::Function* func)
{
  auto attr = func->getFnAttribute(llvm::Attribute::AttrKind::AllocKind);
  if (attr.isValid() && (attr.getValueAsInt() & static_cast<std::uint64_t>(llvm::AllocFnKind::Realloc))) {
    return true;
  }
  return false;
}

LLVM_DUMP_METHOD
void PSan::printValueStrWithParent(const llvm::Value* value, llvm::raw_ostream& os)
{
  if (const llvm::Instruction* inst = llvm::dyn_cast<llvm::Instruction>(value)) {
    const llvm::BasicBlock* bb = inst->getParent();
    const llvm::Function* func = bb->getParent();
    os << "@" << func->getName() << " " << bb->getName() << ": ";
    inst->print(os, FastDebugDumper::getSlotTracker(func->getParent()));
  } else if (const llvm::BasicBlock* bb = llvm::dyn_cast<llvm::BasicBlock>(value)) {
    const llvm::Function* func = bb->getParent();
    os << "@" << func->getName() << ": BasicBlock " << bb->getName();
  } else if (const llvm::Function* func = llvm::dyn_cast<llvm::Function>(value)) {
    os << "Function " << func->getName() << ": ";
    func->getFunctionType()->print(os);
  } else if (const llvm::Argument* arg = llvm::dyn_cast<llvm::Argument>(value)) {
    const llvm::Function* func = arg->getParent();
    os << "@" << func->getName() << ": ";
    arg->print(os, FastDebugDumper::getSlotTracker(func->getParent()));
  } else {
    value->print(os, FastDebugDumper::getSlotTracker(FastDebugDumper::getModuleFromVal(value)));
  }
}

LLVM_DUMP_METHOD
std::string PSan::getValueStrWithParent(const llvm::Value* value)
{
  if (!value) {
    return "<No value>";
  }
  std::string buf;
  llvm::raw_string_ostream ss(buf);
  printValueStrWithParent(value, ss);
  return buf;
}

void PSan::linkInLibrary(llvm::Module* destModule, llvm::StringRef path)
{
  llvm::LLVMContext& ctx = destModule->getContext();
  llvm::SMDiagnostic err;
  std::unique_ptr<llvm::Module> srcModule = llvm::parseIRFile(path, err, ctx);
  if (!srcModule) {
    PSan::errs() << "load module failed: " << path << "\n";
    err.print("SVFModuleLoader", PSan::errs());
    psan_unreachable("PSan::linkInLibrary() failed to load the depended LLVM IR file; make sure the file (.ll/.bc) is present");
  }
  bool isFailed = llvm::Linker::linkModules(*destModule, std::move(srcModule));
  if (isFailed) {
    psan_unreachable("PSan::linkInLibrary() failed to link the library IR file into the destination module");
  }
}

void PSan::handleDebugLoc(llvm::Instruction* newInst, llvm::Instruction* insertPoint)
{
  PSanPrintDebugger::handleDebugLoc(newInst, insertPoint);
}

std::ostream& SVF::operator<<(std::ostream& os, llvm::Value* val)
{
  std::string s;
  {
    llvm::raw_string_ostream ros(s);
    val->print(ros, FastDebugDumper::getSlotTracker(FastDebugDumper::getModuleFromVal(val)));
  }
  os << s;
  return os;
}

llvm::raw_ostream& operator<<(llvm::raw_ostream& os, llvm::Value* val)
{
  val->print(os, FastDebugDumper::getSlotTracker(FastDebugDumper::getModuleFromVal(val)));
  return os;
}
