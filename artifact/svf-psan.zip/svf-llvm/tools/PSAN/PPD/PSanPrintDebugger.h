#ifndef PSAN_PRINT_DEBUGGER_H
#define PSAN_PRINT_DEBUGGER_H

#include <functional>
#include <stdint.h>
#include "llvm/IR/Module.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/ADT/StringRef.h"
#include "llvm/ADT/StringMap.h"
#include "llvm/ADT/StringSet.h"

class PSanPrintStream;
class PSanPrintDebugger {
  friend class PSanPrintStream;
public:
  PSanPrintDebugger(llvm::Module& M) : M(M) {}
  void init(); // pupulate the module with necessary functions
  void instrument(bool skipCalls = false); // instrument the module to log events
  void instrumentCalls(); // only instrument calls

  // calls to functions whose names start with these prefixes will be excluded from instrumentation
  void addExcludedCalleePrefix(const std::string& prefix) {excludedCalleePrefixes.push_back(prefix);}

  // when we log calls to these callee names, we will flush the log before the call
  void addMayAbortCallee(const std::string& callee) {mayAbortCallees.insert(callee);}

  static void handleDebugLoc(llvm::Instruction* newInst, llvm::Instruction* insertPoint);

  // if we want to do something when we reach an unreachable, we can set this callback
  static std::function<void()> unreachableCallBack;
public:
  // use this for custom events
  PSanPrintStream logCustomEvent(llvm::StringRef msg, llvm::Instruction* insertBefore);
private:
  enum DataFunctionKind {
    EMIT = 0,
    WRITE,
    READ,
  };
  std::size_t allocateEventID() {return numEvents++;}
  bool shouldExcludeCallee(llvm::Function* callee);
  void attachCallEventID(llvm::CallBase* call, std::size_t eventID);
  std::size_t retrieveOrAllocateEventID(llvm::CallBase* call);
  llvm::Value* getCastedPtr(llvm::Value* ptrValue, llvm::Instruction* insertBefore);
  llvm::CallInst* generateElementCall(DataFunctionKind kind, llvm::Value* val, llvm::ArrayRef<llvm::Value*> proceedingArgs, llvm::Instruction* insertBefore);
  llvm::CallInst* emitNewLine(llvm::Instruction* insertBefore);
  llvm::Value* getString(llvm::StringRef s);
private:
  llvm::Module& M;
  llvm::IntegerType* i8Ty = nullptr;
  llvm::IntegerType* i16Ty = nullptr;
  llvm::IntegerType* i32Ty = nullptr;
  llvm::IntegerType* i64Ty = nullptr;
  llvm::Type* f32Ty = nullptr;
  llvm::Type* f64Ty = nullptr;
  llvm::PointerType* ptrTy = nullptr;
  llvm::Type* voidTy = nullptr;
  llvm::FunctionCallee fn_write_i8;
  llvm::FunctionCallee fn_write_i16;
  llvm::FunctionCallee fn_write_i32;
  llvm::FunctionCallee fn_write_i64;
  llvm::FunctionCallee fn_write_f32;
  llvm::FunctionCallee fn_write_f64;
  llvm::FunctionCallee fn_write_ptr;
  llvm::FunctionCallee fn_write_unknown;
  llvm::FunctionCallee fn_read_i8;
  llvm::FunctionCallee fn_read_i16;
  llvm::FunctionCallee fn_read_i32;
  llvm::FunctionCallee fn_read_i64;
  llvm::FunctionCallee fn_read_f32;
  llvm::FunctionCallee fn_read_f64;
  llvm::FunctionCallee fn_read_ptr;
  llvm::FunctionCallee fn_read_unknown;
  llvm::FunctionCallee fn_emit_i8;
  llvm::FunctionCallee fn_emit_i16;
  llvm::FunctionCallee fn_emit_i32;
  llvm::FunctionCallee fn_emit_i64;
  llvm::FunctionCallee fn_emit_f32;
  llvm::FunctionCallee fn_emit_f64;
  llvm::FunctionCallee fn_emit_ptr;
  llvm::FunctionCallee fn_emit_bool;
  llvm::FunctionCallee fn_event;
  llvm::FunctionCallee fn_raw;
  llvm::FunctionCallee fn_flush;
  std::size_t numEvents = 0;
  std::vector<std::string> excludedCalleePrefixes;
  llvm::StringSet<> mayAbortCallees;
  llvm::StringMap<llvm::GlobalVariable*> stringMap;
};

class PSanPrintStream {
  friend class PSanPrintDebugger;
public:
  PSanPrintStream() = default;
  ~PSanPrintStream() = default;
  PSanPrintStream(const PSanPrintStream& other) = default;
  PSanPrintStream(PSanPrintStream&& other) = default;
  PSanPrintStream& operator=(const PSanPrintStream& other) = default;
private:
  PSanPrintStream(PSanPrintDebugger* parent, uint64_t eventID, llvm::Instruction* insertBefore) : parent(parent), eventID(eventID), insertBefore(insertBefore) {}
private:
  PSanPrintDebugger* parent = nullptr;
  uint64_t eventID = 0;
  llvm::Instruction* insertBefore = nullptr;
public:
  PSanPrintStream& operator<<(llvm::Value* val);
  PSanPrintStream& operator<<(llvm::StringRef s);
  PSanPrintStream& operator<<(const char* s);
  PSanPrintStream& operator<<(const std::string& s);
  PSanPrintStream& operator<<(const llvm::SmallVectorImpl<llvm::Value*>& s);
  PSanPrintStream& operator<<(int val);
  PSanPrintStream& operator<<(unsigned val);
  PSanPrintStream& operator<<(long val);
  PSanPrintStream& operator<<(unsigned long val);
  PSanPrintStream& operator<<(long long val);
  PSanPrintStream& operator<<(unsigned long long val);
  operator bool() const {return parent != nullptr;}
  void flush();
};


#endif // PSAN_PRINT_DEBUGGER_H
