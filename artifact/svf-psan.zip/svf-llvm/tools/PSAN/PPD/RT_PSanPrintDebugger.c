#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

static FILE* __ppd_logfile;

#define LOGFILE (__ppd_logfile? __ppd_logfile : (stdout))
#define NOINLINE __attribute__((noinline))
#define USED __attribute__((used))

__attribute__((constructor))
static void __pdd_init() {
  char* logfile = getenv("PPD_LOGFILE");
  if (logfile)
    __ppd_logfile = fopen(logfile, "w");
}
NOINLINE
void __ppd_flush(void) {
  fflush(LOGFILE);
}
NOINLINE USED
void __ppd_close(void) {
  if (__ppd_logfile) {
    fclose(__ppd_logfile);
    __ppd_logfile = NULL;
  }
}

NOINLINE
void __ppd_event(uint64_t eventID, const char* msg) {
  fprintf(LOGFILE, "[%lu] %s ", eventID, msg);
}
NOINLINE
void __ppd_raw(const char* msg) {
  fprintf(LOGFILE, "%s", msg);
}

#define DECLARE_RWTYPE(typename, ctypename, specifier) \
  NOINLINE void __ppd_emit_##typename(ctypename val) { fprintf(LOGFILE, specifier, val); } \
  NOINLINE void __ppd_write_##typename(uint64_t eventID, void* addr, ctypename val) { \
    __ppd_event(eventID, "PPD_W_" #typename); fprintf(LOGFILE, " %p ", addr); __ppd_emit_##typename(val); fputc('\n', LOGFILE); \
  } \
  NOINLINE void __ppd_read_##typename(uint64_t eventID, void* addr, ctypename val) { \
    __ppd_event(eventID, "PPD_R_" #typename); fprintf(LOGFILE, " %p ", addr); __ppd_emit_##typename(val); fputc('\n', LOGFILE); \
  }

DECLARE_RWTYPE(i8, int8_t, "%d")
DECLARE_RWTYPE(i16, int16_t, "%d")
DECLARE_RWTYPE(i32, int32_t, "%d")
DECLARE_RWTYPE(i64, int64_t, "%ld")
DECLARE_RWTYPE(f32, float, "%f")
DECLARE_RWTYPE(f64, double, "%lf")
DECLARE_RWTYPE(ptr, void*, "%p")
DECLARE_RWTYPE(unknown, const char*, "%s")

NOINLINE
void __ppd_emit_bool(char val) {
  fprintf(LOGFILE, "%s", (val? "true" : "false"));
}
