#include "PSanPrintDebugger.h"
#include "llvm/IR/InlineAsm.h"
#include "llvm/IR/DebugInfoMetadata.h"

#define ppd_unreachable(msg) do {if (unreachableCallBack) {unreachableCallBack();} llvm_unreachable(msg);} while (0)

std::function<void()> PSanPrintDebugger::unreachableCallBack;

void PSanPrintDebugger::init() {
  llvm::LLVMContext& ctx = M.getContext();
  i8Ty = llvm::Type::getInt8Ty(ctx);
  i16Ty = llvm::Type::getInt16Ty(ctx);
  i32Ty = llvm::Type::getInt32Ty(ctx);
  i64Ty = llvm::Type::getInt64Ty(ctx);
  f32Ty = llvm::Type::getFloatTy(ctx);
  f64Ty = llvm::Type::getDoubleTy(ctx);
  ptrTy = llvm::Type::getInt8PtrTy(ctx);
  voidTy = llvm::Type::getVoidTy(ctx);

  llvm::AttributeList fnAttrList = llvm::AttributeList::get(ctx, llvm::AttributeList::FunctionIndex, {
    llvm::Attribute::NoInline,
    llvm::Attribute::NoFree,
    llvm::Attribute::NoUnwind,
    llvm::Attribute::WillReturn
  });

  llvm::FunctionType* fn_write_i8_ty = llvm::FunctionType::get(voidTy, {i64Ty, ptrTy, i8Ty}, false);
  fn_write_i8 = M.getOrInsertFunction("__ppd_write_i8", fn_write_i8_ty, fnAttrList);
  llvm::FunctionType* fn_write_i16_ty = llvm::FunctionType::get(voidTy, {i64Ty, ptrTy, i16Ty}, false);
  fn_write_i16 = M.getOrInsertFunction("__ppd_write_i16", fn_write_i16_ty, fnAttrList);
  llvm::FunctionType* fn_write_i32_ty = llvm::FunctionType::get(voidTy, {i64Ty, ptrTy, i32Ty}, false);
  fn_write_i32 = M.getOrInsertFunction("__ppd_write_i32", fn_write_i32_ty, fnAttrList);
  llvm::FunctionType* fn_write_i64_ty = llvm::FunctionType::get(voidTy, {i64Ty, ptrTy, i64Ty}, false);
  fn_write_i64 = M.getOrInsertFunction("__ppd_write_i64", fn_write_i64_ty, fnAttrList);
  llvm::FunctionType* fn_write_f32_ty = llvm::FunctionType::get(voidTy, {i64Ty, ptrTy, f32Ty}, false);
  fn_write_f32 = M.getOrInsertFunction("__ppd_write_f32", fn_write_f32_ty, fnAttrList);
  llvm::FunctionType* fn_write_f64_ty = llvm::FunctionType::get(voidTy, {i64Ty, ptrTy, f64Ty}, false);
  fn_write_f64 = M.getOrInsertFunction("__ppd_write_f64", fn_write_f64_ty, fnAttrList);
  llvm::FunctionType* fn_write_ptr_ty = llvm::FunctionType::get(voidTy, {i64Ty, ptrTy, ptrTy}, false);
  fn_write_ptr = M.getOrInsertFunction("__ppd_write_ptr", fn_write_ptr_ty, fnAttrList);
  llvm::FunctionType* fn_write_unknown_ty = fn_write_ptr_ty;
  fn_write_unknown = M.getOrInsertFunction("__ppd_write_unknown", fn_write_unknown_ty, fnAttrList);

  llvm::FunctionType* fn_read_i8_ty = llvm::FunctionType::get(voidTy, {i64Ty, ptrTy, i8Ty}, false);
  fn_read_i8 = M.getOrInsertFunction("__ppd_read_i8", fn_read_i8_ty, fnAttrList);
  llvm::FunctionType* fn_read_i16_ty = llvm::FunctionType::get(voidTy, {i64Ty, ptrTy, i16Ty}, false);
  fn_read_i16 = M.getOrInsertFunction("__ppd_read_i16", fn_read_i16_ty, fnAttrList);
  llvm::FunctionType* fn_read_i32_ty = llvm::FunctionType::get(voidTy, {i64Ty, ptrTy, i32Ty}, false);
  fn_read_i32 = M.getOrInsertFunction("__ppd_read_i32", fn_read_i32_ty, fnAttrList);
  llvm::FunctionType* fn_read_i64_ty = llvm::FunctionType::get(voidTy, {i64Ty, ptrTy, i64Ty}, false);
  fn_read_i64 = M.getOrInsertFunction("__ppd_read_i64", fn_read_i64_ty, fnAttrList);
  llvm::FunctionType* fn_read_f32_ty = llvm::FunctionType::get(voidTy, {i64Ty, ptrTy, f32Ty}, false);
  fn_read_f32 = M.getOrInsertFunction("__ppd_read_f32", fn_read_f32_ty, fnAttrList);
  llvm::FunctionType* fn_read_f64_ty = llvm::FunctionType::get(voidTy, {i64Ty, ptrTy, f64Ty}, false);
  fn_read_f64 = M.getOrInsertFunction("__ppd_read_f64", fn_read_f64_ty, fnAttrList);
  llvm::FunctionType* fn_read_ptr_ty = llvm::FunctionType::get(voidTy, {i64Ty, ptrTy, ptrTy}, false);
  fn_read_ptr = M.getOrInsertFunction("__ppd_read_ptr", fn_read_ptr_ty, fnAttrList);
  llvm::FunctionType* fn_read_unknown_ty = fn_read_ptr_ty;
  fn_read_unknown = M.getOrInsertFunction("__ppd_read_unknown", fn_read_unknown_ty, fnAttrList);

  llvm::FunctionType* fn_emit_i8_ty = llvm::FunctionType::get(voidTy, {i8Ty}, false);
  fn_emit_i8 = M.getOrInsertFunction("__ppd_emit_i8", fn_emit_i8_ty, fnAttrList);
  llvm::FunctionType* fn_emit_i16_ty = llvm::FunctionType::get(voidTy, {i16Ty}, false);
  fn_emit_i16 = M.getOrInsertFunction("__ppd_emit_i16", fn_emit_i16_ty, fnAttrList);
  llvm::FunctionType* fn_emit_i32_ty = llvm::FunctionType::get(voidTy, {i32Ty}, false);
  fn_emit_i32 = M.getOrInsertFunction("__ppd_emit_i32", fn_emit_i32_ty, fnAttrList);
  llvm::FunctionType* fn_emit_i64_ty = llvm::FunctionType::get(voidTy, {i64Ty}, false);
  fn_emit_i64 = M.getOrInsertFunction("__ppd_emit_i64", fn_emit_i64_ty, fnAttrList);
  llvm::FunctionType* fn_emit_f32_ty = llvm::FunctionType::get(voidTy, {f32Ty}, false);
  fn_emit_f32 = M.getOrInsertFunction("__ppd_emit_f32", fn_emit_f32_ty, fnAttrList);
  llvm::FunctionType* fn_emit_f64_ty = llvm::FunctionType::get(voidTy, {f64Ty}, false);
  fn_emit_f64 = M.getOrInsertFunction("__ppd_emit_f64", fn_emit_f64_ty, fnAttrList);
  llvm::FunctionType* fn_emit_ptr_ty = llvm::FunctionType::get(voidTy, {ptrTy}, false);
  fn_emit_ptr = M.getOrInsertFunction("__ppd_emit_ptr", fn_emit_ptr_ty, fnAttrList);

  llvm::FunctionType* fn_emit_bool_ty = llvm::FunctionType::get(voidTy, {i8Ty}, false);
  fn_emit_bool = M.getOrInsertFunction("__ppd_emit_bool", fn_emit_bool_ty, fnAttrList);

  llvm::FunctionType* fn_event_ty = llvm::FunctionType::get(voidTy, {i64Ty, ptrTy}, false);
  fn_event = M.getOrInsertFunction("__ppd_event", fn_event_ty, fnAttrList);
  llvm::FunctionType* fn_raw_ty = llvm::FunctionType::get(voidTy, {ptrTy}, false);
  fn_raw = M.getOrInsertFunction("__ppd_raw", fn_raw_ty, fnAttrList);
  llvm::FunctionType* fn_flush_ty = llvm::FunctionType::get(voidTy, false);
  fn_flush = M.getOrInsertFunction("__ppd_flush", fn_flush_ty, fnAttrList);

  addExcludedCalleePrefix("__ppd_");
}

void PSanPrintDebugger::attachCallEventID(llvm::CallBase* call, std::size_t eventID)
{
  // attach the event ID as metadata
  llvm::LLVMContext& ctx = M.getContext();
  llvm::Metadata* idValue = llvm::ConstantAsMetadata::get(llvm::ConstantInt::get(i64Ty, eventID));
  call->setMetadata("ppd_event", llvm::MDNode::get(ctx, {idValue}));
}

std::size_t PSanPrintDebugger::retrieveOrAllocateEventID(llvm::CallBase* call)
{
  if (llvm::MDNode* md = call->getMetadata("ppd_event")) {
    if (md->getNumOperands() != 1) {
      ppd_unreachable("ppd_event metadata should have exactly one operand");
    }
    llvm::Metadata* idValue = md->getOperand(0);
    if (llvm::ConstantAsMetadata* cam = llvm::dyn_cast<llvm::ConstantAsMetadata>(idValue)) {
      if (llvm::ConstantInt* ci = llvm::dyn_cast<llvm::ConstantInt>(cam->getValue())) {
        return ci->getZExtValue();
      }
    }
    ppd_unreachable("ppd_event metadata should have a constant integer operand");
  }
  return allocateEventID();
}

llvm::Value* PSanPrintDebugger::getCastedPtr(llvm::Value* ptrValue, llvm::Instruction* insertBefore)
{
  if (ptrValue->getType() == ptrTy) {
    return ptrValue;
  }
  if (ptrValue->getType()->isPointerTy()) {
    return new llvm::BitCastInst(ptrValue, ptrTy, "", insertBefore);
  }
  ppd_unreachable("getCastedPtr() expects pointer type value");
}

llvm::CallInst* PSanPrintDebugger::generateElementCall(DataFunctionKind kind, llvm::Value* val, llvm::ArrayRef<llvm::Value*> proceedingArgs, llvm::Instruction* insertBefore)
{
  llvm::SmallVector<llvm::Value*> args(proceedingArgs.begin(), proceedingArgs.end());
  llvm::FunctionCallee callee;
  if (llvm::IntegerType* intTy = llvm::dyn_cast<llvm::IntegerType>(val->getType())) {
    switch (intTy->getBitWidth()) {
    case 1: {
      // we extend it to i8
      val = new llvm::ZExtInst(val, i8Ty, "", insertBefore);
      callee = ((kind == DataFunctionKind::EMIT)? fn_emit_bool: (kind == DataFunctionKind::READ ? fn_read_i8 : fn_write_i8));
    } break;
    case 8:
      callee = ((kind == DataFunctionKind::EMIT)? fn_emit_i8: (kind == DataFunctionKind::READ ? fn_read_i8 : fn_write_i8));
      break;
    case 16:
      callee = ((kind == DataFunctionKind::EMIT)? fn_emit_i16: (kind == DataFunctionKind::READ ? fn_read_i16 : fn_write_i16));
      break;
    case 32:
      callee = ((kind == DataFunctionKind::EMIT)? fn_emit_i32: (kind == DataFunctionKind::READ ? fn_read_i32 : fn_write_i32));
      break;
    case 64:
      callee = ((kind == DataFunctionKind::EMIT)? fn_emit_i64: (kind == DataFunctionKind::READ ? fn_read_i64 : fn_write_i64));
      break;
    default:
      ppd_unreachable("unsupported integer type");
    }
  } else if (val->getType()->isFloatTy()) {
    callee = ((kind == DataFunctionKind::EMIT)? fn_emit_f32: (kind == DataFunctionKind::READ ? fn_read_f32 : fn_write_f32));
  } else if (val->getType()->isDoubleTy()) {
    callee = ((kind == DataFunctionKind::EMIT)? fn_emit_f64: (kind == DataFunctionKind::READ ? fn_read_f64 : fn_write_f64));
  } else if (val->getType()->isPointerTy()) {
    callee = ((kind == DataFunctionKind::EMIT)? fn_emit_ptr: (kind == DataFunctionKind::READ ? fn_read_ptr : fn_write_ptr));
    val = getCastedPtr(val, insertBefore);
  } else {
    // we print out the type name
    std::string typeName;
    {
      llvm::raw_string_ostream ss(typeName);
      val->getType()->print(ss);
    }
    val = getString(typeName);
    callee = ((kind == DataFunctionKind::EMIT)? fn_raw: (kind == DataFunctionKind::READ ? fn_read_unknown : fn_write_unknown));
  }
  args.push_back(val);
  llvm::CallInst* call = llvm::CallInst::Create(callee, args, "", insertBefore);
  handleDebugLoc(call, insertBefore);
  return call;
}

llvm::CallInst* PSanPrintDebugger::emitNewLine(llvm::Instruction* insertBefore)
{
  llvm::CallInst* call = llvm::CallInst::Create(fn_raw, getString("\n"), "", insertBefore);
  handleDebugLoc(call, insertBefore);
  return call;
}

void PSanPrintDebugger::instrument(bool skipCalls)
{
  for (auto& F : M) {
    if (F.isDeclaration())
      continue;
    for (auto& B : F) {
      for (auto& I : B) {
        if (auto* call = llvm::dyn_cast<llvm::CallBase>(&I)) {
          bool shouldExclude = false;
          if (llvm::Function* callee = call->getCalledFunction()) {
            shouldExclude = shouldExcludeCallee(callee);
          }
          if (shouldExclude) {
            continue;
          }
          std::size_t eventID = allocateEventID();
          attachCallEventID(call, eventID);
          continue;
        }
        if (auto* load = llvm::dyn_cast<llvm::LoadInst>(&I)) {
          llvm::Instruction* next = load->getNextNode();
          llvm::ConstantInt* eventID = llvm::ConstantInt::get(i64Ty, allocateEventID());
          llvm::Value* addr = getCastedPtr(load->getPointerOperand(), next);
          llvm::CallInst* call = generateElementCall(DataFunctionKind::READ, load, {eventID, addr}, next);
          (void) call;
          continue;
        }
        if (auto* store = llvm::dyn_cast<llvm::StoreInst>(&I)) {
          llvm::ConstantInt* eventID = llvm::ConstantInt::get(i64Ty, allocateEventID());
          llvm::Value* addr = getCastedPtr(store->getPointerOperand(), &I);
          llvm::CallInst* call = generateElementCall(DataFunctionKind::WRITE, store->getValueOperand(), {eventID, addr}, &I);
          (void) call;
          continue;
        }
      }
    }
  }
  if (!skipCalls) {
    instrumentCalls();
  }
}

llvm::Value* PSanPrintDebugger::getString(llvm::StringRef s)
{
  llvm::GlobalVariable* backingGVStr = nullptr;
  auto it = stringMap.find(s);
  if (it != stringMap.end()) {
    backingGVStr = it->second;
  } else {
    llvm::LLVMContext& ctx = M.getContext();
    llvm::Constant* str = llvm::ConstantDataArray::getString(ctx, s);
    std::string symbolName(".ppd.str.");
    symbolName += std::to_string(stringMap.size());
    backingGVStr = new llvm::GlobalVariable(M, str->getType(), true, llvm::GlobalValue::PrivateLinkage, str, symbolName);
    stringMap[s] = backingGVStr;
  }
  llvm::ConstantInt* i64Zero = llvm::ConstantInt::get(i64Ty, 0);
  llvm::ConstantInt* i32Zero = llvm::ConstantInt::get(i32Ty, 0);
  llvm::Value* strValue = llvm::ConstantExpr::getInBoundsGetElementPtr(backingGVStr->getValueType(), backingGVStr, llvm::ArrayRef<llvm::Constant*>{i64Zero, i32Zero});
  if (strValue->getType() != ptrTy) {
    ppd_unreachable("expected pointer type");
  }
  return strValue;
}

PSanPrintStream PSanPrintDebugger::logCustomEvent(llvm::StringRef msg, llvm::Instruction* insertBefore)
{
  PSanPrintStream result(this, allocateEventID(), insertBefore);
  llvm::CallInst* call = llvm::CallInst::Create(fn_event, {llvm::ConstantInt::get(i64Ty, result.eventID), getString(msg)}, "", insertBefore);
  handleDebugLoc(call, insertBefore);
  return result;
}

void PSanPrintDebugger::handleDebugLoc(llvm::Instruction* newInst, llvm::Instruction* insertPoint)
{
  if (insertPoint->getDebugLoc()) {
    newInst->setDebugLoc(insertPoint->getDebugLoc());
    return;
  }

  // check if we have to set the debug loc
  llvm::Function* parentFunc = insertPoint->getFunction();
  llvm::DISubprogram* subprogram = parentFunc->getSubprogram();
  if (!subprogram) {
    return;
  }
  // ok, now we have to set the debug loc
  // we first go from the insert point to the first non-phi instruction
  // if not found, we then go from the insert point to the terminator of the block
  // if we still did not find one, we create a dummy location
  if (llvm::isa<llvm::PHINode>(insertPoint)) {
    ppd_unreachable("Insert point should not be PHI node");
  }
  llvm::Instruction* curInst = insertPoint;
  while (curInst && !curInst->getDebugLoc()) {
    curInst = curInst->getPrevNode();
  }
  if (curInst) {
    newInst->setDebugLoc(curInst->getDebugLoc());
    return;
  }
  curInst = insertPoint->getNextNode();
  while (curInst && !curInst->getDebugLoc()) {
    curInst = curInst->getNextNode();
  }
  if (curInst) {
    newInst->setDebugLoc(curInst->getDebugLoc());
    return;
  }
  llvm::DILocation* loc = llvm::DILocation::get(subprogram->getContext(), 0, 0, subprogram, nullptr, true);
  newInst->setDebugLoc(loc);
}

void PSanPrintDebugger::instrumentCalls()
{
  // for each callee, we create a print function that prints the callee name and the arguments
  auto createPrintFunction = [&](llvm::FunctionType* calleeTy, llvm::StringRef calleeName) -> llvm::Function* {
    llvm::SmallVector<llvm::Type*> argTypes;
    argTypes.push_back(i64Ty);
    auto curArgs = calleeTy->params();
    argTypes.append(curArgs.begin(), curArgs.end());
    llvm::LLVMContext& ctx = M.getContext();
    llvm::FunctionType* printFnTy = llvm::FunctionType::get(voidTy, argTypes, false);
    llvm::Function* printFn = llvm::Function::Create(printFnTy, llvm::GlobalValue::InternalLinkage, "__ppd_call_" + calleeName, &M);
    printFn->addFnAttr(llvm::Attribute::NoInline);
    llvm::BasicBlock* entry = llvm::BasicBlock::Create(ctx, "entry", printFn);
    llvm::IRBuilder<> builder(entry);
    llvm::Value* eventID = printFn->getArg(0);
    llvm::Value* msg = getString(calleeName);
    builder.CreateCall(fn_event, {eventID, msg});
    llvm::ReturnInst* ret = builder.CreateRetVoid();
    PSanPrintStream stream(this, 0, ret);
    llvm::SmallVector<llvm::Value*> args;
    for (unsigned i = 1, n = printFn->arg_size(); i < n; ++i) {
      args.push_back(printFn->getArg(i));
    }
    stream << args << "\n";
    if (mayAbortCallees.count(calleeName)) {
      llvm::CallInst* callFlush = llvm::CallInst::Create(fn_flush, "", ret);
      (void) callFlush;
    }
    return printFn;
  };

  llvm::DenseMap<llvm::Function*, llvm::Function*> printFuncMap;
  llvm::DenseMap<llvm::FunctionType*, llvm::Function*> indCallPrintFuncMap;
  llvm::DenseMap<llvm::FunctionType*, llvm::Function*> asmPrintFuncMap;

  auto getPrintFunction = [&](llvm::Value* callee, llvm::FunctionType* calleeTy) -> llvm::Function* {
    if (llvm::Function* func = llvm::dyn_cast<llvm::Function>(callee)) {
      auto iter = printFuncMap.find(func);
      if (iter != printFuncMap.end()) {
        return iter->second;
      }
      llvm::Function* printFn = createPrintFunction(calleeTy, func->getName());
      printFuncMap[func] = printFn;
      return printFn;
    }
    if (llvm::InlineAsm* ia = llvm::dyn_cast<llvm::InlineAsm>(callee)) {
      (void) ia;
      auto iter = asmPrintFuncMap.find(calleeTy);
      if (iter != asmPrintFuncMap.end()) {
        return iter->second;
      }
      std::string name("asm");
      name += std::to_string(asmPrintFuncMap.size());
      llvm::Function* printFn = createPrintFunction(calleeTy, name);
      asmPrintFuncMap[calleeTy] = printFn;
      return printFn;
    }
    // otherwise, it is an indirect call
    auto iter = indCallPrintFuncMap.find(calleeTy);
    if (iter != indCallPrintFuncMap.end()) {
      return iter->second;
    }
    std::string name("indcall");
    name += std::to_string(indCallPrintFuncMap.size());
    llvm::Function* printFn = createPrintFunction(calleeTy, name);
    indCallPrintFuncMap[calleeTy] = printFn;
    return printFn;
  };
  for (auto& F : M) {
    if (F.isDeclaration())
      continue;
    for (auto& B : F) {
      for (auto& I : B) {
        if (auto* call = llvm::dyn_cast<llvm::CallBase>(&I)) {
          bool shouldExclude = false;
          if (llvm::Function* callee = call->getCalledFunction()) {
            shouldExclude = shouldExcludeCallee(callee);
          }
          if (shouldExclude) {
            continue;
          }
          std::size_t eventID = retrieveOrAllocateEventID(call);
          llvm::FunctionType* calleeTy = call->getFunctionType();
          llvm::Function* printCallee = getPrintFunction(call->getCalledOperand(), calleeTy);
          // we discard additional params for vararg functions for now
          llvm::SmallVector<llvm::Value*> args;
          args.push_back(llvm::ConstantInt::get(i64Ty, eventID));
          for (unsigned i = 0, n = calleeTy->getNumParams(); i < n; ++i) {
            args.push_back(call->getArgOperand(i));
          }
          llvm::CallInst* callPrint = llvm::CallInst::Create(printCallee, args, "", call);
          handleDebugLoc(callPrint, call);
          if (!call->getType()->isVoidTy()) {
            // we also print the return value using the same event ID
            llvm::Instruction* insertPoint = call->getNextNode();
            if (llvm::InvokeInst* invoke = llvm::dyn_cast<llvm::InvokeInst>(call)) {
              insertPoint = invoke->getNormalDest()->getFirstNonPHI();
            }
            llvm::Value* returnMsg = getString("Return");
            llvm::CallInst* callReturn = llvm::CallInst::Create(fn_event, {llvm::ConstantInt::get(i64Ty, eventID), returnMsg}, "", insertPoint);
            handleDebugLoc(callReturn, insertPoint);
            llvm::CallInst* callReturnPrint = generateElementCall(DataFunctionKind::EMIT, call, {}, insertPoint);
            (void) callReturnPrint;
            emitNewLine(insertPoint);
          }
        }
      }
    }
  }
}

bool PSanPrintDebugger::shouldExcludeCallee(llvm::Function* callee)
{
  // first, check if the callee is an llvm intrinsic that is not memset/memcpy/memmove
  if (callee->isIntrinsic()) {
    switch (callee->getIntrinsicID()) {
    case llvm::Intrinsic::memset:
    case llvm::Intrinsic::memcpy:
    case llvm::Intrinsic::memmove:
      return false;
    default:
      return true;
    }
  }

  // now check if this is excluded by prefix
  return std::any_of(excludedCalleePrefixes.begin(), excludedCalleePrefixes.end(),
                     [callee](const std::string& prefix) {
                       return callee->getName().startswith(prefix);
                     });
}

PSanPrintStream& PSanPrintStream::operator<<(llvm::Value* val)
{
  parent->generateElementCall(PSanPrintDebugger::DataFunctionKind::EMIT, val, {}, insertBefore);
  return *this;
}



PSanPrintStream& PSanPrintStream::operator<<(llvm::StringRef s)
{
  llvm::Value* strValue = parent->getString(s);
  llvm::CallInst* call = llvm::CallInst::Create(parent->fn_raw, strValue, "", insertBefore);
  PSanPrintDebugger::handleDebugLoc(call, insertBefore);
  return *this;
}

PSanPrintStream& PSanPrintStream::operator<<(const char* s)
{
  return *this << llvm::StringRef(s);
}

PSanPrintStream& PSanPrintStream::operator<<(const std::string& s)
{
  return *this << llvm::StringRef(s);
}

PSanPrintStream& PSanPrintStream::operator<<(const llvm::SmallVectorImpl<llvm::Value*>& s)
{
  *this << "{"; // start of array
  bool isFirst = true;
  for (auto& val : s) {
    if (isFirst) {
      isFirst = false;
    } else {
      *this << ", ";
    }
    *this << val;
  }
  *this << "}"; // end of array
  return *this;
}

PSanPrintStream& PSanPrintStream::operator<<(int val)
{
  return *this << llvm::ConstantInt::get(parent->i32Ty, val);
}

PSanPrintStream& PSanPrintStream::operator<<(unsigned val)
{
  return *this << llvm::ConstantInt::get(parent->i32Ty, val);
}

PSanPrintStream& PSanPrintStream::operator<<(long val)
{
  return *this << llvm::ConstantInt::get(parent->i64Ty, val);
}

PSanPrintStream& PSanPrintStream::operator<<(unsigned long val)
{
  return *this << llvm::ConstantInt::get(parent->i64Ty, val);
}

PSanPrintStream& PSanPrintStream::operator<<(long long val)
{
  return *this << llvm::ConstantInt::get(parent->i64Ty, val);
}

PSanPrintStream& PSanPrintStream::operator<<(unsigned long long val)
{
  return *this << llvm::ConstantInt::get(parent->i64Ty, val);
}

void PSanPrintStream::flush()
{
  llvm::CallInst* call = llvm::CallInst::Create(parent->fn_flush, "", insertBefore);
  PSanPrintDebugger::handleDebugLoc(call, insertBefore);
}
