#ifndef EPTG_H
#define EPTG_H

#include "Graphs/GenericGraph.h"
#include "Graphs/SVFG.h"
#include "Util/ExtAPI.h"
#include "Util/SVFUtil.h"

#include <llvm/Support/raw_ostream.h>
#include <llvm/Support/Alignment.h>
#include <llvm/ADT/StringMap.h>
#include <llvm/ADT/SmallSet.h>
#include <llvm/ADT/DenseSet.h>
#include <llvm/ADT/SetVector.h>
#include <llvm/Transforms/Utils/Cloning.h>
#include <llvm/IR/Function.h>
#include <llvm/IR/Dominators.h>
#include <llvm/Analysis/AssumptionCache.h>
#include <llvm/Analysis/LoopInfo.h>
#include <llvm/Analysis/ScalarEvolution.h>
#include <llvm/Analysis/TargetLibraryInfo.h>
#include <llvm/Analysis/LazyValueInfo.h>

#include <type_traits>
#include <map>

namespace PSan {

class EPTGNode;
class AllocEPTGNode;
class CellEPTGNode;
class ExpressionEPTGNode;
class EPTGEdge;
class ContainsEPTGEdge;
class PointsToEPTGEdge;
class AllocEPTGEdge;
class LoadEPTGEdge;
class StoreEPTGEdge;
class CopyEPTGEdge;

typedef SVF::NodeID NodeID;

typedef SVF::GenericEdge<EPTGNode> GenericEPTGEdgeTy;
class EPTGEdge : public GenericEPTGEdgeTy
{
public:
  enum EPTGEdgeK {
    ContainsEdge,
    PointsToEdge,
    AllocEdge,
    LoadEdge,
    StoreEdge,
    CopyEdge,
  };

  typedef EPTGEdgeK SVFGEdgeK;
public:
  EPTGEdge(EPTGNode* s, EPTGNode* d, GEdgeFlag k) : GenericEPTGEdgeTy(s, d, k) {}
  ~EPTGEdge() {}

  inline bool isContainsEdge() const {
    return getEdgeKind() == ContainsEdge;
  }
  inline bool isPointsToEdge() const {
    return getEdgeKind() == PointsToEdge;
  }
  inline bool isAllocEdge() const {
    return getEdgeKind() == AllocEdge;
  }
  inline bool isLoadEdge() const {
    return getEdgeKind() == LoadEdge;
  }
  inline bool isStoreEdge() const {
    return getEdgeKind() == StoreEdge;
  }
  inline bool isCopyEdge() const {
    return getEdgeKind() == CopyEdge;
  }

  typedef std::set<EPTGEdge*> EPTGEdgeSetTy;

  friend SVF::OutStream& operator<<(SVF::OutStream& o, const EPTGEdge& edge)
  {
      o << edge.toString();
      return o;
  }

  virtual const std::string toString() const;

  struct equalGEdge
  {
    bool operator()(const EPTGEdge* lhs, const EPTGEdge* rhs) const
    {
      return lhs->operator<(*rhs);
    }
  };

  bool operator<(const EPTGEdge& rhs) const;
  bool operator==(const EPTGEdge& rhs) const;
};

// equivalent to a list of GEP indices
/// The value represent absolute member position
class MemberPosition {
public:
  /// represent an offset from an absolute member position
  /// -1 means going one level above; no other negative numbers allowed
  /// (e.g., [1,1] + [-1] -> [1])
  /// we always drop the tail position when computing the offset
  /// e.g., from gep index [1, 1] to [1, 2, 3],
  /// the offset will be [2, 3] instead of [-1, 2, 3]
  typedef llvm::SmallVector<int64_t, 4> OffsetType;
  typedef OffsetType PositionType;

  MemberPosition() = default;
  explicit MemberPosition(const PositionType& src)
    : pos(src)
  {}
  explicit MemberPosition(std::int64_t idx)
    : pos(1, idx)
  {}
  static MemberPosition get(const llvm::GetElementPtrInst* gep);
  static MemberPosition get(const llvm::Value* gepValue); // can be ConstantExpr or GetElementPtrInst
  static MemberPosition getWithSingleIndex(std::int64_t idx) {
    PositionType pos;
    pos.push_back(idx);
    return MemberPosition(pos);
  }
  static llvm::Type* getTypeAtPos(llvm::Type* Ty, const MemberPosition& pos);

  // function to get MemberPosition from GepSVFGNode
  // Note that this also handles the case where consecutive gep edges are collapsed
  // (e.g., a->b->c where a->b and b->c are both gep edges, SVFG only having a->b and a->c)
  static MemberPosition get(const SVF::GepSVFGNode* node);

  bool operator==(const MemberPosition& rhs) const {
    return pos == rhs.pos;
  }
  bool operator<(const MemberPosition& rhs) const {
    return pos < rhs.pos;
  }
  bool isPrefixOf(const MemberPosition& rhs) const {
    if (pos.size() > rhs.pos.size())
      return false;
    for (unsigned n = pos.size(), i = 0; i < n; ++i) {
      if (pos[i] != rhs.pos[i])
        return false;
    }
    return true;
  }
  std::size_t size() const {
    return pos.size();
  }
  bool empty() const {return pos.empty();}
  unsigned getHashValue() const {
    llvm::DenseMapInfo<int64_t> infoObj;
    unsigned hash = 0;
    for (int64_t v : pos) {
      unsigned value = infoObj.getHashValue(v);
      hash = llvm::detail::combineHashValue(hash, value);
    }
    return hash;
  }

  int64_t at(std::size_t index) const {
    return pos[index];
  }
  int64_t front() const {
    return pos.front();
  }
  int64_t back() const {
    return pos.back();
  }
  void push_back(int64_t v) {
    if (!pos.empty())
      assert(v >= 0);
    pos.push_back(v);
  }
  void pop_back() {
    pos.pop_back();
  }
  int64_t setIndexAt(std::size_t index, int64_t value) {
    int64_t oldIndex = pos[index];
    pos[index] = value;
    return oldIndex;
  }
  PositionType::iterator        begin()       {return pos.begin();}
  PositionType::const_iterator  begin() const {return pos.begin();}
  PositionType::iterator        end()         {return pos.end();}
  PositionType::const_iterator  end() const   {return pos.end();}

  MemberPosition dropPrefix(const MemberPosition& prefix) const {
    // currently no further checking
    // assert(prefix.isPrefixOf(*this));
    assert (prefix.size() <= pos.size());
    MemberPosition result;
    result.pos.append(this->pos.begin()+prefix.pos.size(), this->pos.end());
    return result;
  }
  MemberPosition dropPrefixWithSize(std::size_t len) const {
    MemberPosition result;
    assert (len <= pos.size());
    result.pos.append(this->pos.begin()+len, this->pos.end());
    return result;
  }

  MemberPosition addPrefix(const MemberPosition& prefix) const {
    MemberPosition result(prefix);
    result.pos.append(this->pos.begin(), this->pos.end());
    return result;
  }

  void print(llvm::raw_ostream& os) const;
  inline std::string toString() const {
    std::string str;
    llvm::raw_string_ostream rawstr(str);
    print(rawstr);
    return rawstr.str();
  }

private:
  PositionType pos;
};

class ContainsEPTGEdge : public EPTGEdge
{
  // Contains EPTG edge represents the containment relationship between cells
public:
  ContainsEPTGEdge(EPTGNode* s, EPTGNode* d) : EPTGEdge(s, d, ContainsEdge) {}
  static inline bool classof(const ContainsEPTGEdge *) {
    return true;
  }
  static inline bool classof(const EPTGEdge *edge) {
    return edge->getEdgeKind() == ContainsEdge;
  }
  static inline bool classof(const GenericEPTGEdgeTy *edge) {
    return edge->getEdgeKind() == ContainsEdge;
  }
  virtual const std::string toString() const;
  void setMemberPosition(const MemberPosition& pos) {
    this->pos = pos;
  }
  void setMemberPosition(int64_t pos) {
    this->pos = MemberPosition::getWithSingleIndex(pos);
  }
  const MemberPosition& getMemberPosition() const {
    return pos;
  }
private:
  MemberPosition pos;
};

class PointsToEPTGEdge : public EPTGEdge
{
  // PointsTo EPTG edge represents the points-to relationship between cells
public:
  PointsToEPTGEdge(EPTGNode* s, EPTGNode* d) : EPTGEdge(s, d, PointsToEdge) {}
  static inline bool classof(const PointsToEPTGEdge *) {
    return true;
  }
  static inline bool classof(const EPTGEdge *edge) {
    return edge->getEdgeKind() == PointsToEdge;
  }
  static inline bool classof(const GenericEPTGEdgeTy *edge) {
    return edge->getEdgeKind() == PointsToEdge;
  }
  virtual const std::string toString() const;
};

class AllocEPTGEdge : public EPTGEdge
{
  // Alloc EPTG edge represents the mapping from allocations to cells
public:
  AllocEPTGEdge(EPTGNode* s, EPTGNode* d) : EPTGEdge(s, d, AllocEdge) {}
  static inline bool classof(const AllocEPTGEdge *) {
    return true;
  }
  static inline bool classof(const EPTGEdge *edge) {
    return edge->getEdgeKind() == AllocEdge;
  }
  static inline bool classof(const GenericEPTGEdgeTy *edge) {
    return edge->getEdgeKind() == AllocEdge;
  }
  virtual const std::string toString() const;
};

class LoadEPTGEdge : public EPTGEdge
{
  // Load EPTG edge represents a pointer load from cell to expression
public:
  LoadEPTGEdge(EPTGNode* s, EPTGNode* d) : EPTGEdge(s, d, LoadEdge) {}
  static inline bool classof(const LoadEPTGEdge *) {
    return true;
  }
  static inline bool classof(const EPTGEdge *edge) {
    return edge->getEdgeKind() == LoadEdge;
  }
  static inline bool classof(const GenericEPTGEdgeTy *edge) {
    return edge->getEdgeKind() == LoadEdge;
  }
  virtual const std::string toString() const;
};

class StoreEPTGEdge : public EPTGEdge
{
  // Store EPTG edge represents a pointer store from expression to cell
public:
  StoreEPTGEdge(EPTGNode* s, EPTGNode* d) : EPTGEdge(s, d, StoreEdge) {}
  static inline bool classof(const StoreEPTGEdge *) {
    return true;
  }
  static inline bool classof(const EPTGEdge *edge) {
    return edge->getEdgeKind() == StoreEdge;
  }
  static inline bool classof(const GenericEPTGEdgeTy *edge) {
    return edge->getEdgeKind() == StoreEdge;
  }
  virtual const std::string toString() const;
  void setBackingInst(llvm::Instruction* inst) {
    backingInst = inst;
  }
private:
  llvm::Instruction* backingInst = nullptr;
};

class CopyEPTGEdge : public EPTGEdge
{
  // Copy EPTG edge represents a pointer copy from expression to expression
public:
  CopyEPTGEdge(EPTGNode* s, EPTGNode* d) : EPTGEdge(s, d, CopyEdge) {}
  static inline bool classof(const CopyEPTGEdge *) {
    return true;
  }
  static inline bool classof(const EPTGEdge *edge) {
    return edge->getEdgeKind() == CopyEdge;
  }
  static inline bool classof(const GenericEPTGEdgeTy *edge) {
    return edge->getEdgeKind() == CopyEdge;
  }
  virtual const std::string toString() const;
};

typedef SVF::GenericNode<EPTGNode, EPTGEdge> GenericEPTGNodeTy;
class EPTGNode : public GenericEPTGNodeTy
{
public:
  enum EPTGNodeK
  {
    AllocNode,
    CellNode,
    ExpressionNode,
  };
  typedef EPTGEdge::EPTGEdgeSetTy::iterator iterator;
  typedef EPTGEdge::EPTGEdgeSetTy::const_iterator const_iterator;

public:
  EPTGNode(NodeID i, EPTGNodeK k) : GenericEPTGNodeTy(i, k)
  {}
  friend SVF::OutStream &operator<<(SVF::OutStream &o, const EPTGNode &node)
  {
    o << node.toString();
    return o;
  }
  virtual const std::string toString() const;
  virtual const std::string getNodeTitle() const;
  virtual const std::string getNodeBackingValueDescription() const;

  // for attaching auxiliary informations (e.g., new cell types after EPTG transform)
  static llvm::DenseMap<EPTGNode*, llvm::SmallVector<std::shared_ptr<std::string>>> auxiliaryInfoMap;

  void dump() const;

  // we use this flag just for debugging
  // in the final EPTG output, no node should be tainted
  bool getIsTainted() const {
    return isTainted;
  }
  void setIsTainted(bool value) {
    isTainted = value;
  }
  void setDebugIndex(std::size_t index) {
    debugIndex = index;
  }
  std::size_t getDebugIndex() const {
    return debugIndex;
  }
protected:
  void populateAuxiliaryInfo(llvm::raw_ostream& os) const;
private:
  bool isTainted = false;
  std::size_t debugIndex = 0; // this is the temporary index when constructing the graph
};

class AllocEPTGNode : public EPTGNode
{
public:
  AllocEPTGNode(NodeID i, llvm::Value* AllocationSite);
  static inline bool classof(const AllocEPTGNode *) {
    return true;
  }
  static inline bool classof(const EPTGNode *node) {
    return node->getNodeKind() == AllocNode;
  }
  static inline bool classof(const GenericEPTGNodeTy *node) {
    return node->getNodeKind() == AllocNode;
  }
  virtual const std::string toString() const override;
  virtual const std::string getNodeTitle() const override;
  virtual const std::string getNodeBackingValueDescription() const override;
  llvm::Value* getAllocationSite() const {
    return AllocationSite;
  }
  CellEPTGNode* getCell() const;
private:
  llvm::Value* AllocationSite = nullptr;
};

class CellEPTGNode : public EPTGNode
{
public:
  constexpr static unsigned FLAG_EMPTY = 0;
  constexpr static unsigned FLAG_EXPOSED = 1;
  constexpr static unsigned FLAG_ARGCELL = 2;

public:
  CellEPTGNode(NodeID i, llvm::Type* ty) : EPTGNode(i, CellNode), ty(ty)
  {}
  static inline bool classof(const CellEPTGNode *) {
    return true;
  }
  static inline bool classof(const EPTGNode *node) {
    return node->getNodeKind() == CellNode;
  }
  static inline bool classof(const GenericEPTGNodeTy *node) {
    return node->getNodeKind() == CellNode;
  }
  virtual const std::string toString() const override;
  virtual const std::string getNodeTitle() const override;
  virtual const std::string getNodeBackingValueDescription() const override;
  inline bool isExposed() const {
    return flags & FLAG_EXPOSED;
  }
  inline bool isArgumentCell() const { // this includes both arguments and return values
    return flags & FLAG_ARGCELL;
  }
  inline void setFlag(unsigned flag) {
    flags |= flag;
  }
  inline llvm::Type* getType() const {
    return ty;
  }
  inline bool isPointerTy() const {
    return ty->isPointerTy();
  }
  CellEPTGNode* getPointsTo() const;
  CellEPTGNode* getSubObjectIfAvailable(const MemberPosition& pos) const;
private:
  unsigned flags = 0;
  llvm::Type* ty = nullptr;
};

class ExpressionEPTGNode : public EPTGNode
{
public:
  ExpressionEPTGNode(NodeID i, llvm::Value* expr, SVF::SVFGNode* def);
  static inline bool classof(const ExpressionEPTGNode *) {
    return true;
  }
  static inline bool classof(const EPTGNode *node) {
    return node->getNodeKind() == ExpressionNode;
  }
  static inline bool classof(const GenericEPTGNodeTy *node) {
    return node->getNodeKind() == ExpressionNode;
  }
  virtual const std::string toString() const override;
  virtual const std::string getNodeTitle() const override;
  virtual const std::string getNodeBackingValueDescription() const override;
  SVF::SVFGNode* getSVFGDefNode() const {
    return svfgDefNode;
  }
  llvm::Value* getExpression() const {
    return expr;
  }
  CellEPTGNode* getPointsTo() const;
private:
  llvm::Value* expr = nullptr;
  SVF::SVFGNode* svfgDefNode = nullptr;
  // unsigned flags = 0;
};

typedef SVF::GenericGraph<EPTGNode, EPTGEdge> GenericEPTG;
class EPTG : public GenericEPTG
{
  friend class EPTGBuilder;
public:
  typedef SVF::OrderedMap<NodeID, EPTGNode *> EPTGNodeIDToNodeMapTy;
  typedef EPTGEdge::EPTGEdgeSetTy EPTGEdgeSetTy;
  typedef EPTGNodeIDToNodeMapTy::iterator iterator;
  typedef EPTGNodeIDToNodeMapTy::const_iterator const_iterator;

  NodeID totalEPTGNode = 0;

public:
  /// Constructor
  explicit EPTG(llvm::Module* module);

  /// Destructor
  ~EPTG() override;

  /// Get a EPTG node
  inline EPTGNode* getEPTGNode(NodeID id) const
  {
      return getGNode(id);
  }

  /// Whether has the EPTGNode
  inline bool hasEPTGNode(NodeID id) const
  {
      return hasGNode(id);
  }

  // get the EPTGNode with the given kind
  // traps if there are more than one edge with the same kind
  EPTGEdge* getEPTGEdge(const EPTGNode* src, const EPTGNode* dst, EPTGEdge::EPTGEdgeK kind);

  /// Dump graph into dot file
  void dump(const std::string& file, bool simple = false);

  /// View graph from the debugger
  void view();

  ExpressionEPTGNode* getExpressionNode(llvm::Value* srcValue);

  void forAllExpressionNodes(std::function<void(ExpressionEPTGNode*, llvm::Value*)> func) {
    for (auto& p : valueToExpressionNodeMap) {
      func(p.second, p.first);
    }
  }

protected:
  /// Remove a SVFG edge
  inline void removeEPTGEdge(EPTGEdge* edge)
  {
    edge->getDstNode()->removeIncomingEdge(edge);
    edge->getSrcNode()->removeOutgoingEdge(edge);
    delete edge;
  }
  /// Remove a EPTGNode
  inline void removeEPTGNode(EPTGNode* node)
  {
    removeGNode(node);
  }
  inline bool addEPTGEdge(EPTGEdge* edge)
  {
    bool added1 = edge->getDstNode()->addIncomingEdge(edge);
    bool added2 = edge->getSrcNode()->addOutgoingEdge(edge);
    bool all_added = added1 && added2;
    assert(all_added && "EPTGEdge not added?");
    return all_added;
  }
  void addEPTGNode(EPTGNode* node);

protected:
  llvm::DenseMap<llvm::Value*, ExpressionEPTGNode*> valueToExpressionNodeMap;
  llvm::Module* module = nullptr;
};

} // end namespace PSan

namespace SVF {
/* !
 * GenericGraphTraits specializations for generic graph algorithms.
 * Provide graph traits for traversing from a constraint node using standard graph traversals.
 */
template<> struct GenericGraphTraits<PSan::EPTGNode*> : public SVF::GenericGraphTraits<SVF::GenericNode<PSan::EPTGNode,PSan::EPTGEdge>*  >
{
};

template<> struct GenericGraphTraits<PSan::EPTG*> : public SVF::GenericGraphTraits<SVF::GenericGraph<PSan::EPTGNode,PSan::EPTGEdge>* >
{
  typedef PSan::EPTGNode *NodeRef;
};
} // end namespace SVF

namespace llvm {
template <> struct DenseMapInfo<PSan::MemberPosition> {
  static inline PSan::MemberPosition getEmptyKey() {
    PSan::MemberPosition V(-2);
    return V;
  }
  static inline PSan::MemberPosition getTombstoneKey() {
    PSan::MemberPosition V(-3);
    return V;
  }
  static unsigned getHashValue(const PSan::MemberPosition &Key) {
    return Key.getHashValue();
  }
  static bool isEqual(const PSan::MemberPosition &LHS, const PSan::MemberPosition &RHS) {
    return LHS == RHS;
  }
};
template <typename T> struct DenseMapInfo<llvm::DenseMap<PSan::MemberPosition, T>> {
  // the magic numbers below (-4, -5) must not collide with the ones above;
  // they must remain valid values
  static inline llvm::DenseMap<PSan::MemberPosition, T> getEmptyKey() {
    llvm::DenseMap<PSan::MemberPosition, T> V;
    V.insert(std::make_pair(PSan::MemberPosition(-4), 0));
    return V;
  }
  static inline llvm::DenseMap<PSan::MemberPosition, T> getTombstoneKey() {
    llvm::DenseMap<PSan::MemberPosition, T> V;
    V.insert(std::make_pair(PSan::MemberPosition(-5), 0));
    return V;
  }
  static unsigned getHashValue(const llvm::DenseMap<PSan::MemberPosition, T> &Key) {
    llvm::DenseMapInfo<T> hashV;
    unsigned result = 0;
    for (const auto& p : Key) {
      unsigned keyhash = p.first.getHashValue();
      unsigned valuehash = hashV.getHashValue(p.second);
      unsigned curVal = llvm::detail::combineHashValue(keyhash, valuehash);
      result = llvm::detail::combineHashValue(result, curVal);
    }
    return result;
  }
  static bool isEqual(const llvm::DenseMap<PSan::MemberPosition, T> &LHS, const llvm::DenseMap<PSan::MemberPosition, T> &RHS) {
    return LHS == RHS;
  }
};
} // end namespace llvm

#endif // EPTG_H
