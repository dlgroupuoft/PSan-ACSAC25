#ifndef PSAN_FAST_DEBUG_DUMPER_H
#define PSAN_FAST_DEBUG_DUMPER_H

#include <cstdint>
#include <cstddef>
#include <string>
#include <memory>
#include <deque>
#include <vector>
#include <thread>
#include "llvm/ADT/DenseMap.h"
#include "llvm/ADT/StringMap.h"
#include "llvm/ADT/StringRef.h"
#include "llvm/ADT/BitVector.h"
#include "llvm/IR/Value.h"
#include "llvm/IR/ModuleSlotTracker.h"
#include "llvm/Support/raw_ostream.h"
#include "Graphs/SVFG.h"
#include "eptg.h"

namespace PSan {

using CacheDataKindType = std::uint8_t;
using EventKindType = std::uint16_t;
using EventIDType = std::uint32_t;

struct DumpCacheNode {
  // each node represents the string dump of an llvm::Value*, an SVFGNode, or some other things that are costly to dump
  // and we want to avoid dumping them multiple times
  std::unique_ptr<std::string> data;
  CacheDataKindType kind = 0;
  bool isAlive = false; // true if this cached entry is still valid and we may add more reference to it
};

class FastDebugDumper;
class DumpEventDeclBase {
private:
  EventKindType kind = 0;
protected:
  DumpEventDeclBase();
  virtual ~DumpEventDeclBase() = default;
  EventKindType getKind() const {return kind;}
public:
  virtual void print(llvm::raw_ostream& os, void* dataptr, EventIDType id) = 0;
  virtual void* detachData() = 0;
  virtual void freeData(void* dataptr) = 0;
};

class FastDebugDumper {
public:
  static constexpr CacheDataKindType CDK_INVALID = 0;
  static constexpr CacheDataKindType CDK_VALUE = 1; // llvm::Value*
  static constexpr CacheDataKindType CDK_SVFGNODE = 2; // SVFGNode* (never invalidated)
  static constexpr CacheDataKindType CDK_TYPE = 3; // llvm::Type* (never invalidated)
  static constexpr CacheDataKindType CDK_EPTGNODE = 4; // EPTGNode* (never invalidated)
  static std::vector<DumpEventDeclBase*> EventDeclVec;
  static llvm::DenseMap<const llvm::Module*, llvm::ModuleSlotTracker*> SlotTrackerMap;

  static FastDebugDumper* instance();
  static void flush();
  static void write_parallel_hint(); // suggest a parallel write
  static llvm::ModuleSlotTracker& getSlotTracker(const llvm::Module* module);
  static const llvm::Module* getModuleFromVal(const llvm::Value *V); // copied from AsmWriter.cpp

  std::string* getString(llvm::StringRef s);
  void write();
  void write_nowait();
  void wait();
  void addEvent(EventKindType kind, EventIDType id);

  const DumpCacheNode* getValueString(llvm::Value* value);
  const DumpCacheNode* getSVFGNodeString(const SVF::SVFGNode* node);
  const DumpCacheNode* getTypeString(llvm::Type* type);
  const DumpCacheNode* getEPTGNodeString(EPTGNode* node);

  // if the value is invalidated, the next time we try to dump it, we will recompute the string
  static void valueModified(llvm::Value* value);

  // to be called when we do value->replaceAllUsesWith(newVal)
  static void valueReplaced(llvm::Value* value);
private:
  struct EventGroup {
    EventIDType id;
    EventIDType num; // if num > 1, this is a group of events with the same kind
    EventKindType kind;
  };
  struct WriteTask {
    llvm::DenseMap<EventKindType, void*> dataMap;
    std::vector<DumpEventDeclBase*> EventDeclVecCopy;
    std::vector<EventGroup> eventList;
  };
  llvm::StringMap<std::string*> stringMap;
  llvm::DenseMap<llvm::Value*, DumpCacheNode*> valueCache;
  llvm::DenseMap<const SVF::SVFGNode*, DumpCacheNode*> svfgNodeCache;
  llvm::DenseMap<llvm::Type*, DumpCacheNode*> typeCache;
  llvm::DenseMap<EPTGNode*, DumpCacheNode*> eptgNodeCache;
  std::vector<EventGroup> eventList;
  llvm::BitVector eventDeclsWithData;
  std::thread* writeThread = nullptr;
  std::size_t eventCount = 0;

  static void writeEntry(WriteTask* task);
  WriteTask* createWriteTask();

  // for now just create a static instance
  static FastDebugDumper d;
};

template<typename T>
struct EventDataStoreTy {
  using DataTy = T;
  T data;
  EventDataStoreTy(FastDebugDumper*, T data) : data(data) {}
  operator T() {return data;}
  operator const T() const {return data;}
};

template<typename T>
using S = EventDataStoreTy<T>;

template<>
struct EventDataStoreTy<llvm::StringRef> {
  using DataTy = std::string*;
  std::string* data;
  EventDataStoreTy(FastDebugDumper* dumper, llvm::StringRef data) : data(dumper->getString(data)) {}
  operator DataTy() {return data;}
};

template<>
struct EventDataStoreTy<const char*> {
  using DataTy = std::string*;
  std::string* data;
  EventDataStoreTy(FastDebugDumper* dumper, const char* data) : data(dumper->getString(llvm::StringRef(data))) {}
  operator DataTy() {return data;}
};

template<>
struct EventDataStoreTy<std::string> {
  using DataTy = std::string*;
  std::string* data;
  EventDataStoreTy(FastDebugDumper* dumper, std::string data) : data(dumper->getString(data)) {}
  operator DataTy() {return data;}
};

template<>
struct EventDataStoreTy<llvm::Value*> {
  using DataTy = const DumpCacheNode*;
  const DumpCacheNode* data;
  EventDataStoreTy(FastDebugDumper* dumper, llvm::Value* data) : data(dumper->getValueString(data)) {}
  operator DataTy() {return data;}
};

template<>
struct EventDataStoreTy<const SVF::SVFGNode*> {
  using DataTy = const DumpCacheNode*;
  const DumpCacheNode* data;
  EventDataStoreTy(FastDebugDumper* dumper, const SVF::SVFGNode* data) : data(dumper->getSVFGNodeString(data)) {}
  operator DataTy() {return data;}
};

template<>
struct EventDataStoreTy<llvm::Type*> {
  using DataTy = const DumpCacheNode*;
  const DumpCacheNode* data;
  EventDataStoreTy(FastDebugDumper* dumper, llvm::Type* data) : data(dumper->getTypeString(data)) {}
  operator DataTy() {return data;}
};

template<>
struct EventDataStoreTy<EPTGNode*> {
  using DataTy = const DumpCacheNode*;
  const DumpCacheNode* data;
  EventDataStoreTy(FastDebugDumper* dumper, EPTGNode* data) : data(dumper->getEPTGNodeString(data)) {}
  operator DataTy() {return data;}
};

template<typename T>
struct EventDataStoreTy<llvm::SmallVector<T>> {
  using DataTy = llvm::SmallVector<EventDataStoreTy<T>>;
  DataTy data;
  EventDataStoreTy(FastDebugDumper* dumper, const llvm::SmallVector<T>& vec) {
    data.reserve(vec.size());
    for (const T& elem : vec) {
      data.emplace_back(dumper, elem);
    }
  }
  operator DataTy() {return data;}
};

template<typename... ArgTys>
struct EventData {
  std::tuple<EventDataStoreTy<ArgTys>...> data;
  EventData(FastDebugDumper* dumper, ArgTys... args) : data(EventDataStoreTy<ArgTys>(dumper, args)...) {}

  template<std::size_t I>
  auto get() const { // -> decltype(std::get<I>(data))
    return std::get<I>(data);
  }

  template<std::size_t I>
  const auto& getref() const {
    return std::get<I>(data);
  }
};

template<typename... CreateCallArgTy>
class DumpEventDecl : public DumpEventDeclBase {
public:
  using StorageTy = EventData<CreateCallArgTy...>;
private:
  std::vector<StorageTy> data;
  std::function<void(llvm::raw_ostream&, const StorageTy&)> printer;
public:
  explicit DumpEventDecl(std::function<void(llvm::raw_ostream&, const StorageTy&)> printer) : printer(printer) {}
  ~DumpEventDecl() override = default;
  void operator()(CreateCallArgTy... args) {
    FastDebugDumper* dumper = FastDebugDumper::instance();
    std::size_t id = data.size();
    if (id >= std::numeric_limits<EventIDType>::max()) {
      llvm_unreachable("EventIDType too small to hold all events");
    }
    this->data.emplace_back(dumper, args...);
    dumper->addEvent(getKind(), id);
  }
  virtual void print(llvm::raw_ostream& os, void* dataptr, EventIDType id) override {
    std::vector<StorageTy>* ptr = reinterpret_cast<std::vector<StorageTy>*>(dataptr);
    if (id >= ptr->size()) {
      llvm_unreachable("EventID out of range");
    }
    printer(os, ptr->at(id));
  }
  virtual void* detachData() override {
    decltype(data)* ptr = new decltype(data)();
    ptr->swap(data);
    return ptr;
  }
  virtual void freeData(void* dataptr) override {
    delete reinterpret_cast<decltype(data)*>(dataptr);
  }
};

template<>
class DumpEventDecl<> : public DumpEventDeclBase {
public:
  using StorageTy = char;
private:
  std::size_t numEvents = 0;
  const char* printer = nullptr;
public:
  explicit DumpEventDecl(const char* printer) : printer(printer) {}
  ~DumpEventDecl() override = default;
  void operator()() {
    FastDebugDumper* dumper = FastDebugDumper::instance();
    std::size_t id = numEvents;
    if (id >= std::numeric_limits<EventIDType>::max()) {
      llvm_unreachable("EventIDType too small to hold all events");
    }
    ++numEvents;
    dumper->addEvent(getKind(), id);
  }
  virtual void print(llvm::raw_ostream& os, void* dataptr, EventIDType id) override {
    (void) dataptr;
    if (printer) {
      os << printer;
    }
  }
  virtual void* detachData() override {
    numEvents = 0;
    return nullptr;
  }
  virtual void freeData(void* dataptr) override {
    (void) dataptr;
  }
};

} // namespace PSan

inline llvm::raw_ostream& operator<<(llvm::raw_ostream& os, const PSan::DumpCacheNode* node) {
  if (node) {
    os << *node->data;
  }
  return os;
}

inline llvm::raw_ostream& operator<<(llvm::raw_ostream& os, const std::string* data) {
  if (data) {
    os << *data;
  }
  return os;
}

template<typename T>
llvm::raw_ostream& operator<<(llvm::raw_ostream& os, const PSan::EventDataStoreTy<T>& data) {
  os << data.data;
  return os;
}

template<typename T>
llvm::raw_ostream& operator<<(llvm::raw_ostream& os, const llvm::SmallVector<PSan::EventDataStoreTy<T>>& data) {
  os << "[";
  bool first = true;
  for (const PSan::EventDataStoreTy<T>& elem : data) {
    if (!first) {
      os << ", ";
    }
    os << elem;
    first = false;
  }
  os << "]";
  return os;
}


#endif // PSAN_FAST_DEBUG_DUMPER_H
