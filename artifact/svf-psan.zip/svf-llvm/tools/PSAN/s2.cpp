#include "psan.h"
#include "FastDebugDumper.h"
#include "s2.h"
#include <llvm/ADT/StringMap.h>

using namespace PSan;

void step2_preparation_safeGVIdentification(llvm::Module* srcModule, PreTransformResult& decisions)
{
  // for global variables without pointers and are not address-taken,
  // it is more efficient to store them to a separate data structure than leaving them in the trimmed IR
  // this would also allow trimming away accesses on these global variables and make more function empty
  // in this way we can further shrink down the trimmed IR to speed up analysis

  // helper for checking whether a value (global variable) only has load/store/gep/cast(i8*)/mem-intrinsics uses
  // if so, we don't bother to keep them in the trimmed IR
  std::function<bool(llvm::Value*)> helper_hasPotentiallyUnsafeUse = [&](llvm::Value* v) -> bool {
    for (auto& u : v->uses()) {
      llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(u.getUser());
      if (!instr) {
        static DumpEventDecl<llvm::Value*> userEvent([](llvm::raw_ostream& os, const EventData<llvm::Value*>& data) {
          os << "  Non-instruction user: " << data.get<0>() << "\n";
        });
        PSAN_DEBUG(userEvent(u.getUser()));
        return true;
      }


      if (llvm::LoadInst* load = llvm::dyn_cast<llvm::LoadInst>(instr)) {
        (void) load;
        continue;
      }
      if (llvm::StoreInst* store = llvm::dyn_cast<llvm::StoreInst>(instr)) {
        if (store->getPointerOperandIndex() != u.getOperandNo()) {
          static DumpEventDecl<llvm::Value*> storeEvent([](llvm::raw_ostream& os, const EventData<llvm::Value*>& data) {
            os << "  Store not as address: " << data.get<0>() << "\n";
          });
          PSAN_DEBUG(storeEvent(store));
          return true;
        }
        continue;
      }
      if (llvm::GetElementPtrInst* gep = llvm::dyn_cast<llvm::GetElementPtrInst>(instr)) {
        if (helper_hasPotentiallyUnsafeUse(gep)) {
          static DumpEventDecl<llvm::Value*> fallbackEvent([](llvm::raw_ostream& os, const EventData<llvm::Value*>& data) {
            os << "  Fallback from:" << data.get<0>() << "\n";
          });
          PSAN_DEBUG(fallbackEvent(gep));
          return true;
        }
        continue;
      }
      if (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(instr)) {
        // only allowing cast to i8*, which are present before calls to memory intrinsics
        if (!getPointerElementType(bc->getType())->isIntegerTy(8)) {
          static DumpEventDecl<llvm::Value*> castEvent([](llvm::raw_ostream& os, const EventData<llvm::Value*>& data) {
            os << "  Casting to non-i8* value:" << data.get<0>() << "\n";
          });
          PSAN_DEBUG(castEvent(bc));
          return true;
        }
        if (helper_hasPotentiallyUnsafeUse(bc)) {
          static DumpEventDecl<llvm::Value*> fallbackEvent([](llvm::raw_ostream& os, const EventData<llvm::Value*>& data) {
            os << "  Fallback from:" << data.get<0>() << "\n";
          });
          PSAN_DEBUG(fallbackEvent(bc));
          return true;
        }
        continue;
      }
      if (llvm::CallInst* call = llvm::dyn_cast<llvm::CallInst>(instr)) {
        switch (call->getIntrinsicID())
        {
        default: {
          static DumpEventDecl<llvm::Value*> callEvent([](llvm::raw_ostream& os, const EventData<llvm::Value*>& data) {
            os << "  Unrecognized call:" << data.get<0>() << "\n";
          });
          PSAN_DEBUG(callEvent(call));
          return true;
        }
        case llvm::Intrinsic::memcpy:
        case llvm::Intrinsic::memset:
        case llvm::Intrinsic::memmove:
        case llvm::Intrinsic::memcpy_element_unordered_atomic:
        case llvm::Intrinsic::memset_element_unordered_atomic:
        case llvm::Intrinsic::memmove_element_unordered_atomic:
          break;
        }
        continue;
      }
      // if we reach here, we got a use that is not in the permitted category
      static DumpEventDecl<llvm::Value*> instrEvent([](llvm::raw_ostream& os, const EventData<llvm::Value*>& data) {
        os << "  Unrecognized instr user:" << data.get<0>() << "\n";
      });
      PSAN_DEBUG(instrEvent(instr));
      return true;
    }
    return false;
  };
  for (auto& GV : srcModule->globals()) {
    if (decisions.taintedValues.contains(&GV))
      continue;
    // first, check whether this global variable contains pointers
    if (isTypeContainPointer(GV.getValueType()))
      continue;
    // then, check if there is any use that are not load/store/gep/cast/mem-intrinsics
    GV.removeDeadConstantUsers();
    if (helper_hasPotentiallyUnsafeUse(&GV)) {
      static DumpEventDecl<llvm::Value*> unsafeEvent([](llvm::raw_ostream& os, const EventData<llvm::Value*>& data) {
        os << "GV has unsafe use: " << data.get<0>() << "\n";
      });
      PSAN_DEBUG(unsafeEvent(&GV));
      continue;
    }
    // ok, now all check passed
    decisions.safeGVs.insert(&GV);
    static DumpEventDecl<llvm::Value*> safeEvent([](llvm::raw_ostream& os, const EventData<llvm::Value*>& data) {
      os << "GV assumed safe: " << data.get<0>() << "\n";
    });
    PSAN_DEBUG(safeEvent(&GV));
  }
}

llvm::DenseSet<llvm::Value*> step2_preparation_mergetaints(llvm::Module* srcModule, PreTransformResult& decisions)
{
  // the source taintedValues only contain values from opaque regions
  // for trimming, besides these tainted values, we also want to exclude values that do not have to be in the trimmed IR
  // example is (1) global variables / arrays with only load/store/gep/cast/mem-intrinsics, (2) compiler-introduced weird stuff
  // here we merge all of them together
  llvm::DenseSet<llvm::Value*> result;
  result.insert(decisions.taintedValues.begin(), decisions.taintedValues.end());
  result.insert(decisions.safeGVs.begin(), decisions.safeGVs.end());
  for (const auto& p : decisions.excludeValues) {
    result.insert(p.first);
  }

  // add geps from the safeGV users
  std::function<void(llvm::Instruction*)> taintSafeGVUsers = [&](llvm::Instruction* instr) -> void {
    result.insert(instr);
    for (auto& u : instr->uses()) {
      if (llvm::GetElementPtrInst* gep = llvm::dyn_cast<llvm::GetElementPtrInst>(u.getUser())) {
        if (!result.contains(gep)) {
          taintSafeGVUsers(gep);
        }
      }
      if (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(u.getUser())) {
        if (!result.contains(bc)) {
          taintSafeGVUsers(bc);
        }
      }
    }
  };
  for (llvm::GlobalVariable* gv : decisions.safeGVs) {
    for (auto& u : gv->uses()) {
      llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(u.getUser());
      if (instr && (llvm::isa<llvm::GetElementPtrInst>(instr) ||llvm::isa<llvm::BitCastInst>(instr))) {
        taintSafeGVUsers(instr);
      }
    }
  }
  return result;
}

llvm::Module* PSan::step2_clone(llvm::Module* srcModule, PreTransformResult& decisions, llvm::ValueToValueMapTy& mapping, llvm::DenseMap<llvm::Value*,llvm::Value*>& taintedClones, StaticStats& stats)
{
  // do all before-trim logic first
  step2_preparation_safeGVIdentification(srcModule, decisions);
  llvm::DenseSet<llvm::Value*> excluded = step2_preparation_mergetaints(srcModule, decisions);

  // because when we request do not clone something, it means only keeping the declaration instead of not cloning it altogether,
  // we will just clone everything first and then drop the ones we don't need
  // to simplify handling globals, we still request to drop the initializer of globals that we don't use
  auto cloningResult = llvm::CloneModule(*srcModule, mapping, [&](const llvm::GlobalValue* v) -> bool {
    if (const llvm::GlobalVariable* gv = llvm::dyn_cast<const llvm::GlobalVariable>(v)) {
      // always preserve llvm intrinsic globals
      if (gv->getName().startswith("llvm."))
        return true;
      return (!excluded.contains(gv));
    }
    return true;
  });
  // check if we cloned any function; if none, just drop the module
  if (cloningResult.get()->functions().empty()) {
    cloningResult.reset(nullptr);
    return nullptr;
  }
  // just for debugging purpose; check what are included in the mapping
  // we will keep this so that if the assumption breaks in some programs, we will be able to find them
  {
    std::size_t numFunctions = 0;
    std::size_t numBBs = 0;
    std::size_t numInstrs = 0;
    std::size_t numGVs = 0;
    std::size_t numCExprs = 0;
    std::size_t numCData = 0;
    std::size_t numCAggr = 0;
    std::size_t numArgs = 0;
    std::size_t numOthers = 0;
    std::size_t numMd = 0;
    std::size_t numAlias = 0;
    std::size_t numASMs = 0;
    for (const auto& p : mapping) {
      llvm::Value* original = const_cast<llvm::Value*>(p.first);
      if (!p.second.pointsToAliveValue()) {
        static DumpEventDecl<llvm::Value*> deadEvent([](llvm::raw_ostream& os, const EventData<llvm::Value*>& data) {
          os << "Value dead after clone: " << data.get<0>() << "\n";
        });
        PSAN_DEBUG(deadEvent(original));
      }
      if (llvm::isa<llvm::Function>(original)) {
        numFunctions += 1;
        assert (p.second != original);
      } else if (llvm::isa<llvm::BasicBlock>(original)) {
        numBBs += 1;
        assert (p.second != original);
      } else if (llvm::isa<llvm::Instruction>(original)) {
        numInstrs += 1;
        assert (p.second != original);
      } else if (llvm::isa<llvm::GlobalVariable>(original)) {
        numGVs += 1;
        assert (p.second != original);
      } else if (llvm::isa<llvm::ConstantExpr>(original)) {
        numCExprs += 1;
        // it is not clear whether the original is guaranteed to be the same or different
        //assert (p.second != original);
      } else if (llvm::isa<llvm::ConstantData>(original)) {
        numCData += 1;
        assert (p.second == original);
      } else if (llvm::isa<llvm::ConstantAggregate>(original)) {
        numCAggr += 1;
        // it is not clear whether the original is guaranteed to be the same or different
        // it depends on what is inside the aggregate
        // assert (p.second != original);
      } else if (llvm::isa<llvm::Argument>(original)) {
        numArgs += 1;
        assert (p.second != original);
      } else if (llvm::isa<llvm::MetadataAsValue>(original)) {
        numMd += 1;
      } else if (llvm::isa<llvm::GlobalAlias>(original)) {
        numAlias += 1;
        assert (p.second != original);
      } else if (llvm::isa<llvm::InlineAsm>(original)) {
        numASMs += 1;
      } else {
        numOthers += 1;
      }
    }
    static DumpEventDecl<std::size_t, std::size_t, std::size_t, std::size_t, std::size_t, std::size_t, std::size_t, std::size_t, std::size_t, std::size_t, std::size_t, std::size_t, std::size_t>
    statsEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t, std::size_t, std::size_t, std::size_t, std::size_t, std::size_t, std::size_t, std::size_t, std::size_t, std::size_t, std::size_t, std::size_t>& data) {
      os << "step2_clone: " << data.get<0>() << " entries\n";
      os << data.get<1>() << " functions, "
          << data.get<2>() << " basic blocks, "
          << data.get<3>() << " instructions, "
          << data.get<4>() << " global variables, "
          << data.get<5>() << " constant expressions, "
          << data.get<6>() << " constant data, "
          << data.get<7>() << " constant aggregates, "
          << data.get<8>() << " arguments, "
          << data.get<9>() << " metadata, "
          << data.get<10>() << " aliases, "
          << data.get<11>() << " inline asms, "
          << data.get<12>() << " others" << "\n";
    });
    PSAN_DEBUG(statsEvent(mapping.size(), numFunctions, numBBs, numInstrs, numGVs, numCExprs, numCData, numCAggr, numArgs, numMd, numAlias, numASMs, numOthers));
    assert (numOthers == 0);
  }
  auto getLiveValue = [&](llvm::Value* src) -> llvm::Value* {
    auto iter = mapping.find(src);
    assert (iter != mapping.end());
    assert (iter->second.pointsToAliveValue());
    llvm::Value* v = &*iter->second;
    assert (v != nullptr);
    return v;
  };
  auto checkSafeForErasing = [](llvm::Value* v) -> void {
    if (v->use_empty())
      return;
    if (!isNoDebugPrint()) {
      auto& os = PSan::outs_before_unreachable();
      os << "Value not safe for erasing: ";
      v->print(os, true);
      os << "\n";
      for (const auto& u : v->uses()) {
        os << "  Arg " << u.getOperandNo() << " of ";
        u.getUser()->print(os, true);
        os << "\n";
      }
    }
    psan_unreachable("Erasing value with user");
  };

  // helper to create functions that create placeholder values
  // whenever we replace dataflow with a placeholder value, we create a call to the function defined here
  PlaceholderFunctionManager placeholders(cloningResult.get());

  // let's deal with the tainted globals; we need to update references to them and drop them in the trimmed code
  // for tainted global variables, because the user is likely to be tainted or to be removed as well, we can just replace the use
  // for simple safe global variables, the user is likely doing load/store on this and we can removed
  auto replaceUseWithPlaceholder = [&](llvm::Use& u, llvm::DenseMap<llvm::Use*, llvm::Value*>& replacements) -> void {
    llvm::User* rawuser = u.getUser();
    llvm::Instruction* user = llvm::dyn_cast<llvm::Instruction>(rawuser);
    if (!user) {
      // something is wrong; in previous stages we did not taint all related global variables
      // to assist debugging, we here print necessary information
      if (!isNoDebugPrint()) {
        auto& os = PSan::outs_before_unreachable();
        os << "Excluded GV used in: ";
        rawuser->print(os, true);
        os << "\nValue used at:\n";
        for (auto& vu : rawuser->uses()) {
          os << "  [" << vu.getOperandNo() << "] ";
          vu.getUser()->print(os, true);
          os << "\n";
        }
      }
      psan_unreachable("excluded global variables has non-instruction user");
    }
    llvm::Function* parent = user->getFunction();
    llvm::Value* placeholder = placeholders.getPlaceholderValue(parent, u.get()->getType());
    replacements.insert(std::make_pair(&u, placeholder));
  };
  std::function<void(llvm::Use&, llvm::DenseMap<llvm::Use*, llvm::Value*>&)> replaceGVUseRecursive =
   [&](llvm::Use& u, llvm::DenseMap<llvm::Use*, llvm::Value*>& replacements) -> void {
    // there are two cases we need to consider for the users:
    // 1. instruction users
    // 2. constexpr users that are also instruction operands
    // whenever seeing situation 2, we recurse on the constexpr and replace all uses of this constexpr first
    // for situation 1, we use replaceUseWithPlaceholder()
    llvm::User* rawuser = u.getUser();
    if (llvm::isa<llvm::Instruction>(rawuser)) {
      replaceUseWithPlaceholder(u, replacements);
      return;
    }
    if (llvm::ConstantExpr* cexpr = llvm::dyn_cast<llvm::ConstantExpr>(rawuser)) {
      for (auto& vu : cexpr->uses()) {
        replaceGVUseRecursive(vu, replacements);
      }
      return;
    }
    if (llvm::ConstantAggregate* caggr = llvm::dyn_cast<llvm::ConstantAggregate>(rawuser)) {
      for (auto& vu : caggr->uses()) {
        replaceGVUseRecursive(vu, replacements);
      }
      return;
    }
    psan_unreachable("Unexpected user type");
  };
  for (llvm::GlobalVariable& GV : srcModule->globals()) {
    if (excluded.contains(&GV)) {
      auto iter = mapping.find(&GV);
      assert (iter != mapping.end());
      llvm::GlobalVariable* clonedGV = llvm::cast<llvm::GlobalVariable>(iter->second);
      llvm::DenseMap<llvm::Use*, llvm::Value*> replacements;
      for (auto& u : clonedGV->uses()) {
        replaceGVUseRecursive(u, replacements);
      }
      for (auto& p : replacements) {
        p.first->set(p.second);
      }
      clonedGV->removeDeadConstantUsers();
      checkSafeForErasing(clonedGV);
      clonedGV->eraseFromParent();
    }
  }

  // now go through each function, eliminate code that (1) does not affect pointer dataflow (e.g., producing integer / fp results), (2) work on pointers in opaque region
  for (auto& Src : srcModule->functions()) {
    if (Src.getBasicBlockList().empty())
      continue;

    llvm::Function* clonedFunc = llvm::cast<llvm::Function>(getLiveValue(&Src));
    if (excluded.contains(&Src)) {
      taintedClones.insert(std::make_pair(clonedFunc, &Src));
    }

    // first of all, if any parameters are tainted, replace all uses
    for (auto& SrcArg : Src.args()) {
      if (!SrcArg.getType()->isPointerTy()) {
        continue;
      }
      if (excluded.contains(&SrcArg)) {
        llvm::Argument* replacedArg = clonedFunc->getArg(SrcArg.getArgNo());
        llvm::Value* replacementValue = placeholders.getPlaceholderValue(clonedFunc, replacedArg->getType());
        replacedArg->replaceAllUsesWith(replacementValue);
        taintedClones.insert(std::make_pair(replacedArg, &SrcArg));
      }
    }
    // then, go through the function body and remove unnecessary code
    for (auto& SrcBB : Src.getBasicBlockList()) {
      llvm::BasicBlock* clonedBlock = llvm::cast<llvm::BasicBlock>(getLiveValue(&SrcBB));
      (void) clonedBlock;
      for (auto& SrcI : SrcBB) {
        llvm::Instruction* srcInstr = &SrcI;
        llvm::Instruction* clonedInstr = llvm::cast<llvm::Instruction>(getLiveValue(srcInstr));
        if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(srcInstr)) {
          // when encountering call instruction, we may (1) taint return value if applicable, (2) remove the call whenever possible
          // if calling intrinsic: we remove the call unless it is memset/... and its argument is not tainted
          // if directly calling removed function: remove the call
          // if directly calling preserved function: preserve the call, taint return value if needed
          // if call is indirect and the callee pointer is tainted: replace the callee to call the approximator function
          // if call is indirect and the callee is not tainted: preserve the call
          // if calling inline assembly: remove the call (the operands and the return values should all be tainted anyway)
          // UPDATE: we now do not try to remove any function calls to defined functions
          // so now we always preserve the call, although if the return value is tainted, we just replace the operands
          // for calls to externally defined functions, we still try to remove them because we cannot change the memory layout of parameters
          bool shouldRemove = false;
          if (llvm::Function* func = call->getCalledFunction()) {
            if (!func->isIntrinsic() && func->getBasicBlockList().empty()) {
              // we want to preserve intrinsics like memcpy, memset, etc.
              if (!isAllocatorCall(call)) {
                shouldRemove = true;
              }
            }
          }
          bool shouldReplace = shouldRemove;
          if (call->getType()->isPointerTy()) {
            if (excluded.contains(call)) {
              shouldReplace = true;
            }
          } else {
            // for non-pointer values, we also replace their use here
            // this makes it easier to remove the call later on
            shouldReplace = true;
          }
          if (shouldReplace && !call->getType()->isVoidTy()) {
            llvm::Value* replacementValue = placeholders.getPlaceholderValue(clonedFunc, clonedInstr->getType());
            clonedInstr->replaceAllUsesWith(replacementValue);
          }
          if (shouldRemove) {
            checkSafeForErasing(clonedInstr);
            clonedInstr->eraseFromParent();
          } else if (shouldReplace) {
            taintedClones.insert(std::make_pair(clonedInstr, srcInstr));
          }
          continue;
        }
        auto handleLoadLikeInstr = [&](llvm::Instruction* instr, llvm::Value* ptrArg) -> void {
          // if we are loading from an untainted pointer, we preserve the load even if the load result is tainted
          bool isShouldErase = false;
          if (excluded.contains(ptrArg)) {
            isShouldErase = true;
          }
          bool isShouldReplace = isShouldErase;
          if (!isShouldReplace && instr->getType()->isPointerTy()) {
            if (excluded.contains(instr)) {
              isShouldReplace = true;
            }
          }
          if (isShouldReplace) {
            llvm::Value* replacementValue = placeholders.getPlaceholderValue(clonedFunc, clonedInstr->getType());
            clonedInstr->replaceAllUsesWith(replacementValue);
          }
          if (isShouldErase) {
            checkSafeForErasing(clonedInstr);
            clonedInstr->eraseFromParent();
          } else if (isShouldReplace) {
            taintedClones.insert(std::make_pair(clonedInstr, srcInstr));
          }
        };
        if (llvm::LoadInst* load = llvm::dyn_cast<llvm::LoadInst>(srcInstr)) {
          handleLoadLikeInstr(load, load->getPointerOperand());
          continue;
        }
        if (llvm::StoreInst* store = llvm::dyn_cast<llvm::StoreInst>(srcInstr)) {
          // if we are storing using an untainted pointer, we preserve the store
          // otherwise, just drop it
          llvm::Value* ptr = store->getPointerOperand();
          if (excluded.contains(ptr)) {
            checkSafeForErasing(clonedInstr);
            clonedInstr->eraseFromParent();
          }
          continue;
        }
        if (llvm::AtomicRMWInst* rmw = llvm::dyn_cast<llvm::AtomicRMWInst>(srcInstr)) {
          handleLoadLikeInstr(rmw, rmw->getPointerOperand());
          continue;
        }
        if (llvm::AtomicCmpXchgInst* cmpxchg = llvm::dyn_cast<llvm::AtomicCmpXchgInst>(srcInstr)) {
          handleLoadLikeInstr(cmpxchg, cmpxchg->getPointerOperand());
          continue;
        }
        if (llvm::ICmpInst* icmp = llvm::dyn_cast<llvm::ICmpInst>(srcInstr)) {
          llvm::Value* lhs = icmp->getOperand(0);
          llvm::Value* rhs = icmp->getOperand(1);
          if (lhs->getType()->isPointerTy() && !excluded.contains(lhs) && !excluded.contains(rhs)) {
            // if we are comparing two pointers and none of them are tainted, we preserve the clone
            continue;
          }
          // otherwise we drop it
          llvm::Value* replacementValue = placeholders.getPlaceholderValue(clonedFunc, clonedInstr->getType());
          clonedInstr->replaceAllUsesWith(replacementValue);
          checkSafeForErasing(clonedInstr);
          clonedInstr->eraseFromParent();
          continue;
        }
        // for the rest of instructions, if (1) they are producing tainted value, or (2) they are not producing pointer-type values, we drop them
        if (srcInstr->isTerminator()) {
          continue;
        }
        bool shouldRemove = false;
        if (srcInstr->getType()->isPointerTy()) {
          if (excluded.contains(srcInstr)) {
            shouldRemove = true;
          }
        } else if (srcInstr->getType()->isPointerTy()) {
          // should be a function pointer
          // do nothing here
        } else {
          shouldRemove = true;
        }
        if (shouldRemove) {
          if (!clonedInstr->getType()->isVoidTy()) {
            llvm::Value* replacementValue = placeholders.getPlaceholderValue(clonedFunc, clonedInstr->getType());
            clonedInstr->replaceAllUsesWith(replacementValue);
          }
          checkSafeForErasing(clonedInstr);
          clonedInstr->eraseFromParent();
        }
      }
    }
  }

  // all functions are processed and we are done
  StaticStats::setTime(stats.s2_cloneTime);
  auto collectStats = [](StaticStats& stats, llvm::Module* dest, bool isPre) -> void {
    for (auto& GV : dest->globals()) {
      (void) GV;
      stats.S2Prune_GlobalVariableCount.increment(isPre);
    }
    for (auto& F : dest->functions()) {
      if (F.getBasicBlockList().empty())
        continue;
      stats.S2Prune_FunctionCount.increment(isPre);
      for (auto& BB : F) {
        stats.S2Prune_BasicBlockCount.increment(isPre);
        for (auto& I : BB) {
          (void) I;
          stats.S2Prune_InstructionCount.increment(isPre);
        }
      }
    }
  };
  if (!isNoStaticStats()) {
    collectStats(stats, cloningResult.get(), true);
  }
  step2_pruning_entry(cloningResult.get(), decisions, mapping, taintedClones, stats, placeholders);
  if (!isNoStaticStats()) {
    collectStats(stats, cloningResult.get(), false);
  }
  StaticStats::setTime(stats.s2_finishTime);
  return cloningResult.release();
}