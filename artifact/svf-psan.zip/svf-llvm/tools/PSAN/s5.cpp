#include "psan.h"
#include "s5.h"
#include "FastDebugDumper.h"
#include <deque>
#include "llvm/IR/InlineAsm.h"
#include "llvm/IR/Verifier.h"
#include "llvm/IR/ModuleSlotTracker.h"
#include "llvm/Analysis/ConstantFolding.h"

using namespace PSan;
using namespace SVF;
using namespace SVF::SVFUtil;

// if runtime stats collection is enabled, we use this to annotate allocations in EPTG so that later on we can distinguish them
const char* const PSan::PSanInstrumentationManager::psan_eptg_alloc_md = "psan_eptg_alloc";

llvm::Module* PSan::step5_instrument(llvm::Module* srcModule, GraphConstructionResults& graphs, InstrumentationListType& instrumentations, const InstrumentationOptions& options, InstrumentationPlan& plan, StaticStats& stats)
{
  PSanInstrumentationManager manager(srcModule->getContext(), graphs, instrumentations, options, plan, stats, srcModule);
  return manager.run();
}

PSanInstrumentationManager::PSanInstrumentationManager(llvm::LLVMContext& ctx, PSan::GraphConstructionResults& graphs, PSan::InstrumentationListType& instrumentations, const PSan::InstrumentationOptions& options, PSan::InstrumentationPlan& plan, PSan::StaticStats& stats, llvm::Module* srcModule)
  : ctx(ctx), graphs(graphs), instrumentations(instrumentations), options(options), plan(plan), stats(stats), srcModule(srcModule) {
  clonedModule = llvm::CloneModule(*srcModule, valueMap).release();
  i64Ty = llvm::Type::getInt64Ty(ctx);
  i32Ty = llvm::Type::getInt32Ty(ctx);
  i8Ty = llvm::Type::getInt8Ty(ctx);
  i8PtrTy = llvm::Type::getInt8PtrTy(ctx);
  i64zero = llvm::ConstantInt::get(i64Ty, 0);
  i32zero = llvm::ConstantInt::get(i32Ty, 0);

  lifetimeStart = llvm::Intrinsic::getDeclaration(clonedModule, llvm::Intrinsic::lifetime_start, {i8PtrTy});
  lifetimeEnd = llvm::Intrinsic::getDeclaration(clonedModule, llvm::Intrinsic::lifetime_end, {i8PtrTy});
  memsetFunc = llvm::Intrinsic::getDeclaration(clonedModule, llvm::Intrinsic::memset, {i8PtrTy, i64Ty});

  functionsWithHiddenCalls = step1_getFunctionsWithHiddenCalls(srcModule);
  slotTracker = &FastDebugDumper::getSlotTracker(clonedModule);
}

llvm::Module* PSanInstrumentationManager::run()
{
  preparation();

  if (oobMetadataType) {
    auto& layout = clonedModule->getDataLayout();
    auto mdsize = layout.getTypeAllocSize(oobMetadataType);
    auto mdalign = layout.getABITypeAlignment(oobMetadataType);
    mdscheme = new TwoLevelTrieMetadataScheme(clonedModule->getContext(), options, mdsize, mdalign, clonedModule);
  }

  for (auto* instrumentation : instrumentations) {
    instrumentation->prepareInstrumentation(options, clonedModule);
  }

  if (isEnableRuntimePrintDebug()) {
    ppd = new PSanPrintDebugger(*clonedModule);
    ppd->init();
    // ppd->addExcludedCalleePrefix("__psan_");
    llvm::SmallVector<std::string> mayAbortHelpers;
    for (auto* instrumentation : instrumentations) {
      instrumentation->populateHelperFunctionsThatMayAbort(mayAbortHelpers);
    }
    for (const std::string& func : mayAbortHelpers) {
      ppd->addMayAbortCallee(func);
    }

    ppd->instrument(/*skipCalls*/true);
  }
  if (isCollectRuntimeStats()) {
    initRuntimeStatsCollection();
  }

  convertCheckInfo();
  stats.setTime(stats.s5_prepTime);
  replaceDefinitions();
  dumpIR(clonedModule, "inst_1_replacedef");
  replacePointerLoadStores();
  dumpIR(clonedModule, "inst_2_ptrls");
  handleCallsForMDProp();
  dumpIR(clonedModule, "inst_3_calls");
  handleSizeUpdates();
  dumpIR(clonedModule, "inst_4_sizeupdate");
  handleEPTGTypeTransform();
  dumpIR(clonedModule, "inst_5_eptg");
  stats.setTime(stats.s5_transformTime);
  handleMetadataPropagation();
  reapPlaceholders(false);
  dumpIR(clonedModule, "inst_6_mdprop");
  stats.setTime(stats.s5_mdpropTime);
  reapPlaceholders();
  trivialOptimization();
  sanityCheck();

  if (ppd) {
    ppd->instrumentCalls();
  }

  for (auto* instrumentation : instrumentations) {
    instrumentation->finalize(clonedModule);
  }
  if (mdscheme) {
    mdscheme->finalize();
  }
  if (isCollectRuntimeStats()) {
    linkInLibrary(clonedModule, PSAN_RTPATH_RT_PSanRTStats);
  }
  linkInLibrary(clonedModule, PSAN_RTPATH_RT_PSanSupport);
  stats.setTime(stats.s5_finishTime);
  return clonedModule;
}

void PSanInstrumentationManager::preparation()
{
  // here we do preparation that needs to be done before replacing any constructs in the cloned IR
  // (e.g., queueing load/store for metadata propagation without confusing them with load/store from function interface changes)

  if (instrumentations.size() > MaxNumCheckingSchemes) {
    psan_unreachable("Too many checking schemes (need to update MaxNumCheckingSchemes)");
  }

  // we pre-compute the additional parameters for pointer metadata
  // in-register representation first
  // when passing metadata across function boundary, we do not bother the instrumentation scheme for in-mem/in-reg conversion;
  // we just copy the in-reg representation around
  mdvecWithAll = 0;
  unsigned curbit = 1;

  for (unsigned instrumentationIndex = 0, n = instrumentations.size(); instrumentationIndex < n; ++instrumentationIndex) {
    auto* instrumentation = instrumentations[instrumentationIndex];
    const auto& mdTypes = instrumentation->getPointerMetadataTypesInRegisters();
    if (!mdTypes.empty()) {
      std::size_t curIndex = nonEPTGPtrMetadataParamTypes.size();
      nonEPTGPtrMetadataParamTypes.append(mdTypes);
      mdvecWithAll |= curbit;
      llvm::SmallVector<llvm::SmallVector<llvm::Value*>> gepIndices;
      for (std::size_t i = 0, n = mdTypes.size(); i < n; ++i) {
        llvm::SmallVector<llvm::Value*> innerIndices;
        std::size_t gepSecondIndex = curIndex + i;
        llvm::Value* gepSecondIndexVal = llvm::ConstantInt::get(i32Ty, gepSecondIndex);
        gepIndices.push_back({i64zero, gepSecondIndexVal});
      }
      retMDGEPIndices_nonEPTG.insert(std::make_pair(instrumentationIndex, gepIndices));
    }
    curbit <<= 1;
  }
  if (!nonEPTGPtrMetadataParamTypes.empty()) {
    if (nonEPTGPtrMetadataParamTypes.size() == 1) {
      retMDPointsToType = nonEPTGPtrMetadataParamTypes.front();
      retMDGEPIndices_nonEPTG.clear();
    } else {
      retMDPointsToType = llvm::StructType::get(clonedModule->getContext(), nonEPTGPtrMetadataParamTypes);
    }
    retMDAppendParamType = llvm::PointerType::get(retMDPointsToType, 0);
  }

  // now get oobMetadataType
  // if there is only one instrumentation scheme, we directly use its in-memory representation
  // if there are more than one, we use a struct to hold all the metadata
  llvm::SmallVector<llvm::Type*> inMemMDTypes;
  for (unsigned i = 0, n = instrumentations.size(); i < n; ++i) {
    llvm::Type* mdType = instrumentations[i]->getPointerMetadataTypeInMemory();
    if (!mdType) {
      continue;
    }
    indicesForOOBMetadata.push_back(i);
    inMemMDTypes.push_back(mdType);
  }
  if (inMemMDTypes.empty()) {
    oobMetadataType = nullptr;
  } else {
    if (PSan::isConservativeOOB()) {
      // make a copy of the pointer value so that we can detect stale metadata
      // (this is to handle pointer modification in uninstrumented code)
      inMemMDTypes.push_back(i8PtrTy);
    }
    if (inMemMDTypes.size() == 1) {
      oobMetadataType = inMemMDTypes.front();
    } else {
      llvm::StructType* sTy = llvm::StructType::create(clonedModule->getContext(), inMemMDTypes, "__psan_oobmd");
      oobMetadataType = sTy;
    }
  }

  auto isLoadStoreValueContainsPointer = [](llvm::Type* ty) -> bool {
    if (ty->isPointerTy()) {
      return true;
    }
    if (llvm::VectorType* vTy = llvm::dyn_cast<llvm::VectorType>(ty)) {
      return vTy->getElementType()->isPointerTy();
    }
    return false;
  };
  auto isLoadStoreValueContainsDataPointer = [](llvm::Type* ty) -> bool {
    if (isDataPointerTy(ty)) {
      return true;
    }
    if (llvm::VectorType* vTy = llvm::dyn_cast<llvm::VectorType>(ty)) {
      return isDataPointerTy(vTy->getElementType());
    }
    return false;
  };
  auto isArgRetTypeContainsPointer = [](llvm::Type* ty) -> bool {
    // we don't expect function call arguments / return values to be vector types
    // otherwise it is identical to isLoadStoreValueContainsPointer
    // UPDATE: umm we have llvm intrinsics that indeed have vector type return values...
    if (llvm::VectorType* vTy = llvm::dyn_cast<llvm::VectorType>(ty)) {
      return vTy->getElementType()->isPointerTy();
    }
    return ty->isPointerTy();
  };

  llvm::DenseSet<llvm::Value*> forStats_ImplicitValuesInEPTG;
  const unsigned TAINTED_ALLOC_GLOBAL = 0;
  const unsigned TAINTED_ALLOC_LOCAL = 1;
  {
    llvm::SmallVector<std::string> allocTypes = {"NonEPTG_Global_Tys", "NonEPTG_Local_Tys"};
    stats.S5_TaintedAllocTypes.init(allocTypes);
  }
  llvm::DenseMap<llvm::Value*, ExpressionEPTGNode*> eptgExprNodeMap;
  if (graphs.eptg) {
    for (auto iter = graphs.eptg->begin(), iterEnd = graphs.eptg->end(); iter != iterEnd; ++iter) {
      if (AllocEPTGNode* allocNode = llvm::dyn_cast<AllocEPTGNode>(iter->second)) {
        // also skip allocations that are tainted
        CellEPTGNode* rootAO = allocNode->getCell();
        if (rootAO->getIsTainted()) {
          continue;
        }
        llvm::Value* allocationSite = allocNode->getAllocationSite();
        if (llvm::Function* func = llvm::dyn_cast<llvm::Function>(allocationSite)) {
          (void) func;
          functionAllocs.push_back(allocNode);
        } else if (llvm::GlobalVariable* gv = llvm::dyn_cast<llvm::GlobalVariable>(allocationSite)) {
          (void) gv;
          globalAllocs.push_back(allocNode);
        } else if (llvm::AllocaInst* alloca = llvm::dyn_cast<llvm::AllocaInst>(allocationSite)) {
          (void) alloca;
          localAllocs.push_back(allocNode);
        } else if (llvm::CallInst* call = llvm::dyn_cast<llvm::CallInst>(allocationSite)) {
          (void) call;
          dynamicAllocs.push_back(allocNode);
        } else {
          psan_unreachable("Unexpected allocation site");
        }
      } else if (ExpressionEPTGNode* exprNode = llvm::dyn_cast<ExpressionEPTGNode>(iter->second)) {
        llvm::Value* preCloneValue = exprNode->getExpression();
        llvm::Value* postCloneValue = getOrReconstructPostCloneValue(preCloneValue);
        eptgExprNodeMap.insert(std::make_pair(postCloneValue, exprNode));
        if (!isNoStaticStats() && !exprNode->getIsTainted()) {
          // we use forStats_ImplicitValuesInEPTG to include additional values that should be considered as in EPTG even if it is not in eptgExprNodeMap
          // for example, for dynamic allocations, the root pointer is usually the bitcast after the call instruction; the call value itself is not in eptgExprNodeMap
          if (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(postCloneValue)) {
            forStats_ImplicitValuesInEPTG.insert(bc->getOperand(0));
          }
        }
      }
      // nothing to do for cell nodes
    }
  }
  auto isValueInEPTGForStatsCounting = [&](llvm::Value* v) -> bool {
    if (forStats_ImplicitValuesInEPTG.contains(v)) {
      return true;
    }
    auto iter = eptgExprNodeMap.find(v);
    if (iter != eptgExprNodeMap.end()) {
      return !iter->second->getIsTainted();
    }
    return false;
  };
  std::function<void(llvm::Type*, llvm::raw_ostream&)> getTypeStringForTaintedAllocTypeReport = [&](llvm::Type* ty, llvm::raw_ostream& os) -> void {
    // if the type is an array, we write "[N x <T>]" no matter what N is
    if (llvm::ArrayType* aTy = llvm::dyn_cast<llvm::ArrayType>(ty)) {
      os << "[N x ";
      getTypeStringForTaintedAllocTypeReport(aTy->getElementType(), os);
      os << "]";
      return;
    }
    if (llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(ty)) {
      if (sTy->hasName()) {
        os << sTy->getName();
      } else {
        sTy->print(os, /*isForDebug*/true, /*NoDetails*/false);
      }
      return;
    }
    ty->print(os, /*isForDebug*/true, /*NoDetails*/false);
  };
  auto reportNonEPTGAllocType = [&](unsigned allocTy, llvm::Type* ty) -> void {
    if (allocTy >= 2) {
      psan_unreachable("Unexpected allocTy");
    }
    std::string typeName;
    {
      llvm::raw_string_ostream os(typeName);
      getTypeStringForTaintedAllocTypeReport(ty, os);
    }
    stats.S5_TaintedAllocTypes.increment(allocTy, typeName);
  };
  if (!isNoStaticStats()) {
    // sanity check
    for (auto* gvnode : globalAllocs) {
      llvm::GlobalVariable* preCloneValue = llvm::cast<llvm::GlobalVariable>(gvnode->getAllocationSite());
      llvm::GlobalVariable* postCloneValue = getPostCloneValue<llvm::GlobalVariable>(preCloneValue);
      if (!isValueInEPTGForStatsCounting(postCloneValue)) {
        psan_unreachable("Global allocation not in EPTG");
      }
    }
    for (auto* lvnode : localAllocs) {
      llvm::AllocaInst* preCloneValue = llvm::cast<llvm::AllocaInst>(lvnode->getAllocationSite());
      llvm::AllocaInst* postCloneValue = getPostCloneValue<llvm::AllocaInst>(preCloneValue);
      if (!isValueInEPTGForStatsCounting(postCloneValue)) {
        psan_unreachable("Local allocation not in EPTG");
      }
    }
    for (auto* dynalloc : dynamicAllocs) {
      llvm::CallBase* preCloneValue = llvm::cast<llvm::CallBase>(dynalloc->getAllocationSite());
      llvm::CallBase* postCloneValue = getPostCloneValue<llvm::CallBase>(preCloneValue);
      if (!isValueInEPTGForStatsCounting(postCloneValue)) {
        psan_unreachable("Dynamic allocation not in EPTG");
      }
    }
  }

  // add all functions
  // also walk through all code to queue pointer-type load/store for metadata propagation
  // we also collect calls to external functions and indirect calls that involve pointer arguments or return values for metadata propagation
  for (auto& F : *clonedModule) {
    if (F.isDeclaration()) {
      continue;
    }
    functionDefinitions.insert(&F);
    for (auto& BB : F) {
      for (auto& I : BB) {
        if (llvm::LoadInst* load = llvm::dyn_cast<llvm::LoadInst>(&I)) {
          // check if the load loads a pointer or a vector containing pointer
          if (isLoadStoreValueContainsPointer(load->getType())) {
            // check if the pointer operand is in EPTG AND it have points-to cell
            // if yes, we add it to ptrloadsForMD_eptg, otherwise we add it to ptrloadsForMD_oob
            llvm::Value* ptrOperand = load->getPointerOperand();
            auto iter = eptgExprNodeMap.find(ptrOperand);
            if (iter != eptgExprNodeMap.end() && iter->second->getPointsTo() && !iter->second->getPointsTo()->getIsTainted()) {
              ptrloadsForMD_eptg.insert(std::make_pair(load, iter->second));
              stats.S5_EPTGStat_LoadCount.increment(true);
            } else if (isLoadStoreValueContainsDataPointer(load->getType())) {
              ptrloadsForMD_oob.insert(load);
              stats.S5_EPTGStat_LoadCount.increment(false);
            }
          }
        } else if (llvm::StoreInst* store = llvm::dyn_cast<llvm::StoreInst>(&I)) {
          llvm::Value* storedValue = store->getValueOperand();
          if (isLoadStoreValueContainsPointer(storedValue->getType())) {
            llvm::Value* ptrOperand = store->getPointerOperand();
            auto iter = eptgExprNodeMap.find(ptrOperand);
            if (iter != eptgExprNodeMap.end() && iter->second->getPointsTo() && !iter->second->getPointsTo()->getIsTainted()) {
              ptrstoresForMD_eptg.insert(std::make_pair(store, iter->second));
              stats.S5_EPTGStat_StoreCount.increment(true);
            } else if (isLoadStoreValueContainsDataPointer(storedValue->getType())) {
              ptrstoresForMD_oob.insert(store);
              stats.S5_EPTGStat_StoreCount.increment(false);
            }
          }
        } else if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(&I)) {
          // check if this is a call that is (1) not handled by EPTG, (2) involves pointers, and (3) is not a call to internally defined function
          // we need to handle metadata propagation for such calls
          bool isEnqueue = true;
          bool isAllocatorCall = false;
          bool isFreeLikeCall = false;
          llvm::Value* callee = call->getCalledOperand();
          if (llvm::Function* calleeFunc = llvm::dyn_cast<llvm::Function>(callee)) {
            // if this is a direct call to internally defined function, they will be handled when we transform the function definitions
            if (!calleeFunc->isDeclaration()) {
              isEnqueue = false;
            }
            isAllocatorCall = isAllocatorCallee(calleeFunc);
            if (isAllocatorCall) {
              // check if it is a free-like function
              llvm::Attribute attr = calleeFunc->getFnAttribute(llvm::Attribute::AttrKind::AllocKind);
              switch (attr.getAllocKind()) {
              default: break;
              case llvm::AllocFnKind::Free: {
                isFreeLikeCall = true;
              } break;
              }
            }
          }
          if (isEnqueue) {
            // check if this call involves pointer arguments or return value
            bool isPointerArgRetFound = false;
            if (isArgRetTypeContainsPointer(call->getType())) {
              isPointerArgRetFound = true;
            } else {
              for (unsigned i = 0, n = call->arg_size(); i < n; ++i) {
                llvm::Value* arg = call->getArgOperand(i);
                if (isArgRetTypeContainsPointer(arg->getType())) {
                  isPointerArgRetFound = true;
                  break;
                }
              }
            }
            if (!isPointerArgRetFound) {
              isEnqueue = false;
            }
          }
          if (isEnqueue) {
            // before enqueuing it, we distinguish special intrinsics
            switch (call->getIntrinsicID()) {
            // use this "assertion" to identify new intrinsics that may need special handling
            // UPDATE: we ignore them for now
            // default: psan_unreachable("Unexpected intrinsic");
            default: break;
            case llvm::Intrinsic::not_intrinsic: {
              // not a special intrinsic; just enqueue it
              if (isAllocatorCall) {
                // ignore free() like functions
                if (!isFreeLikeCall) {
                  allocatorCallsForMDProp.insert(call);
                  stats.S5_EPTGStat_DynamicAllocCount.increment(isValueInEPTGForStatsCounting(call));
                }
              } else {
                opaqueCallsForMDProp.insert(call);
              }
            } break;
            case llvm::Intrinsic::memcpy:
            case llvm::Intrinsic::memcpy_element_unordered_atomic:
            case llvm::Intrinsic::memcpy_inline:
            case llvm::Intrinsic::memmove:
            case llvm::Intrinsic::memmove_element_unordered_atomic:
            case llvm::Intrinsic::memset:
            case llvm::Intrinsic::memset_element_unordered_atomic:
            case llvm::Intrinsic::memset_inline: {
              llvm::CallInst* callInst = llvm::cast<llvm::CallInst>(call);
              bool isAllInEPTG = true;
              for (unsigned i = 0, n = call->arg_size(); i < n; ++i) {
                llvm::Value* arg = call->getArgOperand(i);
                if (!arg->getType()->isPointerTy()) {
                  continue;
                }
                auto iterArg = eptgExprNodeMap.find(arg);
                if (iterArg != eptgExprNodeMap.end() && iterArg->second->getPointsTo() && !iterArg->second->getPointsTo()->getIsTainted()) {
                  continue;
                }
                isAllInEPTG = false;
                break;
              }
              intrinsicCallsForMDProp.insert(std::make_pair(callInst, !isAllInEPTG));
            } break;
            case llvm::Intrinsic::lifetime_start:
            case llvm::Intrinsic::lifetime_end:
              // we ignore lifetime intrinsics
              break;
            case llvm::Intrinsic::vastart:
            case llvm::Intrinsic::vaend:
            case llvm::Intrinsic::vacopy:
              // we ignore varargs intrinsics
              break;
            }
          }
        } else if (llvm::AllocaInst* alloca = llvm::dyn_cast<llvm::AllocaInst>(&I)) {
          if (!isNoStaticStats() || isCollectRuntimeStats()) {
            bool isValueInEPTG = isValueInEPTGForStatsCounting(alloca);
            if (!isNoStaticStats()) {
              stats.S5_EPTGStat_LocalVarCount.increment(isValueInEPTG);
              if (!isValueInEPTG) {
                reportNonEPTGAllocType(TAINTED_ALLOC_LOCAL, alloca->getAllocatedType());
              }
            }
            if (isCollectRuntimeStats()) {
              allocasForStatsCollection.insert(std::make_pair(alloca, isValueInEPTG));
            }
          }
        }
      }
    }
  }

  // add all globals outside EPTG to nonEPTGGlobals
  for (auto& G : clonedModule->globals()) {
    if (eptgExprNodeMap.find(&G) == eptgExprNodeMap.end()) {
      nonEPTGGlobals.insert(&G);
    }
    if (!isNoStaticStats()) {
      bool isValueInEPTG = isValueInEPTGForStatsCounting(&G);
      stats.S5_EPTGStat_GlobalVarCount.increment(isValueInEPTG);
      if (!isValueInEPTG) {
        reportNonEPTGAllocType(TAINTED_ALLOC_GLOBAL, G.getValueType());
      }
    }
  }
}

void PSanInstrumentationManager::eraseInstrFromParent(llvm::Instruction* inst)
{
  if (!inst->use_empty()) {
    psan_unreachable("Cannot erase value with uses");
  }
  PSAN_DEBUG(PSan::outs() << "Erasing: " << getValueStrWithParent(inst) << "\n");
  auto iter = metadataMap.find(inst);
  if (iter != metadataMap.end()) {
    // sanity check: if the metadata is placeholder, they should have no user
    // otherwise, we should have redirected these uses to the replacement value
    for (auto& p : iter->second) {
      for (llvm::Value* md : p.second) {
        if (llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(md)) {
          if (!instr->use_empty()) {
            psan_unreachable("Metadata placeholder should have no user when the corresponding value is erased");
          }
        }
      }
    }
    metadataMap.erase(iter);
  }
  auto iterVec = vectorMetadataMap.find(inst);
  if (iterVec != vectorMetadataMap.end()) {
    vectorMetadataMap.erase(iterVec);
  }
  inst->eraseFromParent();
}

bool PSanInstrumentationManager::isFunctionDead(llvm::Function* func)
{
  if (step2_pruning_isFunctionHaveHiddenCalls(functionsWithHiddenCalls, func)) {
    return false;
  }
  if (!func->use_empty()) {
    // we want to exclude recursive calls
    for (auto iter = func->use_begin(), iterEnd = func->use_end(); iter != iterEnd; ++iter) {
      llvm::User* user = iter->getUser();
      if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(user)) {
        if (call->getFunction() == func) {
          continue;
        }
      }
      // we found a user
      return false;
    }
  }
  return true;
}

llvm::Value* PSanInstrumentationManager::reconstructPostCloneValue(llvm::Value* value)
{
  // we only handle a few types of values
  // first of all, if some global variables are not used in the code body, we may have to reconstruct them
  auto getNewConstantOperand = [this](llvm::Constant* srcOperand) -> llvm::Constant* {
    auto iter = valueMap.find(srcOperand);
    llvm::Constant* newOperand = nullptr;
    if (iter != valueMap.end()) {
      llvm::Value* v = iter->second;
      newOperand = llvm::cast<llvm::Constant>(v);
    } else {
      llvm::Value* v = reconstructPostCloneValue(srcOperand);
      newOperand = llvm::cast<llvm::Constant>(v);
    }
    return newOperand;
  };
  if (llvm::ConstantExpr* cexpr = llvm::dyn_cast<llvm::ConstantExpr>(value)) {
    switch (cexpr->getOpcode())
    {
    default: psan_unreachable("Unexpected constant expression");
    case llvm::Instruction::BitCast:
    case llvm::Instruction::IntToPtr:
    case llvm::Instruction::PtrToInt:
    case llvm::Instruction::AddrSpaceCast: {
      llvm::Constant* srcOperand = cexpr->getOperand(0);
      llvm::Constant* newOperand = getNewConstantOperand(srcOperand);
      return llvm::ConstantExpr::getCast(cexpr->getOpcode(), newOperand, cexpr->getType());
    } break;
    case llvm::Instruction::GetElementPtr: {
      llvm::Constant* srcOperand = cexpr->getOperand(0);
      llvm::Constant* newOperand = getNewConstantOperand(srcOperand);
      llvm::SmallVector<llvm::Constant*> operands;
      operands.push_back(newOperand);
      for (unsigned i = 1, n = cexpr->getNumOperands(); i < n; ++i) {
        operands.push_back(cexpr->getOperand(i));
      }
      return cexpr->getWithOperands(operands);
    } break;
    }
  }
  if (llvm::UndefValue* undef = llvm::dyn_cast<llvm::UndefValue>(value)) {
    return undef;
  }
  if (llvm::ConstantPointerNull* cpn = llvm::dyn_cast<llvm::ConstantPointerNull>(value)) {
    return cpn;
  }
  psan_unreachable("Unhandled value type");
}

llvm::Instruction* PSanInstrumentationManager::createBackwardConverter(llvm::Value* newPtr, llvm::Type* oldType, llvm::Instruction* insertBefore, const llvm::Twine& name)
{
  llvm::BitCastInst* converter = new llvm::BitCastInst(newPtr, oldType, name, insertBefore);
  annotateInstr(converter, "psan_backward_converter");
  return converter;
}

llvm::Value* PSanInstrumentationManager::createForwardConverter(llvm::Value* oldPtr, llvm::Type* newType, llvm::Instruction* insertBefore, const llvm::Twine& name)
{
  if (llvm::Constant* c = llvm::dyn_cast<llvm::Constant>(oldPtr)) {
    if (llvm::ConstantPointerNull* cpn = llvm::dyn_cast<llvm::ConstantPointerNull>(c)) {
      (void) cpn;
      return llvm::ConstantPointerNull::get(llvm::cast<llvm::PointerType>(newType));
    }
    if (llvm::UndefValue* uv = llvm::dyn_cast<llvm::UndefValue>(c)) {
      (void) uv;
      return llvm::UndefValue::get(newType);
    }
  }
  if (isBackwardConverter(oldPtr)) {
    llvm::Value* originalValue = llvm::cast<llvm::BitCastInst>(oldPtr)->getOperand(0);
    if (originalValue->getType() == newType) {
      return originalValue;
    }
  }
  if (oldPtr->getType() == newType) {
    return oldPtr;
  }
  llvm::BitCastInst* converter = new llvm::BitCastInst(oldPtr, newType, name, insertBefore);
  annotateInstr(converter, "psan_forward_converter");
  return converter;
}

bool PSanInstrumentationManager::isBackwardConverter(llvm::Value* value)
{
  if (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(value)) {
    return isInstrAnnotatedWith(bc, "psan_backward_converter");
  }
  return false;
}

bool PSanInstrumentationManager::isForwardConverter(llvm::Value* value)
{
  if (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(value)) {
    return isInstrAnnotatedWith(bc, "psan_forward_converter");
  }
  return false;
}

llvm::Instruction* PSanInstrumentationManager::createPlaceholderMetadata(llvm::Type* ty, llvm::Instruction* insertBefore, const llvm::Twine& name)
{
  auto iter = placeholderFunctionMap.find(ty);
  if (iter == placeholderFunctionMap.end()) {
    std::size_t index = placeholderFunctionMap.size();
    std::string placeholder_name = "__psan_placeholder_" + std::to_string(index);
    llvm::FunctionType* fty = llvm::FunctionType::get(ty, {}, false);
    llvm::Function* func = llvm::Function::Create(fty, llvm::GlobalValue::ExternalLinkage, placeholder_name, clonedModule);
    auto p = placeholderFunctionMap.insert(std::make_pair(ty, func));
    if (!p.second) {
      psan_unreachable("Unexpected insertion failure");
    }
    iter = p.first;
  }
  if (!insertBefore) {
    psan_unreachable("Insert point not specified");
  }
  llvm::CallInst* call = llvm::CallInst::Create(iter->second, {}, name, insertBefore);
  return call;
}

bool PSanInstrumentationManager::isPlaceholderMetadata(llvm::Instruction* instr)
{
  if (llvm::CallInst* call = llvm::dyn_cast<llvm::CallInst>(instr)) {
    auto iter = placeholderFunctionMap.find(call->getType());
    if (iter != placeholderFunctionMap.end() && call->getCalledFunction() == iter->second) {
      return true;
    }
  }
  return false;

}

void PSanInstrumentationManager::queuePointerChange(llvm::Instruction* backwardConverter)
{
  if (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(backwardConverter)) {
    llvm::Value* oldPtr = bc->getOperand(0);
    if (bc->getType() == oldPtr->getType()) {
      psan_unreachable("Enqueuing meaningless pointer change");
    }
  }
  queuedEPTGPointerChanges.insert(backwardConverter);
}

void PSanInstrumentationManager::bindArgumentsAsMetadata(llvm::Function* func, llvm::Argument* ptrArg, unsigned mdvec, const PSan::InstrumentationPlan::FunctionTypeChangeInfo::ArgumentPointerExpandInfo& info, llvm::Instruction* insertBefore)
{
  PSAN_DEBUG(PSan::outs() << "bindArgumentsAsMetadata(): " << func->getName() << ": " << ptrArg
                          << ", mdvec=" << mdvec << ", [" << info.expandStartArgIndex << ", " << info.expandEndArgPos << ")\n");

  // now we associate the metadata with the new arguments
  if (mdvec == 0 || info.expandEndArgPos == info.expandStartArgIndex) {
    return;
  }

  PSanPrintStream ps;
  if (ppd) {
    ps = ppd->logCustomEvent("ArgumentMetadata", insertBefore);
    ps << "#" << ptrArg->getArgNo();
    if (!ptrArg->getName().empty()) {
      ps << " (" << ptrArg->getName() << ")";
    }
    ps << " ";
  }

  unsigned instrumentationIndex = 0;
  unsigned curArgIndex = info.expandStartArgIndex;
  while (mdvec) {
    if (mdvec & 1) {
      auto& mdTypes = instrumentations[instrumentationIndex]->getPointerMetadataTypesInRegisters();
      if (!mdTypes.empty()) {
        llvm::SmallVector<llvm::Value*> mdValues;
        for (unsigned i = 0, n = mdTypes.size(); i < n; ++i) {
          llvm::Value* md = func->getArg(curArgIndex + i);
          mdValues.push_back(md);
        }
        assignMetadataVec(metadataMap[ptrArg][instrumentationIndex], mdValues);
        curArgIndex += mdTypes.size();
        if (ps) {
          ps << " [" << instrumentationIndex << "]: " << mdValues;
        }
      }
    }
    instrumentationIndex += 1;
    mdvec >>= 1;
  }
  if (curArgIndex != info.expandEndArgPos) {
    psan_unreachable("Unexpected end position");
  }
  if (ps) {
    ps << "\n";
  }
}

llvm::Type* PSanInstrumentationManager::isArgumentByvalLike(llvm::Argument* arg)
{
  if (llvm::Type* ty = arg->getParamByValType()) {
    return ty;
  }
  if (llvm::Type* ty = arg->getParamStructRetType()) {
    return ty;
  }
  return nullptr;
}

llvm::CallBase* PSanInstrumentationManager::createDirectReplacementCall(llvm::CallBase* oldCall, llvm::Function* func, llvm::DenseMap<unsigned, llvm::Value*> newArgMap, llvm::DenseMap<unsigned, MetadataMapTy>& argMetadataMap, std::size_t eptgPartitionIndex, llvm::Value* retMDDest)
{
  // step 1: prepare the new arguments
  llvm::SmallVector<llvm::Value*> args;
  llvm::SmallVector<llvm::Value*> extraArgs; // for variadic functions
  llvm::Value* oldCallee = oldCall->getCalledOperand();
  if (llvm::Function* oldFunc = llvm::dyn_cast<llvm::Function>(oldCallee)) {
    llvm::FunctionType* oldFuncTy = oldFunc->getFunctionType();
    for (unsigned i = 0, n = oldFuncTy->getNumParams(); i < n; ++i) {
      auto iter = newArgMap.find(i);
      if (iter != newArgMap.end()) {
        args.push_back(iter->second);
      } else {
        if (oldCall->arg_size() <= i) {
          args.push_back(llvm::UndefValue::get(oldFuncTy->getParamType(i)));
        } else {
          args.push_back(oldCall->getArgOperand(i));
        }
      }
    }
    for (unsigned i = oldFuncTy->getNumParams(), n = oldCall->arg_size(); i < n; ++i) {
      extraArgs.push_back(oldCall->getArgOperand(i));
    }
  } else {
    psan_unreachable("indirect calls and assembly code should not be handled here");
  }
  // step 2: prepare the metadata
  llvm::FunctionType* newFuncTy = func->getFunctionType();
  llvm::SmallVector<llvm::Value*> mdArgs;
  mdArgs.reserve(newFuncTy->getNumParams() - args.size());
  auto fillMDArgs = [&](unsigned argIndex, unsigned mdvec, std::size_t startArgPos) -> std::size_t {
    (void) startArgPos;
    // return the total number of arguments filled
    std::size_t totalArgCount = 0;
    unsigned curMDIndex = 0;
    auto iter = argMetadataMap.find(argIndex);
    if (iter == argMetadataMap.end()) {
      psan_unreachable("Missing metadata for argument");
    }
    unsigned mdvecCopy = mdvec;
    while (mdvecCopy) {
      if (mdvecCopy & 1) {
        const auto& mdValues = getValue(iter->second, curMDIndex);
        mdArgs.append(mdValues);
        totalArgCount += mdValues.size();
      }
      curMDIndex += 1;
      mdvecCopy >>= 1;
    }
    PSAN_DEBUG(PSan::outs() << "fillMDArgs(): argIndex=" << argIndex << ", mdvec=" << mdvec << ", startArgPos=" << startArgPos << ", totalArgCount=" << totalArgCount << "\n");
    return totalArgCount;
  };
  unsigned returnMDVec = 0;
  std::size_t curArgPos = args.size();
  if (eptgPartitionIndex > 0) {
    // this function is in EPTG and we look at functionTypeChanges
    const auto& funcChangeInfo = getValue(plan.functionTypeChanges, eptgPartitionIndex);

    for (const auto& info : funcChangeInfo.argumentExpandArgInfo) {
      auto iter = argMetadataMap.find(info.argumentIndex);
      if (iter == argMetadataMap.end()) {
        psan_unreachable("Missing metadata for argument");
      }
      std::size_t ptrPartitionIndex = info.pointerPartitionIndex_withOffset;
      unsigned targetMDVec = getValue(plan.cellPartitions, ptrPartitionIndex).pointerMDBitVec;
      if (curArgPos != info.expandStartArgIndex) {
        psan_unreachable("Arg metadata start position misaligned");
      }
      std::size_t filledArgCount = fillMDArgs(info.argumentIndex, targetMDVec, curArgPos);
      curArgPos += filledArgCount;
      if (curArgPos != info.expandEndArgPos) {
        psan_unreachable("Arg metadata end position misaligned");
      }
    }
    if (std::size_t retPartitionIndex = funcChangeInfo.retPartitionIndex) {
      returnMDVec = getValue(plan.cellPartitions, retPartitionIndex).pointerMDBitVec;
    }
  } else {
    // if the function is not in EPTG, we just fill the metadata for all pointer arguments and return value
    for (unsigned i = 0, n = args.size(); i < n; ++i) {
      llvm::Type* curArgTy = args[i]->getType();
      if (isDataPointerTy(curArgTy) && !isArgumentByvalLike(func->getArg(i))) {
        std::size_t filledArgCount = fillMDArgs(i, mdvecWithAll, curArgPos);
        curArgPos += filledArgCount;
      }
    }
    if (isDataPointerTy(oldCall->getType())) {
      returnMDVec = mdvecWithAll;
    }
  }
  std::size_t expectedCurNumArgs = newFuncTy->getNumParams();
  if (returnMDVec > 0) {
    expectedCurNumArgs -= 1;
  }
  if (curArgPos != expectedCurNumArgs) {
    psan_unreachable("Metadata argument count mismatch");
  }
  if (returnMDVec > 0) {
    if (!retMDDest) {
      psan_unreachable("Missing return metadata destination");
    }
    mdArgs.push_back(retMDDest);
  }
  if (mdArgs.size() != (newFuncTy->getNumParams() - args.size())) {
    psan_unreachable("Metadata argument count mismatch");
  }
  args.append(mdArgs);
  args.append(extraArgs);
  llvm::CallBase* newCall = nullptr;
  if (llvm::CallInst* call = llvm::dyn_cast<llvm::CallInst>(oldCall)) {
    newCall = llvm::CallInst::Create(func, args, "", call);
  } else if (llvm::InvokeInst* invoke = llvm::dyn_cast<llvm::InvokeInst>(oldCall)) {
    newCall = llvm::InvokeInst::Create(func, invoke->getNormalDest(), invoke->getUnwindDest(), args, "", invoke);
  } else {
    psan_unreachable("Unexpected call type");
  }
  transferValueName(newCall, oldCall);
  newCall->copyMetadata(*oldCall);
  newCall->setCallingConv(oldCall->getCallingConv());
  return newCall;
}

llvm::CallBase* PSanInstrumentationManager::replaceDirectCall(llvm::CallBase* oldCall, llvm::Function* newCallTarget, std::size_t partitionIndex, llvm::Value** callValueReplacement)
{
  llvm::Function* parentFunc = oldCall->getFunction();
  if (!parentFunc) {
    psan_unreachable("Must replace a call inside a function");
  }
  llvm::Function* oldCallee = oldCall->getCalledFunction();
  if (!oldCallee) {
    psan_unreachable("Indirect call should not be handled here");
  }
  llvm::FunctionType* oldFuncTy = oldCallee->getFunctionType();
  llvm::DenseMap<unsigned, unsigned> mdVecMap; // argument index -> mdvec
  unsigned retMDVec = 0;
  llvm::Type* retMDAllocType = nullptr;
  llvm::DenseMap<unsigned, llvm::SmallVector<llvm::SmallVector<llvm::Value*>>> retMDGEPIndices;
  if (partitionIndex == 0) {
    // this callee is not in EPTG, we just fill the metadata for all pointer arguments and return value
    for (unsigned i = 0, n = oldFuncTy->getNumParams(); i < n; ++i) {
      llvm::Type* curArgTy = oldFuncTy->getParamType(i);
      if (isDataPointerTy(curArgTy)) {
        mdVecMap[i] = mdvecWithAll;
      }
    }
    if (isDataPointerTy(oldFuncTy->getReturnType())) {
      retMDVec = mdvecWithAll;
      retMDAllocType = retMDPointsToType;
      retMDGEPIndices = retMDGEPIndices_nonEPTG;
    }
  } else {
    // this callee is in EPTG and we look at the partition info to fill the metadata
    const auto& functionTypeChangeInfo = getValue(plan.functionTypeChanges, partitionIndex);
    for (const auto& p : functionTypeChangeInfo.argIndexToExpandInfoMap) {
      unsigned argIndex = p.first;
      const auto& info = functionTypeChangeInfo.argumentExpandArgInfo[p.second];
      mdVecMap[argIndex] = getValue(plan.cellPartitions, info.pointerPartitionIndex_withOffset).pointerMDBitVec;
    }
    if (std::size_t retPartitionIndex = functionTypeChangeInfo.retPartitionIndex) {
      retMDVec = getValue(plan.cellPartitions, retPartitionIndex).pointerMDBitVec;
      llvm::Type* retmdArgTy = newCallTarget->getFunctionType()->getParamType(functionTypeChangeInfo.retExpandArgIndex);
      llvm::PointerType* castedRetMDArgTy = llvm::cast<llvm::PointerType>(retmdArgTy);
      retMDAllocType = getPointerElementType(castedRetMDArgTy);
      auto iter = retMDGEPIndices_EPTG.find(retMDVec);
      if (iter == retMDGEPIndices_EPTG.end()) {
        // recover the GEP indices for metadata in the alloc-ed type
        unsigned mdvec = retMDVec;
        unsigned instrumentationIndex = 0;
        unsigned curMDCount = 0;
        llvm::IntegerType* i32Ty = llvm::Type::getInt32Ty(clonedModule->getContext());
        llvm::IntegerType* i64Ty = llvm::Type::getInt64Ty(clonedModule->getContext());
        llvm::ConstantInt* i64Zero = llvm::ConstantInt::get(i64Ty, 0);
        while(mdvec) {
          if (mdvec & 1) {
            const auto& mdTypes = instrumentations[instrumentationIndex]->getPointerMetadataTypesInRegisters();
            if (!mdTypes.empty()) {
              llvm::SmallVector<llvm::SmallVector<llvm::Value*>> gepIndexList;
              for (unsigned i = 0, n = mdTypes.size(); i < n; ++i) {
                llvm::Value* index = llvm::ConstantInt::get(i32Ty, curMDCount + i);
                llvm::SmallVector<llvm::Value*> gepIndices({i64Zero, index});
                gepIndexList.push_back(gepIndices);
              }
              curMDCount += mdTypes.size();
              retMDGEPIndices[instrumentationIndex] = gepIndexList;
            }
          }
          instrumentationIndex += 1;
          mdvec >>= 1;
        }
        auto r = retMDGEPIndices_EPTG.insert(std::make_pair(retMDVec, retMDGEPIndices));
        if (!r.second) {
          psan_unreachable("Unexpected insertion failure");
        }
      } else {
        retMDGEPIndices = iter->second;
      }
    }
  }

  // first, deal with the return value metadata
  llvm::AllocaInst* retMDDest = nullptr;
  llvm::ConstantInt* retMDSize = nullptr;
  if (retMDVec > 0) {
    // find an insertion point for the alloca
    llvm::BasicBlock* entry = &parentFunc->getEntryBlock();
    llvm::Instruction* insertPoint = getBlockInsertPoint(entry);
    retMDDest = new llvm::AllocaInst(retMDAllocType, 0, "psan_retmd", insertPoint);
    retMDSize = llvm::ConstantInt::get(i64Ty, srcModule->getDataLayout().getTypeAllocSize(retMDAllocType));
  }

  // now the metadata
  llvm::DenseMap<unsigned, llvm::Value*> newArgMap;
  llvm::DenseMap<unsigned, MetadataMapTy> argMetadataMap; // arg index -> (instrumentation index -> metadata)
  llvm::DenseMap<unsigned, MetadataMapTy> dummyMetadataMap; // for constants

  // we go through all the existing arguments
  // if there is a type change, we add a converter
  llvm::FunctionType* newFuncTy = newCallTarget->getFunctionType();
  for (unsigned i = 0, n = oldFuncTy->getNumParams(); i < n; ++i) {
    llvm::Type* curArgTy = oldFuncTy->getParamType(i);
    llvm::Type* newArgTy = newFuncTy->getParamType(i);
    llvm::Value* argBindingMetadata = oldCall->getArgOperand(i);
    llvm::Value* oldArg = argBindingMetadata;
    if (curArgTy != newArgTy) {
      if (!curArgTy->isPointerTy() || !newArgTy->isPointerTy()) {
        psan_unreachable("Unexpected type change for non-pointer type parameter");
      }
      llvm::Value* newArg = createForwardConverter(oldArg, newArgTy, oldCall, llvm::Twine("conv", oldArg->getName()));
      newArgMap[i] = newArg;
      argBindingMetadata = newArg;
    }
    auto iter = mdVecMap.find(i);
    if (iter != mdVecMap.end()) {
      unsigned mdvec = iter->second;
      auto& mdmap = getMetadataMap(argBindingMetadata, dummyMetadataMap[i]);
      unsigned instrumentationIndex = 0;
      while (mdvec) {
        if (mdvec & 1) {
          populateStubMetadataVector(mdmap[instrumentationIndex], argBindingMetadata, instrumentationIndex, oldCall, "arg_callrepl");
        }
        instrumentationIndex += 1;
        mdvec >>= 1;
      }
      argMetadataMap[i] = mdmap;
    }
  }
  if (partitionIndex == 0) {
    if (!newArgMap.empty()) {
      psan_unreachable("Unexpected type change for non-EPTG function");
    }
  }
  llvm::BitCastInst* retMDAddrCasted = nullptr;
  if (retMDDest) {
    retMDAddrCasted = new llvm::BitCastInst(retMDDest, i8PtrTy, "psan_retmd_cast", oldCall);
    llvm::CallInst* lifetimeStartCall = llvm::CallInst::Create(lifetimeStart, {retMDSize, retMDAddrCasted}, "", oldCall);
    (void) lifetimeStartCall;
    if (retMDAllocType->isSingleValueType()) {
      // emit a store to initialize it (otherwise subsequent load may cause UB)
      llvm::StoreInst* store = new llvm::StoreInst(llvm::Constant::getNullValue(retMDAllocType), retMDDest, false, oldCall);
      (void) store;
    } else {
      // emit a memset instead
      llvm::ConstantInt* i8zero = llvm::ConstantInt::get(i8Ty, 0); // set to zero
      llvm::ConstantInt* i1zero = llvm::ConstantInt::get(llvm::IntegerType::get(ctx, 1), 0); // not volatile
      llvm::CallInst* memsetCall = llvm::CallInst::Create(memsetFunc, {retMDAddrCasted, i8zero, retMDSize, i1zero}, "", oldCall);
      (void) memsetCall;
    }
  }
  llvm::CallBase* newCall = createDirectReplacementCall(oldCall, newCallTarget, newArgMap, argMetadataMap, partitionIndex, retMDDest);
  for (auto& p : dummyMetadataMap) {
    clearDummyMap(p.second);
  }
  dummyMetadataMap.clear();

  llvm::Instruction* replacementValue = newCall;
  llvm::Instruction* insertPoint = oldCall->getNextNode();
  if (!insertPoint) {
    llvm::InvokeInst* invoke = llvm::cast<llvm::InvokeInst>(oldCall);
    insertPoint = invoke->getNormalDest()->getFirstNonPHIOrDbgOrLifetime();
  }

  // if the return value has type change, we add a converter
  if (oldCall->getType() != newCall->getType()) {
    replacementValue = createBackwardConverter(newCall, oldCall->getType(), insertPoint, llvm::Twine("conv", oldCall->getName()));
    queuePointerChange(replacementValue);
  }

  // if the return value is a pointer, we also add metadata load and register these metadata
  if (retMDDest) {
    // if the allocation type is a struct, we need to extract the fields with GEP+load
    // if the allocation type is not a struct, it should be a first-class type and we use a single load to load that
    // in both cases, we need to register the metadata
    MetadataMapTy& retMDMap = this->metadataMap[newCall];
    if (llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(retMDAllocType)) {
      if (retMDGEPIndices.empty()) {
        psan_unreachable("Missing GEP indices for return value metadata");
      }
      std::string namePrefix = "psan_md_ret_";
      for (const auto& p : retMDGEPIndices) {
        unsigned instrumentationIndex = p.first;
        const auto& gepIndices = p.second;
        llvm::SmallVector<llvm::Value*> curMD;
        const llvm::SmallVector<llvm::Type*>& mdTypes = instrumentations[instrumentationIndex]->getPointerMetadataTypesInRegisters();
        std::string prefixWithIndex = namePrefix + std::to_string(instrumentationIndex) + "_";
        for (unsigned i = 0, n = gepIndices.size(); i < n; ++i) {
          std::string namebase = prefixWithIndex + std::to_string(i) + '_';
          llvm::GetElementPtrInst* gep = llvm::GetElementPtrInst::CreateInBounds(sTy, retMDDest, gepIndices[i], llvm::Twine(namebase, "gep"), insertPoint);
          llvm::LoadInst* load = new llvm::LoadInst(mdTypes[i], gep, llvm::Twine(namebase, "load"), false, insertPoint);
          curMD.push_back(load);
        }
        assignMetadataVec(retMDMap[instrumentationIndex], curMD);
      }
    } else {
      llvm::LoadInst* load = new llvm::LoadInst(retMDAllocType, retMDDest, "psan_md_ret_load", false, insertPoint);
      // we need to look at retMDVec to find out which metadata to register
      unsigned mdvec = retMDVec;
      unsigned instrumentationIndex = 0;
      while (mdvec) {
        if (mdvec & 1) {
          break;
        }
        instrumentationIndex += 1;
        mdvec >>= 1;
      }
      if (mdvec != 1) {
        psan_unreachable("Only a single metadata field in the return value alloca but there are more than one instrumentation scheme requiring metadata");
      }
      llvm::SmallVector<llvm::Value*> retMDList = {load};
      assignMetadataVec(retMDMap[instrumentationIndex], retMDList);
    }
    llvm::CallInst* lifetimeEndCall = llvm::CallInst::Create(lifetimeEnd, {retMDSize, retMDAddrCasted}, "", insertPoint);
    (void) lifetimeEndCall;
  }

  // now we can replace the old call value with the replacement value
  oldCall->replaceAllUsesWith(replacementValue);
  replaceValueForMD(oldCall, replacementValue);

  if (callValueReplacement) {
    *callValueReplacement = replacementValue;
  }
  return newCall;
}

llvm::Constant* PSanInstrumentationManager::getUpdatedConstantExprInEPTG(llvm::Constant* src, llvm::Type* valueType, CellEPTGNode* root, const llvm::DenseMap<llvm::Value*, llvm::Value*>& postCloneRemappingMap)
{
  if (src->getType() == valueType) {
    return src;
  }
  // we first try some trivial cases where we don't need the root cell
  if (llvm::ConstantInt* cint = llvm::dyn_cast<llvm::ConstantInt>(src)) {
    if (valueType->isIntegerTy()) {
      return llvm::ConstantInt::get(valueType, cint->getZExtValue());
    }
    if (valueType->isPointerTy()) {
      return llvm::ConstantExpr::getIntToPtr(cint, valueType);
    }
    psan_unreachable("Unexpected constant type conversion");
  }
  if (llvm::ConstantPointerNull* cpn = llvm::dyn_cast<llvm::ConstantPointerNull>(src)) {
    (void) cpn;
    if (llvm::PointerType* nptrTy = llvm::dyn_cast<llvm::PointerType>(valueType)) {
      return llvm::ConstantPointerNull::get(nptrTy);
    }
  }

  // code below should require a valid root cell
  if (!root) {
    psan_unreachable("Missing root cell for constant type conversion");
  }
  // first, we need to find out the type partition of the constant and see how we planned to change the type
  std::size_t typePartition = 0;
  {
    auto iter = plan.cellTypeConversions.find(root);
    if (iter == plan.cellTypeConversions.end()) {
      psan_unreachable("ConstantExpr type change without conversion plan");
    }
    typePartition = iter->second;
  }
  const InstrumentationPlan::EPTGCellTypeChangePartitionInfo& partitionInfo = getValue(plan.cellPartitions, typePartition);
  // consistency check
  if (partitionInfo.finalType != valueType) {
    psan_unreachable("Inconsistent final type for conversion plan");
  }
  unsigned mdvec = partitionInfo.pointerMDBitVec;
  llvm::Type* targetCoreType = valueType;
  if (mdvec > 0) {
    // this is a pointer getting expanded
    // the core type should be the first element instead of the entire type
    llvm::StructType* sTy = llvm::cast<llvm::StructType>(valueType);
    targetCoreType = sTy->getElementType(0);
  }

  // now we start to do the conversion
  llvm::Constant* convertedCore = nullptr;
  if (src->getType() == targetCoreType) {
    convertedCore = src;
  } else if (src->isNullValue()) {
    convertedCore = llvm::Constant::getNullValue(targetCoreType);
  } else if (llvm::isa<llvm::GlobalVariable>(src) || llvm::isa<llvm::Function>(src)) {
    convertedCore = src;
    auto iter = postCloneRemappingMap.find(src);
    if (iter != postCloneRemappingMap.end()) {
      convertedCore = llvm::cast<llvm::Constant>(iter->second);
    }
    if (convertedCore->getType() != targetCoreType) {
      convertedCore = llvm::ConstantExpr::getPointerCast(convertedCore, targetCoreType);
    }
  } else if (llvm::ConstantExpr* cexpr = llvm::dyn_cast<llvm::ConstantExpr>(src)) {
    // TODO
    switch (cexpr->getOpcode())
    {
    default: psan_unreachable("Unexpected ConstantExpr opcode");
    case llvm::Instruction::BitCast:
    case llvm::Instruction::PtrToInt: {
      llvm::Constant* castRootExpr = cexpr->getOperand(0);
      convertedCore = getUpdatedConstantExprInEPTG(castRootExpr, targetCoreType, root, postCloneRemappingMap);
    } break;
    case llvm::Instruction::GetElementPtr: {
      llvm::Constant* rootPtr = cexpr->getOperand(0);
      MemberPosition pos = MemberPosition::get(cexpr);
      CellEPTGNode* child = root->getSubObjectIfAvailable(pos);
      llvm::Constant* convertedRootPtr = getUpdatedConstantExprInEPTG(rootPtr, getPointerElementType(rootPtr->getType()), child, postCloneRemappingMap);
      if (convertedRootPtr == rootPtr) {
        convertedCore = cexpr;
      } else {
        // ok, we need to create a new constexpr
        llvm::SmallVector<llvm::Constant*> indexList;
        for (unsigned i = 1, n = cexpr->getNumOperands(); i < n; ++i) {
          llvm::Constant* curIndex = cexpr->getOperand(i);
          assert (llvm::isa<llvm::ConstantInt>(curIndex));
          indexList.push_back(curIndex);
        }
        convertedCore = llvm::ConstantExpr::getGetElementPtr(getPointerElementType(convertedRootPtr->getType()), convertedRootPtr, indexList);
      }
    } break;
    }
  } else if (llvm::ConstantAggregate* caggr = llvm::dyn_cast<llvm::ConstantAggregate>(src)) {
    if (llvm::ConstantArray* carray = llvm::dyn_cast<llvm::ConstantArray>(caggr)) {
      llvm::ArrayType* arrayTy = llvm::cast<llvm::ArrayType>(targetCoreType);
      CellEPTGNode* child = root->getSubObjectIfAvailable(MemberPosition::getWithSingleIndex(0));
      llvm::SmallVector<llvm::Constant*> newOperands;
      for (unsigned i = 0, n = carray->getNumOperands(); i < n; ++i) {
        llvm::Constant* curValue = carray->getOperand(i);
        llvm::Constant* newValue = getUpdatedConstantExprInEPTG(curValue, arrayTy->getElementType(), child, postCloneRemappingMap);
        newOperands.push_back(newValue);
      }
      convertedCore = llvm::ConstantArray::get(arrayTy, newOperands);
    } else if (llvm::ConstantStruct* cstruct = llvm::dyn_cast<llvm::ConstantStruct>(caggr)) {
      llvm::StructType* sTy = llvm::cast<llvm::StructType>(targetCoreType);
      llvm::SmallVector<llvm::Constant*> newOperands;
      for (unsigned i = 0, n = cstruct->getNumOperands(); i < n; ++i) {
        CellEPTGNode* child = root->getSubObjectIfAvailable(MemberPosition::getWithSingleIndex(i));
        llvm::Constant* curValue = cstruct->getOperand(i);
        llvm::Constant* newValue = getUpdatedConstantExprInEPTG(curValue, sTy->getElementType(i), child, postCloneRemappingMap);
        newOperands.push_back(newValue);
      }
      convertedCore = llvm::ConstantStruct::get(sTy, newOperands);
    } else {
      psan_unreachable("Unexpected constant aggregate type");
    }
  } else {
    psan_unreachable("Unexpected constant type");
  }
  if (!convertedCore) {
    psan_unreachable("core should be converted by now");
  }
  // we do not ask for metadata for function pointers
  bool isFunctionPointer = false;
  if (llvm::PointerType* ptrTy = llvm::dyn_cast<llvm::PointerType>(convertedCore->getType())) {
    isFunctionPointer = getPointerElementType(ptrTy)->isFunctionTy();
  }
  // if for some reason the type still does not match, we need to do a final cast
  if (convertedCore->getType() != targetCoreType) {
    convertedCore = llvm::ConstantExpr::getPointerCast(convertedCore, targetCoreType);
  }
  // finally, if the constant is a pointer and should carry metadata, we create the complete struct
  if (mdvec > 0) {
    llvm::StructType* sTy = llvm::cast<llvm::StructType>(valueType);
    llvm::SmallVector<llvm::Constant*> structValues;
    structValues.push_back(convertedCore);
    forEachScheme(mdvec, [&](unsigned schemeIndex) {
      llvm::Constant* md = nullptr;
      if (!isFunctionPointer) {
        md = instrumentations[schemeIndex]->getMetadataInitializerForConstant(convertedCore);
      }
      if (!md) {
        md = llvm::Constant::getNullValue(instrumentations[schemeIndex]->getPointerMetadataTypeInMemory());
      }
      structValues.push_back(md);
    });
    return llvm::ConstantStruct::get(sTy, structValues);
  }
  return convertedCore;
}

llvm::Constant* PSanInstrumentationManager::getUpdatedConstantExpr(llvm::Constant* src, llvm::Type* valueType, const llvm::DenseMap<llvm::Value*, llvm::Value*>& postCloneRemappingMap, llvm::DenseMap<std::pair<llvm::Constant*, llvm::Type*>, llvm::Constant*>& constantValueRemapper)
{
  auto tryTriviallyGetUpdatedConstantExpr = [&](llvm::Constant* src, llvm::Type* valueType) -> llvm::Constant* {
    if (src->isNullValue()) {
      return llvm::Constant::getNullValue(valueType);
    }
    if (llvm::isa<llvm::GlobalVariable>(src) || llvm::isa<llvm::Function>(src)) {
      // if we have created the new definition of function / gv, redirect them to the new definition
      auto iter = postCloneRemappingMap.find(src);
      if (iter != postCloneRemappingMap.end()) {
        llvm::Constant* result = llvm::cast<llvm::Constant>(iter->second);
        assert (result->getType() == valueType);
        return result;
      }
      // otherwise this should not change
      assert (src->getType() == valueType);
      return src;
    }
    if (src->getNumOperands() == 0 && src->getType() == valueType) {
      return src;
    }
    return nullptr;
  };
  std::function<llvm::Constant*(llvm::Constant*)> getUpdatedConstantExprWithoutType = [&](llvm::Constant* src) -> llvm::Constant* {
    // in this function we just make sure all reference to old global variables are replaced
    if (llvm::GlobalVariable* gv = llvm::dyn_cast<llvm::GlobalVariable>(src)) {
      auto iter = postCloneRemappingMap.find(gv);
      if (iter != postCloneRemappingMap.end()) {
        llvm::GlobalVariable* result = llvm::cast<llvm::GlobalVariable>(iter->second);
        return result;
      }
      return gv;
    }
    if (llvm::ConstantExpr* cexpr = llvm::dyn_cast<llvm::ConstantExpr>(src)) {
      switch (cexpr->getOpcode())
      {
      default:
        psan_unreachable("Unexpected ConstantExpr opcode");
        break;
      case llvm::Instruction::BitCast:
      case llvm::Instruction::PtrToInt: {
        llvm::Constant* castRootExpr = cexpr->getOperand(0);
        llvm::Constant* replacementRootExpr = getUpdatedConstantExprWithoutType(castRootExpr);
        return llvm::ConstantExpr::getCast(cexpr->getOpcode(), replacementRootExpr, cexpr->getType());
      } break;
      case llvm::Instruction::GetElementPtr: {
        llvm::Constant* rootPtr = cexpr->getOperand(0);
        llvm::Constant* replacementRootPtr = getUpdatedConstantExprWithoutType(rootPtr);
        if (replacementRootPtr == rootPtr) {
          return cexpr;
        }
        // ok, we need to create a new constexpr
        llvm::SmallVector<llvm::Constant*> indexList;
        for (unsigned i = 1, n = cexpr->getNumOperands(); i < n; ++i) {
          llvm::Constant* curIndex = cexpr->getOperand(i);
          assert (llvm::isa<llvm::ConstantInt>(curIndex));
          indexList.push_back(curIndex);
        }
        llvm::Constant* result = llvm::ConstantExpr::getGetElementPtr(getPointerElementType(replacementRootPtr->getType()), replacementRootPtr, indexList);
        return result;
      } break;
      }
    }
    if (llvm::ConstantAggregate* caggr = llvm::dyn_cast<llvm::ConstantAggregate>(src)) {
      llvm::SmallVector<llvm::Constant*> newOperands;
      bool isOperandModified = false;
      bool isOperandTypeModified = false;
      for (unsigned i = 0, n = caggr->getNumOperands(); i < n; ++i) {
        llvm::Constant* curValue = caggr->getOperand(i);
        llvm::Constant* newValue = tryTriviallyGetUpdatedConstantExpr(curValue, curValue->getType());
        if (!newValue) {
          newValue = getUpdatedConstantExprWithoutType(curValue);
        }
        assert (newValue);
        if (newValue != curValue) {
          isOperandModified = true;
          if (newValue->getType() != curValue->getType()) {
            isOperandTypeModified = true;
          }
        }
        newOperands.push_back(newValue);
      }
      if (!isOperandModified || newOperands.empty()) {
        return caggr;
      }
      if (llvm::ConstantStruct* cstruct = llvm::dyn_cast<llvm::ConstantStruct>(caggr)) {
        if (!isOperandTypeModified) {
          return llvm::ConstantStruct::get(cstruct->getType(), newOperands);
        }
        // if the type changes, form a new struct type
        // the parent should take care of the type mismatch
        return llvm::ConstantStruct::getAnon(newOperands);
      }
      if (llvm::ConstantArray* carray = llvm::dyn_cast<llvm::ConstantArray>(caggr)) {
        if (!isOperandTypeModified) {
          return llvm::ConstantArray::get(carray->getType(), newOperands);
        }
        // assume that the array types are not modified
        psan_unreachable("Unhandled update to constant array");
      }
    }
    psan_unreachable("Unhandled constant expr kind");
  };
  std::function<llvm::Constant*(llvm::Constant*, llvm::Type*)> convertConstantExprType = [&](llvm::Constant* src, llvm::Type* valueType) -> llvm::Constant* {
    llvm::Type* srcType = src->getType();
    if (llvm::PointerType* ptrTy = llvm::dyn_cast<llvm::PointerType>(srcType)) {
      // we are converting a pointer
      // if we want a struct and the converted value is the main pointer, we currently just zero-fill here
      if (llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(valueType)) {
        assert (sTy->getNumElements() >= 1);
        assert (sTy->getElementType(0) == ptrTy);
        llvm::SmallVector<llvm::Constant*> fieldInitializers;
        fieldInitializers.push_back(src);
        for (unsigned i = 1, n = sTy->getNumElements(); i < n; ++i) {
          fieldInitializers.push_back(llvm::Constant::getNullValue(sTy->getElementType(i)));
        }
        return llvm::ConstantStruct::get(sTy, fieldInitializers);
      }
      psan_unreachable("Unhandled case");
    }
    if (llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(srcType)) {
      // we are converting a struct
      // basically just convert all members to the desired type
      llvm::ConstantStruct* srcValue = llvm::cast<llvm::ConstantStruct>(src);
      llvm::StructType* resultTy = llvm::cast<llvm::StructType>(valueType);
      unsigned numElements = resultTy->getNumElements();
      assert (numElements == sTy->getNumElements());
      llvm::SmallVector<llvm::Constant*> newOperands;
      newOperands.reserve(numElements);
      for (unsigned i = 0; i < numElements; ++i) {
        llvm::Type* desiredType = resultTy->getElementType(i);
        llvm::Constant* memberResult = getUpdatedConstantExpr(srcValue->getOperand(i), desiredType, postCloneRemappingMap, constantValueRemapper);
        newOperands.push_back(memberResult);
      }
      return llvm::ConstantStruct::get(resultTy, newOperands);
    }
    if (llvm::ArrayType* aTy = llvm::dyn_cast<llvm::ArrayType>(srcType)) {
      // we are converting an array
      llvm::ConstantArray* srcValue = llvm::cast<llvm::ConstantArray>(src);
      llvm::ArrayType* resultTy = llvm::cast<llvm::ArrayType>(valueType);
      unsigned numElements = resultTy->getNumElements();
      assert (numElements == aTy->getNumElements());
      llvm::SmallVector<llvm::Constant*> newOperands;
      newOperands.reserve(numElements);
      llvm::Type* desiredMemberType = resultTy->getElementType();
      for (unsigned i = 0; i < numElements; ++i) {
        llvm::Constant* memberResult = getUpdatedConstantExpr(srcValue->getOperand(i), desiredMemberType, postCloneRemappingMap, constantValueRemapper);
        newOperands.push_back(memberResult);
      }
      return llvm::ConstantArray::get(resultTy, newOperands);
    }
    psan_unreachable("Unhandled case");
  };

  // main part
  if (llvm::Constant* result = tryTriviallyGetUpdatedConstantExpr(src, valueType)) {
    return result;
  }
  // check if we have already handled this value before
  std::pair<llvm::Constant*, llvm::Type*> keyPair(src, valueType);
  {
    auto iter = constantValueRemapper.find(keyPair);
    if (iter != constantValueRemapper.end()) {
      return iter->second;
    }
  }
  auto registerResult = [&](llvm::Constant* result) -> void {
    constantValueRemapper.insert(std::make_pair(keyPair, result));
  };
  // okay, let's handle this. We know that it cannot be handled by tryTriviallyGetUpdatedConstantExpr()
  llvm::Constant* converted = getUpdatedConstantExprWithoutType(src);
  if (converted->getType() != valueType) {
    converted = convertConstantExprType(converted, valueType);
  }
  registerResult(converted);
  return converted;
}

llvm::DominatorTree* PSanInstrumentationManager::getDominatorTreeForPostCloneFunction(llvm::Function* func)
{
  // check that we are populating the dominator tree for a function that is in the cloned module
  if (func->getParent() != clonedModule) {
    psan_unreachable("calling getDominatorTreeForPostCloneFunction() for function not in the cloned module");
  }
  auto iter = domTreeMap.find(func);
  if (iter != domTreeMap.end()) {
    return iter->second;
  }
  llvm::DominatorTree* domTree = new llvm::DominatorTree(*func);
  domTreeMap.insert(std::make_pair(func, domTree));
  return domTree;
}

llvm::Value* PSanInstrumentationManager::getSizeReplacementValue(llvm::Value* curSizeValue, llvm::Type* srcElementType, llvm::Type* destElementType, llvm::Instruction* insertBefore)
{
  const auto& layout = clonedModule->getDataLayout();
  auto srcTySize = layout.getTypeAllocSize(srcElementType);
  auto destTySize = layout.getTypeAllocSize(destElementType);
  if (srcTySize == destTySize) {
    return curSizeValue;
  }
  std::uint64_t srcTySizeValue = srcTySize.getKnownMinSize();
  std::uint64_t destTySizeValue = destTySize.getKnownMinSize();

  // the best heuristics I can come up with...
  // basically impossible to always recover the correct value
  if (llvm::ConstantInt* cint = llvm::dyn_cast<llvm::ConstantInt>(curSizeValue)) {
    assert (!cint->isNegative());
    llvm::IntegerType* intTy = llvm::cast<llvm::IntegerType>(cint->getType());
    std::uint64_t curValue = cint->getLimitedValue();
    std::uint64_t count = curValue / srcTySizeValue;
    std::uint64_t rm = curValue % srcTySizeValue;
    std::uint64_t newValue = count * destTySizeValue + rm;
    return llvm::ConstantInt::get(intTy, newValue);
  }
  // okay, this is not a constant value
  // try to convert curSizeValue into Ax+C, where x is variable and A, C are constants
  // if vx becomes null, it means that we found the "non-constant" value is actually constant (think of vx as 1)
  llvm::Value* vx = curSizeValue;
  llvm::IntegerType* dstTy = llvm::cast<llvm::IntegerType>(curSizeValue->getType());
  llvm::APInt vA(dstTy->getBitWidth(), 1, true);
  llvm::APInt vC(dstTy->getBitWidth(), 0, true);
  // we keep going along vx, try to derive vA and vC from it
  while (true) {
    if (llvm::ZExtInst* zext = llvm::dyn_cast<llvm::ZExtInst>(vx)) {
      vx = zext->getOperand(0);
      continue;
    }
    if (llvm::SExtInst* sext = llvm::dyn_cast<llvm::SExtInst>(vx)) {
      vx = sext->getOperand(0);
      continue;
    }
    if (llvm::BinaryOperator* binop = llvm::dyn_cast<llvm::BinaryOperator>(vx)) {
      assert (binop->getNumOperands() == 2);
      llvm::Value* lhs = binop->getOperand(0);
      llvm::Value* rhs = binop->getOperand(1);
      llvm::ConstantInt* lhsCInt = llvm::dyn_cast<llvm::ConstantInt>(lhs);
      llvm::ConstantInt* rhsCInt = llvm::dyn_cast<llvm::ConstantInt>(rhs);
      // for now, we just give up of both lhs and rhs are non-constant
      if (!lhsCInt && !rhsCInt) {
        break;
      }
      // we are not expecting the case where both sides are constants...
      if (lhsCInt && rhsCInt) {
        // multiply vA with the result of current operation
        llvm::Constant* constResult = llvm::ConstantFoldBinaryOpOperands(binop->getOpcode(), lhsCInt, rhsCInt, layout);
        if (llvm::ConstantInt* constResultInt = llvm::dyn_cast<llvm::ConstantInt>(constResult)) {
          vA *= constResultInt->getValue();
          vx = nullptr;
          break;
        } else {
          psan_unreachable("Unexpected constant folding result");
        }
      }
      bool isSwapped = false;
      if (!rhsCInt && lhsCInt) {
        // make rhs constant by swapping them
        llvm::Value* tmp = rhs;
        rhs = lhs;
        lhs = tmp;
        rhsCInt = lhsCInt;
        lhsCInt = nullptr;
        isSwapped = true;
      }
      // so we must have non-const lhs and const rhs
      assert (!lhsCInt && rhsCInt && !llvm::isa<ConstantInt>(lhs));
      llvm::APInt rhsValue = rhsCInt->getValue();
      auto curWidth = rhsValue.getBitWidth();
      // make sure their width matches
      if (curWidth > vA.getBitWidth()) {
        vA = vA.sext(curWidth);
        vC = vC.sext(curWidth);
      } else if (curWidth < vA.getBitWidth()) {
        rhsValue = rhsValue.sext(vA.getBitWidth());
      }
      bool isUnrecognizedOpcode = false;
      switch (binop->getOpcode())
      {
      default: {
        isUnrecognizedOpcode = true;
      } break;
      case llvm::Instruction::Add: {
        vC += vA * rhsValue;
        vx = lhs;
      } break;
      case llvm::Instruction::Mul: {
        vA *= rhsValue;
        vx = lhs;
      } break;
      case llvm::Instruction::Shl: {
        assert (!isSwapped);
        vA *= (llvm::APInt(vA.getBitWidth(), 1, true) << rhsValue);
        vx = lhs;
      } break;
      }
      if (isUnrecognizedOpcode)
        break;
      continue;
    }
    // unrecognized instruction; just break
    break;
  }
  auto bitwidth = vA.getBitWidth();
  assert (vC.getBitWidth() == bitwidth);
  llvm::APInt srcSize (bitwidth, srcTySizeValue, true);
  llvm::APInt dstSize (bitwidth, destTySizeValue, true);
  // handle the case where vx == nullptr (the size is actually constant)
  if (!vx) {
    // same heuristic as above
    llvm::APInt curValue = vA + vC;
    if (curValue.isNegative()) {
      psan_unreachable("Negative size value");
    }
    llvm::APInt count = curValue.udiv(srcSize);
    llvm::APInt rm = curValue.urem(srcSize);
    llvm::APInt newValue = count * dstSize + rm;
    return llvm::ConstantInt::get(dstTy, newValue);
  }
  // now start to compute the new value according to the size change (sizeof(SrcTy) --> sizeof(DstTy))
  llvm::APInt newVA   (bitwidth, 1, true);
  llvm::APInt newVC   (bitwidth, 0, true);
  if (vA != 1) {
    llvm::APInt quot;
    llvm::APInt rem;
    llvm::APInt::sdivrem(vA, srcSize, quot, rem);
    newVA = quot * dstSize + rem;
  }
  if (vC != 0) {
    llvm::APInt quot;
    llvm::APInt rem;
    llvm::APInt::sdivrem(vC, srcSize, quot, rem);
    newVC = quot * dstSize + rem;
  }
  // now start to create the new values
  llvm::IntegerType* intermediateType = llvm::IntegerType::get(ctx, bitwidth);
  llvm::Value* vxValue = vx;
  if (vx->getType() != intermediateType) {
    vxValue = llvm::CastInst::CreateIntegerCast(vx, intermediateType, false, "psan_sizeupdate_src_cast", insertBefore);
  }
  llvm::Value* tmpValue = vxValue;
  if (newVA != 1) {
    tmpValue = llvm::BinaryOperator::CreateMul(tmpValue, llvm::ConstantInt::get(intermediateType, newVA), "", insertBefore);
  }
  if (newVC != 0) {
    tmpValue = llvm::BinaryOperator::CreateAdd(tmpValue, llvm::ConstantInt::get(intermediateType, newVC), "", insertBefore);
  }
  // done
  llvm::Value* finalValue = tmpValue;
  if (finalValue->getType() != dstTy) {
    finalValue = llvm::CastInst::CreateIntegerCast(tmpValue, dstTy, false, "psan_sizeupdate_dest_cast", insertBefore);
  }
  return finalValue;
}

namespace {
struct GVReplacementInfo {
  llvm::GlobalVariable* postCloneGV = nullptr;
  llvm::GlobalVariable* replacementGV = nullptr;
  CellEPTGNode* rootAO = nullptr;
};
} // end anonymous namespace

void PSanInstrumentationManager::replaceDefinitions()
{
  // this function needs to do the following:
  // 1. replace all function definitions, including EPTG-managed and non-EPTG-managed
  // 2. replace all global variable definitions with EPTG type conversions
  // 3. replace all local variable definitions with EPTG type conversions

  // we first collect the set of all function definitions with pointer argument/return values
  llvm::DenseSet<llvm::Function*> allFunctionsWithPtrArgRet;
  for (auto* func : functionDefinitions) {
    bool hasPtrArgRet = false;
    for (auto& arg : func->args()) {
      if (arg.getType()->isPointerTy()) {
        hasPtrArgRet = true;
        break;
      }
    }
    if (func->getReturnType()->isPointerTy()) {
      hasPtrArgRet = true;
    }
    if (hasPtrArgRet) {
      allFunctionsWithPtrArgRet.insert(func);
    }
  }
  // exclude special functions (for now just main()) from function interface change
  if (llvm::Function* mainFunc = clonedModule->getFunction("main")) {
    allFunctionsWithPtrArgRet.erase(mainFunc);
  }

  // now start the actual replacement
  // helper function to create the FunctionTypeChangeInfo for non-EPTG functions
  auto populateDefaultFunctionTypeChanges = [&](llvm::FunctionType* oldTy, llvm::Function* func, PSan::InstrumentationPlan::FunctionTypeChangeInfo& info) -> void {
    info.oldTy = oldTy;
    if (nonEPTGPtrMetadataParamTypes.empty()) {
      info.newTy = oldTy;
      return;
    }
    llvm::SmallVector<llvm::Type*> argumentTypes; // types that replace existing parameters
    llvm::SmallVector<llvm::Type*> appendedTypes; // types added for pointer expansion
    unsigned appendParamStartIndex = oldTy->getNumParams();
    argumentTypes.reserve(oldTy->getNumParams());
    for (unsigned i = 0, n = oldTy->getNumParams(); i < n; ++i) {
      llvm::Type* curTy = oldTy->getParamType(i);
      // we will need to add the current type anyway
      argumentTypes.push_back(curTy);
      // for non-EPTG functions, we change the type of all pointer arguments and return values and nothing else
      if (!isDataPointerTy(curTy)) {
        continue;
      }
      if (isArgumentByvalLike(func->getArg(i))) {
        // we don't change the type of byval/sret arguments
        continue;
      }
      // now we need to create extra parameters
      InstrumentationPlan::FunctionTypeChangeInfo::ArgumentPointerExpandInfo argExpandInfo;
      argExpandInfo.pointerPartitionIndex_withOffset = 0;
      argExpandInfo.argumentIndex = i;
      argExpandInfo.expandStartArgIndex = appendParamStartIndex + appendedTypes.size();
      argExpandInfo.expandEndArgPos = argExpandInfo.expandStartArgIndex + nonEPTGPtrMetadataParamTypes.size();
      appendedTypes.append(nonEPTGPtrMetadataParamTypes);
      unsigned recordIndex = info.argumentExpandArgInfo.size();
      info.argumentExpandArgInfo.push_back(argExpandInfo);
      info.argIndexToExpandInfoMap.insert(std::make_pair(i, recordIndex));
    }
    llvm::Type* newRetTy = oldTy->getReturnType();
    if (isDataPointerTy(newRetTy)) {
      // we also need to expand the return value
      info.retExpandArgIndex = appendParamStartIndex + appendedTypes.size();
      appendedTypes.push_back(retMDAppendParamType);
    }
    // now create the final type
    argumentTypes.append(appendedTypes);
    info.newTy = llvm::FunctionType::get(newRetTy, argumentTypes, oldTy->isVarArg());
  };

  llvm::DenseMap<llvm::Value*, llvm::Value*> postCloneRemappingMap; // both key and value should belong to the cloned module

  auto addPostCloneValueMapping = [&](llvm::Value* oldValue, llvm::Value* newValue) -> void {
    auto result = postCloneRemappingMap.insert(std::make_pair(oldValue, newValue));
    assert (result.second);
  };

  // step 1: create new functions
  // since we reuse the (dead) old function for thunk, we will not add mapping from original function to new function to postCloneRemappingMap
  llvm::DenseMap<llvm::Function*, std::pair<std::size_t, llvm::Function*>> oldToNewFuncMap; // original function -> (instrumentation index, new function)
  auto addFunctionReplacementInfo = [&](llvm::Function* postCloneFunc, llvm::Function* newFunc, std::size_t partitionIndex) -> void {
    oldToNewFuncMap.insert(std::make_pair(postCloneFunc, std::make_pair(partitionIndex, newFunc)));
  };

  auto getThunkMetadataUniqueInfo = [&](llvm::FunctionType* funcTy) -> ThunkMetadataUniqueInfo& {
    auto iter = thunkUniqueInfo.find(funcTy);
    if (iter != thunkUniqueInfo.end()) {
      return iter->second;
    }
    auto p = thunkUniqueInfo.insert(std::make_pair(funcTy, ThunkMetadataUniqueInfo()));
    if (!p.second) {
      psan_unreachable("Unexpected insertion failure");
    }
    auto& info = p.first->second;
    for (unsigned i = 0, n = funcTy->getNumParams(); i < n; ++i) {
      llvm::Type* curTy = funcTy->getParamType(i);
      if (isDataPointerTy(curTy)) {
        info.pointerArgIndices.push_back(i);
      }
    }
    if (isDataPointerTy(funcTy->getReturnType())) {
      info.hasRetMD = true;
    }
    return info;
  };

  auto getThunkMetadataSharedInfo = [&](const ThunkMetadataUniqueInfo& uniqueInfo) -> ThunkMetadataSharedInfo& {
    unsigned numPtrArgs = uniqueInfo.pointerArgIndices.size();
    auto iter = thunkMetadataStructInfo.find(numPtrArgs);
    if (iter != thunkMetadataStructInfo.end()) {
      return uniqueInfo.hasRetMD? iter->second.first : iter->second.second;
    }
    auto p = thunkMetadataStructInfo.insert(std::make_pair(numPtrArgs, std::make_pair(ThunkMetadataSharedInfo(),ThunkMetadataSharedInfo())));
    if (!p.second) {
      psan_unreachable("Unexpected insertion failure");
    }
    iter = p.first;
    if (nonEPTGPtrMetadataParamTypes.empty()) {
      return uniqueInfo.hasRetMD? iter->second.first : iter->second.second;
    }
    auto& fullinfo = iter->second.first;
    llvm::SmallVector<llvm::Type*> metadataStructFields;
    llvm::IntegerType* i32Ty = llvm::Type::getInt32Ty(clonedModule->getContext());
    llvm::IntegerType* i64Ty = llvm::Type::getInt64Ty(clonedModule->getContext());
    llvm::ConstantInt* i64Zero = llvm::ConstantInt::get(i64Ty, 0);
    for (unsigned i = 0, n = numPtrArgs; i < n; ++i) {
      std::size_t baseIndex = metadataStructFields.size();
      llvm::DenseMap<unsigned, llvm::SmallVector<llvm::SmallVector<llvm::Value*>>> mdmap;
      for (unsigned instrumentationIndex = 0, n = instrumentations.size(); instrumentationIndex < n; ++instrumentationIndex) {
        const llvm::SmallVector<llvm::Type*>& mdTypes = instrumentations[instrumentationIndex]->getPointerMetadataTypesInRegisters();
        if (mdTypes.empty()) {
          continue;
        }
        llvm::SmallVector<llvm::SmallVector<llvm::Value*>> gepIndexVec;
        for (unsigned j = 0, m = mdTypes.size(); j < m; ++j) {
          std::size_t gepSecondIndex = metadataStructFields.size();
          llvm::Type* curMDTy = mdTypes[j];
          if (curMDTy != nonEPTGPtrMetadataParamTypes[gepSecondIndex - baseIndex]) {
            psan_unreachable("Metadata type mismatch");
          }
          metadataStructFields.push_back(curMDTy);
          llvm::SmallVector<llvm::Value*> gepIndices;
          gepIndices.push_back(i64Zero);
          gepIndices.push_back(llvm::ConstantInt::get(i32Ty, gepSecondIndex));
          gepIndexVec.push_back(gepIndices);
        }
        mdmap[instrumentationIndex] = gepIndexVec;
      }
      if (metadataStructFields.size() - baseIndex != nonEPTGPtrMetadataParamTypes.size()) {
        psan_unreachable("Metadata field count mismatch");
      }
      fullinfo.metadataOffsetMap.push_back(mdmap);
    }
    // ok, at this point, if the function does not have pointer return value, we can already create the metadata struct
    std::string name = "psan.mdstruct." + std::to_string(numPtrArgs) + ".base";
    llvm::StructType* nonPtrRetMetadataStructType = llvm::StructType::create(clonedModule->getContext(), metadataStructFields, name);
    iter->second.second.metadataStructType = nonPtrRetMetadataStructType;
    iter->second.second.metadataOffsetMap = fullinfo.metadataOffsetMap;
    // now create the version with pointer return value
    metadataStructFields.push_back(retMDPointsToType);
    std::string name2 = "psan.mdstruct." + std::to_string(numPtrArgs) + ".retptr";
    llvm::StructType* ptrRetMetadataStructType = llvm::StructType::create(clonedModule->getContext(), metadataStructFields, name2);
    fullinfo.metadataStructType = ptrRetMetadataStructType;
    fullinfo.retMDGEPIndices.push_back(i64Zero);
    fullinfo.retMDGEPIndices.push_back(llvm::ConstantInt::get(i32Ty, metadataStructFields.size() - 1));
    return uniqueInfo.hasRetMD? fullinfo : iter->second.second;
  };

  // helper for updating param/ret attributes
  auto checkParamRetAttr = [](llvm::Function* func, unsigned index, llvm::PointerType* paramTy, llvm::AttributeList& destAttrs) -> bool {
    if (!destAttrs.hasAttributesAtIndex(index)) {
      return false;
    }
    bool isChangeMade = false;
    auto attrs = func->getAttributes().getAttributes(index);
    llvm::Type* newTy = getPointerElementType(paramTy);
    if (llvm::Type* oldTy = attrs.getByValType()) {
      if (oldTy != newTy) {
        destAttrs = destAttrs.replaceAttributeTypeAtIndex(newTy->getContext(), index, llvm::Attribute::ByVal, newTy);
        isChangeMade = true;
      }
    }
    if (llvm::Type* oldTy = attrs.getByRefType()) {
      if (oldTy != newTy) {
        destAttrs = destAttrs.replaceAttributeTypeAtIndex(newTy->getContext(), index, llvm::Attribute::ByRef, newTy);
        isChangeMade = true;
      }
    }
    if (llvm::Type* oldTy = attrs.getStructRetType()) {
      if (oldTy != newTy) {
        destAttrs = destAttrs.replaceAttributeTypeAtIndex(newTy->getContext(), index, llvm::Attribute::StructRet, newTy);
        isChangeMade = true;
      }
    }
    if (llvm::Type* oldTy = attrs.getPreallocatedType()) {
      if (oldTy != newTy) {
        destAttrs = destAttrs.replaceAttributeTypeAtIndex(newTy->getContext(), index, llvm::Attribute::Preallocated, newTy);
        isChangeMade = true;
      }
    }
    if (llvm::Type* oldTy = attrs.getInAllocaType()) {
      if (oldTy != newTy) {
        destAttrs = destAttrs.replaceAttributeTypeAtIndex(newTy->getContext(), index, llvm::Attribute::InAlloca, newTy);
        isChangeMade = true;
      }
    }
    if (llvm::Type* oldTy = attrs.getElementType()) {
      if (oldTy != newTy) {
        destAttrs = destAttrs.replaceAttributeTypeAtIndex(newTy->getContext(), index, llvm::Attribute::ElementType, newTy);
        isChangeMade = true;
      }
    }
    return isChangeMade;
  };

  // helper to actually perform the function type change
  auto changeFunctionInterface = [&](llvm::Function* postCloneFunction, const InstrumentationPlan::FunctionTypeChangeInfo& info) -> llvm::Function* {
    assert (postCloneFunction->getParent() == clonedModule);
    if (info.oldTy == info.newTy) {
      return postCloneFunction;
    }
    llvm::FunctionType* newFuncTy = llvm::cast<llvm::FunctionType>(info.newTy);

    // reference: https://llvm.org/doxygen/ArgumentPromotion_8cpp_source.html
    llvm::Function* newFunc = llvm::Function::Create(newFuncTy, postCloneFunction->getLinkage(), postCloneFunction->getAddressSpace(), postCloneFunction->getName());
    // at this moment the new function is not in any module yet
    newFunc->copyAttributesFrom(postCloneFunction);
    newFunc->copyMetadata(postCloneFunction, /* offset */ 0);

    // adapted from
    // NF->setAttributes(AttributeList::get(F->getContext(), PAL.getFnAttrs(), PAL.getRetAttrs(), ArgAttrVec));
    newFunc->setAttributes(postCloneFunction->getAttributes());

    // go through the function attributes
    // if there are any attributes require changing due to change of pointer type, we need to handle them here
    llvm::AttributeList curAttrList = newFunc->getAttributes();
    bool isAttrChangeMade = false;
    for (unsigned argno = 0, n = newFunc->arg_size(); argno < n; ++argno) {
      llvm::Argument* arg = newFunc->getArg(argno);
      llvm::Type* argTy = arg->getType();
      if (!isDataPointerTy(argTy)) {
        continue;
      }
      llvm::PointerType* ptrTy = llvm::cast<llvm::PointerType>(argTy);
      isAttrChangeMade |= checkParamRetAttr(newFunc, argno + llvm::AttributeList::FirstArgIndex, ptrTy, curAttrList);
    }
    if (isDataPointerTy(newFunc->getReturnType())) {
      llvm::PointerType* ptrTy = llvm::cast<llvm::PointerType>(newFunc->getReturnType());
      isAttrChangeMade |= checkParamRetAttr(newFunc, llvm::AttributeList::ReturnIndex, ptrTy, curAttrList);
    }
    if (info.retExpandArgIndex >= 0) {
      curAttrList = curAttrList.addAttributeAtIndex(newFunc->getContext(), info.retExpandArgIndex + llvm::AttributeList::FirstArgIndex, llvm::Attribute::WriteOnly);
      isAttrChangeMade = true;
    }
    if (isAttrChangeMade) {
      newFunc->setAttributes(curAttrList);
    }

    clonedModule->getFunctionList().insert(postCloneFunction->getIterator(), newFunc);
    transferValueName(newFunc, postCloneFunction);
    addPostCloneValueMapping(postCloneFunction, newFunc);

    // move the body of old code into the new code
    newFunc->getBasicBlockList().splice(newFunc->begin(), postCloneFunction->getBasicBlockList());

    // create placeholders for all old parameters
    // find the insertion point first
    llvm::Instruction* insertPoint = getBlockInsertPoint(&newFunc->getEntryBlock());

    for (unsigned i = 0, n = info.oldTy->getNumParams(); i < n; ++i) {
      llvm::Argument* oldArg = postCloneFunction->getArg(i);
      llvm::Argument* newArg = newFunc->getArg(i);
      transferValueName(newArg, oldArg);

      auto iterArgChangeInfo = info.argIndexToExpandInfoMap.find(i);
      if (iterArgChangeInfo == info.argIndexToExpandInfoMap.end()) {
        // no size type change on current parameter
        // however the point-to type may change and we may still need a converter
        if (oldArg->getType() == newArg->getType()) {
          oldArg->replaceAllUsesWith(newArg);
        } else {
          auto* converter = createBackwardConverter(newArg, oldArg->getType(), insertPoint, llvm::Twine("converter", oldArg->getName()));
          oldArg->replaceAllUsesWith(converter);
          queuePointerChange(converter);
        }
      } else {
        // size type change expected
        // if the partition index is zero, this function is not managed by EPTG and we use the default mdvec (all metadata included)
        unsigned mdvec = mdvecWithAll;
        std::size_t ptrPartitionIndex = info.argumentExpandArgInfo[iterArgChangeInfo->second].pointerPartitionIndex_withOffset;
        if (ptrPartitionIndex > 0) {
          auto iterPartition = plan.cellPartitions.find(ptrPartitionIndex);
          if (iterPartition != plan.cellPartitions.end()) {
            mdvec = iterPartition->second.pointerMDBitVec;
          } else {
            psan_unreachable("Partition index not found");
          }
        }
        if (newArg->getType() == oldArg->getType()) {
          oldArg->replaceAllUsesWith(newArg);
        } else {
          auto* converter = createBackwardConverter(newArg, oldArg->getType(), insertPoint, llvm::Twine("converter", oldArg->getName()));
          oldArg->replaceAllUsesWith(converter);
          queuePointerChange(converter);
        }
        bindArgumentsAsMetadata(newFunc, newArg, mdvec, info.argumentExpandArgInfo[iterArgChangeInfo->second], insertPoint);
      }
    }
    // now replace all returns if we do expand the return value
    if (info.retExpandArgIndex >= 0) {
      llvm::Argument* retStorePtr = newFunc->getArg(info.retExpandArgIndex);
      unsigned mdvec = mdvecWithAll;
      std::size_t retPartitionIndex = info.retPartitionIndex;
      if (retPartitionIndex > 0) {
        auto iterPartition = plan.cellPartitions.find(retPartitionIndex);
        if (iterPartition != plan.cellPartitions.end()) {
          mdvec = iterPartition->second.pointerMDBitVec;
        } else {
          psan_unreachable("Partition index not found");
        }
      }
      for(auto iterBB = newFunc->begin(), iterBBEnd = newFunc->end(); iterBB != iterBBEnd; ++iterBB) {
        llvm::BasicBlock* bb = &*iterBB;
        // since we are only looking for returns, we just need to check the terminator of each basic block
        llvm::Instruction* terminator = bb->getTerminator();
        llvm::ReturnInst* ret = llvm::dyn_cast<llvm::ReturnInst>(terminator);
        if (!ret) {
          continue;
        }
        // create the forward converter first
        llvm::Value* oldVal = ret->getReturnValue();
        llvm::Value* newVal = createForwardConverter(oldVal, newFunc->getReturnType(), ret, "return_convert");
        if (mdvec > 0) {
          // then create placeholders for the metadata
          auto& mdMap = metadataMap[newVal];
          unsigned instrumentationIndex = 0;
          unsigned numTotalValues = 0;
          llvm::SmallVector<llvm::Value*> mergedValues;
          while (mdvec) {
            if (mdvec & 1) {
              auto& mdValues = mdMap[instrumentationIndex];
              populateStubMetadataVector(mdValues, newVal, instrumentationIndex, ret, "retval");
              if (!mdValues.empty()) {
                mergedValues.append(mdValues);
                numTotalValues += mdValues.size();
              }
            }
            instrumentationIndex += 1;
            mdvec >>= 1;
          }
          // finally figure out how the metadata should be stored to the return store pointer
          // if there is only one extra value, the returnStorePtr is a pointer to the extra member
          if (mdMap.size() == 1 && mdMap.begin()->second.size() == 1) {
            llvm::Value* md = mdMap.begin()->second.front();
            assert (md->getType() == getPointerElementType(retStorePtr->getType()));
            llvm::StoreInst* mdStore = new llvm::StoreInst(md, retStorePtr, /* insertBefore */ret);
            (void) mdStore;
          } else {
            // we need to store into a struct
            llvm::StructType* sTy = llvm::cast<llvm::StructType>(getPointerElementType(retStorePtr->getType()));
            // this struct should contain all the metadata "flattened" in that
            // there is a single nesting level and all instrumentation schemes have their metadata in order
            // we will use GEP to access the individual members
            if (sTy->getNumElements() != numTotalValues) {
              psan_unreachable("Unexpected number of elements in the struct");
            }
            llvm::Value* leadingZero = llvm::ConstantInt::get(llvm::Type::getInt64Ty(clonedModule->getContext()), 0);
            llvm::IntegerType* i32Ty = llvm::Type::getInt32Ty(clonedModule->getContext());
            for (unsigned i = 0; i < numTotalValues; ++i) {
              llvm::Value* md = mergedValues[i];
              llvm::Type* mdTy = sTy->getElementType(i);
              if (md->getType() != mdTy) {
                psan_unreachable("Unexpected metadata type");
              }
              llvm::Value* memberIndex = llvm::ConstantInt::get(i32Ty, i);
              llvm::GetElementPtrInst* gep = llvm::GetElementPtrInst::CreateInBounds(sTy, retStorePtr, {leadingZero, memberIndex});
              gep->insertBefore(ret);
              llvm::StoreInst* mdStore = new llvm::StoreInst(md, gep, /* insertBefore */ret);
              (void) mdStore;
            }
          }
        }
        llvm::ReturnInst* newRet = llvm::ReturnInst::Create(clonedModule->getContext(), newVal, bb);
        newRet->copyMetadata(*ret);
        ret->replaceAllUsesWith(newRet);
        ret->eraseFromParent();
      }
      // finished handling return value expansion
    } else if (postCloneFunction->getReturnType() != newFunc->getReturnType()) {
      // return value change requires no new parameters
      // we expect this to be point-to type changes
      llvm::PointerType* oldPtrTy = llvm::cast<llvm::PointerType>(postCloneFunction->getReturnType());
      llvm::PointerType* newPtrTy = llvm::cast<llvm::PointerType>(newFunc->getReturnType());
      (void) oldPtrTy;
      for(auto iterBB = newFunc->begin(), iterBBEnd = newFunc->end(); iterBB != iterBBEnd; ++iterBB) {
        llvm::BasicBlock* bb = &*iterBB;
        // since we are only looking for returns, we just need to check the terminator of each basic block
        llvm::Instruction* terminator = bb->getTerminator();
        llvm::ReturnInst* ret = llvm::dyn_cast<llvm::ReturnInst>(terminator);
        if (!ret) {
          continue;
        }
        llvm::Value* oldVal = ret->getReturnValue();
        llvm::Value* newVal = createForwardConverter(oldVal, newPtrTy, ret, "return_convert");
        llvm::ReturnInst* newRet = llvm::ReturnInst::Create(clonedModule->getContext(), newVal, bb);
        ret->replaceAllUsesWith(newRet);
        newRet->copyMetadata(*ret);
        ret->eraseFromParent();
      }
    }
    // done with converting the type of this function
    addFunctionReplacementInfo(postCloneFunction, newFunc, info.partitionIndex);

    // if this function is outside EPTG and is address-taken, we leave the original function in place
    if (info.partitionIndex == 0) {
      bool isAddrTaken = false;
      postCloneFunction->removeDeadConstantUsers();
      for (auto& u : postCloneFunction->uses()) {
        llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(u.getUser());
        if (!call || call->getCalledOperand() != postCloneFunction) {
          isAddrTaken = true;
          break;
        }
      }
      if (isAddrTaken) {
        // verify that the parameter types are the same (we may have extra parameters for metadata though)
        llvm::FunctionType* oldTy = postCloneFunction->getFunctionType();
        llvm::FunctionType* newTy = newFunc->getFunctionType();
        for (unsigned i = 0, n = oldTy->getNumParams(); i < n; ++i) {
          if (oldTy->getParamType(i) != newTy->getParamType(i)) {
            psan_unreachable("Unexpected parameter type change");
          }
        }
        if (!postCloneFunction->getBasicBlockList().empty()) {
          psan_unreachable("postCloneFunction haven't moved body to newFunc?");
        }
        postCloneFunction->setName(newFunc->getName() + "_psan_thunk");
        postCloneFunction->clearMetadata(); // avoid attaching debug location to both the real function and the thunk
        thunkMap.insert(std::make_pair(newFunc, postCloneFunction));
        // we make postCloneFunction a thunk that calls the new function
        // the new function is only taking new parameters for metadata
        // the old function should:
        // 1. test if __psan_ind_callee points to self:
        //    if yes, retrieve all metadata from __psan_ind_md
        //    if no, initialize all metadata to zero
        //    we may need to allocate a new metadata struct for the return value; we cache them in thunkMetadataStructTypes
        // 2. call the new function
        llvm::Type* i8PtrTy = llvm::Type::getInt8PtrTy(clonedModule->getContext());
        llvm::Constant* nullPtrValue = llvm::Constant::getNullValue(i8PtrTy);
        if (!psan_ind_callee) {
          assert (!psan_ind_md);
          psan_ind_callee = llvm::cast<llvm::GlobalVariable>(clonedModule->getOrInsertGlobal("__psan_ind_callee", i8PtrTy));
          psan_ind_md = llvm::cast<llvm::GlobalVariable>(clonedModule->getOrInsertGlobal("__psan_ind_md", i8PtrTy));
          psan_ind_callee->setLinkage(llvm::GlobalValue::LinkageTypes::PrivateLinkage);
          psan_ind_callee->setThreadLocalMode(llvm::GlobalValue::ThreadLocalMode::LocalDynamicTLSModel);
          psan_ind_callee->setInitializer(nullPtrValue);
          psan_ind_md->setLinkage(llvm::GlobalValue::LinkageTypes::PrivateLinkage);
          psan_ind_md->setThreadLocalMode(llvm::GlobalValue::ThreadLocalMode::LocalDynamicTLSModel);
          psan_ind_md->setInitializer(nullPtrValue);
        }
        const auto& thunkUniqueInfo = getThunkMetadataUniqueInfo(postCloneFunction->getFunctionType());
        const auto& thunkMetadataInfo = getThunkMetadataSharedInfo(thunkUniqueInfo);
        llvm::BasicBlock* entryBB = llvm::BasicBlock::Create(clonedModule->getContext(), "entry", postCloneFunction);
        llvm::IRBuilder<> builder(entryBB);
        llvm::AllocaInst* retmd = nullptr;
        if (thunkUniqueInfo.hasRetMD) {
          retmd = builder.CreateAlloca(retMDPointsToType, nullptr, "retmd");
        }
        llvm::LoadInst* ind_callee = builder.CreateLoad(i8PtrTy, psan_ind_callee);
        llvm::LoadInst* ind_md = builder.CreateLoad(i8PtrTy, psan_ind_md);
        builder.CreateStore(nullPtrValue, psan_ind_callee);
        builder.CreateStore(nullPtrValue, psan_ind_md);
        llvm::Value* castedCurFunc = builder.CreateBitCast(postCloneFunction, i8PtrTy);
        llvm::Value* icmp = builder.CreateICmpEQ(ind_callee, castedCurFunc);
        llvm::BasicBlock* ifBB = llvm::BasicBlock::Create(clonedModule->getContext(), "if", postCloneFunction);
        llvm::BasicBlock* elseBB = llvm::BasicBlock::Create(clonedModule->getContext(), "else", postCloneFunction);
        llvm::BasicBlock* endBB = llvm::BasicBlock::Create(clonedModule->getContext(), "end", postCloneFunction);
        llvm::BranchInst* branch = builder.CreateCondBr(icmp, ifBB, elseBB);
        (void) branch;
        llvm::DenseMap<unsigned, MetadataMapTy> ifMDValueMap; // argument index -> instrumentation index -> value
        llvm::DenseMap<unsigned, MetadataMapTy> elseMDValueMap; // argument index -> instrumentation index -> value
        llvm::DenseMap<unsigned, MetadataMapTy> endMDValueMap; // argument index -> instrumentation index -> value
        llvm::Value* ifRetMDPtr = nullptr;
        llvm::Value* elseRetMDPtr = nullptr;
        builder.SetInsertPoint(ifBB);
        llvm::Value* castedMdStruct = builder.CreateBitCast(ind_md, llvm::PointerType::get(thunkMetadataInfo.metadataStructType, i8PtrTy->getPointerAddressSpace()));
        for (unsigned i = 0, n = thunkUniqueInfo.pointerArgIndices.size(); i < n; ++i) {
          unsigned argIndex = thunkUniqueInfo.pointerArgIndices[i];
          for (auto& p2 : thunkMetadataInfo.metadataOffsetMap[i]) {
            unsigned instrumentationIndex = p2.first;
            const auto& indicesList = p2.second;
            MetadataVecTy mds;
            const auto& mdTypes = instrumentations[instrumentationIndex]->getPointerMetadataTypesInRegisters();
            if (mdTypes.size() != indicesList.size()) {
              psan_unreachable("Unexpected number of indices");
            }
            for (unsigned i = 0, n = mdTypes.size(); i < n; ++i) {
              llvm::Value* gep = builder.CreateGEP(thunkMetadataInfo.metadataStructType, castedMdStruct, indicesList[i]);
              llvm::LoadInst* mdLoad = builder.CreateLoad(mdTypes[i], gep);
              mds.push_back(mdLoad);
            }
            ifMDValueMap[argIndex][instrumentationIndex] = mds;
          }
        }
        if (thunkUniqueInfo.hasRetMD) {
          ifRetMDPtr = builder.CreateGEP(thunkMetadataInfo.metadataStructType, castedMdStruct, thunkMetadataInfo.retMDGEPIndices);
        }
        // terminate if block
        builder.CreateBr(endBB);

        builder.SetInsertPoint(elseBB);
        for (unsigned i = 0, n = thunkUniqueInfo.pointerArgIndices.size(); i < n; ++i) {
          unsigned argIndex = thunkUniqueInfo.pointerArgIndices[i];
          for (auto& p2 : thunkMetadataInfo.metadataOffsetMap[i]) {
            unsigned instrumentationIndex = p2.first;
            llvm::SmallVector<llvm::Value*> mds = instrumentations[instrumentationIndex]->getUnanalyzablePointerMetadata();
            elseMDValueMap[argIndex][instrumentationIndex].assign(mds);
          }
        }
        if (thunkUniqueInfo.hasRetMD) {
          elseRetMDPtr = retmd;
        }
        // terminate else block
        builder.CreateBr(endBB);

        builder.SetInsertPoint(endBB);
        llvm::Value* newRetMDPtr = nullptr;
        for (unsigned i = 0, n = thunkUniqueInfo.pointerArgIndices.size(); i < n; ++i) {
          unsigned argIndex = thunkUniqueInfo.pointerArgIndices[i];
          const auto& trueMDSubmap = ifMDValueMap[argIndex];
          const auto& falseMDSubmap = elseMDValueMap[argIndex];
          for (auto& p2 : thunkMetadataInfo.metadataOffsetMap[i]) {
            unsigned instrumentationIndex = p2.first;
            const auto& trueMDList = getValue(trueMDSubmap,instrumentationIndex);
            const auto& falseMDList = getValue(falseMDSubmap,instrumentationIndex);
            MetadataVecTy mergedMDs;
            mergedMDs.reserve(trueMDList.size());
            for (unsigned i = 0, n = trueMDList.size(); i < n; ++i) {
              llvm::PHINode* phi = builder.CreatePHI(trueMDList[i]->getType(), 2);
              phi->addIncoming(trueMDList[i], ifBB);
              phi->addIncoming(falseMDList[i], elseBB);
              mergedMDs.push_back(phi);
            }
            endMDValueMap[argIndex][instrumentationIndex] = mergedMDs;
          }
        }
        if (thunkUniqueInfo.hasRetMD) {
          llvm::PHINode* phi = builder.CreatePHI(retMDAppendParamType, 2);
          phi->addIncoming(ifRetMDPtr, ifBB);
          phi->addIncoming(elseRetMDPtr, elseBB);
          newRetMDPtr = phi;
        }
        // now we have all metadata values ready
        // we can now call the new function
        // we first add a dummy recursive call, and then use createDirectReplacementCall() to replace it
        llvm::SmallVector<llvm::Value*> dummyArgs;
        for (unsigned i = 0, n = postCloneFunction->arg_size(); i < n; ++i) {
          llvm::Argument* arg = postCloneFunction->getArg(i);
          dummyArgs.push_back(arg);
        }
        llvm::CallInst* dummyCall = llvm::CallInst::Create(postCloneFunction, dummyArgs, "", endBB);
        dummyCall->setCallingConv(postCloneFunction->getCallingConv());
        llvm::CallBase* newCall = createDirectReplacementCall(dummyCall, newFunc, llvm::DenseMap<unsigned, llvm::Value*>(), endMDValueMap, 0, newRetMDPtr);
        dummyCall->eraseFromParent();
        llvm::ReturnInst* retInst = nullptr;
        if (newCall->getType()->isVoidTy()) {
          retInst = llvm::ReturnInst::Create(clonedModule->getContext(), endBB);
        } else {
          retInst = llvm::ReturnInst::Create(clonedModule->getContext(), newCall, endBB);
        }
        (void) retInst;
      }
    }

    return newFunc;
  };
  // now drive the function replacement
  // we first go through functions managed by EPTG, and then handle the rest
  for (auto& p : plan.funcInterfaceChanges) {
    llvm::Function* postCloneFunction = getPostCloneValue<llvm::Function>(p.first);
    stats.S5_EPTGStat_FunctionCount.increment(true);
    allFunctionsWithPtrArgRet.erase(postCloneFunction);
    std::size_t partitionIndex = p.second;
    auto iter = plan.functionTypeChanges.find(partitionIndex);
    if (iter != plan.functionTypeChanges.end()) {
      InstrumentationPlan::FunctionTypeChangeInfo& info = iter->second;
      PSAN_DEBUG(PSan::outs() << "EPTG function change: " << getValueStrWithParent(postCloneFunction) << " -> " << iter->second.newTy << "\n");
      changeFunctionInterface(postCloneFunction, info);
    } else {
      // do nothing; no type change needed
      PSAN_DEBUG(PSan::outs() << "EPTG function no change: " << getValueStrWithParent(postCloneFunction) << "\n");
    }
  }
  for (llvm::Function* func : allFunctionsWithPtrArgRet) {
    stats.S5_EPTGStat_FunctionCount.increment(false);
    llvm::FunctionType* oldTy = func->getFunctionType();
    InstrumentationPlan::FunctionTypeChangeInfo info;
    populateDefaultFunctionTypeChanges(oldTy, func, info);
    PSAN_DEBUG(PSan::outs() << "non-EPTG function change: " << getValueStrWithParent(func) << " -> " << info.newTy << "\n");
    changeFunctionInterface(func, info);
  }
  // step 2: create new global variables
  llvm::DenseMap<llvm::GlobalVariable*, GVReplacementInfo> oldToNewGVMap;
  auto addGlobalVariableReplacementInfo = [&](llvm::GlobalVariable* postCloneGV, llvm::GlobalVariable* newGV, CellEPTGNode* rootAO) -> void {
    GVReplacementInfo info;
    info.postCloneGV = postCloneGV;
    info.replacementGV = newGV;
    info.rootAO = rootAO;
    oldToNewGVMap.insert(std::make_pair(postCloneGV, info));
  };
  auto foreachGlobalVariableReplacement = [&](std::function<void(llvm::GlobalVariable*, const GVReplacementInfo&)> cb) -> void {
    for (const auto& p : oldToNewGVMap) {
      // old, new, partitionIndex
      cb(p.first, p.second);
    }
  };
  (void) foreachGlobalVariableReplacement;
  for (AllocEPTGNode* globalAllocNode : globalAllocs) {
    llvm::GlobalVariable* preCloneGV = llvm::cast<llvm::GlobalVariable>(globalAllocNode->getAllocationSite());
    llvm::GlobalVariable* postCloneGV = getPostCloneValue<llvm::GlobalVariable>(preCloneGV);
    CellEPTGNode* rootAO = globalAllocNode->getCell();
    std::size_t partitionIndex = getValue(plan.cellTypeConversions, rootAO);
    const InstrumentationPlan::EPTGCellTypeChangePartitionInfo& partitionInfo = getValue(plan.cellPartitions, partitionIndex);
    llvm::Type* destType = partitionInfo.finalType;
    // skip if there is no type change
    if (destType == postCloneGV->getValueType()) {
      continue;
    }
    PSAN_DEBUG(PSan::outs() << "GV type change [p#" << partitionIndex << " -> " << destType << "]: " << postCloneGV << "\n");
    // create the new global variable
    llvm::GlobalVariable* newGV = new llvm::GlobalVariable(*clonedModule, destType, postCloneGV->isConstant(), postCloneGV->getLinkage(), nullptr, postCloneGV->getName(),
      /* insertBefore */nullptr, postCloneGV->getThreadLocalMode(), postCloneGV->getType()->getAddressSpace());

    transferValueName(newGV, postCloneGV);
    newGV->copyAttributesFrom(postCloneGV);
    addPostCloneValueMapping(postCloneGV, newGV);
    addGlobalVariableReplacementInfo(postCloneGV, newGV, rootAO);
  }

  // step 3: redirect all reference to old global variables to the new one
  // first, correct all the initializers for global variables
  for (const auto& p : oldToNewGVMap) {
    llvm::GlobalVariable* postCloneGV = p.first;
    llvm::GlobalVariable* newGV = p.second.replacementGV;
    CellEPTGNode* rootAO = p.second.rootAO;
    if (!postCloneGV->hasInitializer()) {
      continue;
    }
    llvm::Constant* oldInitializer = postCloneGV->getInitializer();
    llvm::Constant* newInitializer = getUpdatedConstantExprInEPTG(oldInitializer, newGV->getValueType(), rootAO, postCloneRemappingMap);
    newGV->setInitializer(newInitializer);
    postCloneGV->setInitializer(nullptr);
  }

  /*
  auto getNewFuncIfPresent = [&](llvm::Function* postCloneFunc) -> llvm::Function* {
    auto iter = oldToNewFuncMap.find(postCloneFunc);
    if (iter != oldToNewFuncMap.end()) {
      return iter->second.second;
    }
    return nullptr;
  };
  */

  // TODO update valueMap for global variables and functions, since their old values will be deleted
  // also build reverseValueMap here

  // now all global variable initializers are updated
  // go through all old symbols, check where they are used, and update them
  // for functions:
  //    for each direct call: add converter functions around the calls and redirect the call target
  //        use static alloca for additional storage needed to pass wider pointers through return value; use llvm lifetime marker pairs
  //    for other references: use converter function

  for (const auto& p : oldToNewFuncMap) {
    llvm::Function* postCloneFunc = p.first;
    llvm::Function* newFunc = p.second.second;
    std::size_t partitionIndex = p.second.first;
    postCloneFunc->removeDeadConstantUsers();
    // for functions, we first find all direct calls, queue them, and then replace them
    // we don't want to modify the use list during traversing it...
    llvm::SmallVector<llvm::CallBase*> pendingDirectCalls;
    for (const llvm::Use& u : postCloneFunc->uses()) {
      llvm::User* user = u.getUser();
      if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(user)) {
        // check if the function is used as a call argument; it should be the call destination instead of an argument
        if (call->getCalledFunction() == postCloneFunc) {
          // ok, a direct call found
          pendingDirectCalls.push_back(call);
        }
      }
    }
    for (llvm::CallBase* call : pendingDirectCalls) {
      llvm::CallBase* newCall = replaceDirectCall(call, newFunc, partitionIndex);
      eraseInstrFromParent(call);
      (void) newCall;
    }
    // now everything left in the use list of postCloneFunc is using the function as a pointer value
    // if there are still uses left, the original function should be a thunk calling the actual function, so nothing needed here
    if (postCloneFunc->use_empty()) {
      // no uses left, we can delete the function
      // the function body should have been transferred
      assert (postCloneFunc->getBasicBlockList().empty());
      postCloneFunc->eraseFromParent();
    } else {
      // check if this function is in EPTG
      // if yes, we create a backward converter for each use
      if (partitionIndex != 0) {
        for (auto iter = postCloneFunc->use_begin(), iterEnd = postCloneFunc->use_end(); iter != iterEnd;) {
          auto& u = *iter;
          ++iter;
          if (llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(u.getUser())) {
            llvm::Function* parentFunc = instr->getFunction();
            llvm::DominatorTree* domTree = getDominatorTreeForPostCloneFunction(parentFunc);
            llvm::SmallVector<llvm::Use*> uses;
            uses.push_back(&u);
            llvm::Instruction* insertBeforeInst = getInsertingPointDominatingUses(postCloneFunc, parentFunc, instr, *domTree, &uses);
            llvm::Instruction* replacementValue = createBackwardConverter(newFunc, postCloneFunc->getType(), insertBeforeInst, "backconvert");
            queuePointerChange(replacementValue);
            u.set(replacementValue);
          } else if (llvm::ConstantExpr* cexpr = llvm::dyn_cast<llvm::ConstantExpr>(u.getUser())) {
            // try to create a replacement value directly from the new function
            switch(cexpr->getOpcode()) {
            default: psan_unreachable("Unexpected opcode");
            case llvm::Instruction::AddrSpaceCast:
            case llvm::Instruction::PtrToInt:
            case llvm::Instruction::BitCast: {
              llvm::Constant* replacementValue = llvm::ConstantExpr::getPointerCast(newFunc, cexpr->getType());
              cexpr->replaceAllUsesWith(replacementValue);
            } break;
            }
          } else {
            // we do not expect other types of users
            psan_unreachable("Unexpected user type");
          }
        }
      }
    }
  };
  // end of function replacement

  // for global variables:
  //    for each direct use: find the pointer partition of the root pointer, replace the user with the converter function
  //    for each use of constexpr that wraps the global variable: create parallel constexpr and then create converter call
  // therefore, basically:
  // 1. we find all instruction user of the global variables. There should not be any purely constant users at the end since we already corrected all GV initializers
  // 2. for each such instruction use, we convert all constantexprs along the way, and replace the source pointer value with the converter function

  auto handleGVValueReplacement = [&](llvm::Constant* oldExpr, llvm::Constant* newExpr,
   llvm::DenseMap<llvm::Function*, llvm::BitCastInst*>& dummyValueMap
  ) -> void {
    // when calling this function, the oldExpr (either a global variable or a constant expression backed by a global)
    // should have the replacement value newExpr available
    // in this function, we redirect users to new values and queue the changes
    // dummyValueMap should be a map from each function to a dummy bitcast value that will be used to replace the oldExpr
    for (const auto& funcPair : dummyValueMap) {
      llvm::Function* func = funcPair.first;
      llvm::DominatorTree* domTree = getDominatorTreeForPostCloneFunction(func);
      llvm::BitCastInst* dummyCast = funcPair.second;
      // first place metadata at where they need to be
      // llvm::Instruction* insertBeforeInst = getInsertingPointDominatingUses(dummyCast, func, nullptr, *domTree, &funcPair.second);
      // then replace the uses
      llvm::Instruction* insertBeforeInst = getInsertingPointDominatingUses(dummyCast, func, nullptr, *domTree);
      llvm::Instruction* replacementValue = createBackwardConverter(newExpr, oldExpr->getType(), insertBeforeInst, "backconvert");
      queuePointerChange(replacementValue);
      dummyCast->replaceAllUsesWith(replacementValue);
      assert (dummyCast->use_empty() && !dummyCast->getParent());
      dummyCast->deleteValue();
    }
  };

  // helper function to deal with constant values that are not used by any other constant expressions
  std::function<void(llvm::Constant*,llvm::Constant*,CellEPTGNode*,llvm::GlobalVariable*,llvm::GlobalVariable*,CellEPTGNode*)> handleConstGVUse =
  [&](llvm::Constant* oldExpr, llvm::Constant* newExpr, CellEPTGNode* currentAO, llvm::GlobalVariable* postCloneGV, llvm::GlobalVariable* newGV, CellEPTGNode* rootAO) -> void {
    // if this happens, we should call replaceAllUsesWith() without calling this function at all..
    assert (oldExpr->getType() != newExpr->getType());
    auto iter = oldExpr->use_begin();
    // we want to minimize the number of converters we add to the functions; just one for each function
    // for each function's user, for each instrumentation index, we keep track of their uses and provide metadata at where they are needed
    llvm::DenseMap<llvm::Function*, llvm::BitCastInst*> dummyValueMap;
    auto handleDummyUse = [&](llvm::Instruction* instrUser, llvm::Use& u) -> void {
      llvm::Function* parentFunc = instrUser->getFunction();
      // get the dummy value
      auto iter = dummyValueMap.find(parentFunc);
      llvm::BitCastInst* dummy = nullptr;
      if (iter != dummyValueMap.end()) {
        dummy = iter->second;
      } else {
        // do not bother to insert it into the function; it will be deleted soon
        dummy = new llvm::BitCastInst(llvm::UndefValue::get(oldExpr->getType()), oldExpr->getType());
        dummyValueMap.insert(std::make_pair(parentFunc, dummy));
      }
      u.set(dummy);
    };
    while (iter != oldExpr->use_end()) {
      llvm::User* user = iter->getUser();
      if (llvm::Constant* constUser = llvm::dyn_cast<llvm::Constant>(user)) {
        // the user is a constant
        // we do not expect other possible scenarios for now..
        llvm::ConstantExpr* cexpr = llvm::cast<llvm::ConstantExpr>(constUser);
        llvm::Constant* resultExpr = nullptr;
        switch (cexpr->getOpcode()) {
        default: psan_unreachable("Unexpected opcode");
        case llvm::Instruction::GetElementPtr: {
          // we create a GEP with the same set of indices
          // since we only expand pointers, the gep indices should be the same for all members
          llvm::PointerType* ptrTy = llvm::cast<llvm::PointerType>(newExpr->getType());
          llvm::SmallVector<llvm::Constant*> indices;
          assert (cexpr->getOperand(0) == oldExpr);
          for (unsigned i = 1, n = cexpr->getNumOperands(); i < n; ++i) {
            llvm::Constant* operand = cexpr->getOperand(i);
            assert (llvm::isa<llvm::ConstantInt>(operand));
            indices.push_back(operand);
          }
          resultExpr = llvm::ConstantExpr::getInBoundsGetElementPtr(getPointerElementType(ptrTy), newExpr, indices);
          // if the type is now identical to the old one, we can directly end the recursion; just replace all uses
          if (resultExpr->getType() == cexpr->getType()) {
            cexpr->replaceAllUsesWith(resultExpr);
          } else {
            // ok, the type is different and we still need changes
            MemberPosition currentMemberPos;
            if (indices.size() > 1) {
              for (unsigned i = 0, n = indices.size(); i < n; ++i) {
                llvm::ConstantInt* index = llvm::cast<llvm::ConstantInt>(indices[i]);
                currentMemberPos.push_back(index->getLimitedValue());
              }
            }
            CellEPTGNode* newAO = currentAO->getSubObjectIfAvailable(currentMemberPos);
            assert (newAO);
            // recurse to make sure cexpr's users are properly dealt with
            handleConstGVUse(cexpr, resultExpr, newAO, postCloneGV, newGV, rootAO);
          }
        } break;
        case llvm::Instruction::BitCast: {
          // we simply create a bitcast with the same destination type
          // umm we are not handling bitcasts very elegantly for now
          llvm::Type* destTy = cexpr->getType();
          resultExpr = llvm::ConstantExpr::getBitCast(newExpr, destTy);
          constUser->replaceAllUsesWith(resultExpr);
        } break;
        }
        // we should have replaced all uses
        assert (cexpr->use_empty());
        // increment
        ++iter;
      } else {
        // the user is an instruction instead of a constant
        // we create a dummy value for now and will handle them later
        auto oldIter = iter++;
        llvm::Instruction* instrUser = llvm::cast<llvm::Instruction>(user);
        handleDummyUse(instrUser, *oldIter);
      }
      // the increment for the loop is handled in the if block above; nothing else to do here
    }
    // this function does not handle direct instruction user of global variables; the caller should have handled these cases
    assert(!llvm::isa<llvm::GlobalVariable>(newExpr));
    llvm::ConstantExpr* newExprValue = llvm::cast<llvm::ConstantExpr>(newExpr);
    oldExpr->removeDeadConstantUsers();
    assert (oldExpr->use_empty());
    handleGVValueReplacement(oldExpr, newExprValue, dummyValueMap);
  };
  foreachGlobalVariableReplacement([&](llvm::GlobalVariable* postCloneGV, const GVReplacementInfo& info) -> void {
    llvm::GlobalVariable* newGV = info.replacementGV;
    postCloneGV->removeDeadConstantUsers();
    assert (postCloneGV->getType() != newGV->getType());
    bool hasUnhandledUse = false;
    // we create at most one converter in each function for this global variable
    llvm::DenseMap<llvm::Function*, llvm::BitCastInst*> dummyValueMap;
    for (auto iter = postCloneGV->use_begin(); iter != postCloneGV->use_end();) {
      llvm::User* user = iter->getUser();
      // unsigned argNo = iter->getOperandNo();
      llvm::Instruction* instrUser = llvm::dyn_cast<llvm::Instruction>(user);
      // skip constantexpr users; they will be handled in handleConstGVUse()
      if (!instrUser) {
        assert (llvm::isa<llvm::ConstantExpr>(user));
        hasUnhandledUse = true;
        ++iter;
        continue;
      }
      auto iterDummyValue = dummyValueMap.find(instrUser->getFunction());
      llvm::BitCastInst* dummyCast = nullptr;
      if (iterDummyValue != dummyValueMap.end()) {
        dummyCast = iterDummyValue->second;
      } else {
        dummyCast = new llvm::BitCastInst(llvm::UndefValue::get(postCloneGV->getType()), postCloneGV->getType());
        dummyValueMap.insert(std::make_pair(instrUser->getFunction(), dummyCast));
      }
      auto oldIter = iter++;
      oldIter->set(dummyCast);
    }
    if (!dummyValueMap.empty()) {
      handleGVValueReplacement(postCloneGV, newGV, dummyValueMap);
    }
    if (hasUnhandledUse) {
      handleConstGVUse(postCloneGV, newGV, info.rootAO, postCloneGV, newGV, info.rootAO);
    }
    postCloneGV->eraseFromParent();
  });
  // end of global variable replacement

  // start to replace local variables
  for (AllocEPTGNode* local : localAllocs) {
    llvm::AllocaInst* preCloneAlloca = llvm::cast<llvm::AllocaInst>(local->getAllocationSite());
    llvm::AllocaInst* postCloneAlloca = getPostCloneValue<llvm::AllocaInst>(preCloneAlloca);
    CellEPTGNode* rootAO = local->getCell();
    std::size_t partitionIndex = getValue(plan.cellTypeConversions, rootAO);
    auto& partitionInfo = getValue(plan.cellPartitions, partitionIndex);
    llvm::Type* destType = partitionInfo.finalType;
    llvm::Instruction* replacementValue = postCloneAlloca;
    if (destType != getPointerElementType(postCloneAlloca->getType())) {
      llvm::AllocaInst* newAlloca = new llvm::AllocaInst(destType, postCloneAlloca->getType()->getPointerAddressSpace(), postCloneAlloca->getArraySize(), postCloneAlloca->getName(), postCloneAlloca);
      transferValueName(newAlloca, postCloneAlloca);
      newAlloca->copyMetadata(*postCloneAlloca);
      replacementValue = createBackwardConverter(newAlloca, postCloneAlloca->getType(), postCloneAlloca, "backconvert");
      queuePointerChange(replacementValue);
      postCloneAlloca->replaceAllUsesWith(replacementValue);
      if (isCollectRuntimeStats()) {
        allocasForStatsCollection.erase(postCloneAlloca);
        allocasForStatsCollection.insert(std::make_pair(newAlloca, true));
        annotateInstr(newAlloca, psan_eptg_alloc_md);
      }
    } else {
      if (isCollectRuntimeStats()) {
        annotateInstr(postCloneAlloca, psan_eptg_alloc_md);
      }
    }
  }
  // now for dynamic allocations
  for (AllocEPTGNode* dynalloc : dynamicAllocs) {
    llvm::CallBase* preCloneCall = llvm::cast<llvm::CallBase>(dynalloc->getAllocationSite());
    llvm::CallBase* postCloneCall = getPostCloneValue<llvm::CallBase>(preCloneCall);
    CellEPTGNode* rootAO = dynalloc->getCell();
    std::size_t partitionIndex = getValue(plan.cellTypeConversions, rootAO);
    auto& partitionInfo = getValue(plan.cellPartitions, partitionIndex);
    llvm::Type* srcType = partitionInfo.srcType;
    llvm::Type* destType = partitionInfo.finalType;
    if (isCollectRuntimeStats()) {
      annotateInstr(postCloneCall, psan_eptg_alloc_md);
    }
    // search for the root pointer
    // if the allocation is not i8 array, we should have a bitcast immediately after the call
    llvm::Value* rootPointer = postCloneCall;
    if (!srcType->isIntegerTy(8)) {
      for (llvm::User* user : postCloneCall->users()) {
        if (llvm::BitCastInst* bitcast = llvm::dyn_cast<llvm::BitCastInst>(user)) {
          if (isCheckRequest(bitcast)) {
            continue;
          }
          rootPointer = bitcast;
          if (getPointerElementType(bitcast->getType()) != srcType) {
            psan_unreachable("Type mismatch between the cell type and root pointer points-to type for dynamic allocation");
          }
          break;
        } else {
          // we may have other users like icmp with null
          // psan_unreachable("Unexpected user of dynamic allocation");
        }
      }
    }
    if (destType != srcType) {
      // we need to create a new allocation and replace the root pointer
      const auto& layout = clonedModule->getDataLayout();
      auto srcSize = layout.getTypeAllocSize(srcType);
      auto destSize = layout.getTypeAllocSize(destType);
      if (srcSize != destSize) {
        // we need to update the size operand of the dynamic allocation
        if (llvm::Function* callee = postCloneCall->getCalledFunction()) {
          llvm::FunctionType* funcTy = postCloneCall->getFunctionType();
          if (callee->getName() == "malloc") {
            // should take a single parameter (the size in bytes) and return a single pointer
            assert (funcTy->getNumParams() == 1);
            llvm::Value* curSizeOperand = postCloneCall->getArgOperand(0);
            llvm::Value* newSizeOperand = getSizeReplacementValue(curSizeOperand, srcType, destType, postCloneCall);
            postCloneCall->setArgOperand(0, newSizeOperand);
          } else if (callee->getName() == "calloc") {
            // calloc() has a num and a size parameter
            // check if one is a constant 1 and the other is the size of the allocation
            // if yes, we only need to update the non-constant 1 parameter
            // otherwise, we manually create a multiplication to convert it to (num*size, 1) and use the same approach
            llvm::Value* numOperand = postCloneCall->getArgOperand(0);
            llvm::Value* sizeOperand = postCloneCall->getArgOperand(1);
            bool isHandled = false;
            if (llvm::ConstantInt* sizeConst = llvm::dyn_cast<llvm::ConstantInt>(sizeOperand)) {
              if (sizeConst->isOne()) {
                llvm::Value* newNumOperand = getSizeReplacementValue(numOperand, srcType, destType, postCloneCall);
                postCloneCall->setArgOperand(0, newNumOperand);
                isHandled = true;
              }
              // special case for constant size: if the size matches exactly with the source type, we can directly replace it
              else if (sizeConst->getZExtValue() == srcSize) {
                llvm::Value* newSizeOperand = getSizeReplacementValue(sizeOperand, srcType, destType, postCloneCall);
                postCloneCall->setArgOperand(1, newSizeOperand);
                isHandled = true;
              }
            }
            if (llvm::ConstantInt* numConst = llvm::dyn_cast<llvm::ConstantInt>(numOperand)) {
              if (numConst->isOne() && !isHandled) {
                llvm::Value* newSizeOperand = getSizeReplacementValue(sizeOperand, srcType, destType, postCloneCall);
                postCloneCall->setArgOperand(1, newSizeOperand);
                isHandled = true;
              }
            }
            if (!isHandled) {
              llvm::Value* compositeSize = llvm::BinaryOperator::Create(llvm::Instruction::Mul, numOperand, sizeOperand, "", postCloneCall);
              llvm::Value* newCompositeSize = getSizeReplacementValue(compositeSize, srcType, destType, postCloneCall);
              llvm::Constant* one = llvm::ConstantInt::get(sizeOperand->getType(), 1);
              postCloneCall->setArgOperand(0, newCompositeSize);
              postCloneCall->setArgOperand(1, one);
            }
          } else if (callee->getName() == "realloc") {
            // should take two parameters; one old allocation (nullable) and one size
            assert (funcTy->getNumParams() == 2);
            //llvm::Value* oldPtrOperand  = postCloneCall->getArgOperand(0);
            llvm::Value* curSizeOperand = postCloneCall->getArgOperand(1);
            llvm::Value* newSizeOperand = getSizeReplacementValue(curSizeOperand, srcType, destType, postCloneCall);
            postCloneCall->setArgOperand(1, newSizeOperand);
          } else {
            psan_unreachable("Unexpected allocation function");
          }
        } else {
          psan_unreachable("TODO Indirect call to allocation function");
        }
        // done for size update
      }
      // after the size is updated, now we handle the root pointer type change
      llvm::Value* newRootPointer = postCloneCall;
      llvm::PointerType* curRootPointerTy = llvm::cast<llvm::PointerType>(rootPointer->getType());
      llvm::Instruction* insertionPoint = postCloneCall->getNextNode();
      if (getPointerElementType(newRootPointer->getType()) != destType) {
        newRootPointer = llvm::BitCastInst::Create(llvm::Instruction::BitCast, newRootPointer, destType->getPointerTo(curRootPointerTy->getAddressSpace()), "", insertionPoint);
      }
      llvm::Instruction* replacementValue = createBackwardConverter(newRootPointer, rootPointer->getType(), insertionPoint, "backconvert");
      queuePointerChange(replacementValue);
      rootPointer->replaceAllUsesWith(replacementValue);
    }
  }
  // done with local and dynamic allocations

  // handle metadata initialization for non-EPTG global variable initializers
  // if a global variable contains a pointer and it is initialized with some valid expressions, we need to initialize the metadata for it
  if (mdscheme) {
    llvm::SmallVector<std::pair<llvm::Constant*, llvm::Constant*>> nonEPTGPointerInitializers; // list of <addr, initializer> for pointer values
    std::function<void(llvm::Constant*, llvm::GlobalVariable*, llvm::SmallVectorImpl<unsigned>&)> visitChildExpr =
    [&](llvm::Constant* expr, llvm::GlobalVariable* rootGV, llvm::SmallVectorImpl<unsigned>& indexVec) -> void {
      llvm::Type* exprTy = expr->getType();
      if (llvm::PointerType* ptrTy = llvm::dyn_cast<llvm::PointerType>(exprTy)) {
        (void) ptrTy;
        if (indexVec.empty()) {
          nonEPTGPointerInitializers.push_back(std::make_pair(rootGV, expr));
          return;
        }
        // create a GEP constantexpr from rootGV with indexVec
        llvm::SmallVector<llvm::Constant*> indices;
        indices.push_back(llvm::ConstantInt::get(i64Ty, 0));
        for (unsigned index : indexVec) {
          indices.push_back(llvm::ConstantInt::get(i32Ty, index));
        }
        llvm::Constant* gep = llvm::ConstantExpr::getInBoundsGetElementPtr(rootGV->getValueType(), rootGV, indices);
        nonEPTGPointerInitializers.push_back(std::make_pair(gep, expr));
        return;
      }
      if (llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(exprTy)) {
        for (unsigned i = 0, n = sTy->getNumElements(); i < n; ++i) {
          llvm::Constant* field = expr->getAggregateElement(i);
          llvm::Type* childTy = field->getType();
          if (llvm::isa<llvm::PointerType>(childTy) || llvm::isa<llvm::StructType>(childTy) || llvm::isa<llvm::ArrayType>(childTy)) {
            indexVec.push_back(i);
            visitChildExpr(field, rootGV, indexVec);
            indexVec.pop_back();
          }
        }
        return;
      }
      if (llvm::ArrayType* aTy = llvm::dyn_cast<llvm::ArrayType>(exprTy)) {
        llvm::Type* childTy = aTy->getElementType();
        if (llvm::isa<llvm::PointerType>(childTy) || llvm::isa<llvm::StructType>(childTy) || llvm::isa<llvm::ArrayType>(childTy)) {
          for (unsigned i = 0, n = aTy->getNumElements(); i < n; ++i) {
            llvm::Constant* element = expr->getAggregateElement(i);
            indexVec.push_back(i);
            visitChildExpr(element, rootGV, indexVec);
            indexVec.pop_back();
          }
        }
        return;
      }
    };
    for (llvm::GlobalVariable* global : nonEPTGGlobals) {
      if (!global->hasInitializer()) {
        continue;
      }
      llvm::Constant* initializer = global->getInitializer();
      if (global->isThreadLocal()) {
        // we do not handle thread-local variables for now
        continue;
      }
      if (llvm::PointerType* ptrTy = llvm::dyn_cast<llvm::PointerType>(initializer->getType())) {
        (void) ptrTy;
        nonEPTGPointerInitializers.push_back(std::make_pair(global, initializer));
        continue;
      }
      llvm::SmallVector<unsigned> addrGEPIndexList;
      visitChildExpr(initializer, global, addrGEPIndexList);
      if (!addrGEPIndexList.empty()) {
        psan_unreachable("Unexpected non-empty index list");
      }
    }
    llvm::SmallVector<std::tuple<llvm::Constant*, llvm::Constant*, llvm::GlobalVariable*>> nonEPTGPtrMetadataInitializer;
    if (!nonEPTGPointerInitializers.empty()) {
      // handle metadata initialization for non-EPTG global variable initializers
      // for each pointer in any global variable initializer, we will populate the metadata initializer for it
      // to simplify common metadata scheme implementation that only does memcpy() initialization, for each unique metadata initializer,
      // we also create a global constant that holds the initializer, so that we can memcpy() it to the actual metadata location
      // if the metadata initializer is a null value, the global constant pointer will be null as well
      // <address of pointer, metadata initializer value, global constant that holds the metadata initializer>
      llvm::DenseMap<llvm::Constant*, std::pair<llvm::Constant*, llvm::GlobalVariable*>> initializerTranslationCache;
      llvm::DenseMap<llvm::Constant*, llvm::GlobalVariable*> initializerGVCache; // metadata initializer -> global variable storing them
      for (auto& p : nonEPTGPointerInitializers) {
        llvm::Constant* ptraddr = p.first;
        llvm::Constant* ptrinitializer = p.second;
        auto iter = initializerTranslationCache.find(ptrinitializer);
        if (iter != initializerTranslationCache.end()) {
          llvm::Constant* metadataInitializer = iter->second.first;
          llvm::GlobalVariable* metadataInitializerGV = iter->second.second;
          nonEPTGPtrMetadataInitializer.push_back(std::make_tuple(ptraddr, metadataInitializer, metadataInitializerGV));
          continue;
        }
        // now we need to create the metadata initializer
        bool isAllNullValue = true;
        llvm::Constant* metadataInitializer = nullptr;
        bool isFunctionPointer = getPointerElementType(ptrinitializer->getType())->isFunctionTy();
        if (!isFunctionPointer) {
          llvm::SmallVector<llvm::Constant*> mdInitializerList;
          for (unsigned curIndex = 0, n = indicesForOOBMetadata.size(); curIndex < n; ++curIndex) {
            unsigned scheme = indicesForOOBMetadata[curIndex];
            llvm::Constant* curMDInitializer = instrumentations[scheme]->getMetadataInitializerForConstant(ptrinitializer);
            if (curMDInitializer) {
              mdInitializerList.push_back(curMDInitializer);
              isAllNullValue &= curMDInitializer->isNullValue();
            } else {
              llvm::Type* curMDTy = instrumentations[scheme]->getPointerMetadataTypeInMemory();
              mdInitializerList.push_back(llvm::Constant::getNullValue(curMDTy));
            }
          }
          if (isAllNullValue) {
            metadataInitializer = llvm::Constant::getNullValue(oobMetadataType);
          } else {
            if (PSan::isConservativeOOB()) {
              // add ptrinitializer as the initial value for the pointer field
              llvm::Constant* ptrcopy = ptrinitializer;
              if (ptrinitializer->getType() != i8PtrTy) {
                ptrcopy = llvm::ConstantExpr::getPointerCast(ptrinitializer, i8PtrTy);
              }
              mdInitializerList.push_back(ptrcopy);
            }
            if (mdInitializerList.size() == 1) {
              // there is only one metadata scheme, oobMetadataType is the same as the metadata initializer type
              metadataInitializer = mdInitializerList.front();
            } else {
              llvm::StructType* sTy = llvm::cast<llvm::StructType>(oobMetadataType);
              metadataInitializer = llvm::ConstantStruct::get(sTy, mdInitializerList);
            }
          }
        } else {
          // function pointer
          metadataInitializer = llvm::Constant::getNullValue(oobMetadataType);
        }
        if (metadataInitializer->getType() != oobMetadataType) {
          psan_unreachable("Metadata initializer type mismatch");
        }
        llvm::GlobalVariable* metadataInitializerGV = nullptr;
        if (!isAllNullValue) {
          if (metadataInitializer->isNullValue()) {
            psan_unreachable("Unexpected null metadata initializer");
          }
          auto iter = initializerGVCache.find(metadataInitializer);
          if (iter != initializerGVCache.end()) {
            metadataInitializerGV = iter->second;
          } else {
            // create a static const global with the specified initializer
            metadataInitializerGV = new llvm::GlobalVariable(*clonedModule, oobMetadataType, true, llvm::GlobalValue::InternalLinkage, metadataInitializer, "__psan_gvmdinit", nullptr, llvm::GlobalValue::NotThreadLocal);
            initializerGVCache.insert(std::make_pair(metadataInitializer, metadataInitializerGV));
          }
        }
        initializerTranslationCache.insert(std::make_pair(ptrinitializer, std::make_pair(metadataInitializer, metadataInitializerGV)));
        nonEPTGPtrMetadataInitializer.push_back(std::make_tuple(ptraddr, metadataInitializer, metadataInitializerGV));
      }
    }
    mdscheme->handleGlobalMetadataInit(nonEPTGPtrMetadataInitializer);
  }
}

std::pair<PSanInstrumentationManager::ThunkMetadataUniqueInfo*, PSanInstrumentationManager::ThunkMetadataSharedInfo*> PSanInstrumentationManager::getThunkMetadataInfo(llvm::FunctionType* ty)
{
  // this function is used after replacing function definitions
  // we can assume that the thunk info is already available
  auto iter = thunkUniqueInfo.find(ty);
  if (iter == thunkUniqueInfo.end()) {
    return std::make_pair(nullptr, nullptr);
  }
  ThunkMetadataUniqueInfo& uniqueInfo = iter->second;
  unsigned numPtrArgs = uniqueInfo.pointerArgIndices.size();
  auto iter2 = thunkMetadataStructInfo.find(numPtrArgs);
  if (iter2 == thunkMetadataStructInfo.end()) {
    // actually, there is no reason for having the unique info but not the shared info
    psan_unreachable("Unexpected missing shared info");
    return std::make_pair(nullptr, nullptr);
  }
  ThunkMetadataSharedInfo* sharedInfoPtr = uniqueInfo.hasRetMD? &iter2->second.first : &iter2->second.second;
  return std::make_pair(&uniqueInfo, sharedInfoPtr);
}

void PSanInstrumentationManager::handleSizeUpdates()
{
  // in this function, we handle the size updates from sizeOperandUpdates, which includes the size for memset/memcpy, etc but not for dynamic allocations
  // dynamic allocation size updates are done in the replaceDefinition() function

  // [function] -> [size value] -> [ptrPointsToPartitionIndex] -> list of uses
  llvm::DenseMap<llvm::Function*, llvm::DenseMap<llvm::Value*, llvm::DenseMap<std::size_t, llvm::SmallVector<llvm::Use*>>>> useUnequingMap;

  // we may have more than one pointer values for a single size value on one instruction (e.g., memcpy)
  // in this case we pick the first pointer value as the leader for size change
  llvm::DenseMap<llvm::Instruction*, llvm::DenseMap<unsigned, std::size_t>> leaderPtrMap; // instruction -> size operand index -> pointsToPartitionIndex
  for (const auto& t : graphs.sizeOperands) {
    // if the size operand list is not empty, we should have EPTG enabled
    llvm::Instruction* preCloneUser = std::get<0>(t);
    unsigned ptrArgIndex = std::get<1>(t);
    unsigned sizeArgIndex = std::get<2>(t);
    llvm::Value* preClonePtrValue = preCloneUser->getOperand(ptrArgIndex);
    auto* exprNode = graphs.eptg->getExpressionNode(preClonePtrValue);
    if (!exprNode) {
      // the pointer is not in EPTG so will not undergo type change, skip
      continue;
    }
    auto* cell = exprNode->getPointsTo();
    if (!cell) {
      continue;
    }
    std::size_t pointsToPartitionIndex = getValue(plan.cellTypeConversions, cell);
    llvm::Instruction* postCloneUser = getPostCloneValue<llvm::Instruction>(preCloneUser);
    {
      auto iter = leaderPtrMap.find(postCloneUser);
      if (iter != leaderPtrMap.end()) {
        auto iterSize = iter->second.find(sizeArgIndex);
        if (iterSize != iter->second.end()) {
          if (iterSize->second != pointsToPartitionIndex) {
            // it is possible that we don't transform any of the points-to type (e.g., copying from one character arrays to another with different sizes)
            bool isAnyHavingTypeTransform = false;
            {
              auto& partition1 = getValue(plan.cellPartitions, iterSize->second);
              if (partition1.srcType != partition1.finalType) {
                isAnyHavingTypeTransform = true;
              }
              auto& partition2 = getValue(plan.cellPartitions, pointsToPartitionIndex);
              if (partition2.srcType != partition2.finalType) {
                isAnyHavingTypeTransform = true;
              }
            }
            if (isAnyHavingTypeTransform) {
              psan_unreachable("Conflicting size updates for the same instruction and size operand index");
            }
          }
          continue;
        } else {
          iter->second.insert(std::make_pair(sizeArgIndex, pointsToPartitionIndex));
        }
      } else {
        leaderPtrMap[postCloneUser][sizeArgIndex] = pointsToPartitionIndex;
      }
    }
    llvm::Value* sizeValue = postCloneUser->getOperand(sizeArgIndex);
    llvm::Function* parentFunc = postCloneUser->getFunction();
    auto& ptrMap = useUnequingMap[parentFunc][sizeValue];
    auto& useList = ptrMap[pointsToPartitionIndex];
    useList.push_back(&postCloneUser->getOperandUse(sizeArgIndex));
  }
  for (auto& p_func : useUnequingMap) {
    llvm::Function* func = p_func.first;
    llvm::DominatorTree* domTree = getDominatorTreeForPostCloneFunction(func);
    for (auto& p_size : p_func.second) {
      llvm::Value* sizeValue = p_size.first;
      for (auto& p_ptr : p_size.second) {
        std::size_t pointsToPartitionIndex = p_ptr.first;
        const InstrumentationPlan::EPTGCellTypeChangePartitionInfo& partitionInfo = getValue(plan.cellPartitions, pointsToPartitionIndex);
        auto& useList = p_ptr.second;
        llvm::Instruction* insertBeforeInst = getInsertingPointDominatingUses(sizeValue, func, nullptr, *domTree, &useList);
        llvm::Value* replacementValue = getSizeReplacementValue(sizeValue, partitionInfo.srcType, partitionInfo.finalType, insertBeforeInst);
        if (replacementValue != sizeValue) {
          for (llvm::Use* u : useList) {
            u->set(replacementValue);
          }
        }
      }
    }
  }
}

llvm::Value* PSanInstrumentationManager::getPtrMDValidityValue(llvm::Value* mdaddr, llvm::Value* ptr, llvm::Instruction* insertBefore)
{
  if (!PSan::isConservativeOOB()) {
    psan_unreachable("getPtrMDValidityValue() should not be called when not using conservative OOB");
  }
  if (mdaddr->getType() != oobMetadataType->getPointerTo()) {
    psan_unreachable("Unexpected metadata address type");
  }
  llvm::ConstantInt* indexValue = llvm::ConstantInt::get(i32Ty, indicesForOOBMetadata.size());
  llvm::GetElementPtrInst* gep = llvm::GetElementPtrInst::CreateInBounds(oobMetadataType, mdaddr, {i64zero, indexValue} , "", insertBefore);
  llvm::Value* ptrcopy = new llvm::LoadInst(i8PtrTy, gep, "", insertBefore);
  llvm::Value* curPtr = ptr;
  if (ptr->getType() != i8PtrTy) {
    curPtr = new llvm::BitCastInst(ptr, i8PtrTy, "", insertBefore);
  }
  llvm::ICmpInst* icmp = new llvm::ICmpInst(insertBefore, llvm::ICmpInst::ICMP_EQ, ptrcopy, curPtr, "");
  return icmp;
}

void PSanInstrumentationManager::replacePointerLoadStores()
{
  // during preparation, we have populated all load/stores of pointers to corresponding data structures
  // in this function we will add the code that load/store the metadata as well
  // we first handle all the loads then all the stores because if a load is followed by the store,
  // we don't need to waste time creating the placeholder metadata for the stored value

  auto expandMDLoadForOOB = [this](MetadataMapTy& mddest, llvm::Value* mdaddr, llvm::Value* ptr, llvm::Instruction* insertBefore) -> void {
    if (indicesForOOBMetadata.size() == 1 && !PSan::isConservativeOOB()) {
      // just one scheme; the metadata type is the in-memory metadata type of that scheme
      unsigned scheme = indicesForOOBMetadata.front();
      llvm::Type* mdTy = instrumentations[scheme]->getPointerMetadataTypeInMemory();
      llvm::Value* castedMDAddr = new llvm::BitCastInst(mdaddr, mdTy->getPointerTo(), "", insertBefore);
      llvm::SmallVector<llvm::Value*> mdVec;
      instrumentations[scheme]->emitMetadataLoad(insertBefore, castedMDAddr, mdVec);
      assignMetadataVec(mddest[scheme], mdVec);
    } else {
      // need to use geps to access the metadata for each scheme
      llvm::Type* mdTy = oobMetadataType;
      llvm::Value* castedMDAddr = new llvm::BitCastInst(mdaddr, mdTy->getPointerTo(), "", insertBefore);
      llvm::Value* ptrmdValidityValue = nullptr; // i1 value for the pointer metadata validity
      if (PSan::isConservativeOOB()) {
        ptrmdValidityValue = getPtrMDValidityValue(castedMDAddr, ptr, insertBefore);
      }
      for (unsigned curIndex = 0, n = indicesForOOBMetadata.size(); curIndex < n; ++curIndex) {
        unsigned scheme = indicesForOOBMetadata[curIndex];
        llvm::ConstantInt* indexValue = llvm::ConstantInt::get(i32Ty, curIndex);
        llvm::Value* gep = llvm::GetElementPtrInst::CreateInBounds(mdTy, castedMDAddr, {i64zero, indexValue} , "", insertBefore);
        llvm::SmallVector<llvm::Value*> mdVec;
        instrumentations[scheme]->emitMetadataLoad(insertBefore, gep, mdVec);
        if (ptrmdValidityValue) {
          // we need to select the metadata based on the validity of the pointer metadata
          // set them to null if the pointer metadata is invalid
          decltype(mdVec) newMDVec;
          for (llvm::Value* md : mdVec) {
            llvm::Value* nullvalue = llvm::Constant::getNullValue(md->getType());
            llvm::SelectInst* select = llvm::SelectInst::Create(ptrmdValidityValue, md, nullvalue, "", insertBefore);
            newMDVec.push_back(select);
          }
          newMDVec.swap(mdVec);
        }
        assignMetadataVec(mddest[scheme], mdVec);
      }
    }
  };

  auto expandMDStoreForOOB = [&](MetadataMapTy& mdsrc, llvm::Value* valueToStore, llvm::Value* mdaddr, llvm::Instruction* insertBefore) -> void {
    if (indicesForOOBMetadata.size() == 1 && !PSan::isConservativeOOB()) {
      // just one scheme; the metadata type is the in-memory metadata type of that scheme
      unsigned scheme = indicesForOOBMetadata.front();
      llvm::Type* mdTy = instrumentations[scheme]->getPointerMetadataTypeInMemory();
      llvm::Value* castedMDAddr = new llvm::BitCastInst(mdaddr, mdTy->getPointerTo(), "", insertBefore);
      auto& mdVec = mdsrc[scheme];
      populateStubMetadataVector(mdVec, valueToStore, scheme, insertBefore, "store");
      instrumentations[scheme]->emitMetadataStore(insertBefore, castedMDAddr, mdVec);
      if (valueToStore && PSan::isEnableRuntimeMDStoreCheckDebug()) {
        instrumentations[scheme]->instrumentCheck_Debug(insertBefore, valueToStore, mdVec, globalCheckCount++);
      }
    } else {
      // need to use geps to access the metadata for each scheme
      llvm::Type* mdTy = oobMetadataType;
      llvm::Value* castedMDAddr = new llvm::BitCastInst(mdaddr, mdTy->getPointerTo(), "", insertBefore);
      for (unsigned curIndex = 0, n = indicesForOOBMetadata.size(); curIndex < n; ++curIndex) {
        unsigned scheme = indicesForOOBMetadata[curIndex];
        llvm::ConstantInt* indexValue = llvm::ConstantInt::get(i32Ty, curIndex);
        llvm::Value* gep = llvm::GetElementPtrInst::CreateInBounds(mdTy, castedMDAddr, {i64zero, indexValue} , "", insertBefore);
        auto& mdVec = mdsrc[scheme];
        populateStubMetadataVector(mdVec, valueToStore, scheme, insertBefore, "store");
        instrumentations[scheme]->emitMetadataStore(insertBefore, gep, mdVec);
        if (valueToStore && PSan::isEnableRuntimeMDStoreCheckDebug()) {
          instrumentations[scheme]->instrumentCheck_Debug(insertBefore, valueToStore, mdVec, globalCheckCount++);
        }
      }
      if (PSan::isConservativeOOB()) {
        // store a copy of the pointer value to the last metadata slot
        llvm::ConstantInt* indexValue = llvm::ConstantInt::get(i32Ty, indicesForOOBMetadata.size());
        llvm::Value* ptrcopyAddr = llvm::GetElementPtrInst::CreateInBounds(mdTy, castedMDAddr, {i64zero, indexValue} , "", insertBefore);
        llvm::Value* ptrcopy = valueToStore;
        if (ptrcopy->getType() != i8PtrTy) {
          ptrcopy = new llvm::BitCastInst(ptrcopy, i8PtrTy, "", insertBefore);
        }
        llvm::StoreInst* store = new llvm::StoreInst(ptrcopy, ptrcopyAddr, insertBefore);
        (void) store;
      }
    }
  };

  // start with loads first
  if (mdscheme) {
    for (llvm::LoadInst* load : ptrloadsForMD_oob) {
      // check if this load is loading a pointer vector or a regular pointer
      llvm::Type* loadedTy = load->getType();
      llvm::Value* ptr = load->getPointerOperand();
      PSAN_DEBUG(PSan::outs() << "OOB PtrLoad: " << getValueStrWithParent(load) << "\n");
      if (isCollectRuntimeStats()) {
        incrementRuntimeStat(RTStatKind::PtrLoad_OOB, load);
      }
      llvm::Instruction* insertBefore = load->getNextNode();
      if (llvm::VectorType* vTy = llvm::dyn_cast<llvm::VectorType>(loadedTy)) {
        // we are loading a vector of pointers
        if (!isDataPointerTy(vTy->getElementType())) {
          // we are loading a vector of non-pointer type
          // we should not have this case
          psan_unreachable("Unexpected vector type");
        }
        auto elementCount = vTy->getElementCount();
        if (elementCount.isScalable()) {
          // we do not support scalable vectors yet
          psan_unreachable("Unexpected scalable vector type");
        }
        unsigned elementCountValue = elementCount.getFixedValue();
        auto vec = mdscheme->getMetadataAddressForMDLoadVector(ptr, elementCountValue, insertBefore);
        if (vec.size() != elementCountValue) {
          psan_unreachable("Unexpected vector size mismatch");
        }
        auto& destMDVec = vectorMetadataMap[load];
        unsigned index = 0;
        for (llvm::Value* mdaddr : vec) {
          MetadataMapTy mdMap;
          llvm::ConstantInt* indexValue = llvm::ConstantInt::get(i32Ty, index++);
          llvm::ExtractElementInst* loadedValue = llvm::ExtractElementInst::Create(load, indexValue, "", insertBefore);
          expandMDLoadForOOB(mdMap, mdaddr, loadedValue, insertBefore);
          destMDVec.push_back(mdMap);
        }
        mdscheme->releaseMetadataAddressForMDLoadVector(ptr, vec, insertBefore);
      } else {
        // we are loading a single pointer
        if (!isDataPointerTy(loadedTy)) {
          // we are loading a non-pointer type
          // we should not have this case
          psan_unreachable("Unexpected non-pointer type");
        }
        llvm::Value* mdaddr = mdscheme->getMetadataAddressForMDLoad(ptr, insertBefore);
        auto& mdMap = metadataMap[load];
        expandMDLoadForOOB(mdMap, mdaddr, load, insertBefore);
        dumpPointerMetadata(load, mdMap, insertBefore, "OOBLoad");
        mdscheme->releaseMetadataAddressForMDLoad(ptr, mdaddr, insertBefore);
      }
    }
    ptrloadsForMD_oob.clear();
  }

  for (auto& p : ptrloadsForMD_eptg) {
    llvm::LoadInst* load = p.first;
    ExpressionEPTGNode* addrExpr = p.second;
    llvm::Value* ptr = load->getPointerOperand();
    CellEPTGNode* ptrCell = addrExpr->getPointsTo();
    std::size_t partition = getValue(plan.cellTypeConversions, ptrCell);
    const auto& partitionInfo = getValue(plan.cellPartitions, partition);
    unsigned pointerMDBitVec = partitionInfo.pointerMDBitVec;
    llvm::Type* destTy = partitionInfo.finalType;
    PSAN_DEBUG(PSan::outs() << "EPTG PtrLoad"
                            << ": E#" << addrExpr->getId() << " -> C#" << ptrCell->getId()
                            << " Partition #" << partition
                            << " DestTy: " << destTy << "\n"
                            << "  " << getValueStrWithParent(load) << "\n");
    if (isCollectRuntimeStats()) {
      incrementRuntimeStat(RTStatKind::PtrLoad_InEPTG, load);
    }
    if (pointerMDBitVec == 0 && destTy == partitionInfo.srcType) {
      // no operation needed
      continue;
    }
    // if we reach here, then either the points-to type changes, or we need to also load the metadata
    // no matter what, the type of the address pointer should be changed and we cannot use the old load
    // so the first step is to create the forward converter for the address and create the new load
    llvm::Type* expectedAddrTy = llvm::PointerType::get(destTy, ptr->getType()->getPointerAddressSpace());
    if (ptr->getType() == expectedAddrTy) {
      psan_unreachable("Having points-to type change or inline metadata but no change in address pointer type");
    }
    llvm::Value* newAddr = createForwardConverter(ptr, expectedAddrTy, load, "psan_eptg_ptrload_addrcast");
    llvm::Value* newLeadPtrAddr = nullptr;
    // if the pointed pointer becomes a struct, we need to create a GEP to access the actual pointer
    llvm::PointerType* leadPtrTy = nullptr;
    if (llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(destTy)) {
      leadPtrTy = llvm::cast<llvm::PointerType>(sTy->getElementType(0));
      newLeadPtrAddr = llvm::GetElementPtrInst::CreateInBounds(destTy, newAddr, {i64zero, i32zero}, "", load);
    } else {
      leadPtrTy = llvm::cast<llvm::PointerType>(destTy);
      newLeadPtrAddr = newAddr;
    }
    llvm::LoadInst* newLeadPtr = new llvm::LoadInst(leadPtrTy, newLeadPtrAddr, "", load);
    transferValueName(newLeadPtr, load);
    newLeadPtr->copyMetadata(*load);
    llvm::Instruction* newLeadPtrCasted = newLeadPtr;
    if (leadPtrTy != load->getType()) {
      // we need to cast the loaded pointer to the original type
      newLeadPtrCasted = createBackwardConverter(newLeadPtr, load->getType(), load, "psan_eptg_ptrload");
      queuePointerChange(newLeadPtrCasted);
      PSAN_DEBUG(PSan::outs() << "  Backward convert: " << newLeadPtrCasted << "\n");
    }
    load->replaceAllUsesWith(newLeadPtrCasted);
    PSAN_DEBUG(PSan::outs() << "New load: " << newLeadPtr << "\n");
    // if the pointer also have metadata, we load them as well
    if (pointerMDBitVec != 0) {
      llvm::StructType* sTy = llvm::cast<llvm::StructType>(destTy);
      unsigned gepSecondIndex = 1;
      unsigned curSchemeIndex = 0;
      unsigned mdvec = pointerMDBitVec;
      while (mdvec) {
        if (mdvec & 1) {
          llvm::Type* inMemTy = instrumentations[curSchemeIndex]->getPointerMetadataTypeInMemory();
          if (sTy->getElementType(gepSecondIndex) != inMemTy) {
            psan_unreachable("Unexpected metadata type mismatch");
          }
          llvm::GetElementPtrInst* mdGEP = llvm::GetElementPtrInst::CreateInBounds(destTy, newAddr, {i64zero, llvm::ConstantInt::get(i32Ty, gepSecondIndex)}, "", load);
          gepSecondIndex += 1;
          llvm::SmallVector<llvm::Value*> mdVec;
          instrumentations[curSchemeIndex]->emitMetadataLoad(load, mdGEP, mdVec);
          assignMetadataVec(metadataMap[newLeadPtr][curSchemeIndex], mdVec);
        }
        mdvec >>= 1;
        ++curSchemeIndex;
      }
      dumpPointerMetadata(newLeadPtr, metadataMap[newLeadPtr], load, "EPTGLoad");
    }
    // done with this load
    replaceValueForMD(load, newLeadPtrCasted);
    eraseInstrFromParent(load);
  }
  ptrloadsForMD_eptg.clear();

  // now stores
  if (mdscheme) {
    for (llvm::StoreInst* store : ptrstoresForMD_oob) {
      llvm::Value* ptr = store->getPointerOperand();
      llvm::Value* val = store->getValueOperand();
      llvm::Type* storedTy = val->getType();
      if (isCollectRuntimeStats()) {
        incrementRuntimeStat(RTStatKind::PtrStore_OOB, store);
      }
      PSAN_DEBUG(PSan::outs() << "OOB PtrStore: " << getValueStrWithParent(store) << "\n");
      if (llvm::VectorType* vTy = llvm::dyn_cast<llvm::VectorType>(storedTy)) {
        // we are storing a vector of pointers
        if (!isDataPointerTy(vTy->getElementType())) {
          // we are storing a vector of non-pointer type
          // we should not have this case
          psan_unreachable("Unexpected vector type");
        }
        auto elementCount = vTy->getElementCount();
        if (elementCount.isScalable()) {
          // we do not support scalable vectors yet
          psan_unreachable("Unexpected scalable vector type");
        }
        unsigned elementCountValue = elementCount.getFixedValue();
        auto vec = mdscheme->getMetadataAddressForMDStoreVector(ptr, elementCountValue, store);
        if (vec.size() != elementCountValue) {
          psan_unreachable("Unexpected vector size mismatch");
        }
        auto& destMDVec = vectorMetadataMap[val];
        if (destMDVec.empty()) {
          destMDVec.resize(elementCountValue);
        } else {
          if (destMDVec.size() != elementCountValue) {
            psan_unreachable("Unexpected vector size mismatch");
          }
        }
        if (llvm::ConstantVector* constVec = llvm::dyn_cast<llvm::ConstantVector>(val)) {
          for (unsigned i = 0; i < elementCountValue; ++i) {
            llvm::Constant* value = constVec->getAggregateElement(i);
            expandMDStoreForOOB(destMDVec[i], value, vec[i], store);
          }
        } else if (llvm::ConstantDataVector* constVec = llvm::dyn_cast<llvm::ConstantDataVector>(val)) {
          for (unsigned i = 0; i < elementCountValue; ++i) {
            llvm::Constant* value = constVec->getElementAsConstant(i);
            expandMDStoreForOOB(destMDVec[i], value, vec[i], store);
          }
        } else if (llvm::Constant* miscConstVec = llvm::dyn_cast<llvm::Constant>(val)) {
          // some unknown constant vector we are not supporting yet
          (void) miscConstVec;
          llvm::Type* elementTy = vTy->getElementType();
          llvm::Constant* value = llvm::Constant::getNullValue(elementTy);
          for (unsigned i = 0; i < elementCountValue; ++i) {
            expandMDStoreForOOB(destMDVec[i], value, vec[i], store);
          }
        } else if (llvm::Instruction* instrVec = llvm::dyn_cast<llvm::Instruction>(val)) {
          for (unsigned i = 0; i < elementCountValue; ++i) {
            llvm::ConstantInt* index = llvm::ConstantInt::get(i32Ty, i);
            llvm::Value* value = llvm::ExtractElementInst::Create(instrVec, index, "", store);
            expandMDStoreForOOB(destMDVec[i], value, vec[i], store);
          }
          ptrMetadataRequestWorklist.insert(instrVec);
        } else {
          psan_unreachable("Unexpected vector value type");
        }
        mdscheme->releaseMetadataAddressForMDStoreVector(ptr, vec, store->getNextNode());
      } else {
        // we are storing a single pointer
        if (!isDataPointerTy(storedTy)) {
          // we are storing a non-pointer type
          // we should not have this case
          psan_unreachable("Unexpected non-pointer type");
        }
        llvm::Value* mdaddr = mdscheme->getMetadataAddressForMDStore(ptr, store);
        auto& mdMap = metadataMap[val];
        expandMDStoreForOOB(mdMap, val, mdaddr, store);
        dumpPointerMetadata(val, mdMap, store, "OOBStore");
        mdscheme->releaseMetadataAddressForMDStore(ptr, mdaddr, store->getNextNode());
      }
    }
    ptrstoresForMD_oob.clear();
  }

  for (auto& p : ptrstoresForMD_eptg) {
    llvm::StoreInst* store = p.first;
    ExpressionEPTGNode* addrExpr = p.second;
    llvm::Value* ptr = store->getPointerOperand();
    llvm::Value* val = store->getValueOperand();
    CellEPTGNode* ptrCell = addrExpr->getPointsTo();
    std::size_t partition = getValue(plan.cellTypeConversions, ptrCell);
    const auto& partitionInfo = getValue(plan.cellPartitions, partition);
    unsigned pointerMDBitVec = partitionInfo.pointerMDBitVec;
    llvm::Type* destTy = partitionInfo.finalType;
    PSAN_DEBUG(PSan::outs() << "EPTG PtrStore"
                            << ": E#" << addrExpr->getId() << " -> C#" << ptrCell->getId()
                            << " Partition #" << partition
                            << " DestTy: " << destTy << "\n"
                            << "  " << getValueStrWithParent(store) << "\n");
    if (isCollectRuntimeStats()) {
      incrementRuntimeStat(RTStatKind::PtrStore_InEPTG, store);
    }
    if (pointerMDBitVec == 0 && destTy == partitionInfo.srcType) {
      // no operation needed
      continue;
    }
    // if we reach here, then either the points-to type changes, or we need to also store the metadata
    // no matter what, the type of the address pointer should be changed and we cannot use the old store
    // so the first step is to create the forward converter for the address and create the new store
    llvm::Type* expectedAddrTy = llvm::PointerType::get(destTy, ptr->getType()->getPointerAddressSpace());
    if (ptr->getType() == expectedAddrTy) {
      psan_unreachable("Having points-to type change or inline metadata but no change in address pointer type");
    }
    llvm::Value* newAddr = createForwardConverter(ptr, expectedAddrTy, store, "psan_eptg_ptrstore_addrcast");
    llvm::Value* newLeadPtrAddr = nullptr;
    // if the pointed pointer becomes a struct, we need to create a GEP to access the actual pointer
    llvm::PointerType* leadPtrTy = nullptr;
    if (llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(destTy)) {
      leadPtrTy = llvm::cast<llvm::PointerType>(sTy->getElementType(0));
      newLeadPtrAddr = llvm::GetElementPtrInst::CreateInBounds(destTy, newAddr, {i64zero, i32zero}, "", store);
    } else {
      leadPtrTy = llvm::cast<llvm::PointerType>(destTy);
      newLeadPtrAddr = newAddr;
    }
    llvm::Value* valToStore = val;
    if (val->getType() != leadPtrTy) {
      llvm::Value* newLeadPtr = createForwardConverter(val, leadPtrTy, store, "psan_eptg_ptrstore_valcast");
      valToStore = newLeadPtr;
    }
    llvm::StoreInst* newStore = new llvm::StoreInst(valToStore, newLeadPtrAddr, store);
    transferValueName(newStore, store);
    newStore->copyMetadata(*store);
    PSAN_DEBUG(PSan::outs() << "New store: " << newStore << "\n");
    // if the pointer also have metadata, we store them as well
    if (pointerMDBitVec != 0) {
      llvm::StructType* sTy = llvm::cast<llvm::StructType>(destTy);
      unsigned gepSecondIndex = 1;
      unsigned curSchemeIndex = 0;
      unsigned mdvec = pointerMDBitVec;
      while (mdvec) {
        if (mdvec & 1) {
          llvm::Type* inMemTy = instrumentations[curSchemeIndex]->getPointerMetadataTypeInMemory();
          if (sTy->getElementType(gepSecondIndex) != inMemTy) {
            psan_unreachable("Unexpected metadata type mismatch");
          }
          llvm::GetElementPtrInst* mdGEP = llvm::GetElementPtrInst::CreateInBounds(destTy, newAddr, {i64zero, llvm::ConstantInt::get(i32Ty, gepSecondIndex)}, "", store);
          gepSecondIndex += 1;
          MetadataVecTy& mdVec = metadataMap[valToStore][curSchemeIndex];
          populateStubMetadataVector(mdVec, valToStore, curSchemeIndex, store, "store");
          instrumentations[curSchemeIndex]->emitMetadataStore(store, mdGEP, mdVec);
          if (PSan::isEnableRuntimeMDStoreCheckDebug()) {
            instrumentations[curSchemeIndex]->instrumentCheck_Debug(store, valToStore, mdVec, globalCheckCount++);
          }
        }
        mdvec >>= 1;
        ++curSchemeIndex;
      }
      dumpPointerMetadata(valToStore, metadataMap[valToStore], store, "EPTGStore");
    }
    // done with this store
    eraseInstrFromParent(store);
  }
  ptrstoresForMD_eptg.clear();
}

void PSanInstrumentationManager::handleCallsForMDProp()
{
  // this function handles function calls with non-EPTG pointer arguments / return values (excluding direct calls to internally defined functions)
  // we need to handle the following data structures:
  // - intrinsicCallsForMDProp: set of intrinsic calls (e.g., memset/memcpy/memmove) that need special handling for metadata
  // - allocatorCallsForMDProp: set of allocator calls
  // - opaqueCallsForMDProp: everything else

  // first, handle non-intrinsic calls
  // if this is an indirect call, we implement the indirect call interface for metadata passing
  // if this is a direct call, we create empty metadata for the return value
  // (the external callee won't be able to use the metadata anyway, so no passing for pointer argument metadata)

  // data structure to cache all metadata allocas for indirect call metadata passing
  llvm::DenseMap<llvm::Function*, llvm::DenseMap<llvm::Type*, llvm::AllocaInst*>> indCallMetadataAllocMap;

  for (llvm::CallBase* call : opaqueCallsForMDProp) {
    llvm::Value* callee = call->getCalledOperand();
    bool isHandled = false;
    if (llvm::InlineAsm* asmCallee = llvm::dyn_cast<llvm::InlineAsm>(callee)) {
      (void) asmCallee;
    } else if (llvm::Function* funcCallee = llvm::dyn_cast<llvm::Function>(callee)) {
      if (!funcCallee->isDeclaration()) {
        psan_unreachable("Unexpected non-declaration function");
      }
    } else {
      // indirect call
      llvm::FunctionType* calleeTy = call->getFunctionType();
      ThunkMetadataUniqueInfo* thunkUniqueInfo = nullptr;
      ThunkMetadataSharedInfo* thunkSharedInfo = nullptr;
      std::tie(thunkUniqueInfo, thunkSharedInfo) = getThunkMetadataInfo(calleeTy);
      if (thunkUniqueInfo && thunkSharedInfo) {
        // this indirect call is possible to internally-defined functions and we should use the indirect call convention here
        llvm::StructType* mdTy = thunkSharedInfo->metadataStructType;
        llvm::Function* caller = call->getFunction();
        llvm::AllocaInst*& mdAlloca = indCallMetadataAllocMap[caller][mdTy];
        if (!mdAlloca) {
          llvm::Instruction* insertPoint = getBlockInsertPoint(&caller->getEntryBlock());
          mdAlloca = new llvm::AllocaInst(mdTy, 0, "", insertPoint);
        }

        for (unsigned i = 0, n = thunkUniqueInfo->pointerArgIndices.size(); i < n; ++i) {
          unsigned ptrArgIndex = thunkUniqueInfo->pointerArgIndices[i];
          llvm::DenseMap<unsigned, llvm::SmallVector<llvm::SmallVector<llvm::Value*>>>& mdGEPIndexMap = thunkSharedInfo->metadataOffsetMap[i];
          llvm::Value* arg = call->getArgOperand(ptrArgIndex);
          // llvm::DenseMap<unsigned, llvm::SmallVector<llvm::SmallVector<llvm::Value*>>>
          if (!isDataPointerTy(arg->getType())) {
            psan_unreachable("Unexpected non-pointer type");
          }
          for (unsigned instrumentationIndex = 0, n = instrumentations.size(); instrumentationIndex < n; ++instrumentationIndex) {
            const llvm::SmallVector<llvm::Type*>& mdTypes = instrumentations[instrumentationIndex]->getPointerMetadataTypesInRegisters();
            if (mdTypes.empty()) {
              continue;
            }
            auto iterMDIndex = mdGEPIndexMap.find(instrumentationIndex);
            if (iterMDIndex == mdGEPIndexMap.end()) {
              psan_unreachable("instrumentation scheme having in-reg metadata but not registered");
            }
            if (!((1u << instrumentationIndex) & mdvecWithAll)) {
              psan_unreachable("instrumentation scheme having in-reg metadata but not registered");
            }
            auto& gepIndices = iterMDIndex->second;
            MetadataVecTy& mdvec = metadataMap[arg][instrumentationIndex];
            populateStubMetadataVector(mdvec, arg, instrumentationIndex, call, "arg_mdprop");
            for (unsigned j = 0, m = mdTypes.size(); j < m; ++j) {
              llvm::Value* gep = llvm::GetElementPtrInst::CreateInBounds(mdTy, mdAlloca, gepIndices[j], "", call);
              llvm::Value* mdValue = mdvec[j];
              llvm::StoreInst* store = new llvm::StoreInst(mdValue, gep, call);
              (void) store;
            }
          }
        }
        if (thunkUniqueInfo->hasRetMD) {
          llvm::Value* retMDGEP = llvm::GetElementPtrInst::CreateInBounds(mdTy, mdAlloca, thunkSharedInfo->retMDGEPIndices, "", call);
          std::size_t cumulativeIndexBase = 0;
          for (unsigned instrumentationIndex = 0, n = instrumentations.size(); instrumentationIndex < n; ++instrumentationIndex) {
            const llvm::SmallVector<llvm::Type*>& mdTypes = instrumentations[instrumentationIndex]->getPointerMetadataTypesInRegisters();
            if (mdTypes.empty()) {
              continue;
            }
            const auto& mdvec = instrumentations[instrumentationIndex]->getUnanalyzablePointerMetadata();
            llvm::Instruction* insertPoint = call->getNextNode();
            MetadataVecTy retMDVecTemp;
            for (unsigned i = 0; i < mdTypes.size(); ++i) {
              llvm::Value* gep = llvm::GetElementPtrInst::CreateInBounds(retMDPointsToType, retMDGEP, {i64zero, llvm::ConstantInt::get(i32Ty, cumulativeIndexBase + i)}, "", call);
              llvm::Value* mdValue = mdvec[i];
              llvm::StoreInst* store = new llvm::StoreInst(mdValue, gep, call);
              (void) store;
              llvm::Value* newMDValue = new llvm::LoadInst(mdTypes[i], gep, "", insertPoint);
              retMDVecTemp.push_back(newMDValue);
            }
            assignMetadataVec(metadataMap[call][instrumentationIndex], retMDVecTemp);
            cumulativeIndexBase += mdTypes.size();
          }
        }
        llvm::Value* calleeCasted = new llvm::BitCastInst(callee, i8PtrTy, "", call);
        llvm::StoreInst* storeCallee = new llvm::StoreInst(calleeCasted, psan_ind_callee, call);
        llvm::Value* mdCasted = new llvm::BitCastInst(mdAlloca, i8PtrTy, "", call);
        llvm::StoreInst* storeMD = new llvm::StoreInst(mdCasted, psan_ind_md, call);
        (void) storeCallee;
        (void) storeMD;
        // if this is a tail call, we need to drop the tail call attribute because tail calls cannot access alloca (will cause miscompilation)
        // https://github.com/llvm/llvm-project/issues/56435#issuecomment-1178758792
        if (call->isTailCall()) {
          llvm::cast<llvm::CallInst>(call)->setTailCall(false);
        }
        isHandled = true;
      }
    }
    if (!isHandled) {
      // if this call produces a pointer, we create empty metadata for it, otherwise we do nothing
      if (isDataPointerTy(call->getType())) {
        for (unsigned instrumentationIndex = 0, n = instrumentations.size(); instrumentationIndex < n; ++instrumentationIndex) {
          const llvm::SmallVector<llvm::Type*>& mdTypes = instrumentations[instrumentationIndex]->getPointerMetadataTypesInRegisters();
          if (mdTypes.empty()) {
            continue;
          }
          MetadataVecTy& retMDVec = metadataMap[call][instrumentationIndex];
          assignMetadataVec(retMDVec, instrumentations[instrumentationIndex]->getUnanalyzablePointerMetadata());
        }
      }
    }
  }
  opaqueCallsForMDProp.clear();

  // now for allocations
  // UPDATE: now the metadata requests are on demand (because initializing temporal safety metadata is not free)
  for (llvm::CallBase* call : allocatorCallsForMDProp) {
    // if this is a realloc(), we instrument mdrealloc() for oob metadata scheme
    if (mdscheme) {
      if (llvm::Function* callee = call->getCalledFunction()) {
        llvm::Attribute attr = callee->getFnAttribute(llvm::Attribute::AttrKind::AllocKind);
        if (attr.getAllocKind() == llvm::AllocFnKind::Realloc) {
          mdscheme->mdrealloc(call);
        }
      }
    }
    if (isCollectRuntimeStats()) {
      if (isInstrAnnotatedWith(call, psan_eptg_alloc_md)) {
        incrementRuntimeStat(RTStatKind::Alloc_InEPTG_Dynamic, call);
      } else {
        incrementRuntimeStat(RTStatKind::Alloc_OOB_Dynamic, call);
      }
    }
  }
  allocatorCallsForMDProp.clear();

  if (isCollectRuntimeStats()) {
    for (auto& p : allocasForStatsCollection) {
      llvm::AllocaInst* alloca = p.first;
      bool isInEPTG = p.second;
      llvm::Instruction* insertBefore = alloca->getParent()->getTerminator();
      if (isInEPTG) {
        incrementRuntimeStat(RTStatKind::Alloc_InEPTG_Local, insertBefore);
      } else {
        incrementRuntimeStat(RTStatKind::Alloc_OOB_Local, insertBefore);
      }
    }
    allocasForStatsCollection.clear();
  }

  // finally, handle intrinsic calls
  for (auto& p : intrinsicCallsForMDProp) {
    llvm::CallBase* call = p.first;
    bool isInvolveNonEPTG = p.second;
    if (isCollectRuntimeStats()) {
      if (isInvolveNonEPTG) {
        incrementRuntimeStat(RTStatKind::MemFunc_OOB, call);
      } else {
        incrementRuntimeStat(RTStatKind::MemFunc_InEPTG, call);
      }
    }
    // for now, if the operand pointer(s) does not include pointers outside EPTG, we don't need special handling for them
    if (!isInvolveNonEPTG) {
      continue;
    }
    switch(call->getIntrinsicID()) {
    default: psan_unreachable("Unexpected intrinsic call");
    case llvm::Intrinsic::memset:
    case llvm::Intrinsic::memset_element_unordered_atomic:
    case llvm::Intrinsic::memset_inline: {
      if (mdscheme) {
        mdscheme->mdmemset(call->getArgOperand(0), call->getArgOperand(2), call);
      }
    } break;
    case llvm::Intrinsic::memcpy:
    case llvm::Intrinsic::memcpy_element_unordered_atomic:
    case llvm::Intrinsic::memcpy_inline: {
      if (mdscheme) {
        mdscheme->mdmemcpy(call->getArgOperand(0), call->getArgOperand(1), call->getArgOperand(2), call);
      }
    } break;
    case llvm::Intrinsic::memmove:
    case llvm::Intrinsic::memmove_element_unordered_atomic: {
      if (mdscheme) {
        mdscheme->mdmemmove(call->getArgOperand(0), call->getArgOperand(1), call->getArgOperand(2), call);
      }
    } break;
    }
  }
  intrinsicCallsForMDProp.clear();

  // done
}

void PSanInstrumentationManager::replaceValueForMD(llvm::Value* oldValue, llvm::Value* newValue)
{
  PSAN_DEBUG(PSan::outs() << "replaceValueForMD(): " << oldValue << " -> " << newValue << "\n");
  bool isMetadataRequested = false;
  if (llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(oldValue)) {
    if (ptrMetadataRequestWorklist.find(instr) != ptrMetadataRequestWorklist.end()) {
      ptrMetadataRequestWorklist.erase(instr);
      isMetadataRequested = true;
    }
  }
  if (llvm::isa<llvm::Constant>(oldValue)) {
    // we should not replace a constant value
    psan_unreachable("Unexpected replacement of a constant value");
  }
  auto mergeMetadataMap = [this](MetadataMapTy& fromMD, MetadataMapTy& toMD) -> void {
    // at the end of this function, there should be no user of the fold metadata map (fromMD)
    // for every scheme, we merge the metadata vectors
    for (auto& p : fromMD) {
      auto iter = toMD.find(p.first);
      if (iter == toMD.end() || iter->second.empty()) {
        // just move them over
        toMD[p.first] = std::move(p.second);
      } else {
        // try to do the merge
        bool isDestPlaceholder = false;
        if (llvm::Instruction* firstInstr = llvm::dyn_cast<llvm::Instruction>(iter->second[0])) {
          if (isPlaceholderMetadata(firstInstr)) {
            isDestPlaceholder = true;
          }
        }
        auto& fromVec = p.second;
        auto& toVec = iter->second;
        if (toVec.size() != fromVec.size()) {
          psan_unreachable("Unexpected metadata vector size mismatch");
        }
        if (!isDestPlaceholder) {
          // the destination is not placeholder; we keep them as is
          // check if the source is placeholder; if not, we have an error
          bool isSrcPlaceholder = false;
          if (llvm::Instruction* firstInstr = llvm::dyn_cast<llvm::Instruction>(fromVec[0])) {
            if (isPlaceholderMetadata(firstInstr)) {
              isSrcPlaceholder = true;
            }
          }
          if (!isSrcPlaceholder) {
            psan_unreachable("replaceValueForMD(): both value have non-placeholder metadata?");
          }
          // redirect the use of source metadata to the destination metadata
          for (unsigned i = 0, n = fromVec.size(); i < n; ++i) {
            llvm::Instruction* fromInstr = llvm::cast<llvm::Instruction>(fromVec[i]);
            llvm::Value* toValue = toVec[i];
            if (!isPlaceholderMetadata(fromInstr)) {
              psan_unreachable("Unexpected non-placeholder metadata");
            }
            fromInstr->replaceAllUsesWith(toValue);
            fromInstr->eraseFromParent();
          }
        } else {
          // we would overwrite the placeholder with the source metadata, no matter whether the source is placeholder or not
          for (unsigned i = 0, n = fromVec.size(); i < n; ++i) {
            llvm::Value* fromValue = fromVec[i];
            llvm::Instruction* toInstr = llvm::cast<llvm::Instruction>(toVec[i]);
            if (!isPlaceholderMetadata(toInstr)) {
              psan_unreachable("Unexpected non-placeholder metadata");
            }
            toInstr->replaceAllUsesWith(fromValue);
            toInstr->eraseFromParent();
            toVec[i] = fromValue;
          }
        }
      }
    }
  };
  // before we start merging metadata, if all of the conditions hold:
  // (1) the new value does not have metadata yet
  // (2) the old one has placeholder
  // (3) we can directly populate metadata for the new value
  // then we directly populate the metadata for the new value so that we don't bother requesting its metadata later on
  // TODO
  bool isHaveMetadata = false;
  bool canPopulateNewValueMetadata = false;
  if (llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(newValue)) {
    if (llvm::isa<llvm::AllocaInst>(instr)) {
      canPopulateNewValueMetadata = true;
    }
  } else {
    canPopulateNewValueMetadata = true;
  }
  auto iter = metadataMap.find(oldValue);
  if (iter != metadataMap.end()) {
    decltype(iter->second) fromMD;
    fromMD.swap(iter->second);
    metadataMap.erase(iter);
    isHaveMetadata = true;
    auto iterNew = metadataMap.find(newValue);
    if (iterNew != metadataMap.end()) {
      mergeMetadataMap(fromMD, iterNew->second);
    } else {
      if (canPopulateNewValueMetadata) {
        auto r = metadataMap.insert(std::make_pair(newValue, decltype(fromMD)()));
        if (!r.second) {
          psan_unreachable("Unexpected failure to insert metadata for new value");
        }
        iterNew = r.first;
        // try to find an insertion point
        llvm::Instruction* insertBefore = nullptr;
        if (llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(newValue)) {
          insertBefore = instr;
        } else if (llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(oldValue)) {
          insertBefore = instr;
        }
        if (insertBefore) {
          while (llvm::isa<llvm::PHINode>(insertBefore) || llvm::isa<llvm::AllocaInst>(insertBefore)) {
            insertBefore = insertBefore->getNextNode();
          }
        }
        for (auto& p : fromMD) {
          unsigned scheme = p.first;
          auto& mdvec = iterNew->second[scheme];
          populateStubMetadataVector(mdvec, newValue, scheme, insertBefore, "stubreplace");
          for (llvm::Value* md : mdvec) {
            if (llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(md)) {
              if (isPlaceholderMetadata(instr)) {
                psan_unreachable("Failed to populate metadata for new value");
              }
            }
          }
        }
        mergeMetadataMap(fromMD, iterNew->second);
      } else {
        metadataMap[newValue] = std::move(fromMD);
      }
    }
  }
  auto iterVec = vectorMetadataMap.find(oldValue);
  if (iterVec != vectorMetadataMap.end()) {
    // actually for now we would never replace a vector value, so we should not reach here
    // but we keep the code here for future use
    decltype(iterVec->second) fromMD;
    fromMD.swap(iterVec->second);
    vectorMetadataMap.erase(iterVec);
    isHaveMetadata = true;
    auto iterNew = vectorMetadataMap.find(newValue);
    if (iterNew != vectorMetadataMap.end()) {
      auto& fromVec = fromMD;
      auto& toVec = iterNew->second;
      if (fromVec.size() != toVec.size()) {
        psan_unreachable("Unexpected vector metadata size mismatch");
      }
      for (unsigned i = 0, n = fromVec.size(); i < n; ++i) {
        mergeMetadataMap(fromVec[i], toVec[i]);
      }
    } else {
      if (canPopulateNewValueMetadata) {
        psan_unreachable("TODO support vector metadata population for new value");
      }
      vectorMetadataMap[newValue] = std::move(fromMD);
    }
  }
  if (isMetadataRequested && isHaveMetadata && !canPopulateNewValueMetadata) {
    llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(newValue);
    if (!instr) {
      psan_unreachable("non-instruction value should have metadata directly populated");
    }
    ptrMetadataRequestWorklist.insert(instr);
  }
}

void PSanInstrumentationManager::handleEPTGTypeTransform()
{
  // in this function we handle the type transformation for pointer EPTG expression nodes
  // basically we just follow the dataflow to replace the points-to type of the pointer users
  // note that if the pointer is used in dead code, the EPTG may not contain the nodes for values in there
  // so we may not be able to handle all cases

  // we use this style of loop to allow modification to the queue (removing entries) during the iteration
  while (!queuedEPTGPointerChanges.empty()) {
    auto iterCurrent = queuedEPTGPointerChanges.begin();
    llvm::Instruction* backwardConverter = *iterCurrent;
    queuedEPTGPointerChanges.erase(iterCurrent);

    llvm::BitCastInst* bc = llvm::cast<llvm::BitCastInst>(backwardConverter);
    llvm::Value* newPtr = bc->getOperand(0);
    std::deque<std::pair<llvm::Instruction*, llvm::Value*>> worklist;
    worklist.push_back(std::make_pair(bc, newPtr));
    while (!worklist.empty()) {
      auto p = worklist.front();
      llvm::Instruction* oldInstrToDelete = p.first;
      llvm::Value* newPtr = p.second;
      worklist.pop_front();
      llvm::BasicBlock* parentBB = oldInstrToDelete->getParent();
      assert (parentBB != nullptr);
      if (newPtr == oldInstrToDelete) {
        // we should not have a self-replacement
        psan_unreachable("Unexpected self-replacement");
      }
      if (isDataPointerTy(newPtr)) {
        replaceValueForMD(oldInstrToDelete, newPtr);
      }
      bool isTypeMatch = (oldInstrToDelete->getType() == newPtr->getType());

      while (!oldInstrToDelete->use_empty()) {
        llvm::Use* curUse = &(*oldInstrToDelete->use_begin());
        llvm::Instruction* user = llvm::cast<llvm::Instruction>(curUse->getUser());
        unsigned argno = curUse->getOperandNo();
        // if the user is a backward converter, it may already been in queuedEPTGPointerChanges
        // we need to remove them from queuedEPTGPointerChanges in case it is erased here
        // ... actually it is not known whether we would have a backward converter in the pending uses
        llvm::Instruction* userBackwardConverter = nullptr;
        if (llvm::BitCastInst* userBC = llvm::dyn_cast<llvm::BitCastInst>(user)) {
          auto iter = queuedEPTGPointerChanges.find(userBC);
          if (iter != queuedEPTGPointerChanges.end()) {
            userBackwardConverter = userBC;
            queuedEPTGPointerChanges.erase(iter);
            // fault here if this indeed happens, and we will update the comment above
            psan_unreachable("Unexpected backward converter in pending uses");
          }
        }
        (void) userBackwardConverter;

        if (isForwardConverter(user)) {
          llvm::BitCastInst* bc = llvm::cast<llvm::BitCastInst>(user);
          if (bc->getType() != newPtr->getType()) {
            // this can happen when the forward converter is in dead code
            // psan_unreachable("Unexpected forward converter type mismatch");
            callDeadCodeUnreachable(bc);
            llvm::BitCastInst* newBC = new llvm::BitCastInst(newPtr, bc->getType(), "", bc);
            transferValueName(newBC, bc);
            // we don't copy metadata over (otherwise this newBC would be treated as another converter)
            bc->replaceAllUsesWith(newBC);
            replaceValueForMD(bc, newBC);
            eraseInstrFromParent(bc);
            continue;
          }
          // proceed with the normal case (type matches)
          bc->replaceAllUsesWith(newPtr);
          replaceValueForMD(bc, newPtr);
          eraseInstrFromParent(bc);
          continue;
        } else if (isCheckRequest(user)) {
          llvm::BitCastInst* bc = llvm::cast<llvm::BitCastInst>(user);
          if (!bc->use_empty() || bc->getType() != i8PtrTy) {
            psan_unreachable("malformed check request bitcast");
          }
          curUse->set(newPtr);
          continue;
        }

        if (isTypeMatch) {
          curUse->set(newPtr);
          continue;
        }

        llvm::Value* outputNewValue = nullptr;
        bool isDeleted = false;
        std::tie(outputNewValue, isDeleted) = handleEPTGPointerUser(user, argno, oldInstrToDelete, newPtr);

        // sanity check: the user must have dropped the current use to the old instruction
        if (!isDeleted) {
          if (user->getNumOperands() > argno && user->getOperand(argno) == oldInstrToDelete) {
            psan_unreachable("Unexpected user not dropping the old instruction");
          }
        }

        if (!isDeleted && outputNewValue) {
          // there must be some pending uses of the value and we need to keep propagating
          // the instruction creates a new pointer
          // we need to create a worklist entry for it
          if (user == outputNewValue) {
            psan_unreachable("Unexpected self-replacement");
          }
          worklist.push_back(std::make_pair(user, outputNewValue));
        }
      }

      // now all uses are handled
      if (!oldInstrToDelete->use_empty()) {
        psan_unreachable("Unexpected non-empty use list after replacing all uses with undef");
      }
      eraseInstrFromParent(oldInstrToDelete);
    }
  }
}

std::pair<llvm::Value*, bool> PSanInstrumentationManager::handleEPTGPointerUser(llvm::Instruction* user, unsigned argno, llvm::Instruction* oldValue, llvm::Value* newValue)
{
  constexpr bool PRESERVED = false;
  constexpr bool REMOVED = true;

  llvm::Value* outputNewValue = nullptr;

  auto tryCleanup = [&](llvm::Instruction* inst) -> std::pair<llvm::Value*, bool> {
    bool isDeleted = PRESERVED;
    if (inst->use_empty()) {
      eraseInstrFromParent(inst);
      isDeleted = REMOVED;
    }
    return std::make_pair(outputNewValue, isDeleted);
  };
  auto unsetUse = [&](llvm::Instruction* inst, unsigned argno) -> void {
    inst->setOperand(argno, llvm::UndefValue::get(inst->getOperand(argno)->getType()));
  };
  bool isInDeadCode = isFunctionDead(user->getFunction());
  PSAN_DEBUG(PSan::outs() << "handleEPTGPointerUser(): Op#" << argno << ": " << getValueStrWithParent(user) << ": " << getValueStrWithParent(oldValue) << " -> " << newValue << (isInDeadCode?" [DeadCode]" : "") << "\n");

  auto cannotHandle = [&]() -> std::pair<llvm::Value*, bool> {
    if (isInDeadCode) {
      unsetUse(user, argno);
      callDeadCodeUnreachable(user);
      return std::make_pair(nullptr, PRESERVED);
    }
    psan_unreachable("Unexpected user of pointer value");
  };

  switch (user->getOpcode())
  {
  default: return cannotHandle();
  case llvm::Instruction::GetElementPtr: {
    // for gep, we simply create a new gep with the same set of indices and done
    // all other metadata are assumed to be identical
    llvm::GetElementPtrInst* oldGEP = llvm::cast<llvm::GetElementPtrInst>(user);
    llvm::Value* newSrcPointer = newValue;
    llvm::SmallVector<llvm::Value*> indices;
    for (const auto& idxUse : oldGEP->indices()) {
      indices.push_back(idxUse.get());
    }
    llvm::PointerType* srcPtrType = llvm::cast<llvm::PointerType>(newSrcPointer->getType());
    llvm::GetElementPtrInst* newGEP = llvm::GetElementPtrInst::Create(getPointerElementType(srcPtrType), newSrcPointer, indices, oldGEP->getName());
    newGEP->setIsInBounds(oldGEP->isInBounds());
    newGEP->insertBefore(oldGEP);
    transferValueName(newGEP, oldGEP);
    newGEP->copyMetadata(*oldGEP);
    // we cannot replace all uses of oldGEP to newGEP because they probably have different types

    // produce new outputs
    outputNewValue = newGEP;
    replaceValueForMD(oldGEP, newGEP);
    unsetUse(oldGEP, argno);
    return tryCleanup(oldGEP);
  } break; // case llvm::Instruction::GetElementPtr
  case llvm::Instruction::BitCast: {
    llvm::BitCastInst* bc = llvm::cast<llvm::BitCastInst>(user);
    // should not be backward converters
    if (isBackwardConverter(user)) {
      psan_unreachable("Unexpected forward/backward converter");
    } else if (isForwardConverter(user)) {
      psan_unreachable("Unexpected forward converter");
      // we may have forward converters for users that are not in the EPTG (e.g., icmp in tainted code)
      // just create cast and replace the use
      /*
      llvm::BitCastInst* newBC = new llvm::BitCastInst(newValue, bc->getDestTy(), bc->getName());
      newBC->insertBefore(bc);
      transferValueName(newBC, bc);
      // we do not copy the metadata, which may make this another forward converter
      // produce new outputs
      outputNewValue = newBC;
      replaceValueForMD(bc, newBC);
      unsetUse(bc, argno);
      return tryCleanup(bc);
      */
    }
    // for bitcast, if it is casting to T* where T does not involve pointers
    // for other types that the pointee type may change, we do not handle it for now
    // (in the ideal case, the pointer type is "locked" after it is created / loaded from memory / passed as argument..)
    // also, these pointers should be tainted and we should not have them in the EPTG

    llvm::PointerType* oldPtrTy = llvm::cast<llvm::PointerType>(bc->getDestTy());
    llvm::Type* newPointToTy = getPointerElementType(oldPtrTy);
    if (isTypeContainPointer(newPointToTy)) {
      psan_unreachable("Unhandled pointer cast dest type");
    }
    llvm::BitCastInst* newBC = new llvm::BitCastInst(newValue, oldPtrTy, bc->getName());
    newBC->insertBefore(bc);
    transferValueName(newBC, bc);
    newBC->copyMetadata(*bc);

    // produce new outputs
    outputNewValue = newBC;
    replaceValueForMD(bc, newBC);
    unsetUse(bc, argno);
    return tryCleanup(bc);
  } break; // case llvm::Instruction::BitCast
  case llvm::Instruction::PHI: {
    // we always try to replace the entire phi at the first time we meet them
    // for every other incoming edge, we create converter functions to isolate the dataflow
    // therefore when traversing from their upstreams to this PHI edge, the code should see a converter call first and is handled outside this function
    llvm::PHINode* oldPHI = llvm::cast<llvm::PHINode>(user);
    llvm::PHINode* newPHI = llvm::PHINode::Create(newValue->getType(), oldPHI->getNumIncomingValues(), oldPHI->getName());
    newPHI->insertBefore(oldPHI);
    transferValueName(newPHI, oldPHI);
    newPHI->copyMetadata(*oldPHI);

    // it is possible that a phi node has multiple input edges using the same value
    // it is even possible that we have multiple edge from the same source basic block to the same phi
    // no matter what, we don't want to create redundant converters
    llvm::DenseMap<llvm::BasicBlock*, unsigned> visitedBasicBlocks; // [source BB] -> edge index
    for (unsigned edgeIndex = 0, edgeCount = oldPHI->getNumIncomingValues(); edgeIndex < edgeCount; ++edgeIndex) {
      llvm::Value* inValue = oldPHI->getIncomingValue(edgeIndex);
      llvm::BasicBlock* inBlock = oldPHI->getIncomingBlock(edgeIndex);

      // since we may have duplicated edges, we check the following invariants
      unsigned existingInEdgeIndex = 0;
      bool isExistingEdge = false;
      {
        auto iterVisitedRecord = visitedBasicBlocks.find(inBlock);
        if (iterVisitedRecord != visitedBasicBlocks.end()) {
          existingInEdgeIndex = iterVisitedRecord->second;
          isExistingEdge = true;
          assert (oldPHI->getIncomingValue(existingInEdgeIndex) == inValue);
        } else {
          // this is a brand-new edge
          visitedBasicBlocks.insert(std::make_pair(inBlock, edgeIndex));
        }
      }

      // if the value is what we currently have, we just replace the use
      // otherwise, we create a converter call to wrap them
      // (note that we may have multiple edges using the same value, but this is perfectly fine)
      if (inValue == oldValue) {
        // this is the edge we come in
        newPHI->addIncoming(newValue, inBlock);
      } else if (inValue == oldPHI) {
        // there is a loop in the phi's dataflow
        newPHI->addIncoming(newPHI, inBlock);
      } else if (isExistingEdge) {
        // we have redundant edge but this is not like any prior special case
        // we just borrow whatever we had earlier
        newPHI->addIncoming(newPHI->getIncomingValue(existingInEdgeIndex), inBlock);
      } else {
        // this is not a special case and we have not visited this edge before
        // create the converter and do the usual work
        llvm::Value* converter = createForwardConverter(inValue, newValue->getType(), inBlock->getTerminator(), "psan_phi_convert");
        newPHI->addIncoming(converter, inBlock);
      }
    }
    outputNewValue = newPHI;
    replaceValueForMD(oldPHI, newPHI);
    // we need to drop the edges manually
    for (unsigned i = oldPHI->getNumIncomingValues(); i > 0; --i) {
      oldPHI->removeIncomingValue(i-1, /* DeletePHIIfEmpty */false);
    }
    return tryCleanup(oldPHI);
  } break; // case llvm::Instruction::PHI
  case llvm::Instruction::Select: {
    llvm::SelectInst* select = llvm::cast<llvm::SelectInst>(user);
    assert (select->getTrueValue() != select->getFalseValue());

    llvm::Value* trueBranchValue = nullptr;
    llvm::Value* falseBranchValue = nullptr;
    llvm::Value* otherBranchValue = nullptr;
    llvm::Value** otherBranchValuePtr = nullptr;
    if (argno == 1) {
      assert (select->getTrueValue() == oldValue);
      trueBranchValue = newValue;
      otherBranchValue = select->getFalseValue();
      otherBranchValuePtr = &falseBranchValue;
    } else if (argno == 2) {
      assert (select->getFalseValue() == oldValue);
      falseBranchValue = newValue;
      otherBranchValue = select->getTrueValue();
      otherBranchValuePtr = &trueBranchValue;
    } else {
      psan_unreachable("Unexpected argno for SelectInst user");
    }
    // populate through otherBranchValuePtr using the otherBranchValue
    // create a forward converter
    llvm::Value* converter = createForwardConverter(otherBranchValue, newValue->getType(), select, "psan_select_convert");
    *otherBranchValuePtr = converter;
    llvm::SelectInst* newSelect = llvm::SelectInst::Create(select->getCondition(), trueBranchValue, falseBranchValue);
    newSelect->insertBefore(select);
    transferValueName(newSelect, select);
    newSelect->copyMetadata(*select);
    outputNewValue = newSelect;
    replaceValueForMD(select, newSelect);

    // drop the value edges manually
    unsetUse(select, 1);
    unsetUse(select, 2);
    return tryCleanup(select);
  } break;
  case llvm::Instruction::Call: {
    // llvm::StoreInst* store = llvm::cast<llvm::StoreInst>(user);
    llvm::CallInst* call = llvm::cast<llvm::CallInst>(user);
    llvm::FunctionType* funcType = call->getFunctionType();
    llvm::Type* targetParamType = funcType->getParamType(argno);
    llvm::Value* leadPtr = newValue;
    if (!targetParamType && funcType->isVarArg()) {
      // we are replacing the type of a vararg operand
      // (e.g., replacing a pointer operand to printf())
      // just replace and done
      call->setArgOperand(argno, leadPtr);
      return std::make_pair(nullptr, PRESERVED);
    }
    assert (targetParamType == oldValue->getType());
    if (targetParamType == leadPtr->getType()) {
      call->setArgOperand(argno, leadPtr);
      return std::make_pair(nullptr, PRESERVED);
    }
    // ok, there is a type change
    // we may have callees removed during pruning that does not do anything to the pointer argument
    if (call->getIntrinsicID() == llvm::Intrinsic::not_intrinsic) {
      // double check if the callee is an internally defined function that doesn't use the pointer argument in any way (except metadata ops)
      bool isChecked = false;
      if (llvm::Function* callee = call->getCalledFunction()) {
        if (!callee->getBasicBlockList().empty()) {
          llvm::SmallVector<llvm::Value*> worklist;
          llvm::Argument* arg = callee->getArg(argno);
          worklist.push_back(arg);
          while (!worklist.empty()) {
            llvm::Value* value = worklist.back();
            worklist.pop_back();
            for (llvm::Use& use : value->uses()) {
              llvm::Instruction* user = llvm::cast<llvm::Instruction>(use.getUser());
              if (user->getOpcode() == llvm::Instruction::Call) {
                llvm::CallInst* call = llvm::cast<llvm::CallInst>(user);
                if (call->isDebugOrPseudoInst()) {
                  continue;
                }
              } else if (user->getOpcode() == llvm::Instruction::BitCast) {
                worklist.push_back(user);
                continue;
              }
              psan_unreachable("EPTG type transform for call arguments passed to functions with non-trivial use of pointer value");
            }
          }
          isChecked = true;
        }
      }
      if (!isChecked) {
        psan_unreachable("EPTG type transform for call arguments passed to unexpected functions");
      }
      // if we reach here, we are sure that the callee does not use the pointer argument in any way
      // set it to undef and done
      call->setArgOperand(argno, llvm::UndefValue::get(targetParamType));
      return std::make_pair(nullptr, PRESERVED);
    }
    // we currently only support memcpy/memset/memmove here
    // for these intrinsics involving more than one pointer, if we change the argument type, we only change the type of current argument
    switch(call->getIntrinsicID()) {
    default: psan_unreachable("Unhandled call target in pointer use handling");
    case llvm::Intrinsic::memcpy:
    case llvm::Intrinsic::memcpy_element_unordered_atomic:
    case llvm::Intrinsic::memmove:
    case llvm::Intrinsic::memmove_element_unordered_atomic: {
      // the first three arguments (dest, src, len) use templated type
      llvm::SmallVector<llvm::Type*> templateParamTypes;
      templateParamTypes.push_back(funcType->getParamType(0));
      templateParamTypes.push_back(funcType->getParamType(1));
      templateParamTypes.push_back(funcType->getParamType(2));
      assert (argno == 0 || argno == 1);
      templateParamTypes[argno] = leadPtr->getType();

      llvm::SmallVector<llvm::Value*> operandList(call->arg_begin(), call->arg_end());
      operandList[argno] = leadPtr;

      llvm::Function* newCallee = llvm::Intrinsic::getDeclaration(clonedModule, call->getIntrinsicID(), templateParamTypes);
      llvm::CallInst* newCall = llvm::CallInst::Create(newCallee->getFunctionType(), newCallee, operandList, "", call);
      newCall->copyMetadata(*call);
      transferValueName(newCall, call);
      call->replaceAllUsesWith(newCall);
      eraseInstrFromParent(call);
      return std::make_pair(nullptr, REMOVED);
    } break;
    case llvm::Intrinsic::memset:
    case llvm::Intrinsic::memset_element_unordered_atomic: {
      // the first and third argument (dest, len) use templated type
      assert (argno == 0);
      llvm::SmallVector<llvm::Type*> templateParamTypes;
      templateParamTypes.push_back(leadPtr->getType());
      templateParamTypes.push_back(funcType->getParamType(2));

      llvm::SmallVector<llvm::Value*> operandList(call->arg_begin(), call->arg_end());
      operandList[argno] = leadPtr;

      llvm::Function* newCallee = llvm::Intrinsic::getDeclaration(clonedModule, call->getIntrinsicID(), templateParamTypes);
      llvm::CallInst* newCall = llvm::CallInst::Create(newCallee->getFunctionType(), newCallee, operandList, "", call);
      newCall->copyMetadata(*call);
      transferValueName(newCall, call);
      call->replaceAllUsesWith(newCall);
      call->eraseFromParent();
      return std::make_pair(nullptr, REMOVED);
    } break;
    }
  } break; // case llvm::Instruction::Call
  case llvm::Instruction::ICmp: {
    // we just create a new icmp with the new type
    // if the other operand is null, we create a new null with the correct type
    // otherwise we create a forward converter
    llvm::PointerType* targetType = llvm::cast<llvm::PointerType>(newValue->getType());
    llvm::ICmpInst* icmp = llvm::cast<llvm::ICmpInst>(user);
    assert (icmp->getNumOperands() == 2);
    assert (argno < 2);
    unsigned otherOperandNo = 1 - argno;
    llvm::Value* castedOtherOperand = nullptr;
    llvm::Value* rawOtherOperand = icmp->getOperand(otherOperandNo);
    if (rawOtherOperand->getType() == targetType) {
      // should not be possible...
      castedOtherOperand = rawOtherOperand;
    } else {
      if (llvm::ConstantPointerNull* cnull = llvm::dyn_cast<llvm::ConstantPointerNull>(rawOtherOperand)) {
        (void) cnull;
        castedOtherOperand = llvm::ConstantPointerNull::get(targetType);
      } else {
        // create a forward converter
        llvm::Value* converter = createForwardConverter(rawOtherOperand, targetType, icmp, "psan_icmp_cast");
        castedOtherOperand = converter;
      }
    }
    assert (castedOtherOperand->getType() == targetType);
    llvm::Value* lhsValue = newValue;
    llvm::Value* rhsValue = castedOtherOperand;
    if (argno != 0) {
      llvm::Value* tmp = rhsValue;
      rhsValue = lhsValue;
      lhsValue = tmp;
    }
    llvm::ICmpInst* newICMP = new llvm::ICmpInst(icmp->getPredicate(), lhsValue, rhsValue);
    newICMP->insertBefore(icmp);
    transferValueName(newICMP, icmp);
    newICMP->copyMetadata(*icmp);
    icmp->replaceAllUsesWith(newICMP);
    icmp->eraseFromParent();
    return std::make_pair(nullptr, REMOVED);
  } break; // case llvm::Instruction::ICmp
  case llvm::Instruction::PtrToInt: {
    // just create a new ptrtoint with the updated source type
    llvm::PtrToIntInst* pti = llvm::cast<llvm::PtrToIntInst>(user);
    llvm::PtrToIntInst* newPTI = new llvm::PtrToIntInst(newValue, pti->getType());
    newPTI->insertBefore(pti);
    transferValueName(newPTI, pti);
    newPTI->copyMetadata(*pti);
    pti->replaceAllUsesWith(newPTI);
    pti->eraseFromParent();
    return std::make_pair(nullptr, REMOVED);
  } break; // case llvm::Instruction::PtrToInt
  }
  psan_unreachable("Not returning before end of switch");
}

void PSanInstrumentationManager::populateStubMetadataVector(llvm::SmallVectorImpl<llvm::Value*>& mdVec, llvm::Value* ptrvalue, unsigned scheme, llvm::Instruction* insertBefore, const char* src)
{
  // ptrvalue can be null if we are dealing with non-const vector elements
  auto* instrumentation = instrumentations[scheme];
  const auto& mdTy = instrumentation->getPointerMetadataTypesInRegisters();
  if (mdTy.empty()) {
    // we do not have metadata for this scheme
    return;
  }
  if (mdVec.size() == mdTy.size()) {
    // we already have the metadata
    // sanity check: if the metadata is placeholder, it should be within the same function as the insert point
    llvm::Function* parentFunc = insertBefore->getFunction();
    for (llvm::Value* md : mdVec) {
      if (llvm::Instruction* mdInst = llvm::dyn_cast<llvm::Instruction>(md)) {
        if (isPlaceholderMetadata(mdInst) && mdInst->getFunction() != parentFunc) {
          psan_unreachable("Placeholder not in the target function");
        }
      }
    }
    return;
  } else {
    if (!mdVec.empty()) {
      psan_unreachable("Unexpected metadata vector size mismatch");
    }
  }
  if (llvm::Constant* cptr = llvm::dyn_cast_or_null<llvm::Constant>(ptrvalue)) {
    // check if this is a special constant that we can handle without creating placeholders
    if (llvm::ConstantPointerNull* cnull = llvm::dyn_cast<llvm::ConstantPointerNull>(cptr)) {
      (void) cnull;
      mdVec = instrumentation->getNullPointerMetadata();
      return;
    }
    if (llvm::UndefValue* cundef = llvm::dyn_cast<llvm::UndefValue>(cptr)) {
      // treat it as a null pointer
      (void) cundef;
      mdVec = instrumentation->getNullPointerMetadata();
      return;
    }
    if (llvm::GlobalVariable* gv = llvm::dyn_cast<llvm::GlobalVariable>(cptr)) {
      instrumentation->instrumentMetadataInit(gv, insertBefore, mdVec);
      return;
    }
    if (llvm::ConstantExpr* gvconstexpr = llvm::dyn_cast<llvm::ConstantExpr>(cptr)) {
      instrumentation->instrumentMetadataInit(gvconstexpr, insertBefore, mdVec);
      return;
    }
    if (getPointerElementType(cptr->getType())->isFunctionTy()) {
      mdVec = instrumentation->getUnanalyzablePointerMetadata();
      return;
    }
    psan_unreachable("Unhandled constant ptrvalue in populateStubMetadataVector()");
  }
  if (llvm::AllocaInst* alloca = llvm::dyn_cast_or_null<llvm::AllocaInst>(ptrvalue)) {
    instrumentation->instrumentMetadataInit(alloca, mdVec);
    return;
  }
  if (llvm::IntToPtrInst* inttoptr = llvm::dyn_cast_or_null<llvm::IntToPtrInst>(ptrvalue)) {
    (void) inttoptr;
    mdVec = instrumentation->getUnanalyzablePointerMetadata();
    return;
  }
  if (llvm::ExtractValueInst* extract = llvm::dyn_cast_or_null<llvm::ExtractValueInst>(ptrvalue)) {
    // we are not able to properly handle it for now; just treat it as unanalyzable
    (void) extract;
    mdVec = instrumentation->getUnanalyzablePointerMetadata();
    return;
  }
  // we may need insertion point below
  // we cannot insert the placeholder directly before the insert point, because it may be a PHI
  // just choose the safest place, the entry block
  llvm::Instruction* insertPoint = getBlockInsertPoint(&insertBefore->getFunction()->getEntryBlock());

  // check if this is an argument for some function that we do not change interface (e.g., main)
  // or it is a byval/sret argument
  if (llvm::Argument* arg = llvm::dyn_cast_or_null<llvm::Argument>(ptrvalue)) {
    if (llvm::Type* byvalType = isArgumentByvalLike(arg)) {
      instrumentation->instrumentMetadataInit_ByValArgument(arg, byvalType, insertPoint, mdVec);
      return;
    }
    llvm::Function* parentFunc = arg->getParent();
    if (parentFunc->getName() == "main") {
      mdVec = instrumentation->getUnanalyzablePointerMetadata();
      return;
    }
    if (isFunctionDead(parentFunc) || getPointerElementType(arg->getType())->isFunctionTy()) {
      mdVec = instrumentation->getUnanalyzablePointerMetadata();
      return;
    }
    psan_unreachable("Unhandled argument ptrvalue in populateStubMetadataVector()");
  }

  // check if this is an allocator call
  // we can handle it directly
  if (llvm::CallBase* call = llvm::dyn_cast_or_null<llvm::CallBase>(ptrvalue)) {
    if (llvm::Function* callee = call->getCalledFunction()) {
      if (isAllocatorCallee(callee) && !isDeallocationCallee(callee)) {
        instrumentation->instrumentMetadataInit(call, mdVec);
        return;
      }
    }
  }

  // if we reach here, this should be an instruction
  // enqueue it for metadata requesting
  // if the ptrvalue is null, we are probably handling a vector element; the caller should enqueue the vector itself
  if (ptrvalue) {
    llvm::Instruction* ptrDef = llvm::cast<llvm::Instruction>(ptrvalue);
    ptrMetadataRequestWorklist.insert(ptrDef);
    PSAN_DEBUG(PSan::outs() << "MDVec request: " << getValueStrWithParent(ptrDef) << "\n");
  }

  if (mdVec.empty()) {
    // we need to create placeholders for the metadata
    mdVec.reserve(mdTy.size());
    for (llvm::Type* ty : mdTy) {
      llvm::Instruction* md = createPlaceholderMetadata(ty, insertPoint, llvm::Twine(llvm::StringRef("psan_md_"), src));
      mdVec.push_back(md);
      PSAN_DEBUG(PSan::outs() << "  Placeholder: " << md << "\n");
      if (md->getFunction() == nullptr || md->getFunction() != insertPoint->getFunction()) {
        psan_unreachable("placeholder metadata insertion failed");
      }
    }
  } else {
    if (mdVec.size() != mdTy.size()) {
      psan_unreachable("Unexpected metadata vector size mismatch");
    }
  }
}

template<typename InstrTy>
void PSanInstrumentationManager::replacePlaceholderMetadataMap(llvm::SmallDenseMap<unsigned, llvm::SmallVector<InstrTy*, ExpectMetadataVecSize>, MaxNumCheckingSchemes>& newValue, MetadataMapTy& dest) {
  for (auto& p : newValue) {
    unsigned schemeIndex = p.first;
    MetadataVecTy srcVec(p.second.begin(), p.second.end());
    assignMetadataVec(dest[schemeIndex], srcVec);
  }
}

PSanInstrumentationManager::MetadataMapTy& PSanInstrumentationManager::getMetadataMap(llvm::Value* value, MetadataMapTy& dummyValueMap)
{
  if (value->getType()->isVectorTy()) {
    psan_unreachable("Unexpected vector value in scalar pointer handling");
  }
  if (llvm::isa<llvm::Constant>(value)) {
    return dummyValueMap;
  }
  return metadataMap[value];
}
void PSanInstrumentationManager::clearDummyMap(MetadataMapTy& dummyValueMap)
{
  for (auto& p : dummyValueMap) {
    for (llvm::Value* val : p.second) {
      if (llvm::Instruction* inst = llvm::dyn_cast<llvm::Instruction>(val)) {
        if (isPlaceholderMetadata(inst)) {
          psan_unreachable("placeholder metadata created for constant?");
        }
      }
    }
  }
  dummyValueMap.clear();
}

void PSanInstrumentationManager::assignMetadataVec(llvm::SmallVectorImpl<llvm::Value*>& dest, const llvm::SmallVectorImpl<llvm::Value*>& src)
{
  if (dest.empty()) {
    dest = src;
    return;
  }
  if (dest.size() != src.size()) {
    psan_unreachable("Metadata vector size mismatch");
  }
  for (unsigned i = 0, n = dest.size(); i < n; ++i) {
    llvm::Value* oldVal = dest[i];
    llvm::Value* newVal = src[i];
    if (oldVal == newVal) {
      continue;
    }
    bool isPlaceholder = false;
    llvm::Instruction* oldInst = llvm::dyn_cast<llvm::Instruction>(oldVal);
    if (oldInst) {
      if (isPlaceholderMetadata(oldInst)) {
        isPlaceholder = true;
      }
    }
    if (!isPlaceholder) {
      psan_unreachable("Overriding non-placeholder metadata");
    }
    oldVal->replaceAllUsesWith(newVal);
    if (oldInst) {
      oldInst->eraseFromParent();
    }
    dest[i] = newVal;
  }
}

namespace {

// we attach following metadata for instructions involved in check requests

// added to the dummy bitcast identifying the check pointer and location
// data: <global ID, instrumentationIndex (scheme)>
const char PSAN_CHECK_REQUEST_MD[] = "psan.check_request";

// added to users of checked pointer (in case the instrumentation scheme needs additional info from user to set up checks)
// data: vector of <global ID, argno>
const char PSAN_CHECK_USE_MD[] = "psan.check_use";

} // end anonymous namespace

void PSanInstrumentationManager::convertCheckInfo()
{
  // in this function, we convert everything in plan.checkInfoVec as metadata and additional instructions
  // keeping all pointers up-to-date during transform is error-prone and this way is easier to implement
  // we always create an individual check request bitcast for each check
  // but we must coalesce user-side metadata, because one uses can be checked in different schemes and one instruction can use multiple pointers
  llvm::DenseMap<llvm::Instruction*, llvm::SmallVector<llvm::Metadata*>> userSideMetadataMap;
  std::size_t cumulativeCheckCount = 0;
  for (unsigned instrumentationID = 0; instrumentationID < plan.checkInfoVec.size(); ++instrumentationID) {
    auto& infoVec = plan.checkInfoVec[instrumentationID];
    for (PSan::InstrumentationPlan::CheckInfo& info : infoVec) {
      llvm::Instruction* insertBefore = getPostCloneValue<llvm::Instruction>(info.insertBefore);
      llvm::Value* ptr = getOrReconstructPostCloneValue(info.ptr);
      llvm::BitCastInst* checkRequest = new llvm::BitCastInst(ptr, i8PtrTy, "psan_check_request", insertBefore);
      llvm::ConstantAsMetadata* md_scheme = llvm::ConstantAsMetadata::get(llvm::ConstantInt::get(i32Ty, instrumentationID));
      llvm::ConstantAsMetadata* md_ID     = llvm::ConstantAsMetadata::get(llvm::ConstantInt::get(i32Ty, cumulativeCheckCount));
      llvm::ConstantAsMetadata* md_internalID = llvm::ConstantAsMetadata::get(llvm::ConstantInt::get(i32Ty, info.internalID));
      llvm::MDTuple* mddata = llvm::MDTuple::get(ctx, {md_ID, md_scheme, md_internalID});
      checkRequest->setMetadata(PSAN_CHECK_REQUEST_MD, mddata);
      ++cumulativeCheckCount;
      for (llvm::Use* use : info.uselist) {
        unsigned argno = use->getOperandNo();
        llvm::ConstantAsMetadata* md_argno = llvm::ConstantAsMetadata::get(llvm::ConstantInt::get(i32Ty, argno));
        llvm::MDTuple* mddata = llvm::MDTuple::get(ctx, {md_ID, md_argno});
        llvm::Instruction* preCloneUser = llvm::cast<llvm::Instruction>(use->getUser());
        llvm::Instruction* user = getPostCloneValue<llvm::Instruction>(preCloneUser);
        userSideMetadataMap[user].push_back(mddata);
      }
    }
  }
  for (auto& p : userSideMetadataMap) {
    llvm::Instruction* user = p.first;
    llvm::MDTuple* coalesced = llvm::MDTuple::get(ctx, p.second);
    user->setMetadata(PSAN_CHECK_USE_MD, coalesced);
  }
}

bool PSanInstrumentationManager::isCheckRequest(llvm::Instruction* inst)
{
  if (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(inst)) {
    return bc->hasMetadata(PSAN_CHECK_REQUEST_MD);
  }
  return false;
}

void PSanInstrumentationManager::handleMetadataPropagation()
{
  // in this function we handle the metadata propagation for all pointer values
  // we do the metadata propagation in an on-demand fashion:
  // before this function starts: all pointers requiring metadata should have placeholder metadata and is enqueued in queuedPointerMetadataPlaceholderRefs
  // this includes all pointer stores and argument passing / return value passing
  // in this function, we:
  // 1. we go through all instructions requiring checks and add placeholder metadata (if needed) for pointer operands, and add the checks
  // 2. we solve all pending metadata requests by a backward analysis, keep computing the real metadata from use to def
  //    until we got existing metadata or some special cases we can handle directly (e.g., null)
  // most of the metadata is in the metadataMap, but we also have vectorMetadataMap for special cases

  // for use with getMetadataMap() and clearDummyMap()
  MetadataMapTy dummyValueMap;

  {
    llvm::DenseMap<unsigned, llvm::BitCastInst*> checkRequestMap;
    llvm::DenseMap<unsigned, llvm::SmallVector<llvm::Use*>> useListMap;
    for (llvm::Function& F : *clonedModule) {
      if (F.isDeclaration()) {
        continue;
      }
      checkRequestMap.clear();
      useListMap.clear();
      for (llvm::BasicBlock& BB : F) {
        for (llvm::Instruction& I : BB) {
          if (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(&I)) {
            if (auto* mddata = bc->getMetadata(PSAN_CHECK_REQUEST_MD)) {
              llvm::ConstantInt* idvalue = llvm::cast<llvm::ConstantInt>(llvm::cast<llvm::ConstantAsMetadata>(mddata->getOperand(0))->getValue());
              unsigned checkID = idvalue->getZExtValue();
              checkRequestMap[checkID] = bc;
            }
          }
          if (auto* mddata = I.getMetadata(PSAN_CHECK_USE_MD)) {
            llvm::MDTuple* coalesced = llvm::cast<llvm::MDTuple>(mddata);
            for (unsigned i = 0, n = coalesced->getNumOperands(); i < n; ++i) {
              llvm::MDTuple* leaf = llvm::cast<llvm::MDTuple>(coalesced->getOperand(i));
              llvm::ConstantInt* idvalue    = llvm::cast<llvm::ConstantInt>(llvm::cast<llvm::ConstantAsMetadata>(leaf->getOperand(0))->getValue());
              llvm::ConstantInt* argnoValue = llvm::cast<llvm::ConstantInt>(llvm::cast<llvm::ConstantAsMetadata>(leaf->getOperand(1))->getValue());
              unsigned checkID = idvalue->getZExtValue();
              unsigned argno = argnoValue->getZExtValue();
              useListMap[checkID].push_back(&I.getOperandUse(argno));
            }
          }
        }
      }
      if (checkRequestMap.size() != useListMap.size()) {
        psan_unreachable("Broken check request metadata");
      }
      if (!checkRequestMap.empty()) {
        for (auto& p : checkRequestMap) {
          unsigned globalID = p.first;
          llvm::BitCastInst* checkRequest = p.second;
          auto iterUses = useListMap.find(globalID);
          if (iterUses == useListMap.end()) {
            psan_unreachable("Found no use list for check");
          }
          const auto& uselist = iterUses->second;
          auto* mddata = checkRequest->getMetadata(PSAN_CHECK_REQUEST_MD);
          llvm::ConstantInt* schemeValue = llvm::cast<llvm::ConstantInt>(llvm::cast<llvm::ConstantAsMetadata>(mddata->getOperand(1))->getValue());
          llvm::ConstantInt* internalIDValue = llvm::cast<llvm::ConstantInt>(llvm::cast<llvm::ConstantAsMetadata>(mddata->getOperand(2))->getValue());
          unsigned instrumentationID = schemeValue->getZExtValue();
          unsigned internalID = internalIDValue->getZExtValue();
          llvm::Value* ptr = checkRequest->getOperand(0);
          llvm::Instruction* insertBefore = checkRequest;

          // start to instrument the check
          // for now, when we check a pointer operand, the operand should not be a vector
          if (ptr->getType()->isVectorTy()) {
            psan_unreachable("Unexpected vector operand requiring checks");
          }
          // the following code would check if the used value is a special constant that we can directly get the metadata
          // if not, check if the metadata is already available
          // if not, create a placeholder for the metadata and enqueue the value
          MetadataMapTy& mdMap = getMetadataMap(ptr, dummyValueMap);
          MetadataVecTy& mdvec = mdMap[instrumentationID];
          populateStubMetadataVector(mdvec, ptr, instrumentationID, insertBefore, "check");
          if (isCollectRuntimeStats()) {
            incrementRuntimeStat_Check(instrumentationID, insertBefore);
          }
          if (isNoopCheck()) {
            instrumentNoopCheck(instrumentationID, ptr, mdvec, insertBefore);
            instrumentations[instrumentationID]->inspectCheckSiteForNoopCheck(insertBefore, ptr, uselist, mdvec, globalCheckCount++, internalID);
          } else {
            instrumentations[instrumentationID]->instrumentCheck(insertBefore, ptr, uselist, mdvec, globalCheckCount++, internalID);
          }
          clearDummyMap(dummyValueMap);
        }
      }
    }
  }

  auto getInstrumentationsRequestingMetadata = [&](MetadataMapTy& mdMap, llvm::BitVector& schemes) {
    // for each scheme in the mdMap, we check the metadata vector:
    // 1. all values are placeholder: we need to request metadata for them
    // 2. no values are placeholder: they are already populated from previous iterations, we do not need to request metadata
    // 3. having mixed placeholder and non-placeholder values: this is an error
    for (auto& p : mdMap) {
      unsigned schemeIndex = p.first;
      bool isAllPlaceholder = true;
      bool isNoPlaceholder = true;
      for (llvm::Value* val : p.second) {
        bool isCurValuePlaceholder = false;
        if (llvm::Instruction* placeholder = llvm::dyn_cast<llvm::Instruction>(val)) {
          if (isPlaceholderMetadata(placeholder)) {
            isCurValuePlaceholder = true;
          }
        }
        if (isCurValuePlaceholder) {
          isNoPlaceholder = false;
        } else {
          isAllPlaceholder = false;
        }
      }
      if (isAllPlaceholder) {
        schemes.set(schemeIndex);
      } else if (!isNoPlaceholder) {
        psan_unreachable("Mixed placeholder and non-placeholder metadata");
      }
    }
  };
  bool isVectorEncountered = false;
  // now solve all pending metadata requests
  while (!ptrMetadataRequestWorklist.empty()) {
    llvm::Instruction* curInstr = nullptr;
    {
      auto iter = ptrMetadataRequestWorklist.begin();
      curInstr = *iter;
      ptrMetadataRequestWorklist.erase(iter);
    }
    // for now we do not support vectors
    // once we find them, we replace metadata placeholders with null values
    // and we also emit a warning at the first occurrence
    if (curInstr->getType()->isVectorTy()) {
      if (!isVectorEncountered) {
        PSan::errs() << "Warning: vector encountered in metadata propagation; not supported yet\n";
        isVectorEncountered = true;
      }
      for (auto& p : vectorMetadataMap) {
        for (MetadataMapTy& mdMap : p.second) {
          for (auto& p : mdMap) {
            MetadataVecTy& mdvec = p.second;
            for (unsigned i = 0, n = mdvec.size(); i < n; ++i) {
              llvm::Instruction* placeholderInst = llvm::dyn_cast<llvm::Instruction>(mdvec[i]);
              if (!placeholderInst || !isPlaceholderMetadata(placeholderInst)) {
                continue;
              }
              llvm::Value* newValue = llvm::Constant::getNullValue(placeholderInst->getType());
              mdvec[i] = newValue;
              placeholderInst->replaceAllUsesWith(newValue);
              placeholderInst->eraseFromParent();
            }
          }
        }
      }
      if (metadataMap.find(curInstr) != metadataMap.end()) {
        psan_unreachable("vector instruction appear in scalar metadata map");
      }
      continue;
    }
    // check that we at least have placeholder metadata
    auto iterMD = metadataMap.find(curInstr);
    if (iterMD == metadataMap.end() || iterMD->second.empty()) {
      continue;
      // psan_unreachable("Instruction queued for metadata request but has no metadata map");
    }
    MetadataMapTy& mdMap = iterMD->second;
    llvm::BitVector schemesToRequest(instrumentations.size(), false);
    getInstrumentationsRequestingMetadata(mdMap, schemesToRequest);
    if (schemesToRequest.none()) {
      // we already have all the metadata
      continue;
    }
    // if the dummyValueMap is not empty, we probably forgot to clear it somewhere
    if (!dummyValueMap.empty()) {
      psan_unreachable("Unexpected non-empty dummyValueMap; forgetting cleanup?");
    }
    PSAN_DEBUG(PSan::outs() << "MDProp " << schemesToRequest << ": " << getValueStrWithParent(curInstr) << "\n");

    auto copyMetadataFromOperand = [&](llvm::Instruction* curInstr, unsigned copyFromOperandNo, const char* typestr) {
      llvm::Value* srcValue = curInstr->getOperand(copyFromOperandNo);
      auto& srcMDMap = getMetadataMap(srcValue, dummyValueMap);
      for (auto& p : mdMap) {
        if (!schemesToRequest.test(p.first)) continue; // skip ones we already have metadata
        MetadataVecTy& mdvec = p.second;
        bool isHavingRealMetadata = false;
        auto iter = srcMDMap.find(p.first);
        if (iter != srcMDMap.end()) {
          // the source already have something, maybe placeholder, maybe real metadata
          if (iter->second.size() != mdvec.size()) {
            psan_unreachable("Number of metadata values differ");
          }
          bool isNoPlaceholder = true;
          for (llvm::Value* v : iter->second) {
            llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(v);
            if (instr && isPlaceholderMetadata(instr)) {
              isNoPlaceholder = false;
              break;
            }
          }
          if (isNoPlaceholder) {
            isHavingRealMetadata = true;
          }
        } else {
          auto insertResult = srcMDMap.insert(std::make_pair(p.first, llvm::SmallVector<llvm::Value*>()));
          if (!insertResult.second) {
            psan_unreachable("Unexpected metadata map insertion failure");
          }
          iter = insertResult.first;
          populateStubMetadataVector(iter->second, srcValue, p.first, curInstr, typestr);
        }
        if (isHavingRealMetadata) {
          assignMetadataVec(mdvec, iter->second);
        } else {
          for (unsigned i = 0, n = mdvec.size(); i < n; ++i) {
            llvm::Instruction* placeholderInst = llvm::cast<llvm::Instruction>(mdvec[i]);
            llvm::Value* newValue = iter->second[i];
            llvm::BitCastInst* newBC = new llvm::BitCastInst(newValue, newValue->getType(), "psan_copy");
            newBC->insertAfter(curInstr);
            mdvec[i] = newBC;
            placeholderInst->replaceAllUsesWith(newBC);
            placeholderInst->eraseFromParent();
          }
        }
      }
      clearDummyMap(dummyValueMap);
    };
    auto setNullMetadata = [&]() {
      for (auto& p : mdMap) {
        if (!schemesToRequest.test(p.first)) continue; // skip ones we already have metadata
        MetadataVecTy& mdvec = p.second;
        for (unsigned i = 0, n = mdvec.size(); i < n; ++i) {
          llvm::Instruction* placeholderInst = llvm::cast<llvm::Instruction>(mdvec[i]);
          llvm::Value* newValue = llvm::Constant::getNullValue(placeholderInst->getType());
          mdvec[i] = newValue;
          placeholderInst->replaceAllUsesWith(newValue);
          placeholderInst->eraseFromParent();
        }
      }
    };
    auto cannotHandle = [&]() {
      if (isFunctionDead(curInstr->getFunction())) {
        for (auto& p : mdMap) {
          if (!schemesToRequest.test(p.first)) continue; // skip ones we already have metadata
          MetadataVecTy& mdvec = p.second;
          for (unsigned i = 0, n = mdvec.size(); i < n; ++i) {
            llvm::Instruction* placeholderInst = llvm::cast<llvm::Instruction>(mdvec[i]);
            llvm::Value* newValue = llvm::Constant::getNullValue(placeholderInst->getType());
            mdvec[i] = newValue;
            placeholderInst->replaceAllUsesWith(newValue);
            placeholderInst->eraseFromParent();
          }
        }
        callDeadCodeUnreachable(curInstr);
        return;
      }
      psan_unreachable("Unhandled instruction for metadata propagation");
    };
    if (getPointerElementType(curInstr->getType())->isFunctionTy()) {
      // we probably have some badcast on function pointer
      // just use null metadata
      setNullMetadata();
      continue;
    }

    switch (curInstr->getOpcode())
    {
    default: cannotHandle(); break;
    case llvm::Instruction::PHI: {
      // note that PHI may have duplicated incoming values and edges
      llvm::PHINode* phi = llvm::cast<llvm::PHINode>(curInstr);
      if (phi->getType()->isVectorTy()) {
        psan_unreachable("TODO implement support for vector PHI");
      }
      llvm::DenseMap<llvm::Value*, llvm::DenseMap<llvm::BasicBlock*, unsigned>> dupEdgeMap;
      llvm::SmallVector<MetadataMapTy> incomingMDVecs;
      llvm::SmallDenseMap<unsigned, llvm::SmallVector<llvm::PHINode*, ExpectMetadataVecSize>, MaxNumCheckingSchemes> metadataPHIVec;
      for (auto& p : mdMap) {
        if (!schemesToRequest.test(p.first)) continue; // skip ones we already have metadata
        auto& PHIVec = metadataPHIVec[p.first];
        for (auto* placeholder : p.second) {
          llvm::Instruction* placeholderInst = llvm::cast<llvm::Instruction>(placeholder);
          llvm::PHINode* mdPHI = llvm::PHINode::Create(placeholderInst->getType(), phi->getNumIncomingValues(), "psan_md_phi");
          mdPHI->insertBefore(phi);
          PHIVec.push_back(mdPHI);
        }
      }
      auto assignMDVec = [&](const MetadataMapTy& mdMap, llvm::BasicBlock* inBlock) {
        for (auto& p : mdMap) {
          if (!schemesToRequest.test(p.first)) continue; // skip ones we already have metadata
          auto& mdDest = metadataPHIVec[p.first];
          if (mdDest.size() != p.second.size()) {
            psan_unreachable("Number of metadata values differ");
          }
          for (unsigned i = 0, n = mdDest.size(); i < n; ++i) {
            mdDest[i]->addIncoming(p.second[i], inBlock);
          }
        }
      };
      for (unsigned i = 0, n = phi->getNumIncomingValues(); i < n; ++i) {
        llvm::Value* inValue = phi->getIncomingValue(i);
        llvm::BasicBlock* inBlock = phi->getIncomingBlock(i);
        auto& dupMapEntry = dupEdgeMap[inValue];
        {
          auto iter = dupMapEntry.find(inBlock);
          if (iter != dupMapEntry.end()) {
            unsigned mdIndex = iter->second;
            assignMDVec(incomingMDVecs[mdIndex], inBlock);
            continue;
          }
        }
        unsigned curSize = incomingMDVecs.size();
        dupMapEntry[inBlock] = curSize;
        llvm::Instruction* insertPoint = inBlock->getTerminator();
        auto& curMDMap = getMetadataMap(inValue, dummyValueMap);
        for (auto& p : mdMap) {
          if (!schemesToRequest.test(p.first)) continue; // skip ones we already have metadata
          unsigned schemeIndex = p.first;
          MetadataVecTy& mdvec = curMDMap[schemeIndex];
          populateStubMetadataVector(mdvec, inValue, schemeIndex, insertPoint, "phi");
        }
        incomingMDVecs.emplace_back(curMDMap);
        assignMDVec(curMDMap, inBlock);
        clearDummyMap(dummyValueMap);
      }
      // sanity check on the number of incoming edges
      for (auto& p : metadataPHIVec) {
        for (llvm::PHINode* mdphi : p.second) {
          if (mdphi->getNumIncomingValues() != phi->getNumIncomingValues()) {
            psan_unreachable("Number of incoming edges differ");
          }
        }
      }
      replacePlaceholderMetadataMap(metadataPHIVec, mdMap);
    } break;
    case llvm::Instruction::BitCast: {
      // if the source pointer already has the metadata, then we can directly replace uses of placeholder metadata
      // otherwise, we need to create a dummy cast of the upstream placeholder
      // so that if later on another instr picks up the value from this bitcast, the metadata is still correct
      // (not some dangling placeholder whose instruction body is already deleted but still lingering in the metadata map)
      llvm::BitCastInst* bc = llvm::cast<llvm::BitCastInst>(curInstr);
      if (bc->getType()->isVectorTy()) {
        psan_unreachable("TODO implement support for vector bitcast");
      }
      copyMetadataFromOperand(bc, 0, "bc");
    } break;
    case llvm::Instruction::Freeze: {
      llvm::FreezeInst* freeze = llvm::cast<llvm::FreezeInst>(curInstr);
      if (freeze->getType()->isVectorTy()) {
        psan_unreachable("TODO implement support for vector freeze");
      }
      copyMetadataFromOperand(freeze, 0, "freeze");
    } break;
    case llvm::Instruction::Select: {
      llvm::SelectInst* select = llvm::cast<llvm::SelectInst>(curInstr);
      if (select->getType()->isVectorTy()) {
        psan_unreachable("TODO implement support for vector select");
      }
      llvm::SmallDenseMap<unsigned, llvm::SmallVector<llvm::SelectInst*, ExpectMetadataVecSize>, MaxNumCheckingSchemes> mdMapVec;
      for (auto& p : mdMap) {
        if (!schemesToRequest.test(p.first)) continue; // skip ones we already have metadata
        unsigned schemeIndex = p.first;
        MetadataVecTy& mdvec = p.second;
        auto& destVec = mdMapVec[schemeIndex];
        for (llvm::Value* placeholder : mdvec) {
          llvm::SelectInst* mdselect = llvm::SelectInst::Create(select->getCondition(), placeholder, placeholder);
          mdselect->insertAfter(select);
          destVec.push_back(mdselect);
        }
      }
      auto handleOneSide = [&](llvm::Value* branchValue, llvm::SmallDenseMap<unsigned, llvm::SmallVector<llvm::SelectInst*, ExpectMetadataVecSize>, MaxNumCheckingSchemes>& mdDestMap, bool isTrueBranch) -> void {
        MetadataMapTy& branchMDMap = getMetadataMap(branchValue, dummyValueMap);
        for (auto& p : mdMap) {
          if (!schemesToRequest.test(p.first)) continue; // skip ones we already have metadata
          unsigned schemeIndex = p.first;
          MetadataVecTy& srcMDVec = branchMDMap[schemeIndex];
          populateStubMetadataVector(srcMDVec, branchValue, schemeIndex, select, isTrueBranch ? "select_true" : "select_false");

          auto& dstMDVec = mdDestMap[schemeIndex];
          if (srcMDVec.size() != dstMDVec.size()) {
            psan_unreachable("Number of metadata values differ");
          }
          for (unsigned i = 0, n = srcMDVec.size(); i < n; ++i) {
            llvm::SelectInst* mdselect = dstMDVec[i];
            llvm::Value* newValue = srcMDVec[i];
            if (isTrueBranch) {
              mdselect->setTrueValue(newValue);
            } else {
              mdselect->setFalseValue(newValue);
            }
          }
        }
        clearDummyMap(dummyValueMap);
      };
      llvm::Value* trueValue = select->getTrueValue();
      llvm::Value* falseValue = select->getFalseValue();
      handleOneSide(trueValue, mdMapVec, true);
      handleOneSide(falseValue, mdMapVec, false);
      replacePlaceholderMetadataMap(mdMapVec, mdMap);
    } break;
    case llvm::Instruction::GetElementPtr: {
      llvm::GetElementPtrInst* gep = llvm::cast<llvm::GetElementPtrInst>(curInstr);
      if (gep->getType()->isVectorTy()) {
        psan_unreachable("TODO implement support for vector gep");
      }
      llvm::Value* srcValue = gep->getPointerOperand();
      auto& srcMDMap = getMetadataMap(srcValue, dummyValueMap);
      for (auto& p : mdMap) {
        if (!schemesToRequest.test(p.first)) continue; // skip ones we already have metadata
        unsigned schemeIndex = p.first;
        MetadataVecTy& mdvec = srcMDMap[schemeIndex];
        populateStubMetadataVector(mdvec, srcValue, schemeIndex, gep, "gep");

        MetadataVecTy mdDest;
        instrumentations[schemeIndex]->handleGEP(gep, mdvec, mdDest);
        if (mdDest.size() != mdvec.size()) {
          psan_unreachable("Number of metadata values differ");
        }
        assignMetadataVec(p.second, mdDest);
        clearDummyMap(dummyValueMap);
      }
    } break;
    case llvm::Instruction::Call: {
      // if this is an intrinsic, we just create null metadata
      // otherwise we trap
      llvm::CallInst* call = llvm::cast<llvm::CallInst>(curInstr);
      if (call->getType()->isVectorTy()) {
        psan_unreachable("TODO implement support for vector call");
      }
      if (llvm::Function* calledFunc = call->getCalledFunction()) {
        if (calledFunc->isIntrinsic()) {
          setNullMetadata();
        } else {
          cannotHandle();
        }
      } else {
        setNullMetadata();
      }
    } break;
    case llvm::Instruction::ExtractElement: {
      // cannot handle yet
      setNullMetadata();
    } break;
    }
    llvm::Function* func = curInstr->getFunction();
    EXPENSIVE_VERIFICATION(verifyFunction(func));
  }
}

void PSanInstrumentationManager::verifyModule()
{
  if (isNoDebugPrint()) {
    return;
  }
  bool isValidationFailed = llvm::verifyModule(*clonedModule, &PSan::outs());
  if (isValidationFailed) {
    psan_unreachable("IR validation failed");
  }
}

void PSanInstrumentationManager::verifyFunction(llvm::Function* func)
{
  if (isNoDebugPrint()) {
    return;
  }
  bool isValidationFailed = llvm::verifyFunction(*func, &PSan::outs());
  if (isValidationFailed) {
    func->print(PSan::outs());
    psan_unreachable("IR validation failed");
  }
}

void PSanInstrumentationManager::trivialOptimization()
{
  // go through all code and remove dummy bitcasts from copy operations
  for (llvm::Function& F : *clonedModule) {
    if (F.isDeclaration()) {
      continue;
    }
    for (llvm::BasicBlock& BB : F) {
      for (auto iter = BB.begin(), iterEnd = BB.end(); iter != iterEnd;) {
        llvm::Instruction* inst = &*iter;
        ++iter;
        if (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(inst)) {
          if (bc->getType() == bc->getOperand(0)->getType()) {
            bc->replaceAllUsesWith(bc->getOperand(0));
            bc->eraseFromParent();
          }
        }
      }
    }
  }
}

llvm::Function* PSanInstrumentationManager::getDeadCodeUnreachableFunc()
{
  if (psan_dead_code_unreachable) {
    return psan_dead_code_unreachable;
  }
  llvm::FunctionType* funcType = llvm::FunctionType::get(llvm::Type::getVoidTy(clonedModule->getContext()), false);
  psan_dead_code_unreachable = llvm::Function::Create(funcType, llvm::GlobalValue::ExternalLinkage, "__psan_dead_code_unreachable", clonedModule);
  psan_dead_code_unreachable->addFnAttr(llvm::Attribute::NoReturn);
  psan_dead_code_unreachable->addFnAttr(llvm::Attribute::NoUnwind);
  psan_dead_code_unreachable->addFnAttr(llvm::Attribute::Cold);
  psan_dead_code_unreachable->addFnAttr(llvm::Attribute::NoInline);
  // now build the body of this function
  // it should just call llvm.trap
  llvm::BasicBlock* entry = llvm::BasicBlock::Create(clonedModule->getContext(), "entry", psan_dead_code_unreachable);
  llvm::Function* trapFunc = llvm::Intrinsic::getDeclaration(clonedModule, llvm::Intrinsic::trap);
  llvm::CallInst::Create(trapFunc, "", entry);
  llvm::ReturnInst::Create(clonedModule->getContext(), entry);
  // done
  return psan_dead_code_unreachable;
}

void PSanInstrumentationManager::sanityCheck()
{
  // double check that we don't have forward converters left
  // if we do have them, they should be in some dead code
  for (llvm::Function& F : *clonedModule) {
    if (F.isDeclaration()) {
      continue;
    }
    for (llvm::BasicBlock& BB : F) {
      for (llvm::Instruction& I : BB) {
        if (isForwardConverter(&I)) {
          if (isFunctionDead(&F)) {
            // this is in a dead function and it is fine to keep it
            callDeadCodeUnreachable(&I);
          } else if (isBestEffort) {
            callDeadCodeUnreachable(&I);
          } else {
            psan_unreachable("Forward converter left in the IR");
          }
        }
      }
    }
  }
}

void PSanInstrumentationManager::reapPlaceholders(bool isHardRemoval)
{
  // if isHardRemoval is true, we want to eliminate all placeholders and clear the map
  // otherwise, we just drop unused placeholders for ease of debugging
  for (auto& p : placeholderFunctionMap) {
    llvm::Function* placeholderFunc = p.second;
    for (auto iterUse = placeholderFunc->use_begin(), iterUseEnd = placeholderFunc->use_end(); iterUse != iterUseEnd;) {
      llvm::User* user = (*iterUse).getUser();
      ++iterUse;
      llvm::Instruction* inst = llvm::cast<llvm::Instruction>(user);
      if (!isPlaceholderMetadata(inst)) {
        psan_unreachable("Placeholder function used in unexpected way");
      }
      if (inst->use_empty()) {
        inst->eraseFromParent();
      } else if (isHardRemoval && isBestEffort) {
        callDeadCodeUnreachable(inst);
        inst->replaceAllUsesWith(llvm::UndefValue::get(inst->getType()));
        inst->eraseFromParent();
      } else if (isHardRemoval) {
        psan_unreachable("Placeholder is still in use");
      }
    }
    if (isHardRemoval) {
      if (placeholderFunc->use_empty()) {
        placeholderFunc->eraseFromParent();
      } else {
        psan_unreachable("Placeholder function is still in use");
      }
    }
  }
  if (isHardRemoval) {
    placeholderFunctionMap.clear();
  }
}

void PSanInstrumentationManager::dumpPointerMetadata(llvm::Value* ptr, MetadataMapTy& mdmap, llvm::Instruction* insertBefore, llvm::StringRef msg)
{
  if (!ppd) {
    return;
  }
  while (llvm::isa<llvm::PHINode>(insertBefore)) {
    insertBefore = insertBefore->getNextNode();
  }
  auto s = ppd->logCustomEvent("PtrMD", insertBefore);
  if (!msg.empty()) {
    s << msg << " ";
  }
  s << ptr;
  for (auto& p : mdmap) {
    s << " [" << p.first << "]: " << p.second;
  }
  s << "\n";
}

void PSanInstrumentationManager::transferValueName(llvm::Value* dest, llvm::Value* src)
{
  dest->takeName(src);
  // we don't need to properly transfer the name if we are not debugging...
  if (isNoDebugPrint()) {
    return;
  }
  if (dest->hasName()) {
    src->setName(llvm::Twine(src->getName(), ".old"));
  } else {
    if (dest->getType()->isVoidTy()) {
      return;
    }
    // set a new name for the dest using the slot number (better than <badref>)
    int slot = -1;
    llvm::Function* parentFunc = nullptr;
    if (llvm::Instruction* srcInst = llvm::dyn_cast<llvm::Instruction>(src)) {
      parentFunc = srcInst->getFunction();
    } else if (llvm::Argument* srcArg = llvm::dyn_cast<llvm::Argument>(src)) {
      parentFunc = srcArg->getParent();
    }
    if (parentFunc) {
      if (parentFunc != slotTracker->getCurrentFunction()) {
        slotTracker->incorporateFunction(*parentFunc);
      }
      slot = slotTracker->getLocalSlot(src);
    }
    if (slot >= 0) {
      std::string name("newvalue.");
      name += std::to_string(slot);
      dest->setName(name);
    } else {
      dest->setName("newvalue_badref");
    }
  }
}

void PSanInstrumentationManager::incrementRuntimeStatImpl(unsigned kindID, llvm::Instruction* insertBefore)
{
  llvm::ConstantInt* i64zero = llvm::ConstantInt::get(i64Ty, 0);
  llvm::ConstantInt* i32KindID = llvm::ConstantInt::get(i32Ty, kindID);
  llvm::Constant* addr = llvm::ConstantExpr::getInBoundsGetElementPtr(rtStatValueVecTy, psan_rt_stat_values, llvm::ArrayRef<llvm::Constant*>{i64zero, i32KindID});
  llvm::IRBuilder<> builder(insertBefore);
  llvm::LoadInst* load = builder.CreateLoad(i64Ty, addr);
  llvm::Value* inc = builder.CreateAdd(load, llvm::ConstantInt::get(i64Ty, 1));
  builder.CreateStore(inc, addr);
}

void PSanInstrumentationManager::incrementRuntimeStat(RTStatKind kind, llvm::Instruction* insertBefore)
{
  incrementRuntimeStatImpl(static_cast<unsigned>(kind), insertBefore);
}

void PSanInstrumentationManager::incrementRuntimeStat_Check(unsigned instrumentationID, llvm::Instruction* insertBefore)
{
  auto globalID = stats.instrumentID2GlobalInstrumentationID.find(instrumentationID);
  if (globalID == stats.instrumentID2GlobalInstrumentationID.end()) {
    psan_unreachable("Unknown instrumentation ID");
  }
  std::size_t globalInstrumentationID = globalID->second;
  if (globalInstrumentationID >= stats.maxGlobalInstrumentIDForRuntimeStats) {
    return;
  }
  incrementRuntimeStatImpl(globalInstrumentationID + static_cast<unsigned>(RTStatKind::Check_Start), insertBefore);
}

void PSanInstrumentationManager::initRuntimeStatsCollection()
{
  llvm::SmallVector<llvm::Constant*> statNames;
  auto addRuntimeStat = [&](const char* name, unsigned index) {
    if (statNames.size() != index) {
      psan_unreachable("Runtime stat index mismatch");
    }
    llvm::Constant* str = llvm::ConstantDataArray::getString(ctx, name);
    llvm::GlobalVariable* gv = new llvm::GlobalVariable(*clonedModule, str->getType(), true, llvm::GlobalValue::PrivateLinkage, str, "__psan_rt_stat_name");
    gv->setUnnamedAddr(llvm::GlobalValue::UnnamedAddr::Global);
    llvm::ConstantInt* i64zero = llvm::ConstantInt::get(i64Ty, 0);
    llvm::ConstantInt* i32zero = llvm::ConstantInt::get(i32Ty, 0);
    llvm::Constant* strAddr = llvm::ConstantExpr::getInBoundsGetElementPtr(str->getType(), gv, llvm::ArrayRef<llvm::Constant*>{i64zero, i32zero});
    statNames.push_back(strAddr);
  };

  addRuntimeStat("PtrLoad_InEPTG",  static_cast<unsigned>(RTStatKind::PtrLoad_InEPTG));
  addRuntimeStat("PtrLoad_OOB",     static_cast<unsigned>(RTStatKind::PtrLoad_OOB));
  addRuntimeStat("PtrStore_InEPTG", static_cast<unsigned>(RTStatKind::PtrStore_InEPTG));
  addRuntimeStat("PtrStore_OOB",    static_cast<unsigned>(RTStatKind::PtrStore_OOB));
  addRuntimeStat("MemFunc_InEPTG",  static_cast<unsigned>(RTStatKind::MemFunc_InEPTG));
  addRuntimeStat("MemFunc_OOB",     static_cast<unsigned>(RTStatKind::MemFunc_OOB));
  addRuntimeStat("Alloc_InEPTG_Dynamic", static_cast<unsigned>(RTStatKind::Alloc_InEPTG_Dynamic));
  addRuntimeStat("Alloc_InEPTG_Local",   static_cast<unsigned>(RTStatKind::Alloc_InEPTG_Local));
  addRuntimeStat("Alloc_OOB_Dynamic",    static_cast<unsigned>(RTStatKind::Alloc_OOB_Dynamic));
  addRuntimeStat("Alloc_OOB_Local",      static_cast<unsigned>(RTStatKind::Alloc_OOB_Local));
  for (std::size_t i = 0; i < stats.maxGlobalInstrumentIDForRuntimeStats; ++i) {
    addRuntimeStat(stats.instrumentationNames[i].c_str(), i + static_cast<unsigned>(RTStatKind::Check_Start));
  }

  std::size_t numStats = statNames.size();
  llvm::ArrayType* statNameArrayTy = llvm::ArrayType::get(llvm::Type::getInt8PtrTy(ctx), numStats);
  llvm::Constant* statNameArray = llvm::ConstantArray::get(statNameArrayTy, statNames);
  psan_rt_stat_names = new llvm::GlobalVariable(*clonedModule, statNameArrayTy, true, llvm::GlobalValue::ExternalLinkage, statNameArray, "__psan_rt_stat_names");
  llvm::ArrayType* statValueArrayTy = llvm::ArrayType::get(i64Ty, numStats);
  psan_rt_stat_values = new llvm::GlobalVariable(*clonedModule, statValueArrayTy, false, llvm::GlobalValue::ExternalLinkage, llvm::Constant::getNullValue(statValueArrayTy), "__psan_rt_stat_values");
  rtStatValueVecTy = statValueArrayTy;
  psan_rt_stat_num = new llvm::GlobalVariable(*clonedModule, i32Ty, true, llvm::GlobalValue::ExternalLinkage, llvm::ConstantInt::get(i32Ty, numStats), "__psan_rt_stat_num");
}

void PSanInstrumentationManager::instrumentNoopCheck(unsigned instrumentationID, llvm::Value* ptr, const llvm::SmallVectorImpl<llvm::Value*>& mdvec, llvm::Instruction* insertBefore)
{
  if (noopCheckCallees.size() < instrumentations.size()) {
    noopCheckCallees.resize(instrumentations.size(), nullptr);
  }
  llvm::FunctionCallee& calleeInfo = noopCheckCallees[instrumentationID];
  if (!calleeInfo) {
    // generate the callee
    // first, populate the function type (take ptr + all metadata, return void)
    llvm::SmallVector<llvm::Type*> paramTypes;
    paramTypes.push_back(i8PtrTy);
    paramTypes.append(instrumentations[instrumentationID]->getPointerMetadataTypesInRegisters());
    llvm::FunctionType* calleeTy = llvm::FunctionType::get(llvm::Type::getVoidTy(ctx), paramTypes, false);
    // now build the callee, an assembly with empty body and requiring all inputs to be register operands
    std::string asmBody;
    std::string asmConstraints;
    asmBody = "# psan noop check: ";
    for (unsigned i = 0; i < paramTypes.size(); ++i) {
      if (i > 0) {
        asmConstraints.push_back(',');
      }
      asmConstraints.push_back('r');
      asmBody += " $";
      asmBody += std::to_string(i);
    }
    llvm::InlineAsm* callee = llvm::InlineAsm::get(calleeTy, asmBody, asmConstraints, true, false);
    calleeInfo = llvm::FunctionCallee(calleeTy, callee);
  }
  llvm::SmallVector<llvm::Value*> args;
  llvm::Value* i8ptr = ptr;
  if (ptr->getType() != i8PtrTy) {
    i8ptr = new llvm::BitCastInst(ptr, i8PtrTy, "", insertBefore);
  }
  args.push_back(i8ptr);
  args.append(mdvec);
  llvm::CallInst* checkCall = llvm::CallInst::Create(calleeInfo, args, "", insertBefore);
  handleDebugLoc(checkCall, insertBefore);
}
