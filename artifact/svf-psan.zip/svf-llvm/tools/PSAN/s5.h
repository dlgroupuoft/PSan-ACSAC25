#ifndef PSAN_S5_H
#define PSAN_S5_H

#include "psan.h"
#include "eptg.h"
#include "MetadataScheme.h"
#include "PPD/PSanPrintDebugger.h"
#include "llvm/Transforms/Utils/Cloning.h"
#include <unordered_map>

namespace PSan {

// class that does all the work for instrumentation
class PSanInstrumentationManager {
public:
  PSanInstrumentationManager(llvm::LLVMContext& ctx, PSan::GraphConstructionResults& graphs, PSan::InstrumentationListType& instrumentations, const PSan::InstrumentationOptions& options, PSan::InstrumentationPlan& plan, PSan::StaticStats& stats, llvm::Module* srcModule);
  ~PSanInstrumentationManager() = default;
  llvm::Module* run();
private:
  static constexpr unsigned MaxNumCheckingSchemes = 2; // maximum number of checking schemes
  static constexpr unsigned ExpectMetadataVecSize = 4; // expected size of metadata vector
  // type decls
  // llvm::SmallVector for pointer metadata
  using MetadataVecTy = llvm::SmallVector<llvm::Value*, ExpectMetadataVecSize>;
  using MetadataMapTy = llvm::SmallDenseMap<unsigned, MetadataVecTy, MaxNumCheckingSchemes>;
  // basic data structures
  llvm::LLVMContext& ctx;
  PSan::GraphConstructionResults& graphs;
  PSan::InstrumentationListType& instrumentations;
  const PSan::InstrumentationOptions& options;
  PSan::InstrumentationPlan& plan;
  PSan::StaticStats& stats;
  llvm::Module* srcModule = nullptr;
  llvm::Module* clonedModule = nullptr;
  PSan::MetadataSchemeBase* mdscheme = nullptr;
  PSanPrintDebugger* ppd = nullptr;
  llvm::ValueToValueMapTy valueMap; // forward mapping from source module values to cloned module values
  llvm::Type* oobMetadataType = nullptr; // the all-in-one type for out-of-band metadata
  llvm::StringSet<> functionsWithHiddenCalls;

  llvm::IntegerType* i64Ty = nullptr;
  llvm::IntegerType* i32Ty = nullptr;
  llvm::IntegerType* i8Ty = nullptr;
  llvm::PointerType* i8PtrTy = nullptr;
  llvm::ConstantInt* i64zero = nullptr;
  llvm::ConstantInt* i32zero = nullptr;

  llvm::Function* lifetimeStart = nullptr;
  llvm::Function* lifetimeEnd = nullptr;
  llvm::Function* memsetFunc = nullptr;

  const bool isBestEffort = true; // if true, we will try to continue even if there are errors

  // we use indicesForOOBMetadata to map the overall in-memory representation of the metadata to the individual schemes
  // (1) if only having one element, then oobMetadataType is directly the in-memory representation of the specified instrumentation scheme
  // (2) if having multiple elements, then oobMetadataType is a struct that contains the individual in-memory metadata types with the scheme index listed in indicesForOOBMetadata
  llvm::SmallVector<unsigned> indicesForOOBMetadata;

  llvm::DenseMap<llvm::Value*, llvm::Value*> reverseValueMap; // remapping map for the cloned module values to the source module values

  llvm::DenseSet<llvm::Function*> functionDefinitions; // set of functions in the cloned module (before instrumentation or metadata scheme insert any new functions)
  llvm::DenseSet<llvm::GlobalVariable*> nonEPTGGlobals; // set of global variables outside EPTG in the cloned module (before instrumentation)

  // we will clear the following ones after they are handled (some may get definitions replaced)
  llvm::DenseSet<llvm::LoadInst*> ptrloadsForMD_oob; // set of pointer loads that need out-of-band metadata
  llvm::DenseSet<llvm::StoreInst*> ptrstoresForMD_oob; // set of pointer stores that need out-of-band metadata
  llvm::DenseMap<llvm::LoadInst*, ExpressionEPTGNode*> ptrloadsForMD_eptg; // set of pointer loads that need EPTG metadata
  llvm::DenseMap<llvm::StoreInst*, ExpressionEPTGNode*> ptrstoresForMD_eptg; // set of pointer stores that need EPTG metadata
  // now although their name is for md propagation, some of them are also used for runtime stats collection
  llvm::DenseSet<llvm::CallBase*> opaqueCallsForMDProp; // set of calls that need special handling for metadata
  llvm::DenseSet<llvm::CallBase*> allocatorCallsForMDProp;
  llvm::DenseMap<llvm::CallInst*, bool> intrinsicCallsForMDProp; // call -> isInvolveNonEPTG
  llvm::DenseMap<llvm::AllocaInst*, bool> allocasForStatsCollection; // alloca -> isInEPTG

  // the lists for functions, globals, and local / dynamic allocations
  llvm::SmallVector<AllocEPTGNode*> functionAllocs;
  llvm::SmallVector<AllocEPTGNode*> globalAllocs;
  llvm::SmallVector<AllocEPTGNode*> localAllocs;
  llvm::SmallVector<AllocEPTGNode*> dynamicAllocs;

  template <typename T>
  T* getPostCloneValue(T* value) {
    auto iter = valueMap.find(value);
    if (iter == valueMap.end()) {
      psan_unreachable("value not found in the map");
    }
    return llvm::cast<T>(iter->second);
  }
  template <typename K, typename V>
  const V& getValue(const llvm::DenseMap<K, V>& map, const K& key) {
    auto iter = map.find(key);
    if (iter == map.end()) {
      psan_unreachable("key not found in the map");
    }
    return iter->second;
  }
  template <typename K, typename V, unsigned Size>
  const V& getValue(const llvm::SmallDenseMap<K, V, Size>& map, const K& key) {
    auto iter = map.find(key);
    if (iter == map.end()) {
      psan_unreachable("key not found in the map");
    }
    return iter->second;
  }

  // To assist type changes, we use forward/backward converter casts to keep track of old/new pointer and metadata for EPTG-based type conversion
  // a forward converter cast takes the old (raw) pointer and produces the new pointer, possibly with a different points-to type
  // a backward converter cast takes the (new-type) pointer and produces the old (raw) pointer
  // when we replace a pointer definition but we haven't started handling the uses, we use the backward converter to make IR well-typed
  // when we replace a pointer use, we use the forward converter
  // the bitcast may have the source and destination types the same, but we use it to represent a pending request for updates
  // metadata is tracked in the metadataMap, and the key is always the new pointer; once we added the metadata, they key should not be changed anymore.
  // (however if the key is a forward converter cast, when we resolve the cast,
  //  we will update the metadataMap to put in the real metadata instead of the placehodlers)
  // all values are in the destination (cloned) module
  // we use std::unordered_map because references to the values are stable after insertion
  std::unordered_map<llvm::Value*, MetadataMapTy> metadataMap; // value -> (instrumentation index -> metadata)
  std::unordered_map<llvm::Value*, llvm::SmallVector<MetadataMapTy>> vectorMetadataMap; // metadataMap for fixed-size vectors

  // because instrumentation may introduce new instructions and pointer users,
  // and these instructions may interfere with pointer value updates when propagating the metadata,
  // we add all instrumentations at the end in one shot for each pointer user,
  // and we need to finish converting all the types and getting metadata before that

  // To do the instrumentation with both Out-of-band and In-band metadata, we use the following steps:
  // 1. preparation: clone the module
  // 2. Replace definitions (function/gv/local) managed by EPTG; create backward converters for each definition.
  //    when replacing function definitions, we also replace the call sites and use forward converters for arguments
  //    any forward converters are created as early as possible so that we can use the same forward converter for all uses
  //    For functions that do not use EPTG transform but is taking pointer argument / returning pointer values,
  //    we also do corresponding transform to make them carry metadata
  // 3. Forward propagation of metadata: for each backward converter, we propagate the metadata to the uses and resolve forward converters along the way
  //    at this point, all changes from EPTG should be done
  // 4. Demand-driven analysis for pointer metadata from Out-of-band metadata scheme
  //    We start from instructions that require checks on input pointer, get what metadata they need, and propagate the need to the input pointers
  //    We then add metadata load/store for the source pointers and propagate them along the way

  // for functions outside EPTG but passing pointers across interface, we do:
  // 1. the function is always transformed in the same way as EPTG, in which additional parameters are added for metadata
  // 2. if the function is address-taken, we create a thunk that
  //      (1) checks if the metadata is passed through indirect call interface, and
  //      (2) calls the original function
  //    the address-taken value will use this thunk instead of the original function
  // When we do an indirect function call, we always pass additional metadata in the indirect call interface, which is made with following TLS variable:
  // 1. void* __psan_ind_callee; the indirect caller should set this to the actual callee and the callee (thunk) should check this
  // 2. void* __psan_ind_md; the caller should allocate space for metadata on stack and pass this to the callee
private:
  // because the thunk metadata struct depends on how many pointer arguments are there,
  // we don't have to duplicate the type for each function; we can use a shared type for all thunks with the same number of pointer arguments
  struct ThunkMetadataSharedInfo {
    llvm::StructType* metadataStructType = nullptr;
    // where to store the metadata for pointer arguments
    // list of (instrumentation index -> list of GEP offsets (ConstantInt) for each metadata component)) for each pointer argument
    llvm::SmallVector<llvm::DenseMap<unsigned, llvm::SmallVector<llvm::SmallVector<llvm::Value*>>>> metadataOffsetMap;
    // where to store the metadata for return value; if the function does not return a pointer, this is empty
    llvm::SmallVector<llvm::Value*> retMDGEPIndices;
  };
  struct ThunkMetadataUniqueInfo {
    llvm::SmallVector<unsigned> pointerArgIndices;
    bool hasRetMD = false;
  };

  unsigned mdvecWithAll = 0; // the metadata vector for non-EPTG pointers (includes all schemes with metadata)
  llvm::SmallVector<llvm::Type*> nonEPTGPtrMetadataParamTypes; // the full list of in-register metadata types for non-EPTG pointers
  llvm::DenseMap<llvm::Type*, llvm::Function*> placeholderFunctionMap; // for metadata placeholders
  llvm::GlobalVariable* psan_ind_callee = nullptr;
  llvm::GlobalVariable* psan_ind_md = nullptr;
  llvm::Type* retMDPointsToType = nullptr; // if a function outside EPTG is returning a pointer, this is the points-to type of the additional parameter
  llvm::PointerType* retMDAppendParamType = nullptr; // pointer type to retMDPointsToType
  llvm::DenseMap<llvm::Function*, llvm::Function*> thunkMap; // original function -> thunk
  llvm::DenseMap<llvm::FunctionType*, ThunkMetadataUniqueInfo> thunkUniqueInfo; // original function type -> unique metadata info
  llvm::DenseMap<unsigned, std::pair<ThunkMetadataSharedInfo, ThunkMetadataSharedInfo>> thunkMetadataStructInfo; // list of shared metadata info for thunks with the same number of pointer arguments

  // instrumentation index -> list of GEP indices into the allocated struct for return value metadata
  llvm::DenseMap<unsigned, llvm::SmallVector<llvm::SmallVector<llvm::Value*>>> retMDGEPIndices_nonEPTG;
  llvm::DenseMap<unsigned, llvm::DenseMap<unsigned, llvm::SmallVector<llvm::SmallVector<llvm::Value*>>>> retMDGEPIndices_EPTG; // mdvec -> (instrumentation index -> list of GEP indices)

  llvm::Function* psan_dead_code_unreachable = nullptr;
  llvm::Function* getDeadCodeUnreachableFunc();
  void callDeadCodeUnreachable(llvm::Instruction* insertBefore) {
    llvm::CallInst::Create(getDeadCodeUnreachableFunc(), "", insertBefore);
  }

  // the counter for assigning check IDs
  std::size_t globalCheckCount = 0;

  // keep a pointer to the slot tracker for the cloned module
  llvm::ModuleSlotTracker* slotTracker = nullptr;
  // better version of dest->takeName(src) that also preserves the value name for src, making debugging easier
  void transferValueName(llvm::Value* dest, llvm::Value* src);

  // get the thunk info for indirect call handling
  std::pair<ThunkMetadataUniqueInfo*, ThunkMetadataSharedInfo*> getThunkMetadataInfo(llvm::FunctionType* ty);

  // functions for forward/backward converters
  // createForwardConverter() also handles special constants (like null) under the hood, so is not always returning an instruction
  llvm::Instruction* createBackwardConverter(llvm::Value* newPtr, llvm::Type* oldType, llvm::Instruction* insertBefore, const llvm::Twine& name);
  llvm::Value* createForwardConverter(llvm::Value* oldPtr, llvm::Type* newType, llvm::Instruction* insertBefore, const llvm::Twine& name);
  bool isBackwardConverter(llvm::Value* value);
  bool isForwardConverter(llvm::Value* value);

  // call this function to create placeholders that can use replaceAllUsesWith to replace the actual metadata
  llvm::Instruction* createPlaceholderMetadata(llvm::Type* ty, llvm::Instruction* insertBefore, const llvm::Twine& name);
  void queuePointerChange(llvm::Instruction* backwardConverter);
  bool isPlaceholderMetadata(llvm::Instruction* instr);

  // some llvm::Value* in the source IR is not included in valueMap
  // we use this function to try to reconstruct them in the cloned module
  llvm::Value* reconstructPostCloneValue(llvm::Value* value);
  llvm::Value* getOrReconstructPostCloneValue(llvm::Value* value) {
    auto iter = valueMap.find(value);
    if (iter == valueMap.end()) {
      llvm::Value* result = reconstructPostCloneValue(value);
      valueMap[value] = result;
      return result;
    }
    return iter->second;
  }

  // equivalent to inst->eraseFromParent() but also takes care of metadataMap
  void eraseInstrFromParent(llvm::Instruction* inst);

  // check if a function definition would never be executed
  // if so, forward converters left in the function can be removed. Otherwise, it should be a bug.
  bool isFunctionDead(llvm::Function* func);

  // we mostly have pointer values from instructions and arguments, which should use the metadataMap
  // however, there are some pointers from constants as well (e.g., null, global variables), which should not have backing storage (we regenerate them on demand)
  // when we want to get the metadata or placeholder metadata of a value and we don't want to differentiate if it is a special case
  // just use the functions below to get the metadata mapping
  // we use a separate dummyValueMap for these constants
  // after the map is used, we clear dummyValueMap so it does not keep the (probably stale) metadata
  // the dummyValueMap should be declared in the caller function
  MetadataMapTy& getMetadataMap (llvm::Value* value, MetadataMapTy& dummyValueMap);
  void clearDummyMap(MetadataMapTy& dummyValueMap);

  // for overriding the metadata of a pointer value
  // this function takes care of the case when the destination is already filled with placeholders
  void assignMetadataVec(llvm::SmallVectorImpl<llvm::Value*>& dest, const llvm::SmallVectorImpl<llvm::Value*>& src);

  // helper that analyze function interface changes and bind pointer metadata arguments to the corresponding pointer arguments
  void bindArgumentsAsMetadata(llvm::Function* func, llvm::Argument* ptrArg, unsigned mdvec, const PSan::InstrumentationPlan::FunctionTypeChangeInfo::ArgumentPointerExpandInfo& info, llvm::Instruction* insertBefore);

  // when using conservative out-of-band metadata, this returns the predicate (i1) value for the metadata validity check
  llvm::Value* getPtrMDValidityValue(llvm::Value* mdaddr, llvm::Value* ptr, llvm::Instruction* insertBefore);

  // some arguments (e.g., byval/sret) do not need to propagate metadata; we can create them from scratch
  // this function returns the byval/sret type if the argument is byval/sret-like; otherwise, it returns nullptr
  llvm::Type* isArgumentByvalLike(llvm::Argument* arg);

  // replace the call site with the new function and update the arguments
  // metadataMap maps argument index into map of instrumentation index to metadata
  // if the callee is undering EPTG type transform and some arguments need replacement, they should be in newArgMap. newArgMap can be empty if no replacement is needed
  // if the return value is a pointer that carry metadata, retMDDest should be the destination
  // eptgPartitionIndex is the index of the EPTG partition that the function belongs to; 0 if it is not in EPTG
  llvm::CallBase* createDirectReplacementCall(llvm::CallBase* oldCall, llvm::Function* func, llvm::DenseMap<unsigned, llvm::Value*> newArgMap, llvm::DenseMap<unsigned, MetadataMapTy>& argMetadataMap, std::size_t eptgPartitionIndex, llvm::Value* retMDDest = nullptr);

  // this function wraps createDirectReplacementCall() and does additional stuff needed to replace the call, including:
  // 1. create placeholders for the missing metadata arguments
  // 2. create the alloca for return value metadata
  // 3. init/fini the metadata for the return value
  // this function only returns the new call; the value for replacing the original call may be different
  // in case that the pointer return value have a different type, the return value will be replaced with a bitcast
  // but this function always returns the new call
  // to get the value for replacing the original call, use callValueReplacement
  llvm::CallBase* replaceDirectCall(llvm::CallBase* oldCall, llvm::Function* newCallTarget, std::size_t partitionIndex, llvm::Value** callValueReplacement = nullptr);

  // helper to replace global variable initializers
  // postCloneRemappingMap is the remapping map for the cloned module
  // constantValueRemapper is the cache for results of this function
  llvm::Constant* getUpdatedConstantExpr(llvm::Constant* src, llvm::Type* valueType, const llvm::DenseMap<llvm::Value*, llvm::Value*>& postCloneRemappingMap, llvm::DenseMap<std::pair<llvm::Constant*, llvm::Type*>, llvm::Constant*>& constantValueRemapper);

  llvm::Constant* getUpdatedConstantExprInEPTG(llvm::Constant* src, llvm::Type* valueType, CellEPTGNode* root, const llvm::DenseMap<llvm::Value*, llvm::Value*>& postCloneRemappingMap);

  // cache for the dominator trees for placing instrumentations / metadata operations
  llvm::DenseMap<llvm::Function*, llvm::DominatorTree*> domTreeMap;
  llvm::DominatorTree* getDominatorTreeForPostCloneFunction(llvm::Function* func);

  // get a new size value for the destination type
  llvm::Value* getSizeReplacementValue(llvm::Value* curSizeValue, llvm::Type* srcElementType, llvm::Type* destElementType, llvm::Instruction* insertBefore);

  // helpers for handling EPTG type transform
  llvm::DenseSet<llvm::Instruction*> queuedEPTGPointerChanges;
  std::pair<llvm::Value*, bool> handleEPTGPointerUser(llvm::Instruction* user, unsigned argno, llvm::Instruction* oldValue, llvm::Value* newValue);

  // helper function to update metadata mapping when we replace a value
  void replaceValueForMD(llvm::Value* oldValue, llvm::Value* newValue);

  // dump the metadata to the print debugger if enabled
  void dumpPointerMetadata(llvm::Value* ptr, MetadataMapTy& mdmap, llvm::Instruction* insertBefore, llvm::StringRef msg = llvm::StringRef());

  // helper for replacing metadata map for phi/select whose metadata is also organized in a map+vector of phi/select
  template<typename InstrTy>
  void replacePlaceholderMetadataMap(llvm::SmallDenseMap<unsigned, llvm::SmallVector<InstrTy*, ExpectMetadataVecSize>, MaxNumCheckingSchemes>& newValue, MetadataMapTy& dest);

  // if we have created placeholder metadata for load/store/checking, the instruction creating the pointer should be here
  // note that it may be an instruction producing a pointer vector instead of a single pointer
  llvm::DenseSet<llvm::Instruction*> ptrMetadataRequestWorklist;

  // this function populates mdVec with placeholder metadata if needed:
  // if the mdVec already has the metadata, it does nothing
  // if there is no metadata in mdVec but the pointer is some special constants (e.g., null), it populates the metadata directly
  // otherwise, it creates placeholder metadata
  void populateStubMetadataVector(llvm::SmallVectorImpl<llvm::Value*>& mdVec, llvm::Value* ptrvalue, unsigned scheme, llvm::Instruction* insertBefore, const char* src);

  // return true if this is the bitcast we added to guide placement of checks
  bool isCheckRequest(llvm::Instruction* inst);

  // entry function for preparation that must be done before any instrumentation
  void preparation();

  // entry function for writing check info as metadata (easier for debugging and implementation; they don't need special data structures to keep track of)
  void convertCheckInfo();

  // entry function for replacing definitions
  void replaceDefinitions();

  // entry function for size updates handling
  void handleSizeUpdates();

  // entry function for replacing pointer / pointer vector load/stores for type change and metadata propagation
  void replacePointerLoadStores();

  // entry function for handling opaque calls (call to externally defined functions or indirect calls) or intrinsics
  void handleCallsForMDProp();

  // entry function for handling queued pointer type changes for EPTG
  void handleEPTGTypeTransform();

  // entry function for forward propagation of metadata (both EPTG and non-EPTG)
  void handleMetadataPropagation();

  // entry function for removing placeholder declarations
  void reapPlaceholders(bool isHardRemoval = true);

  // checking at the end of the instrumentation
  void sanityCheck();

  // improve the readability of the result code
  void trivialOptimization();

  // for internal debugging
  void verifyModule();
  void verifyFunction(llvm::Function* func);

private:
  // code for runtime stats collection
  enum class RTStatKind : unsigned {
    PtrLoad_InEPTG,
    PtrLoad_OOB,
    PtrStore_InEPTG,
    PtrStore_OOB,
    MemFunc_InEPTG,
    MemFunc_OOB,
    Alloc_InEPTG_Dynamic,
    Alloc_InEPTG_Local,
    Alloc_OOB_Dynamic,
    Alloc_OOB_Local,
    Check_Start, // the start of check stats; this must be the last one
  };
  void incrementRuntimeStat(RTStatKind kind, llvm::Instruction* insertBefore);
  void incrementRuntimeStat_Check(unsigned instrumentationID, llvm::Instruction* insertBefore);
  void incrementRuntimeStatImpl(unsigned kindID, llvm::Instruction* insertBefore);

  llvm::GlobalVariable* psan_rt_stat_names = nullptr; // i8* array
  llvm::GlobalVariable* psan_rt_stat_values = nullptr; // i64 array
  llvm::GlobalVariable* psan_rt_stat_num = nullptr; // i64 constant
  llvm::Type* rtStatValueVecTy = nullptr; // i64 array type
  static const char* const psan_eptg_alloc_md;

  void initRuntimeStatsCollection();

private:
  // for evaluating metadata cost without checking
  llvm::SmallVector<llvm::FunctionCallee> noopCheckCallees;
  void instrumentNoopCheck(unsigned instrumentationID, llvm::Value* ptr, const llvm::SmallVectorImpl<llvm::Value*>& mdvec, llvm::Instruction* insertBefore);
};

} // namespace PSan

#endif // PSAN_S5_H
