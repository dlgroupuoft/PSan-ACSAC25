#ifndef PSAN_INSTRUMENT_OPTIONS_H
#define PSAN_INSTRUMENT_OPTIONS_H

namespace PSan {
struct InstrumentationOptions {
  bool isCollectRuntimeStats = false;
};
} // end namespace PSan

#endif // PSAN_INSTRUMENT_OPTIONS_H
