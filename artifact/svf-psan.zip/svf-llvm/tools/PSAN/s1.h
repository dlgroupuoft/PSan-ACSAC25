#ifndef PSAN_S1_H
#define PSAN_S1_H

#include "psan.h"

namespace PSan {
struct OpaqueRegionAnalysisState {
  struct FunctionInfo {
    llvm::Function* func = nullptr;

    // whenever we found a value to be in the opaque region, we also push it in this worklist so that upper stream / downstream values are also visited
    SVF::FILOWorkList<llvm::Value*> worklist;
    // when we first visit a function, we put all returns in this set
    // in this way, when we consider the return value to be in the opaque region, we can find all values to taint as opaque
    llvm::DenseSet<llvm::ReturnInst*> returns;

    // because we likely need to finish traversing all functions to decide how we handle ptrtoints,
    // we first remember all the ptrtoints we found, then handle them later on
    llvm::DenseSet<llvm::PtrToIntInst*> ptrtoints;

    // if we taint the return value of a call, we will not sure whether we should remove the call in the trimmed IR
    // because whether the callee has remainings in the analyzable region is not known until the end
    // so whenever we taint the return value of a call,  we add them to this set and we will come back and check later on
    llvm::DenseSet<llvm::CallBase*> taintedCalls;

    // put all indirect calls here so that if we need to taint an address-taken function's return value, we can find all such indirect calls
    llvm::DenseSet<llvm::CallBase*> indirectCalls;
  };
  llvm::DenseMap<llvm::Function*, FunctionInfo*> funcInfo; // this data structure owns the FunctionInfo instances

  // for any function with address taken,
  // if we have an indirect call that the returned pointer is tainted,
  // we will taint the return value of all these functions
  llvm::DenseSet<llvm::Function*> funcWithAddrTaken;

  // during the initialization (first pass), not all funcInfo are created,
  // so when we found that a gv address should be tainted, we cannot immediately push all users to their worklist
  // we use this set to temporarily save them
  llvm::DenseSet<llvm::GlobalVariable*> taintedGVs;

  // during initialization, we may see some bad cast on function pointer
  // and we need to taint the function, including all its parameters and return values
  llvm::DenseSet<llvm::Function*> taintedFunctions;

  // all functions whose worklist is not empty yet
  SVF::FIFOWorkList<FunctionInfo*> functionsWithWork;

  // states to track whether an instruction / value is in the opaque region
  // for gv and instructions: we use a unified map
  // the key llvm::Value* is only in this map if the value corresponds to a pointer in the opaque region
  // for load and call instructions that (1) produces pointers in opaque region but (2) need to be preserved in the analyzed region, we will set isInstrPreserved to true
  struct OpaqueValueInfo {
    bool isInstrPreserved = false;
  };
  llvm::DenseMap<llvm::Value*, OpaqueValueInfo> opaqueRegionValues;

  // for function param/ret values, we use per-function state
  // say the function decl has N parameters, then the bitvector has N+1 elements: 0 ~ N-1 corresponds to each parameter, while index N is for the return value
  // the bit for non-pointer values are always set to zero
  // for simplicity, if a parameter is in the opaque region, we duplicate the values in opaqueRegionValues
  llvm::DenseMap<llvm::Function*, llvm::BitVector> functionInterfaceOpaqueValues;

  // if we found an inttoptr taking integers from a function call / return value, a load, or some other unanalyzable value, we set this flag
  bool isEscapedIntToPtrFound = false;

  // keep track of how the address-taken function's arg/returns are tainted
  bool isAllAddrTakenFunctionReturnsTainted = false;
  llvm::BitVector addrTakenFunctionArgTaints;

  // excluded values to forward
  decltype(PreTransformResult::excludeValues) excludeValues;

  ~OpaqueRegionAnalysisState();
};

// helper that simplify the input IR
void step1_simplify(llvm::Function* func);

// helper that wraps the initial analysis
void step1_opaque_region_analysis_initstats(StaticStats& stats);
void step1_opaque_region_analysis_init(llvm::Function* func, PreTransformResult& result, OpaqueRegionAnalysisState& state, StaticStats& stats);
void step1_opaque_region_analysis_solve(llvm::Module* srcModule, PreTransformResult& result, OpaqueRegionAnalysisState& state, StaticStats& stats);

} // end namespace PSan



#endif /* PSAN_S1_H */
