#include "FastDebugDumper.h"
#include "psan.h"
#include "llvm/ADT/BitVector.h"

using namespace PSan;

namespace {
// we flush the dump queue when it reaches this size
const std::size_t DUMP_QUEUE_SIZE = 65536;
}

std::vector<DumpEventDeclBase*> FastDebugDumper::EventDeclVec;
llvm::DenseMap<const llvm::Module*, llvm::ModuleSlotTracker*> FastDebugDumper::SlotTrackerMap;
FastDebugDumper FastDebugDumper::d;
FastDebugDumper* FastDebugDumper::instance() {
  return &d;
}

llvm::ModuleSlotTracker& FastDebugDumper::getSlotTracker(const llvm::Module* module)
{
  auto iter = SlotTrackerMap.find(module);
  if (iter != SlotTrackerMap.end()) {
    return *iter->second;
  }
  auto* slotTracker = new llvm::ModuleSlotTracker(module, true);
  SlotTrackerMap[module] = slotTracker;
  return *slotTracker;
}

const llvm::Module* FastDebugDumper::getModuleFromVal(const llvm::Value *V) {
  if (const llvm::Argument *MA = llvm::dyn_cast<llvm::Argument>(V))
    return MA->getParent() ? MA->getParent()->getParent() : nullptr;

  if (const llvm::BasicBlock *BB = llvm::dyn_cast<llvm::BasicBlock>(V))
    return BB->getParent() ? BB->getParent()->getParent() : nullptr;

  if (const llvm::Instruction *I = llvm::dyn_cast<llvm::Instruction>(V)) {
    const llvm::Function *M = I->getParent() ? I->getParent()->getParent() : nullptr;
    return M ? M->getParent() : nullptr;
  }

  if (const llvm::GlobalValue *GV = llvm::dyn_cast<llvm::GlobalValue>(V))
    return GV->getParent();

  if (const auto *MAV = llvm::dyn_cast<llvm::MetadataAsValue>(V)) {
    for (const llvm::User *U : MAV->users())
      if (llvm::isa<llvm::Instruction>(U))
        if (const llvm::Module *M = FastDebugDumper::getModuleFromVal(U))
          return M;
    return nullptr;
  }

  return nullptr;
}

void FastDebugDumper::flush() {
  instance()->write();
}

void FastDebugDumper::write_parallel_hint()
{
  instance()->write_nowait();
}

DumpEventDeclBase::DumpEventDeclBase() {
  kind = FastDebugDumper::EventDeclVec.size();
  FastDebugDumper::EventDeclVec.push_back(this);
}

void FastDebugDumper::writeEntry(WriteTask* task)
{
  for (auto& e : task->eventList) {
    auto* decl = task->EventDeclVecCopy.at(e.kind);
    auto dataIter = task->dataMap.find(e.kind);
    if (dataIter == task->dataMap.end()) {
      llvm_unreachable("data not found");
    }
    void* data = dataIter->second;
    for (EventIDType i = 0; i < e.num; ++i) {
      decl->print(PSan::outs(), data, e.id + i);
    }
  }
  for (auto& p : task->dataMap) {
    auto* decl = task->EventDeclVecCopy.at(p.first);
    decl->freeData(p.second);
  }
  delete task;
}

FastDebugDumper::WriteTask* FastDebugDumper::createWriteTask()
{
  if (eventList.empty()) {
    return nullptr;
  }
  WriteTask* task = new WriteTask;
  task->EventDeclVecCopy = EventDeclVec;
  task->eventList.swap(eventList);
  for (int kind = eventDeclsWithData.find_first(); kind != -1; kind = eventDeclsWithData.find_next(kind)) {
    auto* decl = EventDeclVec.at(kind);
    void* data = decl->detachData();
    task->dataMap[kind] = data;
  }
  eventDeclsWithData.clear();
  eventCount = 0;
  return task;
}

void FastDebugDumper::write()
{
  wait();
  if (WriteTask* task = createWriteTask()) {
    writeEntry(task);
  }
}

void FastDebugDumper::wait()
{
  if (writeThread) {
    writeThread->join();
    delete writeThread;
    writeThread = nullptr;
  }
}

void FastDebugDumper::write_nowait()
{
  wait();
  if (WriteTask* task = createWriteTask()) {
    writeThread = new std::thread(writeEntry, task);
  }
}

void FastDebugDumper::addEvent(EventKindType kind, EventIDType id)
{
  if (kind >= eventDeclsWithData.size()) {
    eventDeclsWithData.resize(EventDeclVec.size(), false);
  }
  eventDeclsWithData.set(kind);
  eventCount++;

  // if the last event is of the same kind, we can merge them
  if (!eventList.empty()) {
    auto& lastGroup = eventList.back();
    if (lastGroup.kind == kind && lastGroup.id + lastGroup.num == id) {
      lastGroup.num++;
      return;
    }
  }
  EventGroup newGroup;
  newGroup.kind = kind;
  newGroup.id = id;
  newGroup.num = 1;
  eventList.push_back(newGroup);

  if (eventCount >= DUMP_QUEUE_SIZE) {
    write_nowait();
  }
}

std::string* FastDebugDumper::getString(llvm::StringRef s)
{
  auto iter = stringMap.find(s);
  if (iter != stringMap.end()) {
    return iter->second;
  }
  auto* newStr = new std::string(s);
  stringMap[s] = newStr;
  return newStr;
}

const DumpCacheNode* FastDebugDumper::getValueString(llvm::Value* value)
{
  if (!value) {
    return nullptr;
  }
  auto iter = valueCache.find(value);
  if (iter != valueCache.end()) {
    return iter->second;
  }
  std::string* bufptr = new std::string();
  llvm::raw_string_ostream ss(*bufptr);
  printValueStrWithParent(value, ss);
  auto* node = new DumpCacheNode;
  node->data.reset(bufptr);
  node->kind = FastDebugDumper::CDK_VALUE;
  node->isAlive = true;
  valueCache[value] = node;
  return node;

}
const DumpCacheNode* FastDebugDumper::getSVFGNodeString(const SVF::SVFGNode* node)
{
  if (!node) {
    return nullptr;
  }
  auto iter = svfgNodeCache.find(node);
  if (iter != svfgNodeCache.end()) {
    return iter->second;
  }
  std::string* bufptr = new std::string(node->toString());
  auto* cacheNode = new DumpCacheNode;
  cacheNode->data.reset(bufptr);
  cacheNode->kind = FastDebugDumper::CDK_SVFGNODE;
  cacheNode->isAlive = true;
  svfgNodeCache[node] = cacheNode;
  return cacheNode;
}
const DumpCacheNode* FastDebugDumper::getTypeString(llvm::Type* type)
{
  if (!type) {
    return nullptr;
  }
  auto iter = typeCache.find(type);
  if (iter != typeCache.end()) {
    return iter->second;
  }
  std::string* bufptr = new std::string();
  llvm::raw_string_ostream ss(*bufptr);
  type->print(ss);
  auto* node = new DumpCacheNode;
  node->data.reset(bufptr);
  node->kind = FastDebugDumper::CDK_TYPE;
  node->isAlive = true;
  typeCache[type] = node;
  return node;
}

const DumpCacheNode* FastDebugDumper::getEPTGNodeString(EPTGNode* node)
{
  if (!node) {
    return nullptr;
  }
  auto iter = eptgNodeCache.find(node);
  if (iter != eptgNodeCache.end()) {
    return iter->second;
  }
  std::string* bufptr = new std::string(node->getNodeTitle());
  auto* cacheNode = new DumpCacheNode;
  cacheNode->data.reset(bufptr);
  cacheNode->kind = FastDebugDumper::CDK_EPTGNODE;
  cacheNode->isAlive = true;
  eptgNodeCache[node] = cacheNode;
  return cacheNode;
}

void FastDebugDumper::valueModified(llvm::Value* value)
{
  FastDebugDumper* inst = instance();
  auto iter = inst->valueCache.find(value);
  if (iter != inst->valueCache.end()) {
    iter->second->isAlive = false;
    inst->valueCache.erase(iter);
  }
}

void FastDebugDumper::valueReplaced(llvm::Value* value)
{
  valueModified(value);
  for (auto& u : value->uses()) {
    valueModified(u.getUser());
  }
}
