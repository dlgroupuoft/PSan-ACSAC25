#include "llvm/IR/Instructions.h"
#include "llvm/IR/Constants.h"
#include "MetadataScheme.h"
#include "psan.h"

using namespace PSan;
//using namespace SVF;
//using namespace SVF::SVFUtil;

// ================================================================================
// MetadataSchemeBase
// ================================================================================

MetadataSchemeBase::MetadataSchemeBase(llvm::LLVMContext& ctx, const PSan::InstrumentationOptions& options, std::size_t mdsize, std::size_t mdalign, llvm::Module* dstModule)
  : ctx(ctx), options(options), mdsize(mdsize), mdsize_p2(getP2Size(mdsize)), mdalign(mdalign), dstModule(dstModule)
{
  if (mdsize == 0) {
    psan_unreachable("mdsize must be non-zero");
  }
}

llvm::SmallVector<llvm::Value*> MetadataSchemeBase::getMetadataAddressForMDLoadVector(llvm::Value* addr, unsigned numElements, llvm::Instruction* insertBefore)
{
  llvm::SmallVector<llvm::Value*> mdaddrs;
  if (numElements < 2) {
    if (numElements == 1) {
      mdaddrs.push_back(getMetadataAddressForMDLoad(addr, insertBefore));
    }
  } else {
    llvm::PointerType* i8PtrTy = llvm::Type::getInt8PtrTy(ctx);
    llvm::IntegerType* i8Ty = llvm::Type::getInt8Ty(ctx);
    llvm::IntegerType* i64Ty = llvm::Type::getInt64Ty(ctx);
    llvm::Value* castedAddr = new llvm::BitCastInst(addr, i8PtrTy, "", insertBefore);
    const auto& layout = dstModule->getDataLayout();
    auto ptrsize = layout.getPointerSize();
    for (unsigned i = 0; i < numElements; ++i) {
      llvm::Value* curAddr = castedAddr;
      if (i > 0) {
        llvm::ConstantInt* index = llvm::ConstantInt::get(i64Ty, i*ptrsize);
        llvm::GetElementPtrInst* gep = llvm::GetElementPtrInst::CreateInBounds(i8Ty, castedAddr, {index}, "", insertBefore);
        curAddr = gep;
      }
      mdaddrs.push_back(getMetadataAddressForMDLoad(curAddr, insertBefore));
    }
  }
  return mdaddrs;

}
llvm::SmallVector<llvm::Value*> MetadataSchemeBase::getMetadataAddressForMDStoreVector(llvm::Value* addr, unsigned numElements, llvm::Instruction* insertBefore)
{
  llvm::SmallVector<llvm::Value*> mdaddrs;
  if (numElements < 2) {
    if (numElements == 1) {
      mdaddrs.push_back(getMetadataAddressForMDStore(addr, insertBefore));
    }
  } else {
    llvm::PointerType* i8PtrTy = llvm::Type::getInt8PtrTy(ctx);
    llvm::IntegerType* i8Ty = llvm::Type::getInt8Ty(ctx);
    llvm::IntegerType* i64Ty = llvm::Type::getInt64Ty(ctx);
    llvm::Value* castedAddr = new llvm::BitCastInst(addr, i8PtrTy, "", insertBefore);
    const auto& layout = dstModule->getDataLayout();
    auto ptrsize = layout.getPointerSize();
    for (unsigned i = 0; i < numElements; ++i) {
      llvm::Value* curAddr = castedAddr;
      if (i > 0) {
        llvm::ConstantInt* index = llvm::ConstantInt::get(i64Ty, i*ptrsize);
        llvm::GetElementPtrInst* gep = llvm::GetElementPtrInst::CreateInBounds(i8Ty, castedAddr, {index}, "", insertBefore);
        curAddr = gep;
      }
      mdaddrs.push_back(getMetadataAddressForMDStore(curAddr, insertBefore));
    }
  }
  return mdaddrs;
}
void MetadataSchemeBase::releaseMetadataAddressForMDLoadVector(llvm::Value* addr, llvm::SmallVector<llvm::Value*>& mdaddrs, llvm::Instruction* insertBefore)
{
  for (auto mdaddr : mdaddrs) {
    releaseMetadataAddressForMDLoad(addr, mdaddr, insertBefore);
  }
}
void MetadataSchemeBase::releaseMetadataAddressForMDStoreVector(llvm::Value* addr, llvm::SmallVector<llvm::Value*>& mdaddrs, llvm::Instruction* insertBefore)
{
  for (auto mdaddr : mdaddrs) {
    releaseMetadataAddressForMDStore(addr, mdaddr, insertBefore);
  }
}

void MetadataSchemeBase::populateGlobalMetadataInit(llvm::Function* gvmdinit, const llvm::SmallVector<std::tuple<llvm::Constant*, llvm::Constant*, llvm::GlobalVariable*>>& info, bool isSkipZeroInit)
{
  if (!gvmdinit->getBasicBlockList().empty()) {
    psan_unreachable("gvmdinit should not have body before populateGlobalMetadataInit()");
  }
  llvm::BasicBlock* entryBB = llvm::BasicBlock::Create(ctx, "entry", gvmdinit);
  llvm::IRBuilder<> builder(entryBB);
  llvm::MaybeAlign mdsizeAlign = llvm::Align(mdalign);
  llvm::IntegerType* i8Ty = llvm::Type::getInt8Ty(ctx);
  llvm::IntegerType* i64Ty = llvm::Type::getInt64Ty(ctx);
  llvm::ReturnInst* ret = builder.CreateRetVoid();
  builder.SetInsertPoint(ret);
  for (const auto& t : info) {
    llvm::Constant* addr = std::get<0>(t);
    llvm::Constant* mdinit = std::get<1>(t);
    llvm::GlobalVariable* mdinitGV = std::get<2>(t);
    if (isSkipZeroInit && mdinit->isNullValue()) {
      continue;
    }
    llvm::Value* mdaddr = getMetadataAddressForMDStore(addr, ret);
    if (mdinit->isNullValue()) {
      builder.CreateMemSet(mdaddr, llvm::ConstantInt::get(i8Ty, 0), mdsize, mdsizeAlign);
    } else {
      builder.CreateMemCpy(mdaddr, mdsizeAlign, mdinitGV, mdinitGV->getAlign(), llvm::ConstantInt::get(i64Ty, mdsize));
    }
  }
}

// ================================================================================
// TwoLevelTrieMetadataScheme
// ================================================================================

TwoLevelTrieMetadataScheme::TwoLevelTrieMetadataScheme(llvm::LLVMContext& ctx, const PSan::InstrumentationOptions& options, std::size_t mdsize, std::size_t mdalign, llvm::Module* dstModule)
: MetadataSchemeBase(ctx, options, mdsize, mdalign, dstModule)
{
  i8PtrTy = llvm::Type::getInt8PtrTy(ctx);
  i64Ty = llvm::Type::getInt64Ty(ctx);
  llvm::Type* voidTy = llvm::Type::getVoidTy(ctx);

  llvm::FunctionType* getmdaddrTy = llvm::FunctionType::get(i8PtrTy, {i8PtrTy}, false);
  func_getmdaddr = llvm::Function::Create(getmdaddrTy, llvm::GlobalValue::ExternalLinkage, "__psan_get_md_addr", dstModule);
  func_getmdaddr->addRetAttr(llvm::Attribute::getWithDereferenceableBytes(ctx, mdsize));

  llvm::FunctionType* mdmemsetFuncTy = llvm::FunctionType::get(voidTy, {i8PtrTy, i64Ty}, false);
  llvm::FunctionType* mdmemcpyFuncTy = llvm::FunctionType::get(voidTy, {i8PtrTy, i8PtrTy, i64Ty}, false);
  llvm::FunctionType* mdmemmoveFuncTy = mdmemcpyFuncTy;
  func_mdmemset = llvm::Function::Create(mdmemsetFuncTy, llvm::GlobalValue::ExternalLinkage, "__psan_md_memset", dstModule);
  func_mdmemcpy = llvm::Function::Create(mdmemcpyFuncTy, llvm::GlobalValue::ExternalLinkage, "__psan_md_memcpy", dstModule);
  func_mdmemmove = llvm::Function::Create(mdmemmoveFuncTy, llvm::GlobalValue::ExternalLinkage, "__psan_md_memmove", dstModule);

  llvm::FunctionType* gvmdinitTy = llvm::FunctionType::get(voidTy, {}, false);
  func_gvmdinit = llvm::Function::Create(gvmdinitTy, llvm::GlobalValue::ExternalLinkage, "__psan_md_init_gv_metadata", dstModule);

  llvm::FunctionType* mdreallocFuncTy = llvm::FunctionType::get(voidTy, {i8PtrTy, i8PtrTy, i64Ty, i64Ty}, false);
  func_mdrealloc = llvm::Function::Create(mdreallocFuncTy, llvm::GlobalValue::ExternalLinkage, "__psan_md_realloc", dstModule);
  llvm::FunctionType* reallocGetOldSizeFuncTy = llvm::FunctionType::get(i64Ty, {i8PtrTy}, false);
  func_realloc_get_old_size = llvm::Function::Create(reallocGetOldSizeFuncTy, llvm::GlobalValue::ExternalLinkage, "__psan_realloc_get_old_size", dstModule);
}

void TwoLevelTrieMetadataScheme::finalize()
{
  linkInLibrary(dstModule, PSAN_RTPATH_RT_TwoLevelTrieMetadataScheme);

  auto writeConstIntGV = [this](const char* name, std::uint64_t value) {
    llvm::GlobalVariable* gv = dstModule->getGlobalVariable(name);
    if (!gv) {
      psan_unreachable("missing global variable from runtime library");
    }
    llvm::IntegerType* intTy = llvm::cast<llvm::IntegerType>(gv->getValueType());
    llvm::ConstantInt* constInt = llvm::ConstantInt::get(intTy, value);
    gv->setInitializer(constInt);
  };

  writeConstIntGV("__psan_md_size_p2", mdsize_p2);
  writeConstIntGV("__psan_md_size", mdsize);
}

void TwoLevelTrieMetadataScheme::handleGlobalMetadataInit(const llvm::SmallVector<std::tuple<llvm::Constant*, llvm::Constant*, llvm::GlobalVariable*>>& info)
{
  llvm::Function* gvmdinit = func_gvmdinit;
  populateGlobalMetadataInit(gvmdinit, info, true);
}

void TwoLevelTrieMetadataScheme::setMetadataMemoryInitializer(llvm::Constant* initializer)
{
  psan_unreachable("TODO");
}

llvm::Value* TwoLevelTrieMetadataScheme::getMetadataAddressForMDLoad(llvm::Value* addr, llvm::Instruction* insertBefore)
{
  return call_getmdaddr(addr, insertBefore);
}

llvm::Value* TwoLevelTrieMetadataScheme::getMetadataAddressForMDStore(llvm::Value* addr, llvm::Instruction* insertBefore)
{
  return call_getmdaddr(addr, insertBefore);
}

llvm::Value* TwoLevelTrieMetadataScheme::call_getmdaddr(llvm::Value* addr, llvm::Instruction* insertBefore)
{
  llvm::Value* convertedAddr = addr;
  if (addr->getType() != i8PtrTy) {
    convertedAddr = new llvm::BitCastInst(addr, i8PtrTy, "", insertBefore);
  }
  llvm::CallInst* call = llvm::CallInst::Create(func_getmdaddr, {convertedAddr}, "", insertBefore);
  handleDebugLoc(call, insertBefore);
  return call;
}

void TwoLevelTrieMetadataScheme::call_mdmemset(llvm::Value* addr, llvm::Value* len, llvm::Instruction* insertBefore)
{
  llvm::Value* convertedAddr = addr;
  if (addr->getType() != i8PtrTy) {
    convertedAddr = new llvm::BitCastInst(addr, i8PtrTy, "", insertBefore);
  }
  llvm::Value* convertedLen = len;
  if (len->getType() != i64Ty) {
    convertedLen = new llvm::ZExtInst(len, i64Ty, "", insertBefore);
  }
  llvm::CallInst* call = llvm::CallInst::Create(func_mdmemset, {convertedAddr, convertedLen}, "", insertBefore);
  handleDebugLoc(call, insertBefore);
}

void TwoLevelTrieMetadataScheme::call_mdmemcpymove(llvm::Value* dst, llvm::Value* src, llvm::Value* len, llvm::Instruction* insertBefore, llvm::Function* func)
{
  llvm::Value* convertedDst = dst;
  if (dst->getType() != i8PtrTy) {
    convertedDst = new llvm::BitCastInst(dst, i8PtrTy, "", insertBefore);
  }
  llvm::Value* convertedSrc = src;
  if (src->getType() != i8PtrTy) {
    convertedSrc = new llvm::BitCastInst(src, i8PtrTy, "", insertBefore);
  }
  llvm::Value* convertedLen = len;
  if (len->getType() != i64Ty) {
    convertedLen = new llvm::ZExtInst(len, i64Ty, "", insertBefore);
  }
  llvm::CallInst* call = llvm::CallInst::Create(func, {convertedDst, convertedSrc, convertedLen}, "", insertBefore);
  handleDebugLoc(call, insertBefore);
}

void TwoLevelTrieMetadataScheme::mdmemset(llvm::Value* addr, llvm::Value* len, llvm::Instruction* insertBefore)
{
  call_mdmemset(addr, len, insertBefore);
}

void TwoLevelTrieMetadataScheme::mdmemcpy(llvm::Value* dst, llvm::Value* src, llvm::Value* len, llvm::Instruction* insertBefore)
{
  call_mdmemcpymove(dst, src, len, insertBefore, func_mdmemcpy);
}

void TwoLevelTrieMetadataScheme::mdmemmove(llvm::Value* dst, llvm::Value* src, llvm::Value* len, llvm::Instruction* insertBefore)
{
  call_mdmemcpymove(dst, src, len, insertBefore, func_mdmemmove);
}

void TwoLevelTrieMetadataScheme::mdrealloc(llvm::CallBase* reallocCall)
{
  llvm::Value* oldPtr = reallocCall->getArgOperand(0);
  if (!oldPtr->getType()->isPointerTy()) {
    psan_unreachable("realloc() first argument should be a pointer (ptr)");
  }
  llvm::Value* newSize = reallocCall->getArgOperand(1);
  if (!newSize->getType()->isIntegerTy()) {
    psan_unreachable("realloc() second argument should be an integer (new_size)");
  }
  if (oldPtr->getType() != i8PtrTy) {
    oldPtr = new llvm::BitCastInst(oldPtr, i8PtrTy, "", reallocCall);
  }
  llvm::CallInst* oldSize = llvm::CallInst::Create(func_realloc_get_old_size, {oldPtr}, "", reallocCall);
  handleDebugLoc(oldSize, reallocCall);
  llvm::Instruction* insertPoint = reallocCall->getNextNonDebugInstruction();
  llvm::Value* newPtr = reallocCall;
  if (newPtr->getType() != i8PtrTy) {
    newPtr = new llvm::BitCastInst(newPtr, i8PtrTy, "", insertPoint);
  }
  if (newSize->getType() != i64Ty) {
    newSize = new llvm::ZExtInst(newSize, i64Ty, "", insertPoint);
  }
  // void* dst, void* src, uint64_t dstSize, uint64_t srcSize
  llvm::CallInst* call = llvm::CallInst::Create(func_mdrealloc, {newPtr, oldPtr, newSize, oldSize}, "", insertPoint);
  handleDebugLoc(call, insertPoint);
}
