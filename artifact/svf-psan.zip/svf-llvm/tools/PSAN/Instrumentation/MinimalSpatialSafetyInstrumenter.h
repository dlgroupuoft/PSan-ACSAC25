#ifndef PSAN_INSTRUMENTATION_MINIMALSPATIALSAFETYINSTRUMENTER_H
#define PSAN_INSTRUMENTATION_MINIMALSPATIALSAFETYINSTRUMENTER_H

#include "instrumentation.h"

namespace PSan {
class MinimalSpatialSafetyInstrumenter : public InstrumentationBase {
public:
  MinimalSpatialSafetyInstrumenter(llvm::LLVMContext& ctx, llvm::Module& M);
  virtual ~MinimalSpatialSafetyInstrumenter() = default;
  virtual void analysis() override;
  virtual llvm::SmallVector<llvm::Type*> createPointerMetadataTypes() const override;
  virtual llvm::SmallVector<llvm::Value*> createNullPointerMetadata() const override;
  virtual void instrumentMetadataInit(llvm::AllocaInst* alloc, llvm::SmallVectorImpl<llvm::Value*>& md) override;
  virtual void instrumentMetadataInit(llvm::GlobalVariable* gv, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md) override;
  virtual void instrumentMetadataInit(llvm::ConstantExpr* gvconstexpr, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md) override;
  virtual void instrumentMetadataInit(llvm::CallBase* call, llvm::SmallVectorImpl<llvm::Value*>& md) override;
  virtual void instrumentCheck(llvm::Instruction* insertBefore, llvm::Value* ptr, const llvm::SmallVectorImpl<llvm::Use*>& uselist, llvm::SmallVectorImpl<llvm::Value*>& md, std::size_t checkID, std::size_t internalID) override;
  virtual void instrumentCheck_Debug(llvm::Instruction* insertBefore, llvm::Value* ptr, llvm::SmallVectorImpl<llvm::Value*>& md, std::size_t checkID) override;

  virtual void instrumentMetadataInit_ByValArgument(llvm::Argument* arg, llvm::Type* byvalType, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md) override;

  virtual llvm::Constant* getMetadataInitializerForConstant(llvm::Constant* c) override;

  virtual void populateHelperFunctionsThatMayAbort(llvm::SmallVectorImpl<std::string>& functions) override;
  virtual void prepareInstrumentation(const PSan::InstrumentationOptions& options, llvm::Module* dstModule) override;
  virtual void finalize(llvm::Module* dstModule) override;

  static bool isEnabled();
private:
  void instrumentMetadataInitCommon(llvm::Value* alloc, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md);
  std::tuple<llvm::Constant*, std::int64_t, std::int64_t> getConstantBounds(llvm::Constant* addr);
  std::pair<llvm::Constant*, llvm::Constant*> convertConstantBounds(const std::tuple<llvm::Constant*, std::int64_t, std::int64_t>& bounds);
  void analyzeFunction(llvm::Function* func);
  llvm::Value* getRootPointerWithAccessSizeRange(llvm::Value* ptr, std::pair<int64_t, int64_t>& shiftedAccessSizeRange);
  uint64_t getStaticallySafeSizeFromDynamicAllocation(llvm::CallBase* call);

  llvm::PointerType* i8PtrTy = nullptr;
  llvm::IntegerType* i64Ty = nullptr;
  llvm::Function* checkFunc = nullptr;
};
} // end namespace PSan

#endif // PSAN_INSTRUMENTATION_MINIMALSPATIALSAFETYINSTRUMENTER_H
