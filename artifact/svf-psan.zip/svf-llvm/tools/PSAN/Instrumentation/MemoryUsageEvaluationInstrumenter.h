#ifndef PSAN_INSTRUMENTATION_MEMORYUSAGEEVALUATIONINSTRUMENTER_H
#define PSAN_INSTRUMENTATION_MEMORYUSAGEEVALUATIONINSTRUMENTER_H

#include "instrumentation.h"

namespace PSan {

class MemoryUsageEvaluationInstrumenter : public InstrumentationBase {
  // this is not a real safety check; it is used to evaluate PSAN
  // we use this to adjust the metadata size per pointer for experiments
public:
  MemoryUsageEvaluationInstrumenter(llvm::LLVMContext& ctx, llvm::Module& M);
  virtual ~MemoryUsageEvaluationInstrumenter() = default;
  virtual void analysis() override;
  virtual llvm::SmallVector<llvm::Type*> createPointerMetadataTypes() const override;
  virtual llvm::SmallVector<llvm::Value*> createNullPointerMetadata() const override;
  virtual void instrumentMetadataInit(llvm::AllocaInst* alloc, llvm::SmallVectorImpl<llvm::Value*>& md) override;
  virtual void instrumentMetadataInit(llvm::GlobalVariable* gv, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md) override;
  virtual void instrumentMetadataInit(llvm::ConstantExpr* gvconstexpr, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md) override;
  virtual void instrumentMetadataInit(llvm::CallBase* call, llvm::SmallVectorImpl<llvm::Value*>& md) override;
  virtual void instrumentCheck(llvm::Instruction* insertBefore, llvm::Value* ptr, const llvm::SmallVectorImpl<llvm::Use*>& uselist, llvm::SmallVectorImpl<llvm::Value*>& md, std::size_t checkID, std::size_t internalID) override;

  virtual void instrumentMetadataInit_ByValArgument(llvm::Argument* arg, llvm::Type* byvalType, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md) override;

  virtual void prepareInstrumentation(const PSan::InstrumentationOptions& options, llvm::Module* dstModule) override;
  virtual void finalize(llvm::Module* dstModule) override;

  virtual void emitMetadataLoad(llvm::Instruction* insertBefore, llvm::Value* mdaddr, llvm::SmallVectorImpl<llvm::Value*>& md) override;
  virtual void emitMetadataStore(llvm::Instruction* insertBefore, llvm::Value* mdaddr, llvm::SmallVectorImpl<llvm::Value*>& md) override;

  static bool isEnabled();
protected:
  virtual llvm::Type* createMetadataStructType() override;
private:
  llvm::IntegerType* i64Ty = nullptr;
  llvm::IntegerType* i8Ty = nullptr;
  llvm::PointerType* i8PtrTy = nullptr;
  llvm::ConstantInt* i64zero = nullptr;
  llvm::Function* checkFunc = nullptr;
};

} // end namespace PSan

#endif // PSAN_INSTRUMENTATION_MEMORYUSAGEEVALUATIONINSTRUMENTER_H
