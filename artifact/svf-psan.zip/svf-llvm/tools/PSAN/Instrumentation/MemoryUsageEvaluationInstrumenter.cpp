#include "MemoryUsageEvaluationInstrumenter.h"
#include "psan.h"
#include <llvm/IR/Constants.h>
#include <llvm/IR/Instructions.h>
#include <llvm/IR/Operator.h>
#include <llvm/Support/CommandLine.h>

using namespace PSan;
using namespace SVF;
using namespace SVF::SVFUtil;

// ================================================================================
// MemoryUsageEvaluationInstrumenter
//
// The in-memory representation is an array with the specified size
// The in-register representation is a single i64 value
// When we do a load/store, we load/store one i64 value at a time,
// OR then together in load, duplicate them in store, and then
// zero extend / truncate as necessary
// assuming value = 0xdeadbeef (using a 32 bit value for readability),
// we store it as: (assuming little endian)
//  ef be ad de ef be ad de ...
// and if the memory looks like
//  04 03 02 01 08 07 06 05 ...
// then we load it as 0x01020304 | 0x05060708
// When we do check, we just check that it is not all one (0xffff...)
// The value content really does not matter;
// we currently set it to be a "summary" describing the pointer
// ================================================================================

static llvm::cl::opt<unsigned> MemoryUsageEvaluationMDSizeOption(
  "psan-memeval-md-size",
  llvm::cl::init(0u),
  llvm::cl::callback([](const unsigned& size) {
    if (size > 8) {
      if (size % 8 != 0) {
        PSan::errs() << "-psan-memeval-md-size: size must be a multiple of 8 if > 8\n";
        std::exit(1);
      }
    } else if (size > 0) {
      switch (size)
      {
      default:
        PSan::errs() << "-psan-memeval-md-size: unsupported size\n";
        std::exit(1);
      // these sizes are supported
      case 1:
      case 2:
      case 4:
      case 8: break;
      }
    }
  }),
  llvm::cl::desc("Metadata size (in bytes) per pointer for memory usage evaluation. Scheme enabled if > 0.")
);

bool MemoryUsageEvaluationInstrumenter::isEnabled()
{
  return MemoryUsageEvaluationMDSizeOption > 0;
}

llvm::Type* MemoryUsageEvaluationInstrumenter::createMetadataStructType()
{
  return llvm::ArrayType::get(llvm::Type::getInt8Ty(ctx), MemoryUsageEvaluationMDSizeOption);
}

MemoryUsageEvaluationInstrumenter::MemoryUsageEvaluationInstrumenter(llvm::LLVMContext& ctx, llvm::Module& M)
  : InstrumentationBase(ctx, M)
{
  i64Ty = llvm::Type::getInt64Ty(ctx);
  i8Ty = llvm::Type::getInt8Ty(ctx);
  i8PtrTy = llvm::Type::getInt8PtrTy(ctx);
  i64zero = llvm::ConstantInt::get(i64Ty, 0);
}

llvm::SmallVector<llvm::Type*> MemoryUsageEvaluationInstrumenter::createPointerMetadataTypes() const
{
  llvm::SmallVector<llvm::Type*> result;
  result.push_back(i64Ty);
  return result;
}

llvm::SmallVector<llvm::Value*> MemoryUsageEvaluationInstrumenter::createNullPointerMetadata() const
{
  llvm::SmallVector<llvm::Value*> result;
  result.push_back(i64zero);
  return result;
}

void MemoryUsageEvaluationInstrumenter::emitMetadataLoad(llvm::Instruction* insertBefore, llvm::Value* mdaddr, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  llvm::Type* mdTy = getPointerMetadataTypeInMemory();
  if (!mdTy) {
    psan_unreachable("metadata type not set");
  }
  if (getPointerElementType(mdaddr->getType()) != mdTy) {
    psan_unreachable("metadata address type mismatch");
  }
  llvm::ArrayType* arrayTy = llvm::cast<llvm::ArrayType>(mdTy);
  llvm::IRBuilder<> builder(insertBefore);
  llvm::Value* result = nullptr;
  switch (arrayTy->getNumElements())
  {
  default: {// should be power of 8
    unsigned numloads = arrayTy->getNumElements() / 8;
    llvm::Value* castedAddr = builder.CreatePointerCast(mdaddr, llvm::PointerType::get(i64Ty, 0));
    for (unsigned i = 0; i < numloads; ++i) {
      llvm::Value* index = builder.getInt64(i);
      llvm::Value* curAddr = builder.CreateGEP(i64Ty, castedAddr, {index});
      llvm::Value* curValue = builder.CreateLoad(i64Ty, curAddr);
      if (i == 0) {
        result = curValue;
      } else {
        result = builder.CreateOr(result, curValue);
      }
    }
  } break;
  case 1: {
    llvm::Value* i32zero = builder.getInt32(0);
    llvm::Value* addr = builder.CreateGEP(arrayTy, mdaddr, {i64zero, i32zero});
    llvm::Value* curValue = builder.CreateLoad(i8Ty, addr);
    result = builder.CreateZExt(curValue, i64Ty);
  } break;
  case 2: {
    llvm::IntegerType* i16Ty = llvm::Type::getInt16Ty(ctx);
    llvm::Value* addr = builder.CreatePointerCast(mdaddr, llvm::PointerType::get(i16Ty, 0));
    llvm::Value* curValue = builder.CreateLoad(i16Ty, addr);
    result = builder.CreateZExt(curValue, i64Ty);
  } break;
  case 4: {
    llvm::IntegerType* i32Ty = llvm::Type::getInt32Ty(ctx);
    llvm::Value* addr = builder.CreatePointerCast(mdaddr, llvm::PointerType::get(i32Ty, 0));
    llvm::Value* curValue = builder.CreateLoad(i32Ty, addr);
    result = builder.CreateZExt(curValue, i64Ty);
  } break;
  }
  md.clear();
  md.push_back(result);
}
void MemoryUsageEvaluationInstrumenter::emitMetadataStore(llvm::Instruction* insertBefore, llvm::Value* mdaddr, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  llvm::Type* mdTy = getPointerMetadataTypeInMemory();
  if (!mdTy) {
    psan_unreachable("metadata type not set");
  }
  if (getPointerElementType(mdaddr->getType()) != mdTy) {
    psan_unreachable("metadata address type mismatch");
  }
  llvm::ArrayType* arrayTy = llvm::cast<llvm::ArrayType>(mdTy);
  llvm::IRBuilder<> builder(insertBefore);
  llvm::Value* value = md.front();
  switch (arrayTy->getNumElements())
  {
  default: {// should be power of 8
    unsigned numstores = arrayTy->getNumElements() / 8;
    llvm::Value* castedAddr = builder.CreatePointerCast(mdaddr, llvm::PointerType::get(i64Ty, 0));
    for (unsigned i = 0; i < numstores; ++i) {
      llvm::Value* index = builder.getInt64(i);
      llvm::Value* curAddr = builder.CreateGEP(i64Ty, castedAddr, {index});
      builder.CreateStore(value, curAddr);
    }
  } break;
  case 1: {
    llvm::Value* i32zero = builder.getInt32(0);
    llvm::Value* addr = builder.CreateGEP(arrayTy, mdaddr, {i64zero, i32zero});
    llvm::Value* curValue = builder.CreateTrunc(value, i8Ty);
    builder.CreateStore(curValue, addr);
  } break;
  case 2: {
    llvm::IntegerType* i16Ty = llvm::Type::getInt16Ty(ctx);
    llvm::Value* addr = builder.CreatePointerCast(mdaddr, llvm::PointerType::get(i16Ty, 0));
    llvm::Value* curValue = builder.CreateTrunc(value, i16Ty);
    builder.CreateStore(curValue, addr);
  } break;
  case 4: {
    llvm::IntegerType* i32Ty = llvm::Type::getInt32Ty(ctx);
    llvm::Value* addr = builder.CreatePointerCast(mdaddr, llvm::PointerType::get(i32Ty, 0));
    llvm::Value* curValue = builder.CreateTrunc(value, i32Ty);
    builder.CreateStore(curValue, addr);
  } break;
  }
}

void MemoryUsageEvaluationInstrumenter::analysis()
{
  // go through all code and instrument every load/store
  // same as the minimal memory safety instrumenter
  for (llvm::Function& F : M) {
    if (F.isDeclaration())
      continue;
    for (llvm::BasicBlock& BB : F) {
      for (llvm::Instruction& I : BB) {
        std::uint64_t fixedAccessSize = 0;
        llvm::Value* variableAccessSize = nullptr;
        llvm::SmallVector<llvm::Use*> ptrArgs;
        if (hasMemoryAccess(&I, fixedAccessSize, variableAccessSize, ptrArgs)) {
          for (llvm::Use* ptrArg : ptrArgs) {
            addCheckRequestMark(*ptrArg);
          }
        }
      }
    }
  }
}

void MemoryUsageEvaluationInstrumenter::prepareInstrumentation(const PSan::InstrumentationOptions& options, llvm::Module* dstModule)
{
  InstrumentationBase::prepareInstrumentation(options, dstModule);
  // build the checking function
  llvm::FunctionType* checkFuncTy = llvm::FunctionType::get(llvm::Type::getVoidTy(ctx), {i8PtrTy, i64Ty, i64Ty}, false);
  checkFunc = llvm::Function::Create(checkFuncTy, llvm::GlobalValue::ExternalLinkage, "__psan_mue_check", dstModule);
}

void MemoryUsageEvaluationInstrumenter::instrumentCheck(llvm::Instruction* insertBefore, llvm::Value* ptr, const llvm::SmallVectorImpl<llvm::Use*>& uselist, llvm::SmallVectorImpl<llvm::Value*>& md, std::size_t checkID, std::size_t internalID)
{
  (void) internalID;
  if (md.size() != 1) {
    psan_unreachable("metadata size mismatch");
  }
  llvm::Value* ptrArg = ptr;
  if (ptrArg->getType() != i8PtrTy) {
    ptrArg = llvm::CastInst::CreatePointerCast(ptrArg, i8PtrTy, "", insertBefore);
  }
  llvm::Value* checkValue = md.front();
  llvm::Value* checkIDVal = llvm::ConstantInt::get(i64Ty, checkID);
  llvm::CallInst* call = llvm::CallInst::Create(checkFunc, {ptrArg, checkValue, checkIDVal}, "", insertBefore);
  handleDebugLoc(call, insertBefore);
}

void MemoryUsageEvaluationInstrumenter::finalize(llvm::Module* dstModule)
{
  linkInLibrary(dstModule, PSAN_RTPATH_RT_MemoryUsageEvaluationInstrumenter);
}

void MemoryUsageEvaluationInstrumenter::instrumentMetadataInit_ByValArgument(llvm::Argument* arg, llvm::Type* byvalType, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  (void) arg;
  (void) byvalType;
  (void) insertBefore;
  llvm::Value* value = llvm::ConstantInt::get(i64Ty, 1);
  md.push_back(value);
}

void MemoryUsageEvaluationInstrumenter::instrumentMetadataInit(llvm::AllocaInst* alloc, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  (void) alloc;
  llvm::Value* value = llvm::ConstantInt::get(i64Ty, 2);
  md.push_back(value);
}

void MemoryUsageEvaluationInstrumenter::instrumentMetadataInit(llvm::GlobalVariable* gv, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  (void) gv;
  (void) insertBefore;
  llvm::Value* value = llvm::ConstantInt::get(i64Ty, 3);
  md.push_back(value);
}

void MemoryUsageEvaluationInstrumenter::instrumentMetadataInit(llvm::ConstantExpr* gvconstexpr, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  (void) gvconstexpr;
  (void) insertBefore;
  llvm::Value* value = llvm::ConstantInt::get(i64Ty, 4);
  md.push_back(value);
}

void MemoryUsageEvaluationInstrumenter::instrumentMetadataInit(llvm::CallBase* call, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  (void) call;
  llvm::Value* value = llvm::ConstantInt::get(i64Ty, 5);
  md.push_back(value);
}
