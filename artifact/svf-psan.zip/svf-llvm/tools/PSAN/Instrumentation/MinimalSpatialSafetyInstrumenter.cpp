
#include "MinimalSpatialSafetyInstrumenter.h"
#include "psan.h"
#include <llvm/IR/Constants.h>
#include <llvm/IR/Instructions.h>
#include <llvm/IR/Operator.h>
#include <llvm/Support/CommandLine.h>

using namespace PSan;
using namespace SVF;
using namespace SVF::SVFUtil;

// ================================================================================
// MinimalSpatialSafetyInstrumenter
// ================================================================================

static llvm::cl::opt<bool> EnableMSSOption(
  "psan-mss",
  llvm::cl::init(true),
  llvm::cl::desc("Enable mimimal spatial safety instrumentation")
);

bool MinimalSpatialSafetyInstrumenter::isEnabled()
{
  return EnableMSSOption;
}

MinimalSpatialSafetyInstrumenter::MinimalSpatialSafetyInstrumenter(llvm::LLVMContext& ctx, llvm::Module& M)
  : InstrumentationBase(ctx, M)
{
  i8PtrTy = llvm::Type::getInt8PtrTy(ctx);
  i64Ty = llvm::Type::getInt64Ty(ctx);
}

llvm::SmallVector<llvm::Type*> MinimalSpatialSafetyInstrumenter::createPointerMetadataTypes() const
{
  return llvm::SmallVector<llvm::Type*>{i8PtrTy, i8PtrTy};
}

llvm::SmallVector<llvm::Value*> MinimalSpatialSafetyInstrumenter::createNullPointerMetadata() const
{
  llvm::Constant* nullPtr = llvm::ConstantPointerNull::get(i8PtrTy);
  return llvm::SmallVector<llvm::Value*>{nullPtr, nullPtr};
}

void MinimalSpatialSafetyInstrumenter::prepareInstrumentation(const PSan::InstrumentationOptions& options, llvm::Module* dstModule)
{
  InstrumentationBase::prepareInstrumentation(options, dstModule);
  // build the checking function
  llvm::FunctionType* checkFuncTy = llvm::FunctionType::get(llvm::Type::getVoidTy(ctx), {i8PtrTy, i8PtrTy, i8PtrTy, i64Ty, i64Ty}, false);
  checkFunc = llvm::Function::Create(checkFuncTy, llvm::GlobalValue::ExternalLinkage, "__psan_mss_check", dstModule);
}

void MinimalSpatialSafetyInstrumenter::populateHelperFunctionsThatMayAbort(llvm::SmallVectorImpl<std::string>& functions)
{
  functions.push_back(checkFunc->getName().str());
}

void MinimalSpatialSafetyInstrumenter::finalize(llvm::Module* dstModule)
{
  linkInLibrary(dstModule, PSAN_RTPATH_RT_MinimalSpatialSafetyInstrumenter);
}

void MinimalSpatialSafetyInstrumenter::instrumentMetadataInitCommon(llvm::Value* alloc, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  llvm::Value* sizeArg = getAllocationSizeInBytes(alloc, insertBefore);
  llvm::Value* lb = alloc;
  if (alloc->getType() != i8PtrTy) {
    lb = llvm::CastInst::CreatePointerCast(alloc, i8PtrTy, "", insertBefore);
  }
  llvm::Value* ub = llvm::GetElementPtrInst::Create(llvm::Type::getInt8Ty(ctx), lb, {sizeArg}, "", insertBefore);
  md.push_back(lb);
  md.push_back(ub);
}

void MinimalSpatialSafetyInstrumenter::instrumentMetadataInit(llvm::AllocaInst* alloc, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  llvm::Instruction* insertBefore = getInsertionPointAfter(alloc);
  instrumentMetadataInitCommon(alloc, insertBefore, md);
}

void MinimalSpatialSafetyInstrumenter::instrumentMetadataInit(llvm::GlobalVariable* gv, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  std::tuple<llvm::Constant*, std::int64_t, std::int64_t> boundsinfo = getConstantBounds(gv);
  std::pair<llvm::Constant*, llvm::Constant*> bounds = convertConstantBounds(boundsinfo);
  md.clear();
  md.push_back(bounds.first);
  md.push_back(bounds.second);
}

void MinimalSpatialSafetyInstrumenter::instrumentMetadataInit(llvm::ConstantExpr* gvconstexpr, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  std::tuple<llvm::Constant*, std::int64_t, std::int64_t> boundsinfo = getConstantBounds(gvconstexpr);
  if (std::get<0>(boundsinfo) == nullptr) {
    md = nullptrMetadata;
  } else {
    std::pair<llvm::Constant*, llvm::Constant*> bounds = convertConstantBounds(boundsinfo);
    md.clear();
    md.push_back(bounds.first);
    md.push_back(bounds.second);
  }
}

void MinimalSpatialSafetyInstrumenter::instrumentMetadataInit(llvm::CallBase* call, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  llvm::Instruction* insertBefore = getInsertionPointAfter(call);
  instrumentMetadataInitCommon(call, insertBefore, md);
}

void MinimalSpatialSafetyInstrumenter::instrumentMetadataInit_ByValArgument(llvm::Argument* arg, llvm::Type* byvalType, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  llvm::IntegerType* i64Ty = llvm::Type::getInt64Ty(ctx);
  auto size = M.getDataLayout().getTypeAllocSize(byvalType);
  llvm::Value* sizeArg = llvm::ConstantInt::get(i64Ty, size);
  llvm::Value* lb = arg;
  if (arg->getType() != i8PtrTy) {
    lb = llvm::CastInst::CreatePointerCast(arg, i8PtrTy, "", insertBefore);
  }
  llvm::Value* ub = llvm::GetElementPtrInst::Create(llvm::Type::getInt8Ty(ctx), lb, {sizeArg}, "", insertBefore);
  md.push_back(lb);
  md.push_back(ub);
}

std::tuple<llvm::Constant*, std::int64_t, std::int64_t> MinimalSpatialSafetyInstrumenter::getConstantBounds(llvm::Constant* addr)
{
  // returns a tuple of (base global variable, offset, size)
  if (llvm::GlobalVariable* gv = llvm::dyn_cast<llvm::GlobalVariable>(addr)) {
    auto size = M.getDataLayout().getTypeAllocSize(gv->getValueType());
    return std::make_tuple(gv, 0, size);
  }
  if (llvm::ConstantExpr* ce = llvm::dyn_cast<llvm::ConstantExpr>(addr)) {
    switch (ce->getOpcode())
    {
    default: psan_unreachable("unexpected constexpr opcode");
    case llvm::Instruction::BitCast:
      return getConstantBounds(ce->getOperand(0));
    case llvm::Instruction::IntToPtr:
      return std::make_tuple(nullptr, 0, 0);
    case llvm::Instruction::GetElementPtr: {
      auto baseResult = getConstantBounds(ce->getOperand(0));
      if (std::get<0>(baseResult) == nullptr) {
        return std::make_tuple(nullptr, 0, 0);
      }
      // now adjust the offset based on the GEP
      auto* gep = llvm::dyn_cast<llvm::GEPOperator>(ce);
      if (!gep) {
        return std::make_tuple(nullptr, 0, 0);
      }
      llvm::APInt offset(64, 0);
      if (!gep->accumulateConstantOffset(M.getDataLayout(), offset)) {
        return std::make_tuple(nullptr, 0, 0);
      }
      auto baseSize = std::get<2>(baseResult);
      return std::make_tuple(std::get<0>(baseResult), std::get<1>(baseResult) + offset.getSExtValue(), baseSize);
    } break;
    }
  }
  if (llvm::ConstantPointerNull* nullPtr = llvm::dyn_cast<llvm::ConstantPointerNull>(addr)) {
    (void) nullPtr;
    return std::make_tuple(nullptr, 0, 0);
  }
  if (llvm::isa<llvm::UndefValue>(addr)) {
    return std::make_tuple(nullptr, 0, 0);
  }
  if (llvm::isa<llvm::Function>(addr)) {
    return std::make_tuple(nullptr, 0, 0);
  }
  psan_unreachable("unhandled constant type");
}

std::pair<llvm::Constant*, llvm::Constant*> MinimalSpatialSafetyInstrumenter::convertConstantBounds(const std::tuple<llvm::Constant*, std::int64_t, std::int64_t>& bounds)
{
  // for object bounds, we only need the base address and the size
  llvm::Constant* baseGV = std::get<0>(bounds);
  if (baseGV == nullptr) {
    llvm::Constant* nullPtr = llvm::ConstantPointerNull::get(i8PtrTy);
    return std::make_pair(nullPtr, nullPtr);
  }
  llvm::Constant* lb = baseGV;
  if (baseGV->getType() != i8PtrTy) {
    lb = llvm::ConstantExpr::getPointerCast(baseGV, i8PtrTy);
  }
  llvm::Constant* ub = llvm::ConstantExpr::getGetElementPtr(llvm::Type::getInt8Ty(ctx), lb, llvm::ConstantInt::get(i64Ty, std::get<2>(bounds)), false);
  return std::make_pair(lb, ub);
}

llvm::Constant* MinimalSpatialSafetyInstrumenter::getMetadataInitializerForConstant(llvm::Constant* c)
{
  std::tuple<llvm::Constant*, std::int64_t, std::int64_t> boundsinfo = getConstantBounds(c);
  if (std::get<0>(boundsinfo) == nullptr) {
    return llvm::Constant::getNullValue(metadataStructTy);
  }
  std::pair<llvm::Constant*, llvm::Constant*> bounds = convertConstantBounds(boundsinfo);
  llvm::StructType* sTy = llvm::cast<llvm::StructType>(metadataStructTy);
  return llvm::ConstantStruct::get(sTy, {bounds.first, bounds.second});
}

void MinimalSpatialSafetyInstrumenter::instrumentCheck(llvm::Instruction* insertBefore, llvm::Value* ptr, const llvm::SmallVectorImpl<llvm::Use*>& uselist, llvm::SmallVectorImpl<llvm::Value*>& md, std::size_t checkID, std::size_t internalID)
{
  if (md.size() != 2) {
    psan_unreachable("metadata size mismatch");
  }
  llvm::Value* ptrArg = ptr;
  if (ptrArg->getType() != i8PtrTy) {
    ptrArg = llvm::CastInst::CreatePointerCast(ptrArg, i8PtrTy, "", insertBefore);
  }
  llvm::Value* size = nullptr;
  llvm::Instruction* checkInsertionPoint = insertBefore;
  if (internalID > 0) {
    // we directly use the internalID to store the access size (to simplify code)
    // this should be a coalesced check
    size = llvm::ConstantInt::get(i64Ty, internalID);
  } else {
    if (uselist.size() != 1) {
      psan_unreachable("coalesced checking for (possibly) non-const access size not implemented yet");
    }
    llvm::SmallVector<llvm::Use*> ptrArgs;
    llvm::Use& use = *uselist.front();
    llvm::Instruction* inst = llvm::cast<llvm::Instruction>(use.getUser());
    std::uint64_t fixedAccessSize = 0;
    llvm::Value* variableAccessSize = nullptr;
    if (hasMemoryAccess(inst, fixedAccessSize, variableAccessSize, ptrArgs)) {
      if (ptrArgs[0] != &use && (ptrArgs.size() < 2 || ptrArgs[1] != &use)) {
        psan_unreachable("ptrArgs mismatch");
      }
      if (variableAccessSize) {
        size = variableAccessSize;
        if (size->getType() != i64Ty) {
          size = llvm::CastInst::CreateIntegerCast(size, i64Ty, false, "", insertBefore);
        }
      } else {
        size = llvm::ConstantInt::get(i64Ty, fixedAccessSize);
      }
      if (llvm::Instruction* rawSize = llvm::dyn_cast_or_null<llvm::Instruction>(variableAccessSize)) {
        // in the current implementation, insertBefore may not match with the use site (may be 1-N instructions before)
        // if the access size is not a constant, it is possible that the check is placed before the instruction computing the access size
        // (e.g., because it is a memset that EPTG transformed the object layout)
        // in this case we override the check location and place it immediately before the user
        if (rawSize->getParent() == inst->getParent()) {
          checkInsertionPoint = inst;
        }
      }
    } else {
      psan_unreachable("checking non-memory access");
    }
  }
  llvm::Value* checkIDVal = llvm::ConstantInt::get(i64Ty, checkID);
  llvm::CallInst* call = llvm::CallInst::Create(checkFunc, {ptrArg, md[0], md[1], size, checkIDVal}, "", checkInsertionPoint);
  handleDebugLoc(call, checkInsertionPoint);
}

void MinimalSpatialSafetyInstrumenter::instrumentCheck_Debug(llvm::Instruction* insertBefore, llvm::Value* ptr, llvm::SmallVectorImpl<llvm::Value*>& md, std::size_t checkID)
{
  if (md.size() != 2) {
    psan_unreachable("metadata size mismatch");
  }
  llvm::Value* ptrArg = ptr;
  if (ptrArg->getType() != i8PtrTy) {
    ptrArg = llvm::CastInst::CreatePointerCast(ptrArg, i8PtrTy, "", insertBefore);
  }
  llvm::Value* size = llvm::ConstantInt::get(i64Ty, 0);
  llvm::Value* checkIDVal = llvm::ConstantInt::get(i64Ty, checkID);
  llvm::CallInst* call = llvm::CallInst::Create(checkFunc, {ptrArg, md[0], md[1], size, checkIDVal}, "", insertBefore);
  handleDebugLoc(call, insertBefore);
}

void MinimalSpatialSafetyInstrumenter::analysis()
{
  // for now, go through all code and instrument every load/store
  for (llvm::Function& F : M) {
    if (F.isDeclaration())
      continue;
    analyzeFunction(&F);
  }
}

void MinimalSpatialSafetyInstrumenter::analyzeFunction(llvm::Function* func)
{
  // we try to remove redundant checks (more than one check dominating one another and access size of the "first" check covers subsequent) in any cases
  // we only try to remove checks if the access size is constant (e.g., if we can prove that the pointer is from an allocation)

  // we visit basic blocks using the order of dominance so that we can optimize away redundant checks along the way
  llvm::DominatorTree DT(*func);
  SVF::FIFOWorkList<llvm::BasicBlock*> initialVisitWorkList;
  llvm::BasicBlock* entryBlock = &func->getEntryBlock();
  if (entryBlock != DT.getRootNode()->getBlock()) {
    psan_unreachable("DomTree root block mismatch with entry block");
  }
  initialVisitWorkList.push(entryBlock);

  struct BasicBlockState {
    // for non-constant sized checks, we always check on the directly-used pointer using the non-constant size
    // for constant sized checks, we check on the root pointer with the specified / enlarged access range
    llvm::DenseMap<llvm::Value*, llvm::DenseMap<llvm::Value*, llvm::Use*>> nonConstantSizedChecks;
    llvm::DenseMap<llvm::Value*, llvm::SmallVector<std::pair<std::pair<int64_t, int64_t>, llvm::Use*>>> constantSizedChecks;
  };

  std::map<llvm::BasicBlock*, BasicBlockState> blockStates;
  while (!initialVisitWorkList.empty()) {
    llvm::BasicBlock* bb = initialVisitWorkList.pop();
    auto* node = DT.getNode(bb);
    for (auto* childNode : node->children()) {
      initialVisitWorkList.push(childNode->getBlock());
    }
    BasicBlockState& curBlockState = blockStates[bb];
    for (llvm::Instruction& I : *bb) {
      std::uint64_t fixedAccessSize = 0;
      llvm::Value* variableAccessSize = nullptr;
      llvm::SmallVector<llvm::Use*> ptrArgs;
      if (hasMemoryAccess(&I, fixedAccessSize, variableAccessSize, ptrArgs)) {
        // which is the top-most block in dom tree that we should stop checking for redundant checks
        llvm::BasicBlock* redundantCheckTopBlock = entryBlock;
        if (llvm::Instruction* instrSize = llvm::dyn_cast_or_null<llvm::Instruction>(variableAccessSize)) {
          redundantCheckTopBlock = instrSize->getParent();
        }
        for (llvm::Use* ptrArg : ptrArgs) {
          llvm::Value* usedPtr = ptrArg->get();
          std::pair<int64_t, int64_t> accessRange(0, fixedAccessSize);
          llvm::Value* rootPtr = getRootPointerWithAccessSizeRange(usedPtr, accessRange);
          llvm::BasicBlock* curRedundantCheckTopBlock = redundantCheckTopBlock;
          if (llvm::Instruction* rootPtrInst = llvm::dyn_cast<llvm::Instruction>(rootPtr)) {
            llvm::BasicBlock* rootPtrBlock = rootPtrInst->getParent();
            if (!DT.dominates(curRedundantCheckTopBlock, rootPtrBlock)) {
              curRedundantCheckTopBlock = rootPtrBlock;
            }
          }
          // if this root pointer is pointing to a struct, we enlarge the access range to include the whole struct
          // in this way we can coalesce checks for struct accesses
          if (!variableAccessSize) {
            if (llvm::StructType* st = llvm::dyn_cast<llvm::StructType>(getPointerElementType(rootPtr->getType()))) {
              auto structSize = M.getDataLayout().getStructLayout(st)->getSizeInBytes();
              // if this access is outside the struct, we do not coalesce
              if (accessRange.first >= 0 && accessRange.second <= static_cast<int64_t>(structSize)) {
                accessRange.first = 0;
                accessRange.second = structSize;
              }
            }
          }

          auto checkIsRedundantAlongDomTreePath = [&](std::function<bool(llvm::BasicBlock*, BasicBlockState*)> cb) -> bool {
            // the callback should check if the current check is redundant in this block, return true if so
            // because we traverse along the dominator tree, once we found such an entry, it must dominate this use
            auto* currentCheckBlockNode = node;
            BasicBlockState* stateToCheckOpt = &curBlockState;
            while (currentCheckBlockNode) {
              if (cb(currentCheckBlockNode->getBlock(), stateToCheckOpt)) {
                return true;
              }
              if (currentCheckBlockNode->getBlock() != curRedundantCheckTopBlock) {
                currentCheckBlockNode = currentCheckBlockNode->getIDom();
                stateToCheckOpt = &blockStates[currentCheckBlockNode->getBlock()];
              } else {
                break;
              }
            }
            return false;
          };
          // see if we can find an existing check that covers this one
          if (variableAccessSize) {
            // we follow the line for non-const access size check elimination
            // only consider other checks with exactly the same size and check for duplicates
            bool isCheckDuplicate = checkIsRedundantAlongDomTreePath([=](llvm::BasicBlock* curBlock, BasicBlockState* stateToCheckOpt)->bool {
              auto iterValuePtr = stateToCheckOpt->nonConstantSizedChecks.find(rootPtr);
              if (iterValuePtr != stateToCheckOpt->nonConstantSizedChecks.end()) {
                auto iterSize = iterValuePtr->second.find(variableAccessSize);
                if (iterSize != iterValuePtr->second.end()) {
                  return true;
                }
              }
              return false;
            });
            if (!isCheckDuplicate) {
              curBlockState.nonConstantSizedChecks[rootPtr][variableAccessSize] = ptrArg;
            }
          } else {
            // constant access size check elimination
            // first, check if this access is statically safe (i.e., it is accessing local/global/dynamically-allocated objects that we know the bounds)
            bool isCheckStaticallySafe = false;
            uint64_t staticallySafeSize = 0;
            if (llvm::Constant* constptr = llvm::dyn_cast<llvm::Constant>(rootPtr)) {
              auto cbounds = getConstantBounds(constptr);
              if (!std::get<0>(cbounds)) {
                isCheckStaticallySafe = true;
              } else {
                int64_t curMaxSize = std::get<2>(cbounds) - std::get<1>(cbounds);
                if (curMaxSize >= 0) {
                  staticallySafeSize = curMaxSize;
                }

              }
            } else if (llvm::AllocaInst* alloca = llvm::dyn_cast<llvm::AllocaInst>(rootPtr)) {
              staticallySafeSize = func->getParent()->getDataLayout().getTypeAllocSize(alloca->getAllocatedType());
              if (llvm::Value* cnt = alloca->getArraySize()) {
                if (llvm::ConstantInt* cint = llvm::dyn_cast<llvm::ConstantInt>(cnt)) {
                  staticallySafeSize *= cint->getZExtValue();
                }
              }
            } else if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(rootPtr)) {
              staticallySafeSize = getStaticallySafeSizeFromDynamicAllocation(call);
            }
            //------------------------------------------------------------------------------
            if (staticallySafeSize > 0 && accessRange.first >= 0 && accessRange.second <= static_cast<int64_t>(staticallySafeSize)) {
              isCheckStaticallySafe = true;
            }
            if (isCheckStaticallySafe) {
              continue;
            }
            // then check whether another constant-sized access have covered this one
            bool isCheckDuplicate = checkIsRedundantAlongDomTreePath([=](llvm::BasicBlock* curBlock, BasicBlockState* stateToCheckOpt)->bool {
              auto iterValuePtr = stateToCheckOpt->constantSizedChecks.find(rootPtr);
              if (iterValuePtr != stateToCheckOpt->constantSizedChecks.end()) {
                for (auto& sizeCheck : iterValuePtr->second) {
                  if (sizeCheck.first.first <= accessRange.first && sizeCheck.first.second >= accessRange.second) {
                    return true;
                  }
                }
              }
              return false;
            });
            if (!isCheckDuplicate) {
              curBlockState.constantSizedChecks[rootPtr].push_back(std::make_pair(accessRange, ptrArg));
            }
          }
          // finished handling current use
          // cannot insert code here (they mey be skipped)
        }
      }
    }
  }
  // now we have all the checks in blockStates; write them back
  for (auto& p : blockStates) {
    for (auto& nonConstChecks : p.second.nonConstantSizedChecks) {
      for (auto& detail : nonConstChecks.second) {
        llvm::Use* use = detail.second;
        addCheckRequestMark(*use);
      }
    }
    // for constant sized checks, if they have negative access lower bound (the pointer used is before the root pointer),
    // we still emit the check without coalescing
    for (auto& constSizeChecks : p.second.constantSizedChecks) {
      llvm::Value* rootPtr = constSizeChecks.first;
      // for each root pointer, we only emit one check in a basic block
      // the check is placed before the first use of (derived/original) pointer value
      // because we visit the basic block in the instruction order, we can just use the first one
      llvm::Instruction* insertBefore = nullptr;
      llvm::Use* firstCheckUse = nullptr;
      std::pair<int64_t, int64_t> coalescedRange(0,0);
      llvm::SmallVector<llvm::Use*> uselist;
      for (auto& detail : constSizeChecks.second) {
        const std::pair<int64_t, int64_t>& accessRange = detail.first;
        llvm::Use* use = detail.second;
        if (accessRange.first < 0) {
          // directly emit it without coalescing
          addCheckRequestMark(*use);
          continue;
        }
        if (accessRange.second < 0) {
          psan_unreachable("unexpected negative access range");
        }
        uselist.push_back(use);
        if (insertBefore == nullptr) {
          insertBefore = llvm::cast<llvm::Instruction>(use->getUser());
          coalescedRange = accessRange;
          firstCheckUse = use;
        } else {
          if (accessRange.first < coalescedRange.first) {
            coalescedRange.first = accessRange.first;
            firstCheckUse = use;
          }
          if (accessRange.second > coalescedRange.second) {
            coalescedRange.second = accessRange.second;
          }
        }
      }
      if (uselist.empty()) {
        continue;
      }
      if (coalescedRange.first == 0) {
        // perfectly coalesced
        addCheckRequestMark(insertBefore, rootPtr, uselist, coalescedRange.second);
      } else if (uselist.size() == 1) {
        // fall back to the single-check case
        addCheckRequestMark(insertBefore, firstCheckUse->get(), uselist, coalescedRange.second - coalescedRange.first);
      } else if (firstCheckUse == uselist.front()) {
        // the access to lowest address is the first one
        // we can coalesce the check
        addCheckRequestMark(insertBefore, firstCheckUse->get(), uselist, coalescedRange.second - coalescedRange.first);
      } else {
        // we cannot coalesce the check for now (maybe add later)
        for (auto& detail : constSizeChecks.second) {
          const std::pair<int64_t, int64_t>& accessRange = detail.first;
          llvm::Use* use = detail.second;
          // ones with negative access range lower bounds are already emitted
          if (accessRange.first >= 0) {
            addCheckRequestMark(*use);
          }
        }
      }
    }
  }
}

llvm::Value* MinimalSpatialSafetyInstrumenter::getRootPointerWithAccessSizeRange(llvm::Value* ptr, std::pair<int64_t, int64_t>& shiftedAccessSizeRange)
{
  llvm::Value* result = ptr->stripPointerCastsAndAliases();
  int64_t cumulativeShift = 0;
  // first, solve the instruction part
  while (true) {
    if (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(result)) {
      result = bc->getOperand(0);
      continue;
    }
    if (llvm::GetElementPtrInst* gep = llvm::dyn_cast<llvm::GetElementPtrInst>(result)) {
      if (gep->hasAllConstantIndices()) {
        llvm::APInt offset(64, 0);
        if (!gep->accumulateConstantOffset(M.getDataLayout(), offset)) {
          psan_unreachable("unexpected non-constant GEP offset");
        }
        cumulativeShift += offset.getSExtValue();
        result = gep->getOperand(0);
        continue;
      }
    }
    break;
  }
  // next, look through constant expressions from global variables
  while (llvm::isa<llvm::ConstantExpr>(result)) {
    llvm::Constant* bareConst = llvm::cast<llvm::ConstantExpr>(result)->stripPointerCasts();
    result = bareConst;
    if (llvm::GEPOperator* gep = llvm::dyn_cast<llvm::GEPOperator>(bareConst)) {
      if (gep->hasAllConstantIndices()) {
        llvm::APInt offset(64, 0);
        if (!gep->accumulateConstantOffset(M.getDataLayout(), offset)) {
          psan_unreachable("unexpected non-constant GEP offset");
        }
        cumulativeShift += offset.getSExtValue();
        result = gep->getPointerOperand();
        continue;
      }
    }
    break;
  }
  // write back
  if (shiftedAccessSizeRange.first != 0 || shiftedAccessSizeRange.second != 0) {
    // this is a constant range; we need to do the shifting
    shiftedAccessSizeRange.first += cumulativeShift;
    shiftedAccessSizeRange.second += cumulativeShift;
  }
  return result;
}

uint64_t MinimalSpatialSafetyInstrumenter::getStaticallySafeSizeFromDynamicAllocation(llvm::CallBase* call)
{
  llvm::Function* callee = call->getCalledFunction();
  if (!callee) {
    return 0;
  }
  // first, try to look at the allocsize attribute if present
  auto allocsizeAttr = callee->getFnAttribute(llvm::Attribute::AttrKind::AllocSize);
  if (allocsizeAttr.isValid()) {
    auto args = allocsizeAttr.getAllocSizeArgs();
    unsigned sizeArgno = args.first;
    llvm::Optional<unsigned> numArgno = args.second;
    llvm::Value* sizeArg = call->getArgOperand(sizeArgno);
    llvm::Value* numArg = nullptr;
    if (numArgno.has_value()) {
      numArg = call->getArgOperand(*numArgno);
    }
    uint64_t staticallySafeSize = 1;
    if (llvm::ConstantInt* csize = llvm::dyn_cast<llvm::ConstantInt>(sizeArg)) {
      staticallySafeSize = csize->getZExtValue();
    }
    if (llvm::ConstantInt* cnum = llvm::dyn_cast_or_null<llvm::ConstantInt>(numArg)) {
      staticallySafeSize *= cnum->getZExtValue();
    }
    return staticallySafeSize;
  }
  // then try to test the callee against known allocation functions
  if (callee->getName() == "malloc") {
    if (llvm::ConstantInt* size = llvm::dyn_cast<llvm::ConstantInt>(call->getArgOperand(0))) {
      return size->getZExtValue();
    }
  }
  if (callee->getName() == "calloc") {
    llvm::Value* num = call->getArgOperand(0);
    llvm::Value* size = call->getArgOperand(1);
    uint64_t staticallySafeSize = 1;
    if (llvm::ConstantInt* csize = llvm::dyn_cast<llvm::ConstantInt>(size)) {
      staticallySafeSize = csize->getZExtValue();
    }
    if (llvm::ConstantInt* cnum = llvm::dyn_cast_or_null<llvm::ConstantInt>(num)) {
      staticallySafeSize *= cnum->getZExtValue();
    }
    return staticallySafeSize;
  }
  if (callee->getName() == "realloc") {
    if (llvm::ConstantInt* size = llvm::dyn_cast<llvm::ConstantInt>(call->getArgOperand(1))) {
      return size->getZExtValue();
    }
  }
  return 0;
}
