#include "MinimalTemporalSafetyInstrumenter.h"
#include "psan.h"
#include <llvm/IR/Constants.h>
#include <llvm/IR/Instructions.h>
#include <llvm/IR/Operator.h>
#include <llvm/Support/CommandLine.h>

using namespace PSan;
using namespace SVF;
using namespace SVF::SVFUtil;


// ================================================================================
// MinimalTemporalSafetyInstrumenter
// ================================================================================

static llvm::cl::opt<bool> EnableMTSOption(
  "psan-mts",
  llvm::cl::init(true),
  llvm::cl::desc("Enable mimimal temporal safety instrumentation")
);

bool MinimalTemporalSafetyInstrumenter::isEnabled()
{
  return EnableMTSOption;
}

MinimalTemporalSafetyInstrumenter::MinimalTemporalSafetyInstrumenter(llvm::LLVMContext& ctx, llvm::Module& M)
  : InstrumentationBase(ctx, M)
{
  i64Ty = llvm::Type::getInt64Ty(ctx);
  i8Ty = llvm::Type::getInt8Ty(ctx);
  i8PtrTy = llvm::Type::getInt8PtrTy(ctx);
  i64PtrTy = llvm::Type::getInt64PtrTy(ctx);
  i64zero = llvm::ConstantInt::get(i64Ty, 0);
  i64one = llvm::ConstantInt::get(i64Ty, 1);

  std::uint64_t topbitValue = 1ull << 63;
  i64idmask = llvm::ConstantInt::get(i64Ty, topbitValue - 1);
  i64maxneg = llvm::ConstantInt::get(i64Ty, topbitValue);
}

void MinimalTemporalSafetyInstrumenter::prepareInstrumentation(const PSan::InstrumentationOptions& options, llvm::Module* dstModule)
{
  InstrumentationBase::prepareInstrumentation(options, dstModule);

  // checking functions
  llvm::FunctionType* checkFuncTy = llvm::FunctionType::get(llvm::Type::getVoidTy(ctx), {i8PtrTy, i64PtrTy, i64Ty, i64Ty}, false);
  mts_check = llvm::Function::Create(checkFuncTy, llvm::GlobalValue::ExternalLinkage, "__psan_mts_check", dstModule);
  mts_free_check = llvm::Function::Create(checkFuncTy, llvm::GlobalValue::ExternalLinkage, "__psan_mts_free_check", dstModule);

  // allocate/deallocate locks
  llvm::FunctionType* allocLockTy = llvm::FunctionType::get(i64PtrTy, false);
  mts_allocate_lock = llvm::Function::Create(allocLockTy, llvm::GlobalValue::ExternalLinkage, "__psan_mts_allocate_lock", dstModule);

  llvm::FunctionType* deallocLockTy = llvm::FunctionType::get(llvm::Type::getVoidTy(ctx), {i64PtrTy}, false);
  mts_deallocate_lock = llvm::Function::Create(deallocLockTy, llvm::GlobalValue::ExternalLinkage, "__psan_mts_deallocate_lock", dstModule);
  mts_deallocate_lock_checked = llvm::Function::Create(deallocLockTy, llvm::GlobalValue::ExternalLinkage, "__psan_mts_deallocate_lock_checked", dstModule);

  // alloc counter
  alloc_counter = new llvm::GlobalVariable(*dstModule, i64Ty, false, llvm::GlobalValue::ExternalLinkage, nullptr, "__psan_mts_alloc_counter");
}

void MinimalTemporalSafetyInstrumenter::populateHelperFunctionsThatMayAbort(llvm::SmallVectorImpl<std::string>& functions)
{
  functions.push_back(mts_check->getName().str());
  functions.push_back(mts_free_check->getName().str());
}

void MinimalTemporalSafetyInstrumenter::finalize(llvm::Module* dstModule)
{
  // we must instrument first before linking in the runtime, since that will invalidate function pointers
  instrumentFrameLockDeallocations();
  linkInLibrary(dstModule, PSAN_RTPATH_RT_MinimalTemporalSafetyInstrumenter);
}

llvm::SmallVector<llvm::Type*> MinimalTemporalSafetyInstrumenter::createPointerMetadataTypes() const
{
  llvm::SmallVector<llvm::Type*> result;
  result.push_back(i64PtrTy); // lock
  result.push_back(i64Ty); // key
  return result;
}

llvm::SmallVector<llvm::Value*> MinimalTemporalSafetyInstrumenter::createNullPointerMetadata() const
{
  llvm::SmallVector<llvm::Value*> result;
  llvm::ConstantPointerNull* i64nullptr = llvm::ConstantPointerNull::get(i64PtrTy);
  result.push_back(i64nullptr);
  result.push_back(i64zero);
  return result;
}

void MinimalTemporalSafetyInstrumenter::analysis()
{

  for (llvm::Function& F : M) {
    if (F.isDeclaration())
      continue;
    analyzeFunction(&F);
  }
}

llvm::Value* MinimalTemporalSafetyInstrumenter::getRootPointer(llvm::Value* ptr)
{
  // find the root pointer of a pointer chain, tracing through GEPs and bitcasts
  // if the root pointer is from a constant (e.g., global variables, null pointers), return nullptr
  // if the root pointer is from an alloca, we also return nullptr
  // for other cases, return the root pointer
  llvm::Value* cur = ptr;
  while (true) {
    if (llvm::Constant* c = llvm::dyn_cast<llvm::Constant>(cur)) {
      (void) c;
      return nullptr;
    }
    if (llvm::AllocaInst* alloca = llvm::dyn_cast<llvm::AllocaInst>(cur)) {
      (void) alloca;
      return nullptr;
    }
    if (llvm::GetElementPtrInst* gep = llvm::dyn_cast<llvm::GetElementPtrInst>(cur)) {
      cur = gep->getPointerOperand();
    } else if (llvm::BitCastInst* bitcast = llvm::dyn_cast<llvm::BitCastInst>(cur)) {
      cur = bitcast->getOperand(0);
    } else {
      break;
    }
  }
  return cur;
}

void MinimalTemporalSafetyInstrumenter::analyzeFunction(llvm::Function* func)
{
  // in this function, we find all memory accesses and free-like calls for temporal safety checking
  // we implement basic check elimination but not hoisting
  // we will remove all checks on local/global objects, and for other pointers, we ensure that every check site must be reachable from protential deallocation site
  // for each value, we initially assume that the beginning of the entry block is a deallocation site, and same to all deallocations to this pointer value or opaque calls
  // then we traverse along CFG starting from these deallocation sites, label the first check encountered (they cannot be optimized away) and stop there
  // after this, all checks not visited must have been "covered" by other checks and has no point keeping them

  // TODO: BUG: currently we do not do alias analysis, so a free() on one pointer may deallocate points-to objects of another pointer
  // this is not handled yet and can result in missing checks

  struct BasicBlockEvents {
    enum EventKind {
      OpaqueCall = 0, // all values may be deallocated (no additional info)
      Dealloc = 1, // deallocation of specific values
      CheckRequest = 2, // request for checking specific value
    };
    llvm::SmallVector<llvm::Value*> dealloc_RootPtr;
    llvm::SmallVector<std::pair<EventKind, std::size_t>> events; // the value is an additional info
    void addOpaqueCallEvent() {
      events.push_back(std::make_pair(EventKind::OpaqueCall, 0));
    }
    void addDealloc(llvm::Value* rootptr) {
      unsigned index = dealloc_RootPtr.size();
      dealloc_RootPtr.push_back(rootptr);
      events.push_back(std::make_pair(EventKind::Dealloc, index));
    }
    void addCheckRequest(std::size_t checkID) {
      events.push_back(std::make_pair(EventKind::CheckRequest, checkID));
    }
    bool empty() const {return events.empty();}
    void swap(BasicBlockEvents& rhs) {
      rhs.dealloc_RootPtr.swap(dealloc_RootPtr);
      rhs.events.swap(events);
    }
  };
  llvm::DenseMap<llvm::BasicBlock*, BasicBlockEvents> basicBlockEventsMap;
  llvm::SmallVector<std::pair<llvm::Value*, llvm::Use*>> allCheckRequests;
  llvm::BitVector isCheckRequestEmitted;
  auto addCheckRequest = [&](llvm::Value* rootptr, llvm::Use* use) -> std::size_t {
    std::size_t index = allCheckRequests.size();
    allCheckRequests.push_back(std::make_pair(rootptr, use));
    return index;
  };
  auto emitCheckRequest = [&](std::size_t index) {
    if (index >= allCheckRequests.size()) {
      psan_unreachable("Invalid check request index");
    }
    if (isCheckRequestEmitted.size() <= index) {
      isCheckRequestEmitted.resize(allCheckRequests.size(), false);
    }
    if (isCheckRequestEmitted.test(index)) {
      psan_unreachable("Duplicated check request emission");
    }
    isCheckRequestEmitted.set(index);
    auto& check = allCheckRequests[index];
    llvm::Use* use = check.second;
    llvm::Instruction* insertBefore = llvm::cast<llvm::Instruction>(use->getUser());
    addCheckRequestMark(insertBefore, check.first, {use}, 0); // internalID not used
  };

  for (llvm::BasicBlock& BB : *func) {
    BasicBlockEvents curBlockEvents;
    for (llvm::Instruction& I : BB) {
      std::uint64_t fixedAccessSize = 0;
      llvm::Value* variableAccessSize = nullptr;
      llvm::SmallVector<llvm::Use*> ptrArgs;
      if (hasMemoryAccess(&I, fixedAccessSize, variableAccessSize, ptrArgs)) {
        for (llvm::Use* ptrArg : ptrArgs) {
          if (llvm::Value* rootPtr = getRootPointer(ptrArg->get())) {
            std::size_t checkID = addCheckRequest(rootPtr, ptrArg);
            curBlockEvents.addCheckRequest(checkID);
          }
        }
      } else if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(&I)) {
        if (isFreeLikeCall(call)) {
          for (llvm::Use& use : call->args()) {
            if (!use.get()->getType()->isPointerTy()) {
              continue;
            }
            if (llvm::Value* rootPtr = getRootPointer(use.get())) {
              curBlockEvents.addDealloc(rootPtr);
              addCheckRequestMark(use);
            }
          }
        } else {
          llvm::Function* callee = call->getCalledFunction();
          if (callee && callee->hasFnAttribute(llvm::Attribute::NoFree)) {
            // do nothing
          } else {
            curBlockEvents.addOpaqueCallEvent();
          }
        }
      }
    }
    if (!curBlockEvents.empty()) {
      auto p = basicBlockEventsMap.insert(std::make_pair(&BB, BasicBlockEvents()));
      if (!p.second) {
        psan_unreachable("unexpected insertion failure");
      }
      p.first->second.swap(curBlockEvents);
    }
  }
  if (allCheckRequests.empty()) {
    return;
  }

  // we use bitvector to keep track of "which value may be deallocated" at the entry of each basic block
  // we use the following two data structures to convert root pointer values to indices in the bitvector
  llvm::DenseMap<llvm::Value*, std::size_t> rootPtrMap;
  llvm::SmallVector<llvm::Value*> rootPtrVec;
  auto getRootPtrIndex = [&](llvm::Value* ptr, bool mustExist) -> std::size_t {
    auto iter = rootPtrMap.find(ptr);
    if (iter != rootPtrMap.end()) {
      return iter->second;
    }
    if (mustExist) {
      psan_unreachable("Root pointer not found");
    }
    std::size_t index = rootPtrVec.size();
    rootPtrMap.insert(std::make_pair(ptr, index));
    rootPtrVec.push_back(ptr);
    return index;
  };
  for (auto& p : allCheckRequests) {
    getRootPtrIndex(p.first, false);
  }
  struct BasicBlockInfo {
    // the following are from the basic block events
    // optimization: if the bit vector is empty, we consider them as full vector
    llvm::BitVector ptrsBeingCheckedInBlock;
    llvm::BitVector ptrsShouldCheckAfterBlock;
    // if the root pointer value may be deallocated at the entry of this block, we need to add this check
    llvm::DenseMap<std::size_t, std::size_t> leadingChecks; // root ptr index -> check request index
  };
  llvm::DenseMap<llvm::BasicBlock*, BasicBlockInfo> bbInfo;
  // convert basicBlockEventsMap to bbInfo
  llvm::BitVector fullvector(rootPtrVec.size(), true);
  llvm::BitVector zerovector(rootPtrVec.size(), false);
  for (auto& p : basicBlockEventsMap) {
    llvm::BasicBlock* bb = p.first;
    const BasicBlockEvents& events = p.second;
    llvm::BitVector dontCareValues = zerovector; // if 1, the state of this value has been changed since the entry of the block
    llvm::BitVector ptrsShouldCheckAfterBlock = zerovector;
    llvm::DenseMap<std::size_t, std::size_t> leadingChecks;
    bool isChangeMade = false;
    for (auto& event : events.events) {
      switch (event.first) {
      case BasicBlockEvents::EventKind::OpaqueCall: {
        dontCareValues = fullvector;
        ptrsShouldCheckAfterBlock = fullvector;
        isChangeMade = true;
      } break;
      case BasicBlockEvents::EventKind::Dealloc: {
        llvm::Value* rootPtrValue = events.dealloc_RootPtr[event.second];
        auto iter = rootPtrMap.find(rootPtrValue);
        if (iter != rootPtrMap.end()) {
          std::size_t rootPtrIndex = iter->second;
          dontCareValues.set(rootPtrIndex);
          ptrsShouldCheckAfterBlock.set(rootPtrIndex);
          isChangeMade = true;
        }
      } break;
      case BasicBlockEvents::EventKind::CheckRequest: {
        std::size_t checkID = event.second;
        auto& checkInfo = allCheckRequests[checkID];
        std::size_t rootPtrIndex = getRootPtrIndex(checkInfo.first, true);
        if (!dontCareValues.test(rootPtrIndex)) {
          // emitting this check or not depends on the state at the beginning of basic block
          leadingChecks.insert(std::make_pair(rootPtrIndex, checkID));
          dontCareValues.set(rootPtrIndex);
          ptrsShouldCheckAfterBlock.reset(rootPtrIndex);
          isChangeMade = true;
        } else {
          // the state of this root pointer value is already determined and we can make emission decision now
          if (ptrsShouldCheckAfterBlock.test(rootPtrIndex)) {
            ptrsShouldCheckAfterBlock.reset(rootPtrIndex);
            emitCheckRequest(checkID);
          }
        }
      } break;
      default:
        psan_unreachable("unexpected event kind");
      }
    }
    if (!isChangeMade) {
      continue;
    }
    auto insertResult = bbInfo.insert(std::make_pair(bb, BasicBlockInfo()));
    if (!insertResult.second) {
      psan_unreachable("Unexpected insertion failure");
    }
    BasicBlockInfo& info = insertResult.first->second;
    if (dontCareValues.all()) {
      dontCareValues.clear();
    }
    if (ptrsShouldCheckAfterBlock.all()) {
      ptrsShouldCheckAfterBlock.clear();
    }
    info.ptrsBeingCheckedInBlock.swap(dontCareValues);
    info.ptrsShouldCheckAfterBlock.swap(ptrsShouldCheckAfterBlock);
    info.leadingChecks.swap(leadingChecks);
  }

  llvm::DenseMap<llvm::BasicBlock*, llvm::BitVector> visitStatus; // for each basic block, which value would require checking (bitvector in rootPtrVec)
  SVF::FIFOWorkList<llvm::BasicBlock*> worklist;
  // at the entry block, all values are considered as may be deallocated

  llvm::BasicBlock* entryBlock = &func->getEntryBlock();
  visitStatus.insert(std::make_pair(entryBlock, fullvector));
  worklist.push(entryBlock);
  while (!worklist.empty()) {
    llvm::BasicBlock* curBlock = worklist.pop();
    llvm::Instruction* terminator = curBlock->getTerminator();
    unsigned numSuccessors = terminator->getNumSuccessors();
    if (numSuccessors == 0) {
      continue;
    }
    llvm::BitVector curValueVec = visitStatus[curBlock];
    auto iter = bbInfo.find(curBlock);
    if (iter != bbInfo.end()) {
      BasicBlockInfo& info = iter->second;
      if (info.ptrsShouldCheckAfterBlock.empty()) {
        curValueVec = fullvector;
      } else if (info.ptrsBeingCheckedInBlock.empty()) {
        curValueVec = info.ptrsShouldCheckAfterBlock;
      } else {
        curValueVec.reset(info.ptrsBeingCheckedInBlock);
        curValueVec |= info.ptrsShouldCheckAfterBlock;
      }
    }
    for (unsigned i = 0; i < numSuccessors; ++i) {
      llvm::BasicBlock* succ = terminator->getSuccessor(i);
      auto iterSucc = visitStatus.find(succ);
      if (iterSucc == visitStatus.end()) {
        visitStatus.insert(std::make_pair(succ, curValueVec));
        worklist.push(succ);
      } else {
        if (!curValueVec.test(iterSucc->second)) {
          continue;
        }
        iterSucc->second |= curValueVec;
        worklist.push(succ);
      }
    }
  }

  // write back checks
  for (auto& p : bbInfo) {
    llvm::BasicBlock* bb = p.first;
    auto& info = p.second;
    auto iterVisitStatus = visitStatus.find(bb);
    if (iterVisitStatus == visitStatus.end()) {
      // this block should be unreachable from entry
      continue;
    }
    const llvm::BitVector& ptrsShouldCheckBeforeBlock = iterVisitStatus->second;
    for (auto& p2 : info.leadingChecks) {
      std::size_t rootPtrIndex = p2.first;
      if (ptrsShouldCheckBeforeBlock.test(rootPtrIndex)) {
        emitCheckRequest(p2.second);
      }
    }
  }
}

void MinimalTemporalSafetyInstrumenter::instrumentMetadataInit(llvm::AllocaInst* alloc, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  llvm::Function* parentFunc = alloc->getFunction();
  auto p = getLockAndKeyForStackFrame(parentFunc);
  md.clear();
  md.push_back(p.first);
  md.push_back(p.second);
}

void MinimalTemporalSafetyInstrumenter::instrumentMetadataInit(llvm::GlobalVariable* gv, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  // we assume globals are always alive
  (void) gv;
  (void) insertBefore;
  md = nullptrMetadata;
}

void MinimalTemporalSafetyInstrumenter::instrumentMetadataInit(llvm::ConstantExpr* gvconstexpr, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  // we assume globals are always alive
  (void) gvconstexpr;
  (void) insertBefore;
  md = nullptrMetadata;
}

void MinimalTemporalSafetyInstrumenter::instrumentMetadataInit(llvm::CallBase* call, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  // for now we always assume that dynamic allocations succeed, so we always allocate the lock
  llvm::Instruction* lock = llvm::CallInst::Create(mts_allocate_lock, "", getInsertionPointAfter(call));
  handleDebugLoc(lock, call);
  llvm::Value* key = instrumentLockInitCommon(lock, true);
  md.clear();
  md.push_back(lock);
  md.push_back(key);
}

bool MinimalTemporalSafetyInstrumenter::isAllUsersFreeLike(const llvm::SmallVectorImpl<llvm::Use*>& uselist)
{
  if (uselist.empty()) {
    psan_unreachable("empty uselist for checking");
  }
  // if the user instruction is annotated as free-like, use the free check; otherwise, use the regular check
  auto isUserFreeLike = [&](llvm::Use* use) {
    llvm::User* user = use->getUser();
    if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(user)) {
      return isFreeLikeCall(call);
    }
    return false;
  };
  bool isAllFreeLike = true;
  bool isAllRegular = true;
  for (llvm::Use* use : uselist) {
    if (isUserFreeLike(use)) {
      isAllRegular = false;
    } else {
      isAllFreeLike = false;
    }
  }
  if (isAllFreeLike == isAllRegular) {
    psan_unreachable("mixed free-like and regular uses for temporal safety checking");
  }
  return isAllFreeLike;
}

void MinimalTemporalSafetyInstrumenter::instrumentCheck(llvm::Instruction* insertBefore, llvm::Value* ptr, const llvm::SmallVectorImpl<llvm::Use*>& uselist, llvm::SmallVectorImpl<llvm::Value*>& md, std::size_t checkID, std::size_t internalID)
{
  (void) internalID;
  bool isAllFreeLike = isAllUsersFreeLike(uselist);
  llvm::Function* checkFunc = isAllFreeLike ? mts_free_check : mts_check;
  llvm::Value* ptrArg = ptr;
  emitCheckImpl(insertBefore, ptrArg, checkFunc, md, checkID);
}

void MinimalTemporalSafetyInstrumenter::emitCheckImpl(llvm::Instruction* insertBefore, llvm::Value* ptrArg, llvm::Function* checkFunc, llvm::SmallVectorImpl<llvm::Value*>& md, std::size_t checkID)
{
  if (ptrArg->getType() != i8PtrTy) {
    ptrArg = llvm::CastInst::CreatePointerCast(ptrArg, i8PtrTy, "", insertBefore);
  }
  llvm::Value* lock = md[0];
  llvm::Value* key = md[1];
  llvm::Value* checkIDVal = llvm::ConstantInt::get(i64Ty, checkID);
  llvm::CallInst* call = llvm::CallInst::Create(checkFunc, {ptrArg, lock, key, checkIDVal}, "", insertBefore);
  handleDebugLoc(call, insertBefore);
}

void MinimalTemporalSafetyInstrumenter::instrumentCheck_Debug(llvm::Instruction* insertBefore, llvm::Value* ptr, llvm::SmallVectorImpl<llvm::Value*>& md, std::size_t checkID)
{
  emitCheckImpl(insertBefore, ptr, mts_check, md, checkID);
}

void MinimalTemporalSafetyInstrumenter::inspectCheckSiteForNoopCheck(llvm::Instruction* insertBefore, llvm::Value* ptr, const llvm::SmallVectorImpl<llvm::Use*>& uselist, llvm::SmallVectorImpl<llvm::Value*>& md, std::size_t checkID, std::size_t internalID)
{
  (void) internalID;
  if (isAllUsersFreeLike(uselist)) {
    llvm::Value* lock = md[0];
    llvm::Instruction* dealloc = llvm::CallInst::Create(mts_deallocate_lock_checked, {lock}, "", insertBefore);
    handleDebugLoc(dealloc, insertBefore);
  }
}

bool MinimalTemporalSafetyInstrumenter::isFreeLikeCall(llvm::CallBase* call)
{
  if (llvm::Function* callee = call->getCalledFunction()) {
    return PSan::isDeallocationCallee(callee) || PSan::isReallocCallee(callee);
  }
  return false;
}

std::pair<llvm::Instruction*, llvm::Value*> MinimalTemporalSafetyInstrumenter::getLockAndKeyForStackFrame(llvm::Function* func)
{
  auto it = stackFrameLocks.find(func);
  if (it != stackFrameLocks.end()) {
    return it->second;
  }
  llvm::Instruction* insertPoint = getBlockInsertPoint(&func->getEntryBlock());
  llvm::Instruction* lock = llvm::CallInst::Create(mts_allocate_lock, "", insertPoint);
  handleDebugLoc(lock, insertPoint);
  llvm::Value* key = instrumentLockInitCommon(lock, false);
  auto result = std::make_pair(lock, key);
  stackFrameLocks[func] = result;
  return result;
}

llvm::Value* MinimalTemporalSafetyInstrumenter::instrumentLockInitCommon(llvm::Instruction* lock, bool isDynamicAlloc)
{
  llvm::IRBuilder<> builder(lock->getNextNode());
  llvm::Value* oldcnt = builder.CreateLoad(i64Ty, alloc_counter);
  llvm::Value* newcnt = builder.CreateAdd(oldcnt, i64one);
  builder.CreateStore(newcnt, alloc_counter);
  llvm::Value* key = nullptr;
  if (isDynamicAlloc) {
    // set top bit to 1
    key = builder.CreateOr(newcnt, i64maxneg);
  } else {
    // set top bit to 0
    key = builder.CreateAnd(newcnt, i64idmask);
  }
  builder.CreateStore(key, lock);
  return key;
}

void MinimalTemporalSafetyInstrumenter::instrumentFrameLockDeallocations()
{
  // for all locks in stackFrameLocks, insert deallocation before each returning site
  for (auto& p : stackFrameLocks) {
    llvm::Function* func = p.first;
    llvm::Instruction* lock = p.second.first;
    for (llvm::BasicBlock& BB : *func) {
      for (llvm::Instruction& I : BB) {
        if (llvm::isa<llvm::ReturnInst>(&I) || llvm::isa<llvm::ResumeInst>(&I)) {
          llvm::Instruction* dealloc = llvm::CallInst::Create(mts_deallocate_lock, {lock}, "", &I);
          handleDebugLoc(dealloc, &I);
        }
      }
    }
  }
}
