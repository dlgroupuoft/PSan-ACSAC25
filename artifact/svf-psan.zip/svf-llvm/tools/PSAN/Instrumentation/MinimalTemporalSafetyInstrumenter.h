#ifndef PSAN_INSTRUMENTATION_MINIMALTEMPORALSAFETYINSTRUMENTER_H
#define PSAN_INSTRUMENTATION_MINIMALTEMPORALSAFETYINSTRUMENTER_H

#include "instrumentation.h"

namespace PSan {
class MinimalTemporalSafetyInstrumenter : public InstrumentationBase {
public:
  MinimalTemporalSafetyInstrumenter(llvm::LLVMContext& ctx, llvm::Module& M);
  virtual ~MinimalTemporalSafetyInstrumenter() = default;
  virtual void analysis() override;
  virtual llvm::SmallVector<llvm::Type*> createPointerMetadataTypes() const override;
  virtual llvm::SmallVector<llvm::Value*> createNullPointerMetadata() const override;
  virtual void instrumentMetadataInit(llvm::AllocaInst* alloc, llvm::SmallVectorImpl<llvm::Value*>& md) override;
  virtual void instrumentMetadataInit(llvm::GlobalVariable* gv, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md) override;
  virtual void instrumentMetadataInit(llvm::ConstantExpr* gvconstexpr, llvm::Instruction* insertBefore, llvm::SmallVectorImpl<llvm::Value*>& md) override;
  virtual void instrumentMetadataInit(llvm::CallBase* call, llvm::SmallVectorImpl<llvm::Value*>& md) override;
  virtual void instrumentCheck(llvm::Instruction* insertBefore, llvm::Value* ptr, const llvm::SmallVectorImpl<llvm::Use*>& uselist, llvm::SmallVectorImpl<llvm::Value*>& md, std::size_t checkID, std::size_t internalID) override;
  virtual void instrumentCheck_Debug(llvm::Instruction* insertBefore, llvm::Value* ptr, llvm::SmallVectorImpl<llvm::Value*>& md, std::size_t checkID) override;
  virtual void inspectCheckSiteForNoopCheck(llvm::Instruction* insertBefore, llvm::Value* ptr, const llvm::SmallVectorImpl<llvm::Use*>& uselist, llvm::SmallVectorImpl<llvm::Value*>& md, std::size_t checkID, std::size_t internalID) override;

  virtual void populateHelperFunctionsThatMayAbort(llvm::SmallVectorImpl<std::string>& functions) override;
  virtual void prepareInstrumentation(const PSan::InstrumentationOptions& options, llvm::Module* dstModule) override;
  virtual void finalize(llvm::Module* dstModule) override;

  static bool isEnabled();
private:
  llvm::IntegerType* i64Ty = nullptr; // KeyType
  llvm::IntegerType* i8Ty = nullptr;
  llvm::PointerType* i8PtrTy = nullptr;
  llvm::PointerType* i64PtrTy = nullptr;
  llvm::ConstantInt* i64zero = nullptr;
  llvm::ConstantInt* i64one = nullptr;
  llvm::ConstantInt* i64idmask = nullptr; // all 1 except the top bit
  llvm::ConstantInt* i64maxneg = nullptr; // 0x8000...

  // uint64_t __psan_mts_alloc_counter
  llvm::GlobalVariable* alloc_counter = nullptr;

  // void __psan_mts_check(void* addr, KeyType* lock, KeyType key, uint64_t checkID)
  llvm::Function* mts_check = nullptr;

  // void __psan_mts_free_check(void* addr, KeyType* lock, KeyType key, uint64_t checkID)
  llvm::Function* mts_free_check = nullptr;

  // KeyType* __psan_mts_allocate_lock()
  llvm::Function* mts_allocate_lock = nullptr;

  // void __psan_mts_deallocate_lock(KeyType* lock)
  llvm::Function* mts_deallocate_lock = nullptr;

  // void __psan_mts_deallocate_lock_checked(KeyType* lock)
  llvm::Function* mts_deallocate_lock_checked = nullptr;

  llvm::DenseMap<llvm::Function*, std::pair<llvm::Instruction*, llvm::Value*>> stackFrameLocks;
private:
  std::pair<llvm::Instruction*, llvm::Value*> getLockAndKeyForStackFrame(llvm::Function* func);
  bool isFreeLikeCall(llvm::CallBase* call);
  void instrumentFrameLockDeallocations();
  llvm::Value* instrumentLockInitCommon(llvm::Instruction* lock, bool isDynamicAlloc);
  void emitCheckImpl(llvm::Instruction* insertBefore, llvm::Value* ptrArg, llvm::Function* checkFunc, llvm::SmallVectorImpl<llvm::Value*>& md, std::size_t checkID);
  void analyzeFunction(llvm::Function* func);
  llvm::Value* getRootPointer(llvm::Value* ptr);
  bool isAllUsersFreeLike(const llvm::SmallVectorImpl<llvm::Use*>& uselist);
};
} // end namespace PSan

#endif // PSAN_INSTRUMENTATION_MINIMALTEMPORALSAFETYINSTRUMENTER_H
