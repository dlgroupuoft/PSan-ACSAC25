#include "psan.h"
#include "s1.h"


using namespace PSan;

namespace {

unsigned preTransform_getPointerTypeIndirectionLevels(llvm::PointerType* ty)
{
  unsigned curLevel = 0;
  llvm::Type* curElTy = getPointerElementType(ty);
  while (llvm::PointerType* ptrTy = llvm::dyn_cast<llvm::PointerType>(curElTy)) {
    curLevel += 1;
    curElTy = getPointerElementType(ptrTy);
  }
  return curLevel;
}

bool preTransform_IsTypeConsideredEquivalentForGEPConversion(llvm::Type* lhs, llvm::Type* rhs)
{
  // return true if the two types can be considered equivalent when doing gep conversion
  // besides exact compatibility (lhs == rhs), we also permit pointers with the same level of indirections
  if (lhs == rhs) {
    return true;
  }
  if (lhs->isPointerTy() && rhs->isPointerTy()) {
    return preTransform_getPointerTypeIndirectionLevels(llvm::cast<llvm::PointerType>(lhs))
        == preTransform_getPointerTypeIndirectionLevels(llvm::cast<llvm::PointerType>(rhs));
  }
  return false;
}

unsigned preTransform_testIfCanDoGepConversion_typeonly(llvm::Type* targetElementTy, llvm::Value* realValueWithTy)
{
  assert(realValueWithTy->getType()->isPointerTy());
  llvm::Type* srcElementTy = getPointerElementType(llvm::cast<llvm::PointerType>(realValueWithTy->getType()));
  assert(srcElementTy != targetElementTy);
  llvm::Type* curElementTy = srcElementTy;
  unsigned numZeros = 0;
  while (!preTransform_IsTypeConsideredEquivalentForGEPConversion(curElementTy, targetElementTy)) {
    if (llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(curElementTy)) {
      if (sTy->isOpaque()) {
        return 0; // cannot convert
      }
      curElementTy = sTy->getElementType(0);
      numZeros += 1;
      continue;
    }
    if (llvm::ArrayType* aTy = llvm::dyn_cast<llvm::ArrayType>(curElementTy)) {
      curElementTy = aTy->getElementType();
      numZeros += 1;
      continue;
    }
    // some unexpected type we cannot continue
    return 0;
  }
  return numZeros;
}

unsigned preTransform_testIfCanDoGepConversion(llvm::Instruction* bc, llvm::Value* realValueWithTy)
{
  return preTransform_testIfCanDoGepConversion_typeonly(getPointerElementType(llvm::cast<llvm::PointerType>(bc->getType())), realValueWithTy);
}

llvm::PointerType* preTransform_castJoining_getBetterParentType(const llvm::DataLayout& layout, llvm::PointerType* lhs, llvm::PointerType* rhs);
bool preTransform_castJoining_isTypeACoversB(const llvm::DataLayout& layout, llvm::Type* tyA, llvm::Type* tyB)
{
  bool isTypeAElementary = tyA->isSingleValueType();
  if (isTypeAElementary) {
    return false;
  }

  // get the next element type in the type hierarchy
  llvm::Type* elementTy = nullptr;
  if (llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(tyA)) {
    // if this struct is opaque, we assume no
    if (sTy->isOpaque()) {
      return false;
    }
    assert (sTy->getNumElements() > 0);
    // check if the first element type covers the target type, or it is a pointer type that is a better parent
    elementTy = sTy->getElementType(0);
  }
  if (llvm::ArrayType* aTy = llvm::dyn_cast<llvm::ArrayType>(tyA)) {
    elementTy = aTy->getElementType();
  }
  if (elementTy == tyB) {
    return true;
  }
  // if tyA is not a struct or array, we give up
  if (!elementTy) {
    return false;
  }

  // now check whether the element type covers tyB
  // first, if both are pointers, we do the special handling
  if (llvm::PointerType* elementPtrTy = llvm::dyn_cast<llvm::PointerType>(elementTy)) {
    if (llvm::PointerType* tyBPtrTy = llvm::dyn_cast<llvm::PointerType>(tyB)) {
      return preTransform_castJoining_getBetterParentType(layout, elementPtrTy, tyBPtrTy) == elementPtrTy;
    }
  }
  // then we check if the size of element type is larger
  // if the size of element type is not smaller AND type B is elementary type,
  // we still consider it as better
  llvm::TypeSize elementTySize = layout.getTypeAllocSize(elementTy);
  llvm::TypeSize tyBSize = layout.getTypeAllocSize(tyB);
  if (elementTySize.getKnownMinSize() < tyBSize.getKnownMinSize()) {
    return false;
  }
  if (elementTy->isSingleValueType()) {
    return tyB->isSingleValueType();
  }

  return preTransform_castJoining_isTypeACoversB(layout, elementTy, tyB);
}

llvm::PointerType* preTransform_castJoining_getBetterParentType(const llvm::DataLayout& layout, llvm::PointerType* lhs, llvm::PointerType* rhs)
{
  // should be impossible but just in case
  if (lhs == rhs) {
    return lhs;
  }
  llvm::Type* lhsPointee = getPointerElementType(lhs);
  llvm::Type* rhsPointee = getPointerElementType(rhs);

  // special handling for i8*
  if (lhsPointee->isIntegerTy(8)) {
    return rhs;
  } else if (rhsPointee->isIntegerTy(8)) {
    return lhs;
  }
  // special handling for unsized types (e.g., function pointer, opaque pointer)
  if (!lhsPointee->isSized() && !rhsPointee->isSized()) {
    return nullptr;
  } else if (!lhsPointee->isSized()) {
    return rhs;
  } else if (!rhsPointee->isSized()) {
    return lhs;
  }

  llvm::PointerType* lhsPointerPointee = llvm::dyn_cast<llvm::PointerType>(lhsPointee);
  llvm::PointerType* rhsPointerPointee = llvm::dyn_cast<llvm::PointerType>(rhsPointee);

  if (lhsPointerPointee && rhsPointerPointee) {
    llvm::PointerType* resultPointerPointee = preTransform_castJoining_getBetterParentType(layout, lhsPointerPointee, rhsPointerPointee);
    if (resultPointerPointee == lhsPointerPointee) {
      return lhs;
    } else if (resultPointerPointee == rhsPointerPointee) {
      return rhs;
    } else {
      return nullptr;
    }
  }
  // not both types are pointer pointee
  // we use the type size as an aid to determine which should be a parent type
  llvm::TypeSize lhsPointeeSize = layout.getTypeAllocSize(lhsPointee);
  llvm::TypeSize rhsPointeeSize = layout.getTypeAllocSize(rhsPointee);
  llvm::PointerType* largerTypePtrTy = nullptr;
  llvm::PointerType* smallerTypePtrTy = nullptr;
  llvm::Type* largerPointeeTy = nullptr;
  llvm::Type* smallerPointeeTy = nullptr;
  (void) smallerTypePtrTy;
  if (lhsPointeeSize.getKnownMinSize() == rhsPointeeSize.getKnownMinSize()) {
    // the two element type sizes are the same
    // if both are elementary types, we use pointer > int > anything else
    // if one of them is array/struct, we check if one type can be included in the other
    // if none works, return null
    if (lhsPointee->isSingleValueType() && rhsPointee->isSingleValueType()) {
      if (lhsPointerPointee && !rhsPointerPointee) {
        return lhs;
      } else if (rhsPointerPointee && !lhsPointerPointee) {
        return rhs;
      }
      if (lhsPointee->isIntegerTy() && !rhsPointee->isIntegerTy()) {
        return lhs;
      } else if (rhsPointee->isIntegerTy() && !lhsPointee->isIntegerTy()) {
        return rhs;
      }
    }
    if (preTransform_castJoining_isTypeACoversB(layout, lhsPointee, rhsPointee)) {
      return lhs;
    }
    if (preTransform_castJoining_isTypeACoversB(layout, rhsPointee, lhsPointee)) {
      return rhs;
    }
    // ok, no conclusion
    return nullptr;
  } else if (lhsPointeeSize.getKnownMinSize() < rhsPointeeSize.getKnownMinSize()) {
    largerTypePtrTy = rhs;
    largerPointeeTy = rhsPointee;
    smallerTypePtrTy = lhs;
    smallerPointeeTy = lhsPointee;
  } else {
    largerTypePtrTy = lhs;
    largerPointeeTy = lhsPointee;
    smallerTypePtrTy = rhs;
    smallerPointeeTy = rhsPointee;
  }
  // if both types are elementary type (not struct / array), we choose the one with larger size
  if (largerPointeeTy->isSingleValueType() && smallerPointeeTy->isSingleValueType()) {
    return largerTypePtrTy;
  }
  // if the larger type is an array/struct, check if the other can be a member
  // otherwise, we give up
  if (preTransform_castJoining_isTypeACoversB(layout, largerPointeeTy, smallerPointeeTy)) {
    return largerTypePtrTy;
  }
  return nullptr;
}





/**
 * @brief Once we found that instr is producing an i8*, make sure there is a single bitcast using its value
*/
void pretransform_castjoining(llvm::Instruction* instr, llvm::Function* func, const llvm::DominatorTree& DT, llvm::DenseSet<llvm::Instruction*>& badcastedPointers)
{
  const llvm::DataLayout& layout = func->getParent()->getDataLayout();
  llvm::BitCastInst* bestCastUser = nullptr;
  bool hasOtherUsers = false; // we don't want to do anything if the source only have one cast user
  for (const auto& u : instr->uses()) {
    llvm::User* user = u.getUser();
    if (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(user)) {
      if (!bestCastUser) {
        bestCastUser = bc;
      } else {
        hasOtherUsers = true;
        llvm::PointerType* curBestTy = llvm::cast<llvm::PointerType>(bestCastUser->getType());
        llvm::PointerType* newBCTy   = llvm::cast<llvm::PointerType>(bc->getType());
        if (curBestTy == newBCTy) {
          continue;
        }
        llvm::PointerType* resultBestCastTy = preTransform_castJoining_getBetterParentType(layout, curBestTy, newBCTy);
        /*
        llvm::outs() << "CastJoining: " << *instr << ":\n\t" << *curBestTy << "\n\t" << *newBCTy << "\n->\t";
        if (resultBestCastTy) {
          llvm::outs() << *resultBestCastTy << "\n";
        } else {
          llvm::outs() << "null\n";
        }
        */
        if (!resultBestCastTy) {
          // no single best dest type
          badcastedPointers.insert(bc);
          return;
        } else if (resultBestCastTy == curBestTy) {
          continue;
        } else if (resultBestCastTy == newBCTy) {
          bestCastUser = bc;
        } else {
          psan_unreachable("Unhandled return value from preTransform_castJoining_getBetterParentType()");
        }
      }
    } else {
      hasOtherUsers = true;
    }
  }
  if (!hasOtherUsers || !bestCastUser) {
    return;
  }

  // now we found a place to change
  // step 1: go through all users of the original value
  // replace them with the casted value fom the best cast user
  llvm::BitCastInst* castToOldType = nullptr;
  llvm::Instruction* insertBeforeInstHint = nullptr;
  llvm::PointerType* ptrTy = llvm::cast<llvm::PointerType>(instr->getType());
  auto getReverseCast = [&]() -> llvm::BitCastInst* {
    if (castToOldType) {
      return castToOldType;
    }
    castToOldType = new llvm::BitCastInst(bestCastUser, ptrTy);
    // if instr is PHI, we don't want to insert before another PHI
    // if instr is invoke, we want to insert at the beginning of the normal execution branch
    llvm::Instruction* reverseCastInsertBefore = instr->getNextNode();
    if (llvm::InvokeInst* invoke = llvm::dyn_cast<llvm::InvokeInst>(instr)) {
      reverseCastInsertBefore = &*invoke->getNormalDest()->getFirstInsertionPt();
    }
    while(llvm::isa<llvm::PHINode>(reverseCastInsertBefore)) {
      reverseCastInsertBefore = reverseCastInsertBefore->getNextNode();
    }
    castToOldType->insertBefore(reverseCastInsertBefore);
    insertBeforeInstHint = castToOldType;
    return castToOldType;
  };
  // we detach the bestCastUser first, then redirect all old uses to the best cast user, finally put it back
  llvm::UndefValue* undef = llvm::UndefValue::get(ptrTy);
  assert (bestCastUser->getOperand(0) == instr);
  bestCastUser->setOperand(0, undef);
  while (!instr->use_empty()) {
    llvm::Use& u = *instr->use_begin();
    if (llvm::BitCastInst* bcUser = llvm::dyn_cast<llvm::BitCastInst>(u.getUser())) {
      llvm::PointerType* resultTy = llvm::cast<llvm::PointerType>(bcUser->getType());
      if (resultTy == bestCastUser->getType()) {
        assert (bcUser != bestCastUser);
        bcUser->replaceAllUsesWith(bestCastUser);
        bcUser->eraseFromParent();
      } else {
        llvm::BitCastInst* newBC = new llvm::BitCastInst(bestCastUser, bcUser->getType());
        newBC->takeName(bcUser);
        newBC->copyMetadata(*bcUser);
        newBC->insertBefore(bcUser);
        bcUser->replaceAllUsesWith(newBC);
        bcUser->eraseFromParent();
      }
    } else {
      // non-cast user
      u.set(getReverseCast());
    }
  }
  bestCastUser->setOperand(0, instr);

  if (!insertBeforeInstHint) {
    insertBeforeInstHint = getInsertingPointForInstrHoisting(DT, bestCastUser);
  }
  if (insertBeforeInstHint) {
    bestCastUser->moveBefore(insertBeforeInstHint);
  }
  annotateInstr(bestCastUser, "psan_castjoin");
  return;
}

llvm::GetElementPtrInst* preTransform_getZeroIndexGEPForCastReplacement(llvm::Instruction* oldCast, llvm::Value* srcVal, llvm::Type* pointeeType, unsigned numZeros, llvm::IntegerType* i64Ty, llvm::IntegerType* i32Ty, llvm::Instruction* insertBefore = nullptr)
{
  llvm::SmallVector<llvm::Value*> indexlist;
  // the first zero is i64; subsequent ones are i32
  indexlist.push_back(llvm::ConstantInt::get(i64Ty, 0));
  for (unsigned i = 0; i < numZeros; ++i) {
    indexlist.push_back(llvm::ConstantInt::get(i32Ty, 0));
  }
  llvm::GetElementPtrInst* gep = llvm::GetElementPtrInst::Create(pointeeType, srcVal, indexlist);
  if (insertBefore) {
    gep->insertBefore(insertBefore);
  } else {
    gep->insertBefore(oldCast);
  }
  gep->takeName(oldCast);
  gep->copyMetadata(*oldCast);
  return gep;
}

llvm::GetElementPtrInst* preTransform_getTypedGEPForI8GEPReplacement(const llvm::DataLayout& layout, llvm::GetElementPtrInst* i8gep, llvm::Value* srcValue, llvm::Type* srcPointeeType, std::int64_t& remainingOffset, llvm::IntegerType* i64Ty, llvm::IntegerType* i32Ty)
{
  llvm::SmallVector<llvm::Value*> indexlist;
  // check that this gep is indeed taking an i8*
  assert (getPointerElementType(llvm::cast<llvm::PointerType>(i8gep->getPointerOperand()->getType()))->isIntegerTy(8));
  // check that this gep has a constant single index
  // UPDATE: if the gep index is non-constant but can be decomposed as Ax + C where x is an opaque value and A,C are constants,
  // we use C as the index first, even if C is zero
  // we can have something like "bzf->buf[bzf->bufN] = ..." where bzf is the object, bzf->bufN is the x, &bzf->buf[0] is C, sizeof(char) is A
  assert (i8gep->getNumIndices() == 1);
  llvm::ConstantInt* cintOffset = llvm::dyn_cast<llvm::ConstantInt>(i8gep->getOperand(1));
  std::int64_t offsetValue = 0;
  llvm::Value* unresolvedNonConstOffset = nullptr;
  std::size_t nonConstOffsetStep = 1;
  if (cintOffset) {
    offsetValue = cintOffset->getSExtValue();
  } else {
    llvm::Value* pendingOffset = i8gep->getOperand(1);
    // we need to update nonConstOffsetStep (A), unresolvedNonConstOffset (x), and offsetValue (C) in this loop
    // whenever we see something we cannot handle (e.g., negative operands), we give up
    while (llvm::BinaryOperator* binop = llvm::dyn_cast<llvm::BinaryOperator>(pendingOffset)) {
      llvm::Value* lhs = binop->getOperand(0);
      llvm::Value* rhs = binop->getOperand(1);
      llvm::ConstantInt* constLhs = llvm::dyn_cast<llvm::ConstantInt>(lhs);
      llvm::ConstantInt* constRhs = llvm::dyn_cast<llvm::ConstantInt>(rhs);
      if (!constLhs && !constRhs) {
        // no way to decompose the offset anyway...
        break;
      }
      // make sure we are not handling the case when both sides are constant; should be impossible
      assert (!(constLhs && constRhs));
      llvm::ConstantInt* constSide = constLhs? constLhs: constRhs;
      llvm::Value* nonConstSide = constLhs? rhs : lhs;
      assert (constSide && !llvm::isa<llvm::ConstantInt>(nonConstSide));

      // ok, at least one value is constant; try to decompose it
      bool isUnknownOp = false;
      switch (binop->getOpcode())
      {
      default:
        isUnknownOp = true;
        break;
      case llvm::Instruction::Add: {
        if (!constSide->getValue().isNonNegative()) {
          return nullptr;
        }
        offsetValue += static_cast<std::int64_t>(nonConstOffsetStep) * static_cast<std::int64_t>(constSide->getValue().getLimitedValue());
        pendingOffset = nonConstSide;
      } break;
      case llvm::Instruction::Mul: {
        if (!constSide->getValue().isNonNegative()) {
          return nullptr;
        }
        nonConstOffsetStep *= constSide->getValue().getLimitedValue();
        pendingOffset = nonConstSide;
      } break;
      case llvm::Instruction::Shl: {
        if (!(constSide == constRhs && constSide->getValue().isNonNegative())) {
          return nullptr;
        }
        std::size_t mulValue = 1ull << constSide->getValue().getLimitedValue();
        nonConstOffsetStep *= mulValue;
        pendingOffset = nonConstSide;
      } break;
      }
      if (isUnknownOp) {
        break;
      }
    }
    unresolvedNonConstOffset = pendingOffset;
  }

  // step 1: determine the first index
  std::int64_t baseTypeSize = layout.getTypeAllocSize(srcPointeeType).getKnownMinSize();
  assert (baseTypeSize > 0);
  std::int64_t firstIndex = offsetValue / baseTypeSize;
  std::int64_t newOffset = offsetValue - baseTypeSize * firstIndex;
  while (newOffset < 0) {
    firstIndex -= 1;
    newOffset += baseTypeSize;
  }
  if (!(newOffset >= 0 && newOffset < baseTypeSize)) {
    psan_unreachable("Unexpected offset value");
  }
  offsetValue = newOffset;

  indexlist.push_back(llvm::ConstantInt::getSigned(i64Ty, firstIndex));

  // step 2: determine subsequent indices
  llvm::Type* curPointeeType = srcPointeeType;
  while(offsetValue != 0) {
    assert (offsetValue > 0);
    if (offsetValue >= static_cast<std::int64_t>(layout.getTypeAllocSize(curPointeeType).getKnownMinSize())) {
      // we may have such code appear for programs using flexible array member where the struct has an [1*...] at the end to fill the extra space
      // in this case we should have an array element
      // uhh if this is not the case, then we cannot handle all offsets and we need an extra adjustment on the offset
      if (!llvm::isa<llvm::ArrayType>(curPointeeType)) {
        break;
      }
    }
    if (llvm::ArrayType* aTy = llvm::dyn_cast<llvm::ArrayType>(curPointeeType)) {
      llvm::Type* elementType = aTy->getElementType();
      std::int64_t curElementSize = layout.getTypeAllocSize(elementType);
      std::int64_t curIndex = offsetValue / curElementSize;
      offsetValue -= curIndex * curElementSize;
      curPointeeType = elementType;
      llvm::ConstantInt* curIndexValue = llvm::ConstantInt::get(i32Ty, static_cast<std::uint64_t>(curIndex));
      indexlist.push_back(curIndexValue);
      continue;
    }
    if (llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(curPointeeType)) {
      const llvm::StructLayout* sl = layout.getStructLayout(sTy);
      unsigned curIndex = sl->getElementContainingOffset(offsetValue);
      offsetValue -= sl->getElementOffset(curIndex);
      curPointeeType = sTy->getElementType(curIndex);
      llvm::ConstantInt* curIndexValue = llvm::ConstantInt::get(i32Ty, static_cast<std::uint64_t>(curIndex));
      indexlist.push_back(curIndexValue);
      continue;
    }
    // otherwise it is an elementary value and we cannot do further GEP
    break;
  }
  llvm::GetElementPtrInst* resultGEP = nullptr;
  if (!unresolvedNonConstOffset) {
    // let the caller handle the remaining offset
    remainingOffset = offsetValue;
    // ok, the offset is resolved
    // create the gep
    resultGEP = llvm::GetElementPtrInst::Create(srcPointeeType, srcValue, indexlist);
    resultGEP->insertBefore(i8gep);

    if (offsetValue == 0) {
      assert (getPointerElementType(llvm::cast<llvm::PointerType>(resultGEP->getType())) == curPointeeType);
    }
  } else {
    if (offsetValue != 0) {
      // probably something is wrong; we cannot do the conversion
      return nullptr;
    }
    // check if we have indices into array
    // we should keep indexing until we see a field small enough
    bool isLastIndexIntoArray = false;
    unsigned numZerosToAdd = 0;
    while (layout.getTypeAllocSize(curPointeeType).getFixedSize() > nonConstOffsetStep) {
      if (llvm::ArrayType* aTy = llvm::dyn_cast<llvm::ArrayType>(curPointeeType)) {
        curPointeeType = aTy->getElementType();
        numZerosToAdd += 1;
        isLastIndexIntoArray = true;
      } else if (llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(curPointeeType)) {
        curPointeeType = sTy->getElementType(0);
        numZerosToAdd += 1;
        isLastIndexIntoArray = false;
      } else {
        break;
      }
    }
    // since we have a non-constant component, we should be indexing into an array
    // if not, we cannot handle this for now
    if (!(isLastIndexIntoArray && numZerosToAdd > 0)) {
      return nullptr;
    }
    // step 1: get the real index
    std::uint64_t curPointeeSize = layout.getTypeAllocSize(curPointeeType).getFixedSize();
    llvm::Value* lastIndexValue = unresolvedNonConstOffset;
    if (unresolvedNonConstOffset->getType() != i32Ty) {
      llvm::Value* casted = llvm::CastInst::CreateIntegerCast(unresolvedNonConstOffset, i32Ty, true, "i8gep_indexconv", i8gep);
      lastIndexValue = casted;
    }
    if (curPointeeSize == nonConstOffsetStep) {
      // nothing else to do here
    } else {
      // need to create a multiplication or shift to create the desired index
      llvm::ConstantInt* pointeeSize = llvm::ConstantInt::get(i32Ty, curPointeeSize);
      llvm::Instruction* mulInst = llvm::BinaryOperator::Create(llvm::Instruction::Mul, lastIndexValue, pointeeSize, "i8gep_indexmul", i8gep);
      lastIndexValue = mulInst;
    }
    llvm::ConstantInt* zeroValue = llvm::ConstantInt::get(i32Ty, 0);
    for (unsigned i = 1; i < numZerosToAdd; ++i) {
      indexlist.push_back(zeroValue);
    }
    indexlist.push_back(lastIndexValue);

    resultGEP = llvm::GetElementPtrInst::Create(srcPointeeType, srcValue, indexlist);
    resultGEP->insertBefore(i8gep);
  }

  resultGEP->takeName(i8gep);
  resultGEP->copyMetadata(*i8gep);
  return resultGEP;
}

void preTransform_replaceUses_postGEPReplacement(llvm::GetElementPtrInst* replacementGEP, llvm::Instruction* oldInstr)
{
  if (replacementGEP->getType() == oldInstr->getType()) {
    oldInstr->replaceAllUsesWith(replacementGEP);
  } else {
    // we go through all users, and if there is a bitcast casting to the corrected type (the type of replacementGEP), directly replace the value
    // if there are still uses left, we create a bitcast of replacementGEP to i8* and redirect all uses to it
    llvm::SmallVector<llvm::BitCastInst*> deadcasts;
    for (auto& u : oldInstr->uses()) {
      llvm::Instruction* instrUser = llvm::cast<llvm::Instruction>(u.getUser());
      if (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(instrUser)) {
        if (bc->getType() == replacementGEP->getType()) {
          bc->replaceAllUsesWith(replacementGEP);
          deadcasts.push_back(bc);
        }
      }
    }
    for (llvm::BitCastInst* bc : deadcasts) {
      bc->eraseFromParent();
    }
    if (!oldInstr->use_empty()) {
      llvm::BitCastInst* replacementCast = new llvm::BitCastInst(replacementGEP, oldInstr->getType());
      replacementCast->insertBefore(oldInstr);
      oldInstr->replaceAllUsesWith(replacementCast);
      // we also try to replace the cast with gep here
      unsigned numZeros = preTransform_testIfCanDoGepConversion(replacementCast, replacementGEP);
      if (numZeros > 0) {
        llvm::IntegerType* i64Ty = llvm::Type::getInt64Ty(replacementGEP->getContext());
        llvm::IntegerType* i32Ty = llvm::Type::getInt32Ty(replacementGEP->getContext());
        llvm::GetElementPtrInst* castReplacementGEP = preTransform_getZeroIndexGEPForCastReplacement(replacementCast, replacementGEP, getPointerElementType(replacementGEP->getType()), numZeros, i64Ty, i32Ty);
        preTransform_replaceUses_postGEPReplacement(castReplacementGEP, replacementCast);
        replacementCast->eraseFromParent();
      }
    }
  }
}

void preTransform_handleOffsetFromGEPReplacement(llvm::GetElementPtrInst* replacementGEP, llvm::GetElementPtrInst* i8gep, int64_t remainingOffset, llvm::IntegerType* i64Ty)
{
  if (remainingOffset != 0) {
    // we create a cast and another gep to push the pointer to the desired position
    llvm::Instruction* srcPtr = replacementGEP;
    if (getPointerElementType(llvm::cast<llvm::PointerType>(replacementGEP->getType()))->isIntegerTy(8)) {
      // do nothing
    } else {
      // need to create a cast to convert the pointer to i8*
      llvm::BitCastInst* tailBC = new llvm::BitCastInst(replacementGEP, llvm::Type::getInt8PtrTy(replacementGEP->getContext(), replacementGEP->getType()->getPointerAddressSpace()));
      tailBC->insertAfter(replacementGEP);
      srcPtr = tailBC;
    }
    llvm::ConstantInt* lastIndex = llvm::ConstantInt::get(i64Ty, static_cast<std::uint64_t>(remainingOffset));
    llvm::GetElementPtrInst* lastGEP = llvm::GetElementPtrInst::Create(llvm::Type::getInt8Ty(replacementGEP->getContext()), srcPtr, {lastIndex});
    lastGEP->insertAfter(srcPtr);
    i8gep->replaceAllUsesWith(lastGEP);
  } else {
    // the offset is resolved exactly
    // however the type is likely not matching
    preTransform_replaceUses_postGEPReplacement(replacementGEP, i8gep);
  }
}

// return true if we should delete this instruction
bool pretransform_typejoining(const llvm::DataLayout& layout, llvm::BitCastInst* bc, llvm::Type* bcPointeeType, llvm::Value* src, const llvm::DominatorTree& DT, llvm::DenseSet<llvm::Instruction*>& badcastedPointers, llvm::IntegerType* i64Ty, llvm::IntegerType* i32Ty)
{
  // check if there are more than one cast satisfying the requirement
  // if all competingCasts can be converted using the current bc, which means
  // * bc dominates all competingCasts
  // * other candidates can be converted to gep from current bc
  // then we still do the conversion
  llvm::SmallVector<llvm::BitCastInst*> competingCasts;
  for (const auto& use : src->uses()) {
    llvm::User* user = use.getUser();

    // skip the current user we are working on
    if (user == bc) {
      continue;
    }

    if (llvm::BitCastInst* candidate = llvm::dyn_cast<llvm::BitCastInst>(user)) {
      llvm::PointerType* ty = llvm::cast<llvm::PointerType>(candidate->getDestTy());
      if (!ty->isArrayTy() && !ty->isStructTy()) {
        continue;
      }
      // if we found a cast that we cannot dominate, do not do the transform (maybe the other cast is the "canonical" one)
      if (!isInstrDominates(bc, candidate, DT)) {
        return false;
      }
      // ok, candidate found
      competingCasts.push_back(candidate);
    }
  }
  // if any of competing casts cannot be converted, no need to continue
  llvm::SmallVector<unsigned> competingCastConversionStat;
  for (llvm::BitCastInst* candidate : competingCasts) {

    unsigned numZeros = preTransform_testIfCanDoGepConversion(bc, candidate);
    if (numZeros == 0) {
      badcastedPointers.insert(bc);
      return false;
    }

    competingCastConversionStat.push_back(numZeros);
  }

  // now it should be fine to do the replacement
  // replace the competing casts first
  for (std::size_t i = 0, n = competingCasts.size(); i < n; ++i) {
    llvm::BitCastInst* oldCast = competingCasts[i];
    unsigned numZeros = competingCastConversionStat[i];
    llvm::GetElementPtrInst* replacementGEP = preTransform_getZeroIndexGEPForCastReplacement(oldCast, bc, bcPointeeType, numZeros, i64Ty, i32Ty);
    preTransform_replaceUses_postGEPReplacement(replacementGEP, oldCast);
    oldCast->eraseFromParent();
  }
  // start to handle non-competing cases
  // because we may erase instructions during iterating (which can invalidate the use list), we first store all operation, then apply them
  llvm::SmallVector<std::pair<llvm::BitCastInst*, unsigned>> pendingCastUses;
  llvm::SmallVector<llvm::GetElementPtrInst*> pendingGEPUses;
  llvm::SmallVector<llvm::BitCastInst*> identicalCastUsers;// bitcast that casts to the same type as bc
  for (const auto& use : src->uses()) {
    llvm::User* user = use.getUser();
    if (user == bc) {
      continue;
    }
    if (llvm::BitCastInst* anotherBC = llvm::dyn_cast<llvm::BitCastInst>(user)) {
      if (anotherBC->getType() == bc->getType()) {
        identicalCastUsers.push_back(anotherBC);
        continue;
      }
      unsigned numZeros = preTransform_testIfCanDoGepConversion(anotherBC, bc);
      if (numZeros == 0) {
        // cannot convert
        continue;
      }
      pendingCastUses.emplace_back(anotherBC, numZeros);
      continue;
    }
    if (llvm::GetElementPtrInst* plainGEP = llvm::dyn_cast<llvm::GetElementPtrInst>(user)) {
      assert(plainGEP->getSourceElementType()->isIntegerTy(8) && (plainGEP->getNumIndices() == 1));
      if (plainGEP->hasAllConstantIndices()) {
        pendingGEPUses.push_back(plainGEP);
      }
    }
  }
  for (llvm::BitCastInst* cast : identicalCastUsers) {
    cast->replaceAllUsesWith(bc);
    cast->eraseFromParent();
  }
  for (const auto& p : pendingCastUses) {
    llvm::BitCastInst* oldCast = p.first;
    llvm::GetElementPtrInst* replacementGEP = preTransform_getZeroIndexGEPForCastReplacement(oldCast, bc, bcPointeeType, p.second, i64Ty, i32Ty);
    preTransform_replaceUses_postGEPReplacement(replacementGEP, oldCast);
    oldCast->eraseFromParent();
  }
  if (!pendingGEPUses.empty()) {
    for (llvm::GetElementPtrInst* i8gep : pendingGEPUses) {
      std::int64_t remainingOffset = 0;
      llvm::GetElementPtrInst* replacementGEP = preTransform_getTypedGEPForI8GEPReplacement(layout, i8gep, bc, bcPointeeType, remainingOffset, i64Ty, i32Ty);
      if (!replacementGEP) {
        psan_unreachable("Failed to convert constant GEP");
      }
      preTransform_handleOffsetFromGEPReplacement(replacementGEP, i8gep, remainingOffset, i64Ty);
      assert (i8gep->use_empty());
      i8gep->eraseFromParent();
    }
  }

  // when we do the replacements, we may have uses not being dominated by the bitcast
  // we will clone the current cast to the earliest dominating point so that all users can get it
  if (llvm::Instruction* insertBeforeInst = getInsertingPointForInstrHoisting(DT, bc)) {
    llvm::Instruction* newSrc = bc->clone();
    newSrc->insertBefore(insertBeforeInst);
    newSrc->takeName(bc);
    newSrc->copyMetadata(*bc);
    bc->replaceAllUsesWith(newSrc);
    // the current instruction should be deleted if we have moved it
    return true;
  }

  // we are not deleting the current cast, so return false
  return false;
}

bool isSubobjectIndexingGEP(const llvm::GetElementPtrInst* gep)
{
  // if any index is going into a struct, we consider it as subobject indexing, even if it has array indexing before/after that
  llvm::Type* elementTy = gep->getSourceElementType();
  for (unsigned i = 1, n = gep->getNumIndices(); i < n; ++i) {
    if (llvm::isa<llvm::StructType>(elementTy)) {
      return true;
    }
    if (llvm::ArrayType* aTy = llvm::dyn_cast<llvm::ArrayType>(elementTy)) {
      elementTy = aTy->getArrayElementType();
      continue;
    }
    if (llvm::VectorType* vTy = llvm::dyn_cast<llvm::VectorType>(elementTy)) {
      // we do not handle vectors
      (void) vTy;
      return false;
    }
  }
  // if we went through all indices and did not see a step into a struct, this is not doing subobject indexing
  return false;
}

void pretransform_typeconversion_v2(llvm::Function* func, const llvm::DominatorTree& DT, llvm::DenseSet<llvm::Instruction*>& badcastedPointers)
{
  // in this version, we rely on later code to find badcasts
  (void) badcastedPointers;
  auto& ctx = func->getContext();
  llvm::IntegerType* i64Ty = llvm::Type::getInt64Ty(ctx);
  llvm::IntegerType* i32Ty = llvm::Type::getInt32Ty(ctx);
  auto& layout = func->getParent()->getDataLayout();
  llvm::DenseSet<llvm::Instruction*> dummySet;
  // step 0: find "store i8* ptr, (bitcast T** to i8**) addr" and convert to "store T* ptr, addr"
  // this should create more bitcast from i8* to other types and make the following steps easier
  for (llvm::BasicBlock& BB : *func) {
    for (auto iter = BB.begin(); iter != BB.end();) {
      llvm::Instruction* instr = &*iter;
      ++iter;
      if (llvm::StoreInst* store = llvm::dyn_cast<llvm::StoreInst>(instr)) {
        llvm::Value* value = store->getValueOperand();
        llvm::Value* addr = store->getPointerOperand();
        llvm::PointerType* valueTy = llvm::dyn_cast<llvm::PointerType>(value->getType());
        if (valueTy && getPointerElementType(valueTy)->isIntegerTy(8)) {
          llvm::Value* castedSrcAddr = nullptr; // get address before the bitcast
          if (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(addr)) {
            castedSrcAddr = bc->getOperand(0);
          } else if (llvm::ConstantExpr* ce = llvm::dyn_cast<llvm::ConstantExpr>(addr)) {
            if (ce->getOpcode() == llvm::Instruction::BitCast) {
              castedSrcAddr = ce->getOperand(0);
            }
          }
          if (!castedSrcAddr) {
            continue;
          }
          llvm::PointerType* castedSrcAddrTy = llvm::dyn_cast<llvm::PointerType>(castedSrcAddr->getType());
          if (!castedSrcAddrTy) {
            continue;
          }
          llvm::PointerType* castedSrcAddrPointeeTy = llvm::dyn_cast<llvm::PointerType>(getPointerElementType(castedSrcAddrTy));
          if (!castedSrcAddrPointeeTy) {
            continue;
          }
          llvm::BitCastInst* castedValue = new llvm::BitCastInst(value, castedSrcAddrPointeeTy);
          castedValue->insertBefore(store);
          llvm::StoreInst* newStore = new llvm::StoreInst(castedValue, castedSrcAddr, store->isVolatile(), store->getAlign(), store->getOrdering(), store->getSyncScopeID());
          newStore->insertBefore(store);
          newStore->takeName(store);
          newStore->copyMetadata(*store);
          store->eraseFromParent();
          if (llvm::Instruction* bc = llvm::dyn_cast<llvm::Instruction>(addr)) {
            if (bc->use_empty()) {
              bc->eraseFromParent();
            }
          }
        }
      }
    }
  }
  // step 1: find all casts from i8* to other types and determine a unique type for each of them
  for (llvm::BasicBlock& BB : *func) {
    for (auto iter = BB.begin(); iter != BB.end(); ++iter) {
      llvm::Instruction* instr = &*iter;
      if (llvm::PointerType* ptrTy = llvm::dyn_cast<llvm::PointerType>(instr->getType())) {
        if (getPointerElementType(ptrTy)->isIntegerTy(8)) {
          pretransform_castjoining(instr, func, DT, dummySet);
        }
      }
    }
  }

  auto getCastSourceValue = [](llvm::Value* v) -> llvm::Value* {
    while (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(v)) {
      if (isInstrAnnotatedWith(bc, "psan_castjoin")) {
        break;
      }
      v = bc->getOperand(0);
    }
    return v;
  };
  auto tryReapCast = [](llvm::BitCastInst* bc) -> void {
    llvm::BitCastInst* curInstr = bc;
    while (curInstr && curInstr->use_empty()) {
      llvm::BitCastInst* nextSrc = llvm::dyn_cast<llvm::BitCastInst>(curInstr->getOperand(0));
      curInstr->eraseFromParent();
      curInstr = nextSrc;
    }
  };

  // step 2: cast normalization: for each bitcast, we normalize it so that:
  // 1. it is not using another bitcast as the source (except the root cast, with "psan_castjoin" metadata)
  // 2. we try to convert it into a GEP if possible
  for (llvm::BasicBlock& BB : *func) {
    for (auto iter = BB.begin(), iterEnd = BB.end(); iter != iterEnd;) {
      llvm::Instruction* instr = &*iter;
      ++iter;
      llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(instr);
      if (!bc) {
        continue;
      }
      if (isInstrAnnotatedWith(instr, "psan_castjoin")) {
        continue;
      }
      llvm::Value* srcValue = getCastSourceValue(bc->getOperand(0));
      if (!srcValue->getType()->isPointerTy()) {
        continue;
      }
      llvm::PointerType* srcPtrTy = llvm::cast<llvm::PointerType>(srcValue->getType());
      llvm::Type* srcPointeeType = getPointerElementType(srcPtrTy);
      if (!srcPointeeType->isSized()) {
        // ignore cast from opaque-type pointers
        continue;
      }
      // if this cast is casting to i8*, we try to find gep users and correct their types
      if (getPointerElementType(bc->getType())->isIntegerTy(8)) {
        for (auto iter = bc->use_begin(), iterEnd = bc->use_end(); iter != iterEnd;) {
          llvm::Use& u = *iter;
          ++iter;
          llvm::GetElementPtrInst* gep = llvm::dyn_cast<llvm::GetElementPtrInst>(u.getUser());
          if (!gep) {
            continue;
          }
          if (!gep->getSourceElementType()->isIntegerTy(8)) {
            psan_unreachable("Unexpected GEP source type");
          }
          std::int64_t remainingOffset = 0;
          llvm::GetElementPtrInst* replacementGEP = preTransform_getTypedGEPForI8GEPReplacement(func->getParent()->getDataLayout(), gep, srcValue, srcPointeeType, remainingOffset, i64Ty, i32Ty);
          if (replacementGEP) {
            preTransform_handleOffsetFromGEPReplacement(replacementGEP, gep, remainingOffset, i64Ty);
          }
        }
      }
      // we only want to do the conversion if the cast is used by non-cast instructions
      bool hasNonCastUses = false;
      for (auto iterUse = bc->use_begin(), iterUseEnd = bc->use_end(); iterUse != iterUseEnd;) {
        llvm::Use& u = *iterUse;
        ++iterUse;
        if (llvm::isa<llvm::BitCastInst>(u.getUser())) {
          continue;
        } else {
          hasNonCastUses = true;
          break;
        }
      }
      if (!hasNonCastUses) {
        llvm::BitCastInst* curInstr = bc;
        while (curInstr->use_empty()) {
          llvm::BitCastInst* nextSrc = llvm::dyn_cast<llvm::BitCastInst>(curInstr->getOperand(0));
          curInstr->eraseFromParent();
          curInstr = nextSrc;
        }
        continue;
      }
      if (bc->getType() == srcValue->getType()) {
        bc->replaceAllUsesWith(srcValue);
        bc->eraseFromParent();
        continue;
      }
      // try to convert it to a gep
      unsigned numZeros = preTransform_testIfCanDoGepConversion_typeonly(getPointerElementType(llvm::cast<llvm::PointerType>(bc->getType())), srcValue);
      if (numZeros > 0) {
        llvm::IntegerType* i64Ty = llvm::Type::getInt64Ty(func->getContext());
        llvm::IntegerType* i32Ty = llvm::Type::getInt32Ty(func->getContext());
        llvm::GetElementPtrInst* replacementGEP = preTransform_getZeroIndexGEPForCastReplacement(bc, srcValue, srcPointeeType, numZeros, i64Ty, i32Ty);
        preTransform_replaceUses_postGEPReplacement(replacementGEP, bc);
        bc->eraseFromParent();
      } else {
        // we cannot convert it to a GEP
        if (srcValue != bc->getOperand(0)) {
          llvm::BitCastInst* newBC = new llvm::BitCastInst(srcValue, bc->getType());
          newBC->insertBefore(bc);
          newBC->takeName(bc);
          newBC->copyMetadata(*bc);
          bc->replaceAllUsesWith(newBC);
          bc->eraseFromParent();
        }
      }
    }
  }

  // once we reach here, all casts and geps that we are possible to convert are converted
  // step 3: user-side type transformation
  for (llvm::BasicBlock& BB : *func) {
    for (auto iter = BB.begin(), iterEnd = BB.end(); iter != iterEnd;) {
      llvm::Instruction* instr = &*iter;
      ++iter;
      if (llvm::StoreInst* store = llvm::dyn_cast<llvm::StoreInst>(instr)) {
        // if the address is casted, we try to move the cast to the value
        llvm::Value* addr = getCastSourceValue(store->getPointerOperand());
        if (addr != store->getPointerOperand()) {
          // make sure the store size is not changed and bitcast is valid
          llvm::Type* currentStoredTy = store->getValueOperand()->getType();
          llvm::Type* backingStoreTy = getPointerElementType(addr->getType());
          if (currentStoredTy->isPointerTy() && backingStoreTy->isPointerTy() && layout.getTypeStoreSize(currentStoredTy) == layout.getTypeStoreSize(backingStoreTy)) {
            // we can do the conversion
            // check if the value is also already casted; if yes, we don't bother to create a new cast
            llvm::Value* newStoreValue = nullptr;
            llvm::Value* curStoreValue = store->getValueOperand();
            while (curStoreValue->getType() != backingStoreTy) {
              llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(curStoreValue);
              if (!bc || isInstrAnnotatedWith(bc, "psan_castjoin")) {
                break;
              }
              curStoreValue = bc->getOperand(0);
            }
            if (curStoreValue->getType() != backingStoreTy) {
              llvm::BitCastInst* newBC = new llvm::BitCastInst(curStoreValue, backingStoreTy);
              newBC->insertBefore(store);
              newStoreValue = newBC;
            } else {
              newStoreValue = curStoreValue;
            }
            llvm::StoreInst* newStore = new llvm::StoreInst(newStoreValue, addr, store->isVolatile(), store);
            store->replaceAllUsesWith(newStore);
            newStore->takeName(store);
            newStore->copyMetadata(*store);
            store->eraseFromParent();
            continue;
          }
        }
      } else if (llvm::ICmpInst* icmp = llvm::dyn_cast<llvm::ICmpInst>(instr)) {
        llvm::Value* lhs = icmp->getOperand(0);
        if (!isDataPointerTy(lhs)) {
          // skip if this icmp is not comparing pointers
          continue;
        }
        llvm::Value* rhs = icmp->getOperand(1);
        // try to get rid of casts
        llvm::Value* lhsCastSrc = getCastSourceValue(lhs);
        llvm::Value* rhsCastSrc = getCastSourceValue(rhs);
        llvm::PointerType* lhsPtrTy = llvm::dyn_cast<llvm::PointerType>(lhsCastSrc->getType());
        llvm::PointerType* rhsPtrTy = llvm::dyn_cast<llvm::PointerType>(rhsCastSrc->getType());
        if (!lhsPtrTy || !rhsPtrTy) {
          psan_unreachable("Unexpected non-pointer type in icmp");
        }
        if (lhsCastSrc != lhs || rhsCastSrc != rhs) {
          // at least one of the operands is casted; consider simplifying the icmp
          // if we are comparing one pointer with a null pointer, we can reconstruct the new null pointer without cast
          llvm::Value* newLhs = nullptr;
          llvm::Value* newRhs = nullptr;
          if (llvm::isa<llvm::ConstantPointerNull>(lhs)) {
            newLhs = llvm::ConstantPointerNull::get(rhsPtrTy);
            newRhs = rhsCastSrc;
          } else if (llvm::isa<llvm::ConstantPointerNull>(rhs)) {
            newRhs = llvm::ConstantPointerNull::get(lhsPtrTy);
            newLhs = lhsCastSrc;
          } else if (lhsPtrTy == rhsPtrTy) {
            newLhs = lhsCastSrc;
            newRhs = rhsCastSrc;
          }
          if (newLhs && newRhs) {
            llvm::ICmpInst* newIcmp = new llvm::ICmpInst(icmp, icmp->getPredicate(), newLhs, newRhs);
            newIcmp->takeName(icmp);
            newIcmp->copyMetadata(*icmp);
            icmp->replaceAllUsesWith(newIcmp);
            icmp->eraseFromParent();
          }
        }
      } else if (llvm::LoadInst* load = llvm::dyn_cast<llvm::LoadInst>(instr)) {
        // try to do load type conversion here
        // load (bitcast T** dptr to U**) --> bitcast (load dptr) to U*
        llvm::Value* src = getCastSourceValue(load->getPointerOperand());
        if (src != load->getPointerOperand()) {
          llvm::PointerType* srcPtrTy = llvm::cast<llvm::PointerType>(src->getType());
          llvm::Type* srcElementTy = getPointerElementType(srcPtrTy);
          if (srcElementTy->isPointerTy() && load->getType()->isPointerTy() && layout.getTypeStoreSize(srcElementTy) == layout.getTypeStoreSize(load->getType())) {
            llvm::LoadInst* newLoad = new llvm::LoadInst(srcElementTy, src, "", load->isVolatile(), load);
            newLoad->takeName(load);
            newLoad->copyMetadata(*load);
            llvm::BitCastInst* newCast = new llvm::BitCastInst(newLoad, load->getType(), "", load);
            load->replaceAllUsesWith(newCast);
            load->eraseFromParent();
          }
        }
      }
    }
  }

  // step 4: try to reap all bitcasts that are not used
  for (llvm::BasicBlock& BB : *func) {
    for (auto iter = BB.begin(), iterEnd = BB.end(); iter != iterEnd;) {
      llvm::Instruction* instr = &*iter;
      ++iter;
      llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(instr);
      if (!bc) {
        continue;
      }
      if (bc->use_empty()) {
        tryReapCast(bc);
      }
    }
  }
}

/**
 * @brief convert common patterns on gep and casts so that the pointer types match better with the points-to object type
 *
 * TODO detailed documentation
*/
void pretransform_typeconversion(llvm::Function* func, const llvm::DominatorTree& DT, llvm::DenseSet<llvm::Instruction*>& badcastedPointers)
{
  // we don't need to do gep breaking here, but the rest of conversion is needed:
  // (cast joining, general type joining, store type conversion, void pointer load conversion)
  // for better efficiency, we only go over all instructions once
  // for a non-bitcast instruction: try the cast joining and continue
  //    (we can be sure that the new joining cast must be visited later on after this "source")
  //    (umm we should just traverse all basic blocks in the order of the dominator tree then, from the root to the leaves)
  // for a bitcast instruction: try the rest of pattern matching

  // we traverse all basic blocks in the descending order in the dominator tree so that if we insert instructions after the current one (with data dependency),
  // we can ensure that the new instructions will be visited later on (because the new instruction is either in the same BB or in a BB dominated by the current BB)

  llvm::SmallVector<llvm::BasicBlock*> worklist;
  worklist.push_back(DT.getRoot());

  const llvm::DataLayout& layout = func->getParent()->getDataLayout();
  llvm::LLVMContext& ctx = func->getParent()->getContext();
  llvm::IntegerType* i64Ty = llvm::Type::getInt64Ty(ctx);
  llvm::IntegerType* i32Ty = llvm::Type::getInt32Ty(ctx);

  llvm::DenseSet<llvm::BasicBlock*> enqueuedBlocks;
  enqueuedBlocks.insert(DT.getRoot());

  while (!worklist.empty()) {
    llvm::BasicBlock* curBlock = worklist.back();
    worklist.pop_back();
    llvm::SmallVector<llvm::BasicBlock*> descendants;
    DT.getDescendants(curBlock, descendants);
    for (llvm::BasicBlock* b : descendants) {
      if (b == curBlock)
        continue;
      if (enqueuedBlocks.insert(b).second) {
        worklist.push_back(b);
      }
    }
    llvm::SmallVector<llvm::Instruction*> instrToDelete;
    auto clearDeadInstrs = [&]() {
      for (llvm::Instruction* instr : instrToDelete) {
        instr->eraseFromParent();
      }
      instrToDelete.clear();
    };
    for (auto iter = curBlock->begin(), iterEnd = curBlock->end(); iter != iterEnd; ++iter) {
      clearDeadInstrs();
      llvm::Instruction* instr = &*iter;
      llvm::PointerType* ptrTy = llvm::dyn_cast<llvm::PointerType>(instr->getType());
      // most of our pattern matching is on pointers
      // if the instruction is not producing pointers, we exit early
      if (!ptrTy) {
        if (llvm::StoreInst* store = llvm::dyn_cast<llvm::StoreInst>(instr)) {
          // store type conversion: when we find the following pattern:
          // store (bitcast %v to T), (bitcast %p to T*) where %v has type U and %p has type U*
          // then we replace it with
          // store %v, %P
          // another case is that if %p points to a struct S and %v matches the type of the first struct member,
          // and we will replace it with:
          // store %v, gep %p
          llvm::BitCastInst* valueBC = llvm::dyn_cast<llvm::BitCastInst>(store->getValueOperand());
          llvm::BitCastInst* ptrBC = llvm::dyn_cast<llvm::BitCastInst>(store->getPointerOperand());
          if (valueBC && ptrBC) {
            llvm::Value* rawValue = valueBC->getOperand(0);
            llvm::Value* rawPtr = ptrBC->getOperand(0);
            bool isCanErase = false;
            if (getPointerElementType(ptrBC->getSrcTy()) == valueBC->getSrcTy()) {
              assert (getPointerElementType(rawPtr->getType()) == rawValue->getType());
              llvm::StoreInst* newStore = new llvm::StoreInst(rawValue, rawPtr, store->isVolatile(), store);
              store->replaceAllUsesWith(newStore);
              newStore->takeName(store);
              newStore->copyMetadata(*store);
              isCanErase = true;
            } else if (unsigned numZeros = preTransform_testIfCanDoGepConversion_typeonly(rawValue->getType(), rawPtr)) {
              // try the second pattern
              llvm::SmallVector<llvm::Value*> indexlist;
              // the first zero is i64; subsequent ones are i32
              indexlist.push_back(llvm::ConstantInt::get(i64Ty, 0));
              for (unsigned i = 0; i < numZeros; ++i) {
                indexlist.push_back(llvm::ConstantInt::get(i32Ty, 0));
              }
              llvm::GetElementPtrInst* gep = llvm::GetElementPtrInst::Create(getPointerElementType(rawPtr->getType()), rawPtr, indexlist);
              gep->insertBefore(store);
              llvm::Value* newValue = rawValue;
              if (gep->getResultElementType() != rawValue->getType()) {
                llvm::BitCastInst* newCast = new llvm::BitCastInst(rawValue, gep->getResultElementType());
                newCast->insertAfter(gep);
                newValue = newCast;
              }
              llvm::StoreInst* newStore = new llvm::StoreInst(newValue, gep, store->isVolatile(), store);
              store->replaceAllUsesWith(newStore);
              newStore->takeName(store);
              newStore->copyMetadata(*store);
              isCanErase = true;
            }
            if (isCanErase) {
              // before finishing, check if the two casts can be removed
              store->setOperand(0, llvm::UndefValue::get(valueBC->getType()));
              store->setOperand(1, llvm::UndefValue::get(ptrBC->getType()));
              if (valueBC->use_empty()) {
                valueBC->eraseFromParent();
              }
              if (ptrBC->use_empty()) {
                ptrBC->eraseFromParent();
              }
              instrToDelete.push_back(store);
            }
          }
        } else if (llvm::ICmpInst* icmp = llvm::dyn_cast<llvm::ICmpInst>(instr)) {
          // if we are comparing a casted pointer value with NULL, we just compare the value without cast
          // also, if both pointer operands are casted from another type except i8*, use the original type for comparison instead
          llvm::Value* lhs = icmp->getOperand(0);
          if (!isDataPointerTy(lhs)) {
            // skip if this icmp is not comparing pointers
            continue;
          }
          llvm::Value* rhs = icmp->getOperand(1);
          // check the first case
          // for null comparison, we only transform if it is the equality comparison
          if (icmp->isEquality() && (llvm::isa<llvm::ConstantPointerNull>(lhs) || llvm::isa<llvm::ConstantPointerNull>(rhs))) {
            if (llvm::isa<llvm::ConstantPointerNull>(lhs)) {
              // should not happen but just in case
              llvm::Value* tmp = lhs;
              lhs = rhs;
              rhs = tmp;
            }
            assert (llvm::isa<llvm::ConstantPointerNull>(rhs));
            if (llvm::BitCastInst* castLhs = llvm::dyn_cast<llvm::BitCastInst>(lhs)) {
              llvm::Value* rootLhs = castLhs->getOperand(0);
              if (rootLhs->getType()->isPointerTy()) {
                // start the transform
                // set the current icmp operand to a useless first so that we can drop unnecessary casts
                icmp->setOperand(0, rhs);
                icmp->setOperand(1, rhs);
                while (true) {
                  if (castLhs->use_empty()) {
                    castLhs->eraseFromParent();
                  }
                  if (llvm::BitCastInst* nextCastLhs = llvm::dyn_cast<llvm::BitCastInst>(rootLhs)) {
                    castLhs = nextCastLhs;
                    rootLhs = nextCastLhs->getOperand(0);
                  } else {
                    break;
                  }
                }
                llvm::PointerType* ty = llvm::cast<llvm::PointerType>(rootLhs->getType());
                llvm::ICmpInst* newIcmp = new llvm::ICmpInst(icmp, llvm::ICmpInst::Predicate::ICMP_EQ, rootLhs, llvm::ConstantPointerNull::get(ty));
                newIcmp->copyMetadata(*icmp);
                newIcmp->takeName(icmp);
                icmp->replaceAllUsesWith(newIcmp);
                instrToDelete.push_back(icmp);
              }
            }
            // done for the first case
            continue;
          }
          // check the second case
          llvm::BitCastInst* lhsBC = llvm::dyn_cast<llvm::BitCastInst>(lhs);
          llvm::BitCastInst* rhsBC = llvm::dyn_cast<llvm::BitCastInst>(rhs);
          if (lhsBC && rhsBC && lhsBC->getSrcTy() == rhsBC->getSrcTy() && !getPointerElementType(lhsBC->getSrcTy())->isIntegerTy(8)) {
            llvm::Value* rootLhs = lhsBC->getOperand(0);
            llvm::Value* rootRhs = rhsBC->getOperand(0);
            llvm::ICmpInst* newIcmp = new llvm::ICmpInst(icmp, icmp->getPredicate(), rootLhs, rootRhs);
            newIcmp->copyMetadata(*icmp);
            newIcmp->takeName(icmp);
            icmp->replaceAllUsesWith(newIcmp);
            instrToDelete.push_back(icmp);
            if (lhsBC->use_empty()) {
              lhsBC->eraseFromParent();
            }
            if (rhsBC->use_empty()) {
              rhsBC->eraseFromParent();
            }
            continue;
          }
        }
        continue;
      }
      // now move on to the pattern matching on pointer-type instructions
      bool shouldRemoveCurInst = false;
      if (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(instr)) {
        llvm::Value* src = bc->getOperand(0);
        llvm::PointerType* srcPtrTy = llvm::dyn_cast<llvm::PointerType>(src->getType());
        if (!srcPtrTy) {
          continue;
        }

        // pattern-matching based transforms on casts (general type joining, etc)
        if (getPointerElementType(srcPtrTy)->isIntegerTy(8)) {
          // we found a bitcast from i8* to ptrTy; try general type joining
          llvm::Type* destElementTy = getPointerElementType(ptrTy);
          if (destElementTy->isArrayTy() || destElementTy->isStructTy()) {
            shouldRemoveCurInst |= pretransform_typejoining(layout, bc, destElementTy, src, DT, badcastedPointers, i64Ty, i32Ty);
            if (shouldRemoveCurInst) {
              assert (instr->use_empty());
            }
          }
        }

        if (!shouldRemoveCurInst) {
          if (llvm::StructType* srcStructTy = llvm::dyn_cast<llvm::StructType>(getPointerElementType(srcPtrTy))) {
            // we found a bitcast from U* to T* where U is a struct type
            // we check whether the type U has T* (or another pointer type V*) as its first member
            // if yes, we replace it with a gep followed by a cast
            llvm::PointerType* dstPtrTy = llvm::cast<llvm::PointerType>(bc->getType());
            llvm::Type* dstElementTy = getPointerElementType(dstPtrTy);
            bool isCastToDoublePtr = dstElementTy->isPointerTy();
            unsigned numZeros = 0;
            llvm::StructType* curStructTy = srcStructTy;
            llvm::Type* gepElementType = nullptr;
            bool isGoodToConvert = false;
            while (true) {
              numZeros += 1;
              llvm::Type* firstElementTy = curStructTy->getElementType(0);
              gepElementType = firstElementTy;
              if (firstElementTy == dstElementTy) {
                // perfect match
                isGoodToConvert = true;
                break;
              }
              if (firstElementTy->isPointerTy() && isCastToDoublePtr) {
                // need a cast, but is also good
                isGoodToConvert = true;
                break;
              }
              llvm::StructType* nextStructTy = llvm::dyn_cast<llvm::StructType>(firstElementTy);
              if (!nextStructTy) {
                // not a struct type, cannot do the transform
                break;
              }
              curStructTy = nextStructTy;
            }
            if (isGoodToConvert) {
              // first create the gep
              llvm::SmallVector<llvm::Value*> indexlist;
              // the first zero is i64; subsequent ones are i32
              indexlist.push_back(llvm::ConstantInt::get(i64Ty, 0));
              llvm::ConstantInt* i32zero = llvm::ConstantInt::get(i32Ty, 0);
              for (unsigned i = 0; i < numZeros; ++i) {
                indexlist.push_back(i32zero);
              }
              llvm::GetElementPtrInst* gep = llvm::GetElementPtrInst::Create(srcStructTy, src, indexlist);
              gep->insertBefore(bc);
              llvm::Value* gepResult = gep;
              if (gepElementType != dstElementTy) {
                // need a cast; we insert it after the current bitcast so that it can participate in the subsequent optimization
                llvm::BitCastInst* newCast = new llvm::BitCastInst(gep, bc->getType());
                newCast->insertAfter(bc);
                gepResult = newCast;
              }
              assert (gepResult->getType() == bc->getType());
              bc->replaceAllUsesWith(gepResult);
              shouldRemoveCurInst = true;
            }
            // do nothing here if we cannot do the conversion
          }
        }

        if (llvm::GetElementPtrInst* srcGEP = llvm::dyn_cast<llvm::GetElementPtrInst>(src)) {
          if (!shouldRemoveCurInst && isSubobjectIndexingGEP(srcGEP)) {
            // store type conversion, second form
            // if we found a bitcast on gep and there is a store using the casted pointer, we try to move the cast to cast the value instead
            // i.e., store T value, bitcast (gep ...) to T* --> store (bitcast value to U), gep ...
            for (llvm::Use& use : bc->uses()) {
              if (llvm::StoreInst* store = llvm::dyn_cast<llvm::StoreInst>(use.getUser())) {
                if (store->getPointerOperand() == bc) {
                  // found one match
                  // see if we can cast the stored value
                  llvm::Value* storedValue = store->getValueOperand();
                  llvm::Type* targetType = srcGEP->getResultElementType();
                  if (llvm::CastInst::isBitCastable(storedValue->getType(), targetType)) {
                    // do the replacement
                    // first, get the actual stored value without cast whenever possible
                    // if the stored value is also casted, we want to get rid of the dangling bitcasts
                    // so we first drop the use of current store value
                    llvm::UndefValue* undef = llvm::UndefValue::get(storedValue->getType());
                    store->setOperand(0, undef);
                    assert(store->getValueOperand() == undef);
                    llvm::Value* curStoredValue = storedValue;
                    while (curStoredValue->getType() != targetType) {
                      if (llvm::BitCastInst* bcValue = llvm::dyn_cast<llvm::BitCastInst>(curStoredValue)) {
                        curStoredValue = bcValue->getOperand(0);
                        if (bcValue->use_empty()) {
                          bcValue->eraseFromParent();
                        }
                      } else {
                        break;
                      }
                    }
                    if (curStoredValue->getType() != targetType) {
                      // we need a cast
                      // special case handling for null pointers
                      if (llvm::isa<llvm::ConstantPointerNull>(curStoredValue)) {
                        curStoredValue = llvm::ConstantPointerNull::get(llvm::cast<llvm::PointerType>(targetType));
                      } else {
                        llvm::BitCastInst* newBC = new llvm::BitCastInst(curStoredValue, targetType, llvm::Twine(store->getName(), "vcast"), store);
                        curStoredValue = newBC;
                      }
                    }
                    llvm::StoreInst* newStore = new llvm::StoreInst(curStoredValue, srcGEP, store->isVolatile(), store->getAlign(), store);
                    store->replaceAllUsesWith(newStore);
                    newStore->takeName(store);
                    newStore->copyMetadata(*store);
                    store->eraseFromParent();
                    continue;
                  }
                }
              }
            }
            if (bc->use_empty()) {
              shouldRemoveCurInst = true;
            }
          }
        }
      } else if (llvm::LoadInst* load = llvm::dyn_cast<llvm::LoadInst>(instr)) {
        // try to do load type conversion here
        // load (bitcast T** dptr to U**) --> bitcast (load dptr) to U*
        if (llvm::BitCastInst* srcCast = llvm::dyn_cast<llvm::BitCastInst>(load->getPointerOperand())) {
          llvm::PointerType* srcCastTy = llvm::dyn_cast<llvm::PointerType>(srcCast->getSrcTy());
          llvm::PointerType* dstCastTy = llvm::dyn_cast<llvm::PointerType>(srcCast->getDestTy());
          if (srcCastTy && dstCastTy && getPointerElementType(srcCastTy)->isPointerTy() && getPointerElementType(dstCastTy)->isPointerTy()) {
            // confirmed; let's do it
            llvm::LoadInst* newLoad = new llvm::LoadInst(getPointerElementType(srcCastTy), srcCast->getOperand(0), "", load->isVolatile(), load);
            newLoad->takeName(load);
            newLoad->copyMetadata(*load);
            llvm::BitCastInst* newCast = new llvm::BitCastInst(newLoad, load->getType(), "", load);
            load->replaceAllUsesWith(newCast);
            shouldRemoveCurInst = true;
            if (srcCast->use_empty()) {
              srcCast->eraseFromParent();
            }
          }
        }
      }
      if (!shouldRemoveCurInst && !llvm::isa<llvm::BitCastInst>(instr) && !llvm::isa<llvm::GetElementPtrInst>(instr) && getPointerElementType(ptrTy)->isIntegerTy(8)) {
        pretransform_castjoining(instr, func, DT, badcastedPointers);
      }
      if (shouldRemoveCurInst) {
        instrToDelete.push_back(instr);
      }
    }
    clearDeadInstrs();
  }
}

void collectStats(StaticStats& stats, llvm::Module* srcModule, const PreTransformResult& result, const OpaqueRegionAnalysisState& state)
{
  (void) result;
  for (auto iter = state.funcInfo.begin(), iterEnd = state.funcInfo.end(); iter != iterEnd; ++iter) {
    llvm::Function* func = iter->first;
    for (auto& BB: func->getBasicBlockList()) {
      for (auto& I : BB) {
        if (!isDataPointerTy(&I)) {
          continue;
        }
        bool isTainted = state.opaqueRegionValues.count(&I) != 0;
        if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(&I)) {
          if (isAllocatorCall(call)) {
            stats.DynamicAllocationCount.increment(isTainted);
            continue;
          }
        }
        if (llvm::isa<llvm::AllocaInst>(&I)) {
          stats.AllocaCount.increment(isTainted);
          continue;
        }
        stats.PtrTypeInstrCount.increment(isTainted);
      }
    }
    for (auto& arg : func->args()) {
      if (!isDataPointerTy(&arg)) {
        continue;
      }
      bool isArgTainted = false;
      // if none of the values are tainted, we may not have the function in state.functionInterfaceOpaqueValues
      {
        auto iterIterface = state.functionInterfaceOpaqueValues.find(func);
        if (iterIterface != state.functionInterfaceOpaqueValues.end()) {
          isArgTainted = iterIterface->getSecond().test(arg.getArgNo());
        }
      }
      assert ((state.opaqueRegionValues.count(&arg) != 0) == isArgTainted);
      stats.PtrTypeParameterCount.increment(isArgTainted);
    }
  }
  for (auto& gv : srcModule->globals()) {
    stats.GlobalValueCount.increment(state.opaqueRegionValues.count(&gv) != 0);
  }
}

bool isFunctionAllocWrapper(llvm::Function* func)
{
  // sometimes alloc wrappers are not annotated with allocsize attribute
  // we need to check whether the function is allocating memory and returning the result pointer
  if (func->isDeclaration()) {
    return false;
  }
  llvm::FunctionType* funcTy = func->getFunctionType();
  llvm::PointerType* retTy = llvm::dyn_cast<llvm::PointerType>(funcTy->getReturnType());
  // if the function is not returning i8*, we don't consider it as an allocation wrapper
  // we won't benefit from inlining it
  if (!retTy || !getPointerElementType(retTy)->isIntegerTy(8)) {
    return false;
  }
  // now check all return instructions; they should be returning the return values from allocation functions
  for (auto& BB : *func) {
    for (auto& I : BB) {
      if (llvm::ReturnInst* ret = llvm::dyn_cast<llvm::ReturnInst>(&I)) {
        llvm::Value* retValue = ret->getReturnValue();
        if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(retValue)) {
          if (isAllocatorCall(call)) {
            continue;
          }
        }
        return false;
      }
    }
  }
  return true;
}

unsigned tryInlineAllocSizeFunctions(llvm::Module* srcModule, StaticStats& stats)
{
  // we first go through all functions and inline function definitions that have allocsize attribute
  // in this way, if it wraps malloc() or other memory allocation functions, we can get the type information
  // the key is the function and the value is the list of callees the function may call
  // we use this to avoid inlining (direct/indirect) recursive functions
  llvm::DenseMap<llvm::Function*, llvm::SmallVector<llvm::Function*>> allocSizeFunctions;
  for (auto& F : srcModule->functions()) {
    // skip function declarations
    if (F.getBasicBlockList().empty()) {
      continue;
    }
    if (!F.hasFnAttribute(llvm::Attribute::AllocSize)) {
      if (!isFunctionAllocWrapper(&F)) {
        continue;
      }
    }
    // we only keep track of callees that have definitions
    llvm::SmallVector<llvm::Function*> callees;
    for (llvm::BasicBlock& BB : F.getBasicBlockList()) {
      for (llvm::Instruction& I : BB) {
        if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(&I)) {
          if (llvm::Function* callee = call->getCalledFunction()) {
            if (!callee->isDeclaration()) {
              callees.push_back(callee);
            }
          }
        }
      }
    }
    allocSizeFunctions.try_emplace(&F, std::move(callees));
  }
  // now we check for recursive functions
  // we do DFS to find all recursive functions
  // when we found a non-recursive function, all its callees are also non-recursive
  llvm::DenseSet<llvm::Function*> nonRecursiveAllocSizeFunctions; // these are the functions safe to inline
  llvm::DenseSet<llvm::Function*> recursiveAllocSizeFunctions; // this also includes non-recursive functions that are calling recursive functions
  for (auto iter = allocSizeFunctions.begin(), iterEnd = allocSizeFunctions.end(); iter != iterEnd; ++iter) {
    llvm::Function* func = iter->first;
    if (nonRecursiveAllocSizeFunctions.count(func) != 0) {
      continue;
    }
    if (recursiveAllocSizeFunctions.count(func) != 0) {
      continue;
    }
    if (func->isVarArg()) {
      // we don't inline vararg functions
      continue;
    }
    llvm::SmallVector<llvm::Function*> worklist;
    llvm::DenseSet<llvm::Function*> visited;
    worklist.push_back(func);
    visited.insert(func);
    bool isRecursive = false;
    while (!worklist.empty()) {
      llvm::Function* curFunc = worklist.back();
      worklist.pop_back();
      for (llvm::Function* callee : allocSizeFunctions[curFunc]) {
        if (allocSizeFunctions.find(callee) == allocSizeFunctions.end()) {
          // callee does not have allocsize attribute; do nothing
          continue;
        }
        if (visited.insert(callee).second) {
          worklist.push_back(callee);
        } else {
          // we found a recursive function
          isRecursive = true;
          break;
        }
        if (recursiveAllocSizeFunctions.count(callee) != 0) {
          isRecursive = true;
          break;
        }
      }
      if (isRecursive) {
        break;
      }
    }
    if (isRecursive) {
      recursiveAllocSizeFunctions.insert(visited.begin(), visited.end());
    } else {
      nonRecursiveAllocSizeFunctions.insert(visited.begin(), visited.end());
    }
  }
  // now we inline all non-recursive functions
  for (llvm::Function* func : nonRecursiveAllocSizeFunctions) {
    for (auto iter = func->use_begin(); iter != func->use_end();) {
      auto* use = &*iter;
      ++iter;
      llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(use->getUser());
      if (!call) {
        continue;
      }
      if (call->getCalledFunction() != func) {
        continue;
      }
      // start inlining
      llvm::InlineFunctionInfo IFI;
      llvm::InlineFunction(*call, IFI);
    }
  }
  stats.S1PreTransform_allocSizeFuncInlinedCount = nonRecursiveAllocSizeFunctions.size();
  return nonRecursiveAllocSizeFunctions.size();
}

unsigned createStubForMemAllocFunctions(llvm::Module* srcModule, StaticStats& stats)
{
  // for functions that we do special handling
  // (e.g., malloc() creating pointer metadata or free() adding temporal safety checks),
  // if they get called through function pointers, we may not be able to find them
  // here if any function requiring special handling is called through function pointers,
  // we create a stub for it and redirect the call to the stub
  // the stub will have the same signature as the original function
  auto isFunctionRequireSpecialHandling = [](llvm::Function* func) -> bool {
    if (func->hasFnAttribute(llvm::Attribute::AllocKind)) {
      return true;
    }
    return false;
  };
  unsigned numStubs = 0;
  for (auto& F : srcModule->functions()) {
    // skip function definitions
    if (!F.getBasicBlockList().empty()) {
      continue;
    }
    if (!isFunctionRequireSpecialHandling(&F)) {
      continue;
    }
    if (F.getLinkage() != llvm::GlobalValue::LinkageTypes::ExternalLinkage) {
      continue;
    }
    if (F.getName().startswith("__psan_")) {
      continue;
    }
    llvm::Function* stubFunc = nullptr;
    for (auto iter = F.use_begin(); iter != F.use_end();) {
      auto* use = &*iter;
      ++iter;
      llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(use->getUser());
      if (call && call->getCalledFunction() == &F) {
        continue;
      }
      // this use would require a stub
      if (!stubFunc) {
        // create a stub for the function
        llvm::FunctionType* funcTy = F.getFunctionType();
        stubFunc = llvm::Function::Create(funcTy, llvm::GlobalValue::LinkageTypes::PrivateLinkage, llvm::Twine("__psan_memfunc_stub_", F.getName()), srcModule);
        stubFunc->copyAttributesFrom(&F);
        llvm::BasicBlock* entry = llvm::BasicBlock::Create(srcModule->getContext(), "entry", stubFunc);
        llvm::SmallVector<llvm::Value*> args;
        for (auto& arg : stubFunc->args()) {
          args.push_back(&arg);
        }
        llvm::CallBase* callStub = llvm::CallInst::Create(&F, args, "", entry);
        if (F.getReturnType()->isVoidTy()) {
          llvm::ReturnInst::Create(srcModule->getContext(), entry);
        } else {
          llvm::ReturnInst::Create(srcModule->getContext(), callStub, entry);
        }
        numStubs += 1;
      }
      use->set(stubFunc);
    }
  }
  return numStubs;
}

} // end anonymous namespace

llvm::StringSet<> PSan::step1_getFunctionsWithHiddenCalls(llvm::Module* srcModule)
{
  llvm::StringSet<> result;
  for (auto& gv : srcModule->globals()) {
    if (gv.getName().startswith("llvm.")) {
      // populate functionsWithHiddenCalls if needed
      if (gv.getName() == "llvm.used" || gv.getName() == "llvm.compiler.used") {
        llvm::ConstantArray* usedArray = llvm::cast<llvm::ConstantArray>(gv.getInitializer());
        for (unsigned i = 0, n = usedArray->getNumOperands(); i < n; ++i) {
          llvm::Constant* usedValue = usedArray->getOperand(i);
          if (llvm::GlobalValue* usedGV = llvm::dyn_cast<llvm::GlobalValue>(usedValue)) {
            if (llvm::Function* F = llvm::dyn_cast<llvm::Function>(usedGV)) {
              result.insert(F->getName());
            }
          }
        }
      } else if (gv.getName() == "llvm.global_ctor" || gv.getName() == "llvm.global_dtors") {
        llvm::ConstantArray* ctorArray = llvm::cast<llvm::ConstantArray>(gv.getInitializer());
        for (unsigned i = 0, n = ctorArray->getNumOperands(); i < n; ++i) {
          llvm::Constant* ctorValue = ctorArray->getOperand(i);
          if (llvm::ConstantStruct* ctorStruct = llvm::dyn_cast<llvm::ConstantStruct>(ctorValue)) {
            llvm::Constant* ctorFunc = ctorStruct->getOperand(1);
            if (llvm::Function* F = llvm::dyn_cast<llvm::Function>(ctorFunc)) {
              result.insert(F->getName());
            }
          }
        }

      }
    }
  }
  return result;
}

PreTransformResult PSan::step1_pretransform(llvm::Module* srcModule, StaticStats& stats)
{
  // step 1: run type conversion for each function, and also get a base set of bad types
  // step 2: look at each instr producing pointers closer, and check whether the points-to type is safe
  // step 3: run interprocedural taint analysis to determine which parts of the program to generate SVFG

  PreTransformResult result;
  OpaqueRegionAnalysisState state;

  step1_opaque_region_analysis_initstats(stats);

  // exclude llvm intrinsic globals
  bool mayHaveHiddenCalls = false;
  for (auto& gv : srcModule->globals()) {
    if (gv.getName().startswith("llvm.")) {
      state.excludeValues.insert(std::make_pair(&gv, PreTransformResult::ExcludeValueInfo(PreTransformResult::ExcludeValueKind::LLVM_INTRINSIC_GLOBAL)));
      mayHaveHiddenCalls = true;
    }
  }
  if (mayHaveHiddenCalls) {
    result.functionsWithHiddenCalls = step1_getFunctionsWithHiddenCalls(srcModule);
  }

  createStubForMemAllocFunctions(srcModule, stats);
  tryInlineAllocSizeFunctions(srcModule, stats);

  // we run step 1 and 2 in one iterations of all functions
  for (auto& F : srcModule->functions()) {
    // skip function declarations
    if (F.getBasicBlockList().empty()) {
      continue;
    }
    // TODO discuss what to do for custom allocator functions

    step1_simplify(&F);

    llvm::DenseSet<llvm::Instruction*> badcastedPointers;

    // step 1
    auto p = result.dtmap.try_emplace(&F, llvm::DominatorTree(F));
    const llvm::DominatorTree& DT = p.first->second;
    pretransform_typeconversion_v2(&F, DT, badcastedPointers);
    (void) pretransform_typeconversion;

    // step 2
    step1_opaque_region_analysis_init(&F, result, state, stats);
  }
  StaticStats::setTime(stats.s1_presolveTime);
  step1_opaque_region_analysis_solve(srcModule, result, state, stats);
  // now copy out the data
  for (const auto& p : state.opaqueRegionValues) {
    result.taintedValues.insert(p.first);
    if (llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(p.first)) {
      annotateInstr(instr, "psan_tainted");
    }
  }
  result.excludeValues.swap(state.excludeValues);
  StaticStats::setTime(stats.s1_finishTime);

  if (!isNoStaticStats()) {
    collectStats(stats, srcModule, result, state);
  }

  return result;
}
