#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "psan-rt.h"

typedef uintptr_t KeyType; // should be pointer-sized integers

NOINLINE COLD
static void __psan_mts_check_fail_report(void* addr, KeyType* lock, KeyType lockval, KeyType key, uint64_t checkID) {
  printf("PSAN: MTS check fail (#%lu): addr=%p, lock=%p, lockval=%#018lx, key=%#018lx\n", checkID, addr, lock, lockval, key);
  CHECK_FAIL();
}

ALWAYSINLINE
void __psan_mts_check(void* addr, KeyType* lock, KeyType key, uint64_t checkID) {
  KeyType lockval = lock ? *lock : 0;
  if (LIKELY(lockval == key)) {
    return;
  }
  __psan_mts_check_fail_report(addr, lock, lockval, key, checkID);
}

uint64_t __psan_mts_alloc_counter = 0;

#define MTS_MAX_LOCK_POOL_SIZE 4096u
#define MTX_LOCK_POOL_PREALLOC_SIZE 64u

static KeyType __psan_mts_lock_pool_prealloc[MTX_LOCK_POOL_PREALLOC_SIZE];

static KeyType* __psan_mts_lock_freelist_head = NULL;
static KeyType* __psan_mts_lock_pool = &__psan_mts_lock_pool_prealloc[0];
static size_t __psan_mts_lock_pool_cnt = 0;
static size_t __psan_mts_lock_pool_size = MTX_LOCK_POOL_PREALLOC_SIZE;

static void __psan_mts_allocate_lock_pool(size_t size) {
  __psan_mts_lock_pool = (KeyType*)malloc(size * sizeof(KeyType));
  if (UNLIKELY(!__psan_mts_lock_pool)) {
    INTERNAL_ERROR();
  }
  __psan_mts_lock_pool_size = size;
  __psan_mts_lock_pool_cnt = 0;
}

NOINLINE COLD
static void __psan_mts_grow_lock_pool(void) {
  size_t nextsize = __psan_mts_lock_pool_size * 2;
  if (nextsize > MTS_MAX_LOCK_POOL_SIZE) {
    nextsize = MTS_MAX_LOCK_POOL_SIZE;
  }
  __psan_mts_allocate_lock_pool(nextsize);
}

ALWAYSINLINE
KeyType* __psan_mts_allocate_lock() {
  if (__psan_mts_lock_freelist_head) {
    KeyType* lock = __psan_mts_lock_freelist_head;
    __psan_mts_lock_freelist_head = (KeyType*)*lock;
    return lock;
  }
  if (UNLIKELY(__psan_mts_lock_pool_cnt >= __psan_mts_lock_pool_size)) {
    __psan_mts_grow_lock_pool();
  }
  return &__psan_mts_lock_pool[__psan_mts_lock_pool_cnt++];
}

ALWAYSINLINE
void __psan_mts_deallocate_lock(KeyType* lock) {
  *(KeyType**)lock = __psan_mts_lock_freelist_head;
  __psan_mts_lock_freelist_head = lock;
}

ALWAYSINLINE
void __psan_mts_deallocate_lock_checked(KeyType* lock) {
  if (!lock) {
    return;
  }
  __psan_mts_deallocate_lock(lock);
}

NOINLINE COLD
static void __psan_mts_free_check_fail_report(void* addr, KeyType* lock, KeyType lockval, KeyType key, uint64_t checkID) {
  printf("PSAN: MTS free check fail (#%lu): addr=%p, lock=%p, lockval=%#018lx, key=%#018lx\n", checkID, addr, lock, lockval, key);
  CHECK_FAIL();
}

ALWAYSINLINE
void __psan_mts_free_check(void* addr, KeyType* lock, KeyType key, uint64_t checkID) {
  __psan_mts_check(addr, lock, key, checkID);
  if (lock) {
    // check if this is a dynamic allocation; free-ing the lock for s stack frame is an error
    KeyType lockval = *lock;
    if (UNLIKELY(((lockval >> 63) & 1ull) == 0)) {
      __psan_mts_free_check_fail_report(addr, lock, lockval, key, checkID);
    } else {
      __psan_mts_deallocate_lock(lock);
    }
  }
}