#include <stdio.h>
#include <stdint.h>

extern const char*    __psan_rt_stat_names[];
extern uint64_t       __psan_rt_stat_values[];
extern const uint32_t __psan_rt_stat_num;

__attribute__((destructor))
void __psan_print_rt_stats(void)
{
  if (__psan_rt_stat_num == 0){
    return;
  }
  fputs("\nPSan packed stat: {", stderr);
  for (uint32_t i = 0; i < __psan_rt_stat_num; i++) {
    if (i > 0) {
      fputc(',', stderr);
    }
    fprintf(stderr, "\"%s\":%lu", __psan_rt_stat_names[i], __psan_rt_stat_values[i]);
  }
  fputs("}\n", stderr);
}
