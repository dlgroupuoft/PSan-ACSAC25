#include <stdint.h>
#include <stdio.h>
#include "psan-rt.h"

ALWAYSINLINE
void __psan_mue_check(void* addr, uint64_t value, uint64_t checkID) {
  if (LIKELY(value != (uint64_t)-1)) {
    return;
  }
  printf("PSAN: MUE check fail (#%lu): addr=%p, value=%#010lx\n", checkID, addr, value);
  CHECK_FAIL();
}
