#include <stdint.h>
#include <string.h>
#include <stdatomic.h>
#include <sys/mman.h>
#include <malloc.h>
#include "psan-rt.h"

typedef struct __psan_ptr_metadata_opaque __psan_ptr_metadata_opaque; // placeholder type for metadata
extern const uint64_t __psan_md_size_p2; // size of metadata in bytes, power of 2
extern const uint64_t __psan_md_size; // size of metadata in bytes (guaranteed to be at most (1 << __psan_md_size_p2))

#define ADDRSPACE_WIDTH 48 // assuming 48-bit address space on x86_64
#define ALIGN_PTR_P2 3 // assuming 8-byte size and alignment
#define NUMBITS_STAGE2 ((ADDRSPACE_WIDTH - ALIGN_PTR_P2 + __psan_md_size_p2) / 2 - __psan_md_size_p2)
#define NUMBITS_STAGE1 (ADDRSPACE_WIDTH - ALIGN_PTR_P2 - NUMBITS_STAGE2)
#define NUMENTRIES_STAGE1 (1ull << NUMBITS_STAGE1)
#define NUMENTRIES_STAGE2 (1ull << NUMBITS_STAGE2)
#define INDEX_STAGE1(addr) (((uint64_t)(addr) >> (ALIGN_PTR_P2 + NUMBITS_STAGE2)) & ((1ull << NUMBITS_STAGE1) - 1))
#define INDEX_STAGE2(addr) (((uint64_t)(addr) >> ALIGN_PTR_P2) & ((1ull << NUMBITS_STAGE2) - 1))

#define MD_MMAP(size) mmap(0, (size), PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0)
#define ALIGNED(ptr) ((void*)((ptrdiff_t)(ptr) & ~((1ull << ALIGN_PTR_P2) - 1)))

__psan_ptr_metadata_opaque** __psan_trie_primary_table = NULL;

// provided by the compiler instrumentation
void __psan_md_init_gv_metadata(void);

// basic metadata operations (init, getaddr)

CONSTRUCTOR
void __psan_md_init(void) {
  __psan_trie_primary_table = (__psan_ptr_metadata_opaque**)MD_MMAP(NUMENTRIES_STAGE1 * sizeof(void*));
  if (UNLIKELY(__psan_trie_primary_table == MAP_FAILED)) {
    INTERNAL_ERROR();
  }
  __psan_md_init_gv_metadata();
}

NOINLINE COLD
static __psan_ptr_metadata_opaque* allocate_secondary_table(__psan_ptr_metadata_opaque** tableptr) {
  __psan_ptr_metadata_opaque* table = (__psan_ptr_metadata_opaque*)MD_MMAP(__psan_md_size << NUMBITS_STAGE2);
  if (table == MAP_FAILED) {
    INTERNAL_ERROR();
  }
  __psan_ptr_metadata_opaque* nulltable = NULL;
  if (LIKELY(__atomic_compare_exchange_n(tableptr, &nulltable, table, 0, __ATOMIC_RELAXED, __ATOMIC_RELAXED))) {
    return table;
  }
  // another thread has already allocated the table
  munmap(table, __psan_md_size << NUMBITS_STAGE2);
  return *tableptr;
}

ALWAYSINLINE
static void* get_md_ptr(__psan_ptr_metadata_opaque* table, uint64_t idx2) {
  return (void*)((uint8_t*) table + (idx2 * __psan_md_size));
}

ALWAYSINLINE
void* __psan_get_md_addr(void* addr) {
  uint64_t idx1 = INDEX_STAGE1(addr);
  __psan_ptr_metadata_opaque** tableptr = &__psan_trie_primary_table[idx1];
  __psan_ptr_metadata_opaque* table = *tableptr;
  if (UNLIKELY(!table)) {
    table = allocate_secondary_table(tableptr);
  }
  uint64_t idx2 = INDEX_STAGE2(addr);
  return get_md_ptr(table, idx2);
}

// bulk metadata maintenance operations (memset, memcpy, memmove)

NOINLINE
void __psan_md_memset(void* ptr, uint64_t num) {
  // clear the metadata in the given range
  if (num == 0)
    return;
  if ((num >> ADDRSPACE_WIDTH) != 0) {
    CHECK_FAIL();
  }
  void* base = ALIGNED(ptr);
  void* end = ALIGNED(ptr + num - 1);
  uint64_t idx1from = INDEX_STAGE1(base);
  uint64_t idx1to = INDEX_STAGE1(end);
  for (uint64_t idx1 = idx1from; idx1 <= idx1to; ++idx1) {
    __psan_ptr_metadata_opaque** tableptr = &__psan_trie_primary_table[idx1];
    __psan_ptr_metadata_opaque* table = *tableptr;
    if (!table) {
      // if there is no metadata, we don't need to clear it
      continue;
    }
    uint64_t idx2from = (idx1 == idx1from) ? INDEX_STAGE2(base) : 0;
    uint64_t idx2to = (idx1 == idx1to) ? (INDEX_STAGE2(end) + 1) : (1ull << NUMBITS_STAGE2);
    if (idx2to <= idx2from)
      continue;
    void* startptr = get_md_ptr(table, idx2from);
    void* endptr = get_md_ptr(table, idx2to);
    memset(startptr, 0, (uint8_t*)endptr - (uint8_t*)startptr);
  }
}

NOINLINE
static void* __psan_get_md_addr_noalloc(void* addr) {
  uint64_t idx1 = INDEX_STAGE1(addr);
  __psan_ptr_metadata_opaque** tableptr = &__psan_trie_primary_table[idx1];
  __psan_ptr_metadata_opaque* table = *tableptr;
  if (!table) {
    return NULL;
  }
  uint64_t idx2 = INDEX_STAGE2(addr);
  return get_md_ptr(table, idx2);
}

NOINLINE
void __psan_md_memmove(void* dst, void* src, uint64_t num) {
  // copy the metadata from src to dst
  if (num == 0)
    return;
  if ((num >> ADDRSPACE_WIDTH) != 0) {
    CHECK_FAIL();
  }
  void* dstbase = ALIGNED(dst);
  void* srcbase = ALIGNED(src);
  if (dstbase == srcbase) {
    // no need to copy metadata
    return;
  }
  void* dstend = ALIGNED(dst + num - 1);
  void* srcend = ALIGNED(src + num - 1);
  if (dstend < srcbase || srcend < dstbase) {
    // non-overlapping ranges
    uint64_t dstidx1from = INDEX_STAGE1(dstbase);
    uint64_t dstidx1to = INDEX_STAGE1(dstend);
    uint64_t srcidx1from = INDEX_STAGE1(srcbase);
    uint64_t srcidx1to = INDEX_STAGE1(srcend);
    uint64_t dstidx1 = dstidx1from;
    uint64_t dstidx2 = INDEX_STAGE2(dstbase);
    for (uint64_t idx1 = srcidx1from; idx1 <= srcidx1to; ++idx1) {
      __psan_ptr_metadata_opaque** srctableptr = &__psan_trie_primary_table[idx1];
      __psan_ptr_metadata_opaque* srctable = *srctableptr;
      uint64_t idx2from = (idx1 == srcidx1from) ? INDEX_STAGE2(srcbase) : 0;
      uint64_t idx2to = (idx1 == srcidx1to) ? (INDEX_STAGE2(srcend) + 1) : NUMENTRIES_STAGE2;
      if (idx2to <= idx2from)
        continue;
      if (!srctable) {
        // if there is no metadata, we don't need to copy it
        // however we still need to update the index of the destination
        dstidx2 += idx2to - idx2from;
        if (dstidx2 >= NUMENTRIES_STAGE2) {
          dstidx1++;
          dstidx2 -= NUMENTRIES_STAGE2;
        }
        continue;
      }
      // start copying metadata
      void* srcstartptr = get_md_ptr(srctable, idx2from);
      void* srcendptr = get_md_ptr(srctable, idx2to);
      __psan_ptr_metadata_opaque** dsttableptr = &__psan_trie_primary_table[dstidx1];
      __psan_ptr_metadata_opaque* dsttable = *dsttableptr;
      if (!dsttable) {
        dsttable = allocate_secondary_table(dsttableptr);
      }
      uint64_t dstidx2new = dstidx2 + (idx2to - idx2from);
      void* dststartptr = get_md_ptr(dsttable, dstidx2);
      if (dstidx2new <= NUMENTRIES_STAGE2) {
        // copy the metadata in one go
        memcpy(dststartptr, srcstartptr, (uint8_t*)srcendptr - (uint8_t*)srcstartptr);
        dstidx2 = dstidx2new;
        if (dstidx2 == NUMENTRIES_STAGE2) {
          dstidx1++;
          dstidx2 = 0;
        }
      } else {
        // copy the metadata in two parts
        uint64_t num1 = NUMENTRIES_STAGE2 - dstidx2;
        memcpy(dststartptr, srcstartptr, num1 * __psan_md_size);
        dstidx1++;
        dstidx2 = 0;
        dsttableptr = &__psan_trie_primary_table[dstidx1];
        dsttable = *dsttableptr;
        if (!dsttable) {
          dsttable = allocate_secondary_table(dsttableptr);
        }
        dststartptr = get_md_ptr(dsttable, dstidx2);
        void* srcstartptr2 = (uint8_t*)srcstartptr + (num1 * __psan_md_size);
        memcpy(dststartptr, srcstartptr2, (uint8_t*)srcendptr - (uint8_t*)srcstartptr2);
        dstidx2 = (idx2to - idx2from) - num1;
        // sanity check
        if (dstidx2new - NUMENTRIES_STAGE2 != dstidx2) {
          INTERNAL_ERROR();
        }
      }
    }
  } else {
    // overlapping ranges
    // just copy metadata one by one
    if (dstbase < srcbase) {
      for (void* p = srcbase, *pd = dstbase; p <= srcend; p += (1ull << ALIGN_PTR_P2), pd += (1ull << ALIGN_PTR_P2)) {
        void* mdfrom = __psan_get_md_addr_noalloc(p);
        if (!mdfrom)
          continue;
        void* mdto = __psan_get_md_addr(pd);
        memcpy(mdto, mdfrom, __psan_md_size);
      }
    } else {
      for (void* p = srcend, *pd = dstend; p >= srcbase; p -= (1ull << ALIGN_PTR_P2), pd -= (1ull << ALIGN_PTR_P2)) {
        void* mdfrom = __psan_get_md_addr_noalloc(p);
        if (!mdfrom)
          continue;
        void* mdto = __psan_get_md_addr(pd);
        memcpy(mdto, mdfrom, __psan_md_size);
      }
    }
  }
}

ALWAYSINLINE
void __psan_md_memcpy(void* dst, void* src, uint64_t num) {
  __psan_md_memmove(dst, src, num); // same as memmove (no overlap check)
}

NOINLINE
void __psan_md_realloc(void* dst, void* src, uint64_t dstSize, uint64_t srcSize) {
  if (dst == src || !src || !dst) {
    // no need to do anything
    return;
  }
  // we decompose the range into:
  // (1) a memmove component that covers the overlapping data, and
  // (2) memset components that cover the extra space in the destination and the freed space in the source
  uint64_t memmove_size = (srcSize < dstSize) ? srcSize : dstSize;
  if (memmove_size > 0) {
    __psan_md_memmove(dst, src, memmove_size);
  }
  uint64_t src_memset_size = srcSize - memmove_size;
  if (src_memset_size > 0) {
    __psan_md_memset(src + memmove_size, src_memset_size);
  }
  uint64_t dst_memset_size = dstSize - memmove_size;
  if (dst_memset_size > 0) {
    __psan_md_memset(dst + memmove_size, dst_memset_size);
  }
  // done
}

ALWAYSINLINE
uint64_t __psan_realloc_get_old_size(void* src) {
  return malloc_usable_size(src);
}
