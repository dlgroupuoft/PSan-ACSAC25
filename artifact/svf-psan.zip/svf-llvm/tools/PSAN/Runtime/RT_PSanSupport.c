#include "psan-rt.h"
#include <stdlib.h>
#include <stdio.h>

// 0: uninitialized
// 1: abort on failure
// 2: continue execution
static int PSAN_CHECK_FAIL_POLICY = 0;

NOINLINE COLD
void __psan_check_fail_handler(void) {
  if (PSAN_CHECK_FAIL_POLICY == 0) {
    char* policy = getenv("PSAN_CHECK_FAIL_CONTINUE");
    if (policy && policy[0] == '1') {
      PSAN_CHECK_FAIL_POLICY = 2;
    } else {
      PSAN_CHECK_FAIL_POLICY = 1;
    }
  }
  if (PSAN_CHECK_FAIL_POLICY == 2) {
    return;
  }
  __psan_internal_error_handler();
}

NOINLINE COLD
void __psan_internal_error_handler(void) {
  fflush(stdout);
  fflush(stderr);
  __builtin_trap();
}
