#include <stdint.h>
#include <stdio.h>
#include <limits.h>
#include "psan-rt.h"

NOINLINE COLD
static void __psan_mss_check_fail_report(void* addr, void* lb, void* ub, uint64_t size, uint64_t checkID) {
  printf("PSAN: MSS check fail (#%lu): addr=%p, lb=%p, ub=%p, size=%lu\n", checkID, addr, lb, ub, size);
  CHECK_FAIL();
}

ALWAYSINLINE
void __psan_mss_check(void* addr, void* lb, void* ub, uint64_t size, uint64_t checkID) {
  uint64_t addrval = (uint64_t)addr;
  int isFailed = ((ub > lb) && (addr < lb || addr + size > ub || addrval > ULONG_MAX - size)) || ((ub <= lb) && (ub || lb));
  if (LIKELY(!isFailed || (size == 0))) {
    return;
  }
  __psan_mss_check_fail_report(addr, lb, ub, size, checkID);
}
