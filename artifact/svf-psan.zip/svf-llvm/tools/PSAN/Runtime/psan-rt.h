#ifndef PSAN_RUNTIME_PSAN_RT_H
#define PSAN_RUNTIME_PSAN_RT_H

#define NOINLINE __attribute__((noinline))
#define ALWAYSINLINE __attribute__((always_inline))
#define CONSTRUCTOR __attribute__((constructor))

// use environment variable to decide abort or continue
extern void __psan_check_fail_handler(void);
extern void __psan_internal_error_handler(void);

#define CHECK_FAIL() do{__psan_check_fail_handler(); return;}while(0)
#define INTERNAL_ERROR() __psan_internal_error_handler()

// this is not that useful since the commandline includes -fvisibility=hidden
#define HIDDEN __attribute__((visibility("hidden")))
#define COLD __attribute__((cold))

#define LIKELY(x)      __builtin_expect(!!(x), 1)
#define UNLIKELY(x)    __builtin_expect(!!(x), 0)

#endif // PSAN_RUNTIME_PSAN_RT_H
