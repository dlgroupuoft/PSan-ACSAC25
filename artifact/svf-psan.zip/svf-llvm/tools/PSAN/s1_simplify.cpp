#include "s1.h"

using namespace PSan;

// most of code is adapted from svf-llvm/lib/BreakConstantExpr.cpp

namespace {

llvm::ConstantExpr *
hasConstantExprRequireBreaking (llvm::Value*  V)
{
  if (llvm::ConstantExpr * CE = llvm::dyn_cast<llvm::ConstantExpr>(V))
  {
    if (CE->getOpcode() == llvm::Instruction::GetElementPtr || CE->getOpcode() == llvm::Instruction::BitCast)
    {
      return CE;
    }
    else
    {
      for (unsigned index = 0; index < CE->getNumOperands(); ++index)
      {
        if (hasConstantExprRequireBreaking (CE->getOperand(index)))
          return CE;
      }
    }
  }

  return nullptr;
}

llvm::Value*
convertExpression (llvm::ConstantExpr * CE, llvm::Instruction*  InsertPt)
{
  //
  // Convert this constant expression into a regular instruction.
  //
  //if (CE->getOpcode() == llvm::Instruction::GetElementPtr)
  //    ++GEPChanges;
  //++TotalChanges;
  // we don't want to have bitcast null to T*
  if (CE->getOpcode() == llvm::Instruction::BitCast && llvm::isa<llvm::ConstantPointerNull>(CE->getOperand(0))) {
    return llvm::ConstantPointerNull::get(llvm::cast<llvm::PointerType>(CE->getType()));
  }
  llvm::Instruction* Result = CE->getAsInstruction();
  Result->insertBefore(InsertPt);
  return Result;
}

} // end anonymous namespace

void PSan::step1_simplify(llvm::Function* func)
{
  // Worklist of values to check for constant GEP expressions
  std::vector<llvm::Instruction* > Worklist;

  //
  // Initialize the worklist by finding all instructions that have one or more
  // operands containing a constant GEP expression.
  //
  for (llvm::Function::iterator BB = func->begin(); BB != func->end(); ++BB)
  {
    for (llvm::BasicBlock::iterator i = BB->begin(); i != BB->end(); ++i)
    {
      llvm::Instruction*  I = &(*i);

      // we cannot simplify the operands of a landing pad instruction
      if (llvm::isa<llvm::LandingPadInst>(I)) {
        continue;
      }
      for (unsigned index = 0; index < I->getNumOperands(); ++index)
      {
        if (hasConstantExprRequireBreaking (I->getOperand(index)))
        {
          Worklist.push_back (I);
        }
      }
    }
  }

  //
  // While the worklist is not empty, take an item from it, convert the
  // operands into instructions if necessary, and determine if the newly
  // added instructions need to be processed as well.
  //
  while (Worklist.size())
  {
    llvm::Instruction*  I = Worklist.back();
    Worklist.pop_back();

    //
    // Scan through the operands of this instruction and convert each into an
    // instruction.  Note that this works a little differently for phi
    // instructions because the new instruction must be added to the
    // appropriate predecessor block.
    //
    if (llvm::PHINode * PHI = llvm::dyn_cast<llvm::PHINode>(I))
    {
      for (unsigned index = 0; index < PHI->getNumIncomingValues(); ++index)
      {
        //
        // For PHI Nodes, if an operand is a constant expression with a GEP, we
        // want to insert the new instructions in the predecessor basic block.
        //
        // Note: It seems that it's possible for a phi to have the same
        // incoming basic block listed multiple times; this seems okay as long
        // the same value is listed for the incoming block.
        //
        llvm::Instruction*  InsertPt = PHI->getIncomingBlock(index)->getTerminator();
        if (llvm::ConstantExpr * CE = hasConstantExprRequireBreaking (PHI->getIncomingValue(index)))
        {
          llvm::Value*  NewValue = convertExpression (CE, InsertPt);
          for (unsigned i2 = index; i2 < PHI->getNumIncomingValues(); ++i2)
          {
            if ((PHI->getIncomingBlock (i2)) == PHI->getIncomingBlock (index))
              PHI->setIncomingValue (i2, NewValue);
          }
          if (llvm::Instruction*  NewInst = llvm::dyn_cast<llvm::Instruction>(NewValue)) {
            Worklist.push_back (NewInst);
          }
        }
      }
    }
    else
    {
      for (unsigned index = 0; index < I->getNumOperands(); ++index)
      {
        //
        // For other instructions, we want to insert instructions replacing
        // constant expressions immediently before the instruction using the
        // constant expression.
        //
        if (llvm::ConstantExpr * CE = hasConstantExprRequireBreaking (I->getOperand(index)))
        {
          llvm::Value*  NewValue = convertExpression (CE, I);
          I->replaceUsesOfWith (CE, NewValue);
          if (llvm::Instruction*  NewInst = llvm::dyn_cast<llvm::Instruction>(NewValue)) {
            Worklist.push_back (NewInst);
          }
        }
      }
    }
  }
}
