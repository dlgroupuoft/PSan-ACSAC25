#include "s1.h"
#include "FastDebugDumper.h"

using namespace PSan;

namespace {

enum class InitialTaintReason : unsigned {
  Unknown             = 0,
  ExternCall          = 1, // the value is passed as an operand to / returned from an external callee (additional info: callee name)
  UnsupportedInstr    = 2, // the value is used in / produced from an unsupported instruction (additional info: instruction name)
  BadCast             = 3, // the value is casted to an incompatible type (no additional info)
  FunctionAddrTaken   = 4, // the function is address-taken (no additional info)
  ArgInterfaceTainted = 5, // the argument is tainted by the function interface (no additional info)
  IntToPtr            = 6, // the pointer may flow to an inttoptr instruction (no additional info)
  ASM                 = 7, // the value is used in inline assembly (no additional info)
  Variadic            = 8, // the value is used in a intrinsics related to variadic arguments (no additional info)
  RelTable            = 9, // the value is involved in relative addressing (no additional info)
};

void reportTaint(StaticStats& stats, InitialTaintReason reason, llvm::StringRef additionalInfo)
{
  if (additionalInfo.empty()) {
    stats.S1Taint_InitialCause.increment(static_cast<std::size_t>(reason));
    return;
  }
  stats.S1Taint_InitialCause.increment(static_cast<std::size_t>(reason), additionalInfo);
}

} // end anonymous namespace

void PSan::step1_opaque_region_analysis_initstats(StaticStats& stats)
{
  llvm::SmallVector<std::string> names = {
    "Unknown",
    "ExternCall",
    "UnsupportedInstr",
    "BadCast",
    "FunctionAddrTaken",
    "ArgInterfaceTainted",
    "IntToPtr",
    "ASM",
    "Variadic",
    "RelTable",
  };
  stats.S1Taint_InitialCause.init(names);
}

PSan::OpaqueRegionAnalysisState::~OpaqueRegionAnalysisState() {
  for (auto iter = funcInfo.begin(), iterEnd = funcInfo.end(); iter != iterEnd; ++iter) {
    delete iter->second;
  }
}

llvm::GlobalVariable* PSan::getBackingGlobalVariable(llvm::Constant* constptr)
{
  if (llvm::GlobalVariable* gv = llvm::dyn_cast<llvm::GlobalVariable>(constptr)) {
    return gv;
  }
  if (llvm::ConstantExpr* cexpr = llvm::dyn_cast<llvm::ConstantExpr>(constptr)) {
    switch (cexpr->getOpcode())
    {
    case llvm::Instruction::IntToPtr:
      return nullptr;
    case llvm::Instruction::AddrSpaceCast:
    case llvm::Instruction::BitCast:
    case llvm::Instruction::GetElementPtr:
      return getBackingGlobalVariable(cexpr->getOperand(0));
    default:
      psan_unreachable("Unexpected cexpr opcode");
    }
  }
  if (llvm::isa<llvm::ConstantPointerNull>(constptr) || llvm::isa<llvm::UndefValue>(constptr) || llvm::isa<llvm::Function>(constptr) || llvm::isa<llvm::GlobalIFunc>(constptr)) {
    return nullptr;
  }
  if (llvm::GlobalAlias* alias = llvm::dyn_cast<llvm::GlobalAlias>(constptr)) {
    return getBackingGlobalVariable(alias->getAliasee());
  }
  psan_unreachable("Unexpected constant pointer kind");
}

namespace {

llvm::BitVector& getFunctionInterfaceBV(llvm::Function* func, OpaqueRegionAnalysisState& state)
{
  auto iter = state.functionInterfaceOpaqueValues.find(func);
  if (iter == state.functionInterfaceOpaqueValues.end()) {
    auto insertResult = state.functionInterfaceOpaqueValues.insert(std::make_pair(func, llvm::BitVector(func->getFunctionType()->getNumParams()+1, false)));
    assert (insertResult.second);
    iter = insertResult.first;
  }
  return iter->getSecond();
}

void taintValue(OpaqueRegionAnalysisState& state, StaticStats& stats, OpaqueRegionAnalysisState::FunctionInfo* info, llvm::Value* value, bool isInit, llvm::Value* becauseOf = nullptr, InitialTaintReason reason = InitialTaintReason::Unknown);
void taintAllIndCallRet(OpaqueRegionAnalysisState& state, StaticStats& stats, llvm::Value* becauseOf = nullptr);

// must be called after init
void taintFunctionReturnValue(llvm::Function* func, OpaqueRegionAnalysisState& state, StaticStats& stats)
{
  if (!func->getFunctionType()->getReturnType()->isPointerTy()) {
    return;
  }
  auto iter = state.funcInfo.find(func);
  if (iter == state.funcInfo.end()) {
    return;
  }
  auto* info = iter->second;
  unsigned index = func->getFunctionType()->getNumParams();
  auto& interfaceBV = getFunctionInterfaceBV(func, state);
  if (interfaceBV.test(index)) {
    // the return value is already tainted
    return;
  }

  // if we reach here, this is the first time we taint the return value of this function
  interfaceBV.set(index);

  // taint all returns
  for (auto* ret : info->returns) {
    taintValue(state, stats, info, ret->getReturnValue(), false, func);
  }

  // we go through all callers and taint the returned pointer if they are not already tainted
  for (auto& u : func->uses()) {
    if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(u.getUser())) {
      if (call->getCalledOperandUse().getOperandNo() == u.getOperandNo()) {
        auto* info = state.funcInfo.find(call->getFunction())->second;
        taintValue(state, stats, info, call, false, func);
      }
    }
  }
  // then indirect calls
  if (state.funcWithAddrTaken.count(func) > 0 && !state.isAllAddrTakenFunctionReturnsTainted) {
    taintAllIndCallRet(state, stats, func);
  }
}

// must be called after init
void taintAllIndCallRet(OpaqueRegionAnalysisState& state, StaticStats& stats, llvm::Value* becauseOf)
{
  // taint the return value of all possible callees
  if (!state.isAllAddrTakenFunctionReturnsTainted) {
    state.isAllAddrTakenFunctionReturnsTainted = true;
    for (llvm::Function* func : state.funcWithAddrTaken) {
      taintFunctionReturnValue(func, state, stats);
    }
    // also taint indirect calls
    for (auto iter = state.funcInfo.begin(), iterEnd = state.funcInfo.end(); iter != iterEnd; ++iter) {
      auto* info = iter->second;
      if (!info->indirectCalls.empty()) {
        for (llvm::CallBase* call : info->indirectCalls) {
          taintValue(state, stats, info, call, false, becauseOf);
        }
      }
    }
  }
}

void handleCallReturnValueTaint(llvm::CallBase* call, OpaqueRegionAnalysisState& state, StaticStats& stats)
{
  if (call->isInlineAsm()) {
    return;
  }
  llvm::Value* callee = call->getCalledOperand();
  if (llvm::Function* calleeFunction = llvm::dyn_cast<llvm::Function>(callee)) {
    // if we are calling an external function, we should have already tainted all values
    // so here we only handle functions with body
    if (state.funcInfo.count(calleeFunction) != 0) {
      taintFunctionReturnValue(calleeFunction, state, stats);
    }
  } else {
    // taint the return value of all possible callees
    taintAllIndCallRet(state, stats, call);
  }
}

void taintFunctionParameter(OpaqueRegionAnalysisState::FunctionInfo* info, OpaqueRegionAnalysisState& state, StaticStats& stats, unsigned argno)
{
  llvm::FunctionType* funcTy = info->func->getFunctionType();
  // we don't taint vararg parameters
  if (argno >= funcTy->getNumParams()) {
    assert (funcTy->isVarArg());
    return;
  }
  auto& interfaceBV = getFunctionInterfaceBV(info->func, state);
  if (interfaceBV.test(argno)) {
    // the argument is already tainted
    return;
  }
  interfaceBV.set(argno);
  taintValue(state, stats, info, info->func->getArg(argno), false);
}

void taintInstrUserFromOperand(llvm::Value* value, llvm::Instruction* user, unsigned argno, OpaqueRegionAnalysisState::FunctionInfo* info, OpaqueRegionAnalysisState& state, StaticStats& stats)
{
  if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(user)) {
    // if this is a memory intrinsics (memcpy, memmove, etc) we propagate the taint to the other operand if neneded
    switch (call->getIntrinsicID())
    {
    default: return;
    case llvm::Intrinsic::not_intrinsic: break;

    case llvm::Intrinsic::memcpy:
    case llvm::Intrinsic::memcpy_element_unordered_atomic:
    case llvm::Intrinsic::memmove:
    case llvm::Intrinsic::memmove_element_unordered_atomic:
      for (llvm::Value* v : call->args()) {
        if (v != value && v->getType()->isPointerTy()) {
          taintValue(state, stats, info, v, false);
        }
      }
      return;
    }
    // if this is not an intrinsic, we need to taint the callee's argument
    // if this is an indirect function call, we taint all address-taken function's all pointer parameters
    if (llvm::Function* callee = call->getCalledFunction()) {
      // if this is a library function (declared externally), we should already tainted all parameters, so should do nothing
      // we only taint if the callee is defined here
      auto iter = state.funcInfo.find(callee);
      if (iter != state.funcInfo.end()) {
        assert (call->getArgOperand(argno) == value);
        taintFunctionParameter(iter->second, state, stats, argno);
      }
    } else if (!call->isInlineAsm()) {
      // this should be an indirect function call
      if (call->getCalledOperandUse().getOperandNo() == argno) {
        // the callee function pointer is tainted
        // we just taint all the arguments and the return value
        for (llvm::Value* v : call->args()) {
          if (v->getType()->isPointerTy()) {
            taintValue(state, stats, info, v, false, value);
          }
        }
        taintValue(state, stats, info, call, false, value);
      } else {
        // the argument is tainted
        // taint all function's parameters
        if (state.addrTakenFunctionArgTaints.size() <= argno) {
          state.addrTakenFunctionArgTaints.resize(argno + 1, false);
        }
        if (!state.addrTakenFunctionArgTaints.test(argno)) {
          state.addrTakenFunctionArgTaints.set(argno);
          for (llvm::Function* func : state.funcWithAddrTaken) {
            if (func->getFunctionType()->getNumParams() <= argno)
              continue;
            auto iter = state.funcInfo.find(func);
            auto* curInfo = iter->second;
            taintFunctionParameter(curInfo, state, stats, argno);
          }
        }
      }
      // done with the indirect call case
    }
    return;
  }
  // we just propagate the taint to the output for following instructions
  if (llvm::isa<llvm::BitCastInst>(user) || llvm::isa<llvm::GetElementPtrInst>(user) || llvm::isa<llvm::LoadInst>(user)) {
    taintValue(state, stats, info, user, false, value);
    return;
  }

  // if we are tainting the address of a store, we also taint the value
  // however, if only the value is tainted, the address don't have to be tainted
  if (llvm::StoreInst* store = llvm::dyn_cast<llvm::StoreInst>(user)) {
    if (store->getPointerOperand() == value) {
      taintValue(state, stats, info, store->getValueOperand(), false, store);
    }
    return;
  }

  // for PHI, we also taint other input operand
  if (llvm::PHINode* phi = llvm::dyn_cast<llvm::PHINode>(user)) {
    taintValue(state, stats, info, user, false, value);
    for (auto& operandUse : phi->incoming_values()) {
      llvm::Value* incoming = operandUse.get();
      if (incoming == phi || incoming == value) {
        continue;
      }
      taintValue(state, stats, info, incoming, false, phi);
    }
    return;
  }

  // check if this is a return
  if (llvm::ReturnInst* ret = llvm::dyn_cast<llvm::ReturnInst>(user)) {
    taintFunctionReturnValue(ret->getFunction(), state, stats);
  }

  // no need to propagate taint in other cases
}

void handleGVInitializerTaint(OpaqueRegionAnalysisState& state, StaticStats& stats, llvm::Constant* initializer, llvm::Value* becauseof)
{
  if (llvm::ConstantAggregate* caggr = llvm::dyn_cast<llvm::ConstantAggregate>(initializer)) {
    for (unsigned i = 0, n = caggr->getNumOperands(); i < n; ++i) {
      handleGVInitializerTaint(state, stats, caggr->getOperand(i), becauseof);
    }
  } else if (llvm::ConstantData* cdata = llvm::dyn_cast<llvm::ConstantData>(initializer)) {
    // do nothing
    (void) cdata;
  } else if (llvm::ConstantExpr* cexpr = llvm::dyn_cast<llvm::ConstantExpr>(initializer)) {
    for (unsigned i = 0, n = cexpr->getNumOperands(); i < n; ++i) {
      handleGVInitializerTaint(state, stats, cexpr->getOperand(i), becauseof);
    }
  } else if (llvm::GlobalVariable* gv = llvm::dyn_cast<llvm::GlobalVariable>(initializer)) {
    taintValue(state, stats, nullptr, gv, false, becauseof);
  } else if (llvm::Function* func = llvm::dyn_cast<llvm::Function>(initializer)) {
    taintValue(state, stats, nullptr, func, false, becauseof);
  } else if (llvm::GlobalIFunc* gifunc = llvm::dyn_cast<llvm::GlobalIFunc>(initializer)) {
    taintValue(state, stats, nullptr, gifunc, false, becauseof);
  } else {
    psan_unreachable("Unexpected constant initializer kind");

  }
}

void handleConstantValueTaint(llvm::Constant* src, OpaqueRegionAnalysisState& state, StaticStats& stats)
{
  // use to def
  if (llvm::GlobalVariable* gv = llvm::dyn_cast<llvm::GlobalVariable>(src)) {
    if (gv->hasInitializer()) {
      if (llvm::Constant* initializer = gv->getInitializer()) {
        handleGVInitializerTaint(state, stats, initializer, gv);
      }
    }
  }
  // def to use
  llvm::SmallVector<llvm::Constant*> stack;
  stack.push_back(src);
  while(!stack.empty()) {
    llvm::Constant* constptr = stack.pop_back_val();
    assert (!(llvm::isa<llvm::ConstantPointerNull>(constptr)
           || llvm::isa<llvm::UndefValue>(constptr)
           || llvm::isa<llvm::Function>(constptr)
           || llvm::isa<llvm::GlobalIFunc>(constptr)));
    if (state.opaqueRegionValues.count(constptr) != 0 && constptr != src) {
      // the caller may have already tainted the src pointer (the caller guarantees this is called only once)
      // so only skip if the current constptr is different from src
      continue;
    }
    state.opaqueRegionValues.insert(std::make_pair(constptr, OpaqueRegionAnalysisState::OpaqueValueInfo()));
    for (auto& u : constptr->uses()) {
      llvm::Value* v = u.getUser();
      if (llvm::Constant* next = llvm::dyn_cast<llvm::Constant>(v)) {
        stack.push_back(next);
      } else if (llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(v)) {
        llvm::Function* parent = instr->getFunction();
        auto iterFuncInfo = state.funcInfo.find(parent);
        assert (iterFuncInfo != state.funcInfo.end());
        auto* funcInfo = iterFuncInfo->second;
        taintInstrUserFromOperand(constptr, instr, u.getOperandNo(), funcInfo, state, stats);
      } else {
        psan_unreachable("Unexpected user kind");
      }
    }
  }
}

void handleFunctionPrototypeTaint(OpaqueRegionAnalysisState& state, StaticStats& stats, llvm::Function* func, bool isInit)
{
  if (func->isDeclaration()) {
    return;
  }
  if (isInit) {
    // initialization case; we may not have the function info yet
    state.taintedFunctions.insert(func);
    return;
  }

  // solving phase
  // returns use this special function
  taintFunctionReturnValue(func, state, stats);

  // now arguments
  auto& bv = getFunctionInterfaceBV(func, state);
  bool isChanged = false;
  llvm::FunctionType* funcTy = func->getFunctionType();
  for (unsigned i = 0, n = funcTy->getNumParams(); i < n; ++i) {
    if (funcTy->getParamType(i)->isPointerTy()) {
      if (!bv.test(i)) {
        bv.set(i);
        isChanged = true;
      }
    }
  }
  if (funcTy->getReturnType()->isPointerTy()) {
    if (!bv.test(funcTy->getNumParams())) {
      bv.set(funcTy->getNumParams());
      isChanged = true;
    }
  }
  if (isChanged) {
    auto iter = state.funcInfo.find(func);
    if (iter == state.funcInfo.end()) {
      psan_unreachable("Function not found in funcInfo");
    } else {
      auto* funcInfo = iter->second;
      state.functionsWithWork.push(funcInfo);
    }
  }
}

void taintValue(OpaqueRegionAnalysisState& state, StaticStats& stats, OpaqueRegionAnalysisState::FunctionInfo* info, llvm::Value* value, bool isInit, llvm::Value* becauseOf, InitialTaintReason reason) {
  if (!value->getType()->isPointerTy()) {
    return;
  }
  if (llvm::ConstantPointerNull* ptrnull = llvm::dyn_cast<llvm::ConstantPointerNull>(value)) {
    // we don't taint null pointers
    (void) ptrnull;
    return;
  }
  // if the value is excluded, we should not taint them outside init
  if (!isInit) {
    auto iter = state.excludeValues.find(value);
    if (iter != state.excludeValues.end()) {
      // if some excluded values can be tainted, we can exclude them here
      if (!PreTransformResult::canExcludeValueKindHaveTaint(iter->second.kind)) {
        return;
      }
    }
  }
  auto insertResult = state.opaqueRegionValues.insert(std::make_pair(value, OpaqueRegionAnalysisState::OpaqueValueInfo()));
  if (!insertResult.second) {
    // we must have already tainted this value
    return;
  }
  if (isInit) {
    llvm::StringRef additional;
    switch (reason)
    {
    case InitialTaintReason::ExternCall: {
      llvm::CallBase* call = llvm::cast<llvm::CallBase>(becauseOf);
      if (llvm::Function* callee = call->getCalledFunction()) {
        additional = callee->getName();
      } else {
        additional = "<indirect>";
      }
      if (additional.empty()) {
        psan_unreachable("Unexpected empty callee name");
      }
    } break;
    case InitialTaintReason::UnsupportedInstr: {
      llvm::Instruction* instr = llvm::cast<llvm::Instruction>(becauseOf);
      additional = instr->getOpcodeName();
      if (additional.empty()) {
        psan_unreachable("Unexpected empty instruction name");
      }
    } break;
    default:
      break;
    }
    reportTaint(stats, reason, additional);
  }
  if (!isNoDebugPrint()) {
    static DumpEventDecl<llvm::Value*, llvm::Value*, bool> TaintEvent([](llvm::raw_ostream&os, const EventData<llvm::Value*, llvm::Value*, bool>& data){
      if (data.get<2>()) {
        os << "Initial taint:";
      } else {
        os << "Propagate taint:";
      }
      os << data.get<0>() << "\n";
      if (data.get<1>()) {
        os << "      Because:" << data.get<1>() << "\n";
      }
    });
    TaintEvent(value, becauseOf, isInit);
  }

  // special handling for functions
  // this probably mean that the function pointer is undergoing cast; just taint all arguments and return values
  if (llvm::Function* func = llvm::dyn_cast<llvm::Function>(value)) {
    if (func->isDeclaration()) {
      return;
    }
    handleFunctionPrototypeTaint(state, stats, func, isInit);
    return;
  }

  // special handling for global / constant values
  if (llvm::Constant* constptr = llvm::dyn_cast<llvm::Constant>(value)) {
    llvm::GlobalVariable* gv = getBackingGlobalVariable(constptr);
    if (!gv) {
      return;
    }
    if (state.taintedGVs.insert(gv).second) {
      // this is the initial insertion
      if (!isInit) {
        handleConstantValueTaint(gv, state, stats);
      }
    }
    return;
  }

  assert (llvm::isa<llvm::Instruction>(value) || llvm::isa<llvm::Argument>(value));
  info->worklist.push(value);
  state.functionsWithWork.push(info);
  auto& valueInfo = insertResult.first->getSecond();
  (void) valueInfo;

  // now check if the value corresponds to a function parameter or a call return value
  // if yes, then we need to adjust functionInterfaceOpaqueValues

  // check if this is a call
  if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(value)) {
    if (call->isInlineAsm()) {
      // do nothing
      return;
    }
    info->taintedCalls.insert(call);
    if (isInit) {
      // do nothing else
    } else {
      // go to the body of the callee and taint the return values
      handleCallReturnValueTaint(call, state, stats);
    }
    return;
  }

  // now check if this is an argument / formal parameter
  if (llvm::Argument* arg = llvm::dyn_cast<llvm::Argument>(value)) {
    llvm::Function* func = arg->getParent();
    auto iter = state.functionInterfaceOpaqueValues.find(func);
    if (iter == state.functionInterfaceOpaqueValues.end()) {
      auto insertResult = state.functionInterfaceOpaqueValues.insert(std::make_pair(func, llvm::BitVector(func->getFunctionType()->getNumParams()+1, false)));
      assert (insertResult.second);
      iter = insertResult.first;
    }
    llvm::BitVector& interfaceBV = iter->getSecond();
    interfaceBV.set(arg->getArgNo());
    return;
  }
}

} // end anonymous namespace

void PSan::step1_opaque_region_analysis_init(llvm::Function* func, PreTransformResult& result, OpaqueRegionAnalysisState& state, StaticStats& stats)
{
  // in the first visit, we need to:
  // 1. find initial set of pointers in the opaque region:
  //    - bad casts, int to ptr
  //    - unanalyzable instructions: vector, asm
  //    - other instructions working with pointers that cause the pointer to be in the opaque region
  // 2. find all returns and ptrtoints and save them in FunctionInfo
  // 3. recognize special instruction patterns (e.g., vararg) and put them in excludedValues
  // we will remove the taint of excludedValues later on

  // this function should only be called on internally defined functions
  assert (!func->getBasicBlockList().empty());

  auto* info = new OpaqueRegionAnalysisState::FunctionInfo();
  info->func = func;
  state.funcInfo.insert(std::make_pair(func, info));

  auto taintInstrArg = [&](llvm::Value* ptrValue, llvm::Value* becauseOf, InitialTaintReason reason) -> void {
    llvm::PointerType* ptrTy = llvm::cast<llvm::PointerType>(ptrValue->getType());

    // if this value comes from a constant, check whether there is a global variable we need to taint
    // if yes, just record this and done
    if (!getPointerElementType(ptrTy)->isFunctionTy()) {
      if (llvm::Constant* constptr = llvm::dyn_cast<llvm::Constant>(ptrValue)) {
        if (llvm::GlobalVariable* gv = getBackingGlobalVariable(constptr)) {
          state.taintedGVs.insert(gv);
        }
        return;
      }
    }

    // now the value is not a constant; we can safely add it to worklist and the opaqueRegionValues
    taintValue(state, stats, info, ptrValue, true, becauseOf, reason);
  };
  auto excludeValue = [&](llvm::Value* v, PreTransformResult::ExcludeValueKind kind) -> bool {
    // return true if the value is successfully excluded, false if the value is already excluded with the same ExcludeValueKind
    auto result = state.excludeValues.insert(std::make_pair(v, PreTransformResult::ExcludeValueInfo(kind)));
    if (!result.second) {
      if (result.first->second.kind != kind) {
        psan_unreachable("Inconsistent exclusion reason for the same value");
      }
    } else {
      static DumpEventDecl<llvm::Value*, PreTransformResult::ExcludeValueKind> ExcludeEvent([](llvm::raw_ostream& os, const EventData<llvm::Value*, PreTransformResult::ExcludeValueKind>& data){
        os << "Exclude: " << data.get<0>() << " Reason: ";
        PreTransformResult::printExcludeKind(os, data.get<1>());
        os << "\n";
      });
      PSAN_DEBUG(ExcludeEvent(v, kind));
    }
    return result.second;
  };
  llvm::SmallVector<std::pair<llvm::Instruction*, unsigned>, 8> varargExclusionStack;
  auto varargExcludeEnqueue = [&](llvm::Instruction* v, unsigned indirectionLevel) {
    static DumpEventDecl<llvm::Instruction*, unsigned> EnqueueEvent([](llvm::raw_ostream& os, const EventData<llvm::Instruction*, unsigned>& data){
      os << "Enqueue[" << data.get<1>() << "]: " << data.get<0>() << "\n";
    });
    PSAN_DEBUG(EnqueueEvent(v, indirectionLevel));
    varargExclusionStack.push_back(std::make_pair(v, indirectionLevel));
  };
  auto runPendingVarargExclusion = [&]() {
    // we use this function to exclude all code associated with varargs
    // the initial entry would be alloca of va_list objects (%struct.__va_list_tag)
    // related intrinsics:
    // @llvm.va_start(i8* va): initialize an va_list
    // @llvm.va_end(i8* va): tear down
    // @llvm.va_copy(i8* dst, i8* src): copying the va_list
    // on x86 the type of va_list is:
    //    %struct.__va_list_tag = type { i32, i32, i8*, i8* }
    // the values are initialized by va_start or va_copy
    // reference: https://llvm.org/docs/LangRef.html#int-varargs
    // when the value is a pointer, the indirectionLevel represents the indirection level of data
    // indirection level of 0 means the pointer value itself is excluded but not its points-to data
    // indirection level of 1 means the pointer value AND its points-to data are excluded
    // indirection level of 2 or above only makes sense for double or more levels of pointers
    // whenthere is a load on a ptr with ind.level == 0, we just taint the loaded value and done
    // when there is a load on a ptr with ind.level == 1, we continue recursion on the loaded pointer

    while (!varargExclusionStack.empty()) {
      llvm::Instruction* v = nullptr;
      unsigned indirectionLevel = 0;
      std::tie(v, indirectionLevel) = varargExclusionStack.pop_back_val();
      // (umm actually currently the value is always a pointer..)
      if (!v->getType()->isPointerTy()) {
        psan_unreachable("Non-pointer value for va_list related value exclusion");
      }
      if (!excludeValue(v, PreTransformResult::ExcludeValueKind::VA_INTERNAL)) {
        // skip handling if we have already excluded this value
        static DumpEventDecl<llvm::Value*> SkipEvent([](llvm::raw_ostream& os, const EventData<llvm::Value*>& data){
          os << "Skipping already excluded: " << data.get<0>() << "\n";
        });
        PSAN_DEBUG(SkipEvent(v));
        continue;
      }
      static DumpEventDecl<llvm::Value*, unsigned> ExcludeVararg([](llvm::raw_ostream& os, const EventData<llvm::Value*, unsigned>& data){
        os << "ExcludeVararg [" << data.get<1>() << "]: " << data.get<0>() << "\n";
      });
      PSAN_DEBUG(ExcludeVararg(v, indirectionLevel));
      for (auto& u : v->uses()) {
        llvm::Instruction* user = llvm::dyn_cast<llvm::Instruction>(u.getUser());
        if (!user) {
          // not sure when would this happen, probably some metadata?
          continue;
        }
        static DumpEventDecl<llvm::Instruction*> UserEvent([](llvm::raw_ostream& os, const EventData<llvm::Instruction*>& data){
          os << "  User: " << data.get<0>() << "\n";
        });
        PSAN_DEBUG(UserEvent(user));
        if (llvm::LoadInst* load = llvm::dyn_cast<llvm::LoadInst>(user)) {
          if (load->getType()->isPointerTy()) {
            if (indirectionLevel == 0) {
              excludeValue(load, PreTransformResult::ExcludeValueKind::VA_VALUE);
              taintValue(state, stats, info, load, true, load, InitialTaintReason::Variadic);
            } else {
              varargExcludeEnqueue(load, indirectionLevel-1);
            }
          } else {
            excludeValue(load, PreTransformResult::ExcludeValueKind::VA_VALUE);
          }
          continue;
        }
        if (llvm::StoreInst* store = llvm::dyn_cast<llvm::StoreInst>(user)) {
          excludeValue(store, PreTransformResult::ExcludeValueKind::VA_INTERNAL);
          continue;
        }
        if (llvm::CallInst* call = llvm::dyn_cast<llvm::CallInst>(user)) {
          if (call->getIntrinsicID() == llvm::Intrinsic::not_intrinsic) {
            // this could happen when we are forwarding the va_list to another variadic function
            // psan_unreachable("va_list related pointer passed to non-intrinsic call");
            continue;
          }
          excludeValue(call, PreTransformResult::ExcludeValueKind::VA_INTERNAL);
          continue;
        }
        if (llvm::GetElementPtrInst* gep = llvm::dyn_cast<llvm::GetElementPtrInst>(user)) {
          if (gep->getNumIndices() < 2) {
            // not changing the indirection
            varargExcludeEnqueue(gep, indirectionLevel);
          } else {
            switch (indirectionLevel)
            {
            default: psan_unreachable("Unexpected GEP indirection level for vararg-related code exclusion");
            case 0: {
              // the function is probably passing a struct?
              varargExcludeEnqueue(gep, 0);
            } break;
            case 1: {
              // normal case; probably working on the va_list
              llvm::Type* elty = getPointerElementType(gep->getType());
              unsigned newIndLevel = 1;
              while (elty->isPointerTy()) {
                newIndLevel += 1;
                elty = getPointerElementType(elty);
              }
              varargExcludeEnqueue(gep, newIndLevel);
            } break;
            }
          }
          continue;
        }
        // for any other instructions, if the produced values are pointers, we recurse
        if (user->getType()->isPointerTy()) {
          varargExcludeEnqueue(user, indirectionLevel);
        }
      }
    }
  };

  // check if the function has any non-call users
  // (e.g., maybe it is in a global array of function pointers)
  // currently we cannot track these users, so just taint the function
  for (auto& u : func->uses()) {
    llvm::Value* user = u.getUser();
    if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(user)) {
      if (call->getCalledOperandUse().getOperandNo() == u.getOperandNo()) {
        // this is a direct call that we can track without problem
        continue;
      }
    }
    taintValue(state, stats, info, func, true, user, InitialTaintReason::FunctionAddrTaken);
    break;
  }
  // check if any arguments in the interface bv are tainted
  // we may have already tainted the arguments in the interface bv because of the function pointer
  {
    auto& interfaceBV = getFunctionInterfaceBV(func, state);
    for (unsigned i = 0, n = func->getFunctionType()->getNumParams(); i < n; ++i) {
      if (interfaceBV.test(i)) {
        taintValue(state, stats, info, func->getArg(i), true, nullptr, InitialTaintReason::ArgInterfaceTainted);
      }
    }
  }


  for (auto& BB : func->getBasicBlockList()) {
    for (llvm::Instruction& I : BB) {
      // first, special handling for instructions that we are looking for
      if (llvm::PtrToIntInst* ptrtoint = llvm::dyn_cast<llvm::PtrToIntInst>(&I)) {
        info->ptrtoints.insert(ptrtoint);
        continue;
      }
      if (llvm::ReturnInst* ret = llvm::dyn_cast<llvm::ReturnInst>(&I)) {
        info->returns.insert(ret);
        continue;
      }
      // special handling for call
      // if we have call to inline assembly, we need to taint any input/output pointer
      // if we are calling a library function (not an intrinsic and is defined outside the module), then we also taint the input/output pointer
      // otherwise, we just skip, because we only consider the return value of call to be in opaque region if the callee return value is in opaque region
      if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(&I)) {
        bool isTaintAllPointers = false;
        InitialTaintReason reason = InitialTaintReason::Unknown;
        if (isAllocatorCall(call)) {
          // do nothing
        } else if (call->getIntrinsicID() != llvm::Intrinsic::not_intrinsic) {
          // do nothing for tainting
          // check if this is a special intrinsic
          switch (call->getIntrinsicID())
          {
          default: break;
          case llvm::Intrinsic::load_relative: {
            // we found a llvm.load.relative call
            // we will taint this call AND label the value for exclusion
            excludeValue(call, PreTransformResult::ExcludeValueKind::RELTABLE_VALUE);
            taintValue(state, stats, info, call, true, call, InitialTaintReason::RelTable);
            // then we exclude the referenced global values
            llvm::Value* reltable_value = call->getArgOperand(0);
            llvm::GlobalVariable* reltable = nullptr;
            if (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(reltable_value)) {
              excludeValue(bc, PreTransformResult::ExcludeValueKind::RELTABLE_INTERNAL);
              reltable_value = bc->getOperand(0);
            }
            if (llvm::GlobalVariable* gv = llvm::dyn_cast<llvm::GlobalVariable>(reltable_value)) {
              reltable = gv;
            }
            if (!reltable) {
              psan_unreachable("Unable to find the reltable");
            }
            // the reltable should be a (constant) global array
            // UPDATE: we should not exclude the source values of reltable, because they may be used in other code
            /*
            llvm::Constant* initializer = reltable->getInitializer();
            if (!initializer) {
              psan_unreachable("reltable without initializer?");
            }
            std::function<void(llvm::Constant*)> excludeGVRecursive = [&](llvm::Constant* v) -> void {
              if (llvm::GlobalVariable* gv = llvm::dyn_cast<llvm::GlobalVariable>(v)) {
                // these global values can still exist in the pruned IR and have users
                // (e.g., when the constant string is used in more than once place and the compiler merges the definition)
                excludeValue(gv, PreTransformResult::ExcludeValueKind::RELTABLE_VALUE);
                return;
              }
              if (llvm::ConstantExpr* cexpr = llvm::dyn_cast<llvm::ConstantExpr>(v)) {
                for (unsigned i = 0, n = cexpr->getNumOperands(); i < n; ++i) {
                  excludeGVRecursive(cexpr->getOperand(i));
                }
                return;
              }
            };
            llvm::ConstantArray* initializerArray = llvm::cast<llvm::ConstantArray>(initializer);
            for (unsigned i = 0, n = initializerArray->getNumOperands(); i < n; ++i) {
              excludeGVRecursive(initializerArray->getAggregateElement(i));
            }
            */
            // done
          } break;
          }
        } else if (call->isInlineAsm()) {
          isTaintAllPointers = true;
          reason = InitialTaintReason::ASM;
        } else if (llvm::Function* callee = call->getCalledFunction()) {
          if (callee->getBasicBlockList().empty()) {
            isTaintAllPointers = true;
            reason = InitialTaintReason::ExternCall;
          }
        } else {
          // this is an indirect call
          info->indirectCalls.insert(call);
        }
        if (isTaintAllPointers) {
          if (call->getType()->isPointerTy()) {
            taintValue(state, stats, info, call, true, call, reason);
          }
          for (llvm::Use& u : call->args()) {
            llvm::Value* arg = u.get();
            if (arg->getType()->isPointerTy()) {
              taintInstrArg(arg, call, reason);
            }
          }
        }
        continue;
      }
      // check if this is an alloca of va_list
      if (llvm::AllocaInst* alloca = llvm::dyn_cast<llvm::AllocaInst>(&I)) {
        llvm::Type* allocTy = alloca->getAllocatedType();
        if (llvm::ArrayType* aty = llvm::dyn_cast<llvm::ArrayType>(allocTy)) {
          allocTy = aty->getArrayElementType();
        }
        if (llvm::StructType* sty = llvm::dyn_cast<llvm::StructType>(allocTy)) {
          if (sty->hasName()) {
            if (sty->getName() == "struct.__va_list_tag") {
              varargExcludeEnqueue(alloca, 1);
              runPendingVarargExclusion();
              continue;
            }
          }
        }
      }
      // exclude some instructions that does not cause pointers to be tainted as opaque:
      // load/store: they do not have arithmetics and is fine
      // alloca/PHI/GEP
      // icmp
      if (llvm::isa<llvm::LoadInst>(&I)
       || llvm::isa<llvm::StoreInst>(&I)
       || llvm::isa<llvm::AtomicRMWInst>(&I)
       || llvm::isa<llvm::AtomicCmpXchgInst>(&I)
       || llvm::isa<llvm::AllocaInst>(&I)
       || llvm::isa<llvm::PHINode>(&I)
       || llvm::isa<llvm::SelectInst>(&I)
       || llvm::isa<llvm::GetElementPtrInst>(&I)
       || llvm::isa<llvm::FreezeInst>(&I)
       || llvm::isa<llvm::ICmpInst>(&I)) {
        continue;
      }
      // check if this instruction is pointer cast
      // if yes, we skip it if the cast is benign (cast to i8* or any integer pointer type),
      // otherwise, taint the source and result
      if (llvm::BitCastInst* bc = llvm::dyn_cast<llvm::BitCastInst>(&I)) {
        llvm::PointerType* srcPtrTy = llvm::dyn_cast<llvm::PointerType>(bc->getSrcTy());
        llvm::PointerType* dstPtrTy = llvm::dyn_cast<llvm::PointerType>(bc->getDestTy());
        if (!srcPtrTy && !dstPtrTy) {
          continue;
        }
        assert (srcPtrTy && dstPtrTy);
        if (isDataPointerTy(srcPtrTy) && isDataPointerTy(dstPtrTy)) {
          // check if the cast is benign
          if (isPointerCastSafe(srcPtrTy, dstPtrTy)) {
            // if yes, do nothing
          } else {
            // if no, taint both the source and result
            taintInstrArg(bc->getOperand(0), bc, InitialTaintReason::BadCast);
            taintValue(state, stats, info, bc, true, bc, InitialTaintReason::BadCast);
            // also leave a metadata for better debugging
            annotateInstr(bc, "psan_badcast");
          }
        } else {
          // not both pointers are data pointers
          // just taint them
          taintInstrArg(bc->getOperand(0), bc, InitialTaintReason::BadCast);
          taintValue(state, stats, info, bc, true, bc, InitialTaintReason::BadCast);
        }
        continue;
      }

      // if we reach here, then we probably cannot analyze this instruction
      // if there is no pointer operand or result, we taint it

      // now check if the instruction takes ptr as input or produces ptr as output
      // if there is no pointer operand or result, just skip
      if (llvm::PointerType* ptrty = llvm::dyn_cast<llvm::PointerType>(I.getType())) {
        (void) ptrty;
        taintValue(state, stats, info, &I, true, &I, InitialTaintReason::UnsupportedInstr);
      }
      // check if the instruction takes any (data) pointer operand or produces pointer result
      for (llvm::Value* operand : I.operand_values()) {
        if (operand->getType()->isPointerTy()) {
          taintInstrArg(operand, &I, InitialTaintReason::UnsupportedInstr);
        }
      }
      // special handling for inttoptr
      if (llvm::isa<llvm::IntToPtrInst>(&I)) {
        // check if any value involved comes from a function parameter/return value or a load
        // if yes, we need to set isEscapedIntToPtrFound
        // if no, try to find any (indirect) pointer operand that can flow to this value, and taint these pointers
        llvm::SmallVector<llvm::Value*> worklist;
        llvm::DenseSet<llvm::Value*> visited;
        worklist.push_back(I.getOperand(0));
        visited.insert(I.getOperand(0));
        while (!worklist.empty()) {
          llvm::Value* curValue = worklist.back();
          worklist.pop_back();
          // if this is an argument, set the flag and done
          if (llvm::isa<llvm::Argument>(curValue)) {
            state.isEscapedIntToPtrFound = true;
            break;
          }
          if (llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(curValue)) {
            // if this is a call or a load, set the flag and done
            if (llvm::isa<llvm::CallBase>(instr) || llvm::isa<llvm::LoadInst>(instr)) {
              state.isEscapedIntToPtrFound = true;
              break;
            }
            // otherwise, we check all the source operand
            // if any of them is a pointer, we taint them, otherwise we push the value into the worklist
            for (auto& u : instr->operands()) {
              llvm::Value* operand = u.get();
              if (operand->getType()->isPointerTy()) {
                taintInstrArg(operand, instr, InitialTaintReason::IntToPtr);
              } else {
                if (visited.insert(operand).second) {
                  worklist.push_back(operand);
                }
              }
            }
            continue;
          }
          // if this is not an instruction, it should be a constant
          // we only need additional handling for pointer-type constants
          if (!curValue->getType()->isPointerTy()) {
            continue;
          }
          // this should take care of the constant pointer case
          taintInstrArg(curValue, &I, InitialTaintReason::IntToPtr);
        }
      }
      // done!
    }
  }

  // check if this function is address-taken
  // add to state.funcWithAddrTaken if yes
  bool isAddrTaken = false;
  for (auto& u : func->uses()) {
    if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(u.getUser())) {
      if (call->getCalledOperandUse().getOperandNo() == u.getOperandNo()) {
        continue;
      }
    }
    isAddrTaken = true;
    break;
  }
  if (isAddrTaken) {
    state.funcWithAddrTaken.insert(func);
  }
}

void PSan::step1_opaque_region_analysis_solve(llvm::Module* srcModule, PreTransformResult& result, OpaqueRegionAnalysisState& state, StaticStats& stats)
{
  // first of all, some instructions may be considered as tainted while later code has labeled them for exclusion
  // we go through all excluded values that may be incorrectly tainted, and remove their initial taint
  for (const auto& p : state.excludeValues) {
    if (!PreTransformResult::canExcludeValueKindHaveTaint(p.second.kind)) {
      auto iter = state.opaqueRegionValues.find(p.first);
      if (iter != state.opaqueRegionValues.end()) {
        state.opaqueRegionValues.erase(iter);
      }
      if (llvm::GlobalVariable* gv = llvm::dyn_cast<llvm::GlobalVariable>(p.first)) {
        auto iterGV = state.taintedGVs.find(gv);
        if (iterGV != state.taintedGVs.end()) {
          state.taintedGVs.erase(iterGV);
        }
      } else if (llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(p.first)) {
        // no special things to do here
        (void) instr;
      }
    }
  }

  // also taint global variables that are externally defined
  // ... or global variables that have unsafe users (currently we cannot track these uses)
  std::function<bool(llvm::Constant*)> gvHasUnsafeUser = [&](llvm::Constant* value) -> bool {
    // we accept instructions and constant expressions as valid users
    // anything else (e.g., constant aggregate) are not accepted
    for (auto& u : value->uses()) {
      llvm::Value* user = u.getUser();
      if (llvm::isa<llvm::Instruction>(user)) {
        continue;
      }
      if (llvm::ConstantExpr* cexpr = llvm::dyn_cast<llvm::ConstantExpr>(user)) {
        if (gvHasUnsafeUser(cexpr)) {
          return true;
        }
        continue;
      }
      // if we reach here, this is an unexpected user
      return true;
    }
    return false;
  };
  for (llvm::GlobalVariable& gv : srcModule->globals()) {
    if (!gv.hasInitializer() || gvHasUnsafeUser(&gv)) {
      state.taintedGVs.insert(&gv);
    }
  }

  // step 1: handle all ptrtoints, calls, and gvs
  // also propagate the taint to function arg/return value
  if (!state.taintedGVs.empty()) {
    llvm::SmallVector<llvm::GlobalVariable*> tmpTaintedGVs(state.taintedGVs.begin(), state.taintedGVs.end());
    for (llvm::GlobalVariable* gv : tmpTaintedGVs) {
      handleConstantValueTaint(gv, state, stats);
    }
  }

  bool isTaintAllPtrToInt = false;
  switch (getPtrToIntPolicy())
  {
  case PtrToIntPolicy::AGGRESSIVE: break;
  case PtrToIntPolicy::CONSERVATIVE:
    isTaintAllPtrToInt = true;
    break;
  case PtrToIntPolicy::AUTO:
    isTaintAllPtrToInt = state.isEscapedIntToPtrFound;
    break;
  default:
    psan_unreachable("Unexpected PtrToIntPolicy");
  }
  for (auto iter = state.funcInfo.begin(), iterEnd = state.funcInfo.end(); iter != iterEnd; ++iter) {
    // llvm::Function* func = iter->first;
    auto* info = iter->second;
    if (!info->ptrtoints.empty() && isTaintAllPtrToInt) {
      for (auto* ptrtoint : info->ptrtoints) {
        taintValue(state, stats, info, ptrtoint->getOperand(0), false, ptrtoint);
      }
    }
    if (!info->taintedCalls.empty()) {
      llvm::SmallVector<llvm::CallBase*> calls(info->taintedCalls.begin(), info->taintedCalls.end());
      for (llvm::CallBase* call : calls) {
        handleCallReturnValueTaint(call, state, stats);
      }
    }
  }

  for (llvm::Function* func : state.taintedFunctions) {
    handleFunctionPrototypeTaint(state, stats, func, false);
  }
  state.taintedFunctions.clear();

  // step 2: solve
  // one function at a time, propagate taint until no changes made
  while(!state.functionsWithWork.empty()) {
    auto* info = state.functionsWithWork.front();
    while (!info->worklist.empty()) {
      llvm::Value* valueBeingTainted = info->worklist.pop();
      if (!valueBeingTainted->getType()->isPointerTy()) {
        psan_unreachable("Should not taint non-pointer type!");
      }
      // def to use
      for (auto& u : valueBeingTainted->uses()) {
        llvm::Instruction* user = llvm::cast<llvm::Instruction>(u.getUser());
        taintInstrUserFromOperand(valueBeingTainted, user, u.getOperandNo(), info, state, stats);
      }
      // use to def
      if (llvm::Instruction* def = llvm::dyn_cast<llvm::Instruction>(valueBeingTainted)) {
        // we only taint for cast, gep, and PHI and select
        if (llvm::isa<llvm::BitCastInst>(def)
         || llvm::isa<llvm::GetElementPtrInst>(def)
         || llvm::isa<llvm::PHINode>(def)
         || llvm::isa<llvm::SelectInst>(def)) {
          for (auto* v : def->operand_values()) {
            if (v->getType()->isPointerTy()) {
              taintValue(state, stats, info, v, false, valueBeingTainted);
            }
          }
        }
      }
    }
    state.functionsWithWork.removeFront();
    // now we check if we need to go to the callers of this function and taint call argument / return values
    // we need this to be after removing the current function from worklist, so that recursive calls are handled correctly
    // (if we remove the function from worklist after visiting the callers, we may not properly handle recursive calls that taint one argument due to another)
    auto& bv = getFunctionInterfaceBV(info->func, state);
    llvm::FunctionType* funcTy = info->func->getFunctionType();
    for (auto& u : info->func->uses()) {
      llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(u.getUser());
      if (!call || call->getCalledFunction() != info->func) {
        continue;
      }
      // check the arguments
      unsigned argcount = call->arg_size();
      if (argcount > funcTy->getNumParams()) {
        argcount = funcTy->getNumParams();
      }
      decltype(info) callerInfo = nullptr;
      for (unsigned i = 0; i < argcount; ++i) {
        if (bv.test(i)) {
          if (!callerInfo) {
            auto iterCaller = state.funcInfo.find(call->getFunction());
            if (iterCaller == state.funcInfo.end()) {
              psan_unreachable("Caller not found in funcInfo");
            }
            callerInfo = iterCaller->second;
          }
          taintValue(state, stats, callerInfo, call->getArgOperand(i), false, info->func->getArg(i));
        }
      }
      // check the return value
      if (bv.test(funcTy->getNumParams()) && call->getType()->isPointerTy()) {
        if (!callerInfo) {
          auto iterCaller = state.funcInfo.find(call->getFunction());
          if (iterCaller == state.funcInfo.end()) {
            psan_unreachable("Caller not found in funcInfo");
          }
          callerInfo = iterCaller->second;
        }
        taintValue(state, stats, callerInfo, call, false, info->func);
      }
    }
    // also, since we did not taint arguments when taintValue() is called on the functions,
    // we should taint arguments here
    for (unsigned i = 0, n = funcTy->getNumParams(); i < n; ++i) {
      if (bv.test(i)) {
        taintValue(state, stats, info, info->func->getArg(i), false, info->func);
      }
    }
  }
}