#include <sstream>
#include "eptg.h"
#include "psan.h"
#include "FastDebugDumper.h"
#include "Graphs/DOTGraphTraits.h"

using namespace PSan;
using namespace SVF;
using namespace SVF::SVFUtil;

namespace SVF {

template<>
struct DOTGraphTraits<EPTG*> : public DefaultDOTGraphTraits
{
  typedef EPTGNode NodeType;

  DOTGraphTraits(bool isSimple = false) : DefaultDOTGraphTraits(isSimple)
  {
  }

  /// Return name of the graph
  static std::string getGraphName(EPTG*)
  {
    return "EPTG";
  }

  static std::string getGraphProperties(const EPTG*)
  {
    return "\trankdir=LR;";
  }

  static bool isNodeHidden(EPTGNode* node, EPTG*)
  {
    return false;
  }

  /// Return function name;
  static std::string getNodeLabel(EPTGNode *node, EPTG*)
  {
    return node->getNodeTitle() + "\n" + node->getNodeBackingValueDescription();
  }

  static std::string getNodeAttributes(EPTGNode *node, EPTG*)
  {
    std::string str;
    std::stringstream rawstr(str);
    // use the node type to determine the attribute
    if (AllocEPTGNode* allocNode = SVFUtil::dyn_cast<AllocEPTGNode>(node)) {
      (void) allocNode;
      rawstr << "color=green";
    } else if (CellEPTGNode* cellNode = SVFUtil::dyn_cast<CellEPTGNode>(node)) {
      (void) cellNode;
      rawstr << "color=yellow";
    } else if (ExpressionEPTGNode* exprNode = SVFUtil::dyn_cast<ExpressionEPTGNode>(node)) {
      (void) exprNode;
      rawstr << "color=black";
    } else {
      psan_unreachable("Unknown EPTGNode type");
    }
    if (node->getIsTainted()) {
      rawstr << ",style=filled,fillcolor=red";
    }
    return rawstr.str();
  }

  template<class EdgeIter>
  static std::string getEdgeAttributes(EPTGNode* node, EdgeIter EI, EPTG*)
  {
    (void) node;
    EPTGEdge *edge = *(EI.getCurrent());
    std::string str;
    std::stringstream rawstr(str);

    // to make sure all the expression nodes have a lower rank (i.e., at the right side),
    // we reverse the constraint direction for all edges from expression nodes to cell nodes
    // the way we reverse the constraint direction is:
    // 1. We set constraint=false for all such edges
    // 2. We add an invisible (style=invis) edge from the destination node to the source node later on
    if (ContainsEPTGEdge* containsEdge = SVFUtil::dyn_cast<ContainsEPTGEdge>(edge)) {
      rawstr << "label=\"" << SVF::DOT::EscapeStr(containsEdge->getMemberPosition().toString()) << "\"";
    } else if (PointsToEPTGEdge* pointsToEdge = SVFUtil::dyn_cast<PointsToEPTGEdge>(edge)) {
      (void) pointsToEdge;
      rawstr << "style=dashed,constraint=false";
    } else if (CopyEPTGEdge* copyEdge = SVFUtil::dyn_cast<CopyEPTGEdge>(edge)) {
      (void) copyEdge;
      rawstr << "color=black";
    } else if (AllocEPTGEdge* allocEdge = SVFUtil::dyn_cast<AllocEPTGEdge>(edge)) {
      (void) allocEdge;
      rawstr << "color=black";
    } else if (LoadEPTGEdge* loadEdge = SVFUtil::dyn_cast<LoadEPTGEdge>(edge)) {
      (void) loadEdge;
      rawstr << "color=red";
    } else if (StoreEPTGEdge* storeEdge = SVFUtil::dyn_cast<StoreEPTGEdge>(edge)) {
      (void) storeEdge;
      rawstr << "color=blue,constraint=false";
    } else {
      psan_unreachable("Unknown EPTGEdge type");
    }
    // I keep getting error messages from xdot if there is a tooltip popping up...
    // rawstr << ",tooltip=\"" << SVF::DOT::EscapeStr(edge->toString()) << "\"";
    return rawstr.str();
  }

  template<typename GraphWriter>
  static void addCustomGraphFeatures(EPTG* eptg, GraphWriter& writer)
  {
    // we put all alloc nodes in the minimum rank
    auto& OS = writer.getOStream();
    bool isFirst = true;
    for (auto& p : *eptg) {
      EPTGNode* node = p.second;
      if (AllocEPTGNode* allocNode = SVFUtil::dyn_cast<AllocEPTGNode>(node)) {
        (void) allocNode;
        if (isFirst) {
          OS << "\tsubgraph {rank=source";
          isFirst = false;
        }
        OS << "; Node" << static_cast<void*>(node);
      }
    }
    if (!isFirst) {
      OS << "}\n";
    }
    // we also create inverse (invisible) edges for points-to and store edges (they go from expr to cells)
    for (auto& p : *eptg) {
      EPTGNode* node = p.second;
      for (auto iter = node->OutEdgeBegin(); iter != node->OutEdgeEnd(); ++iter) {
        EPTGEdge* edge = *iter;
        if (PointsToEPTGEdge* pointsToEdge = SVFUtil::dyn_cast<PointsToEPTGEdge>(edge)) {
          (void) pointsToEdge;
          OS << "\tNode" << static_cast<void*>(edge->getDstNode()) << " -> Node" << static_cast<void*>(edge->getSrcNode())
             << " [style=\"invis\"]\n";
        } else if (StoreEPTGEdge* storeEdge = SVFUtil::dyn_cast<StoreEPTGEdge>(edge)) {
          (void) storeEdge;
          OS << "\tNode" << static_cast<void*>(edge->getDstNode()) << " -> Node" << static_cast<void*>(edge->getSrcNode())
             << " [style=\"invis\"]\n";
        }
      }
    }
  }
};

} // end namespace SVF

template<typename OStream>
void writeValue(OStream& os, llvm::Value* v, bool details = false)
{
  if (llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(v)) {
    os << "@" << instr->getFunction()->getName() << ": ";
  } else if (llvm::Argument* arg = llvm::dyn_cast<llvm::Argument>(v)) {
    os << "@" << arg->getParent()->getName() << ": ";
  }
  if (details) {
    v->print(os, FastDebugDumper::getSlotTracker(FastDebugDumper::getModuleFromVal(v)));
  } else {
    if (v->hasName()) {
      os << v->getName();
    } else {
      os << "(unnamed)";
    }
  }
}

const std::string EPTGEdge::toString() const
{
  std::string str;
  std::stringstream rawstr(str);
  rawstr << "EPTGEdge: [EPTGNode" << getDstID() << " <-- EPTGNode" << getSrcID() << "]\t";
  return rawstr.str();
}

bool EPTGEdge::operator<(const EPTGEdge& rhs) const
{
  if (getEdgeKind() != rhs.getEdgeKind()) {
    return getEdgeKind() < rhs.getEdgeKind();
  }
  if (getSrcID() != rhs.getSrcID()) {
    return getSrcID() < rhs.getSrcID();
  }
  if (getDstID() != rhs.getDstID()) {
    return getDstID() < rhs.getDstID();
  }

  // if this is a contains edge, we also compare the member position
  if (const ContainsEPTGEdge* containsEdge = SVFUtil::dyn_cast<ContainsEPTGEdge>(this)) {
    const ContainsEPTGEdge* rhsContainsEdge = SVFUtil::cast<ContainsEPTGEdge>(&rhs);
    return containsEdge->getMemberPosition() < rhsContainsEdge->getMemberPosition();
  }
  return true;
}
bool EPTGEdge::operator==(const EPTGEdge& rhs) const
{
  if (getEdgeKind() != rhs.getEdgeKind()) {
    return false;
  }
  if (getSrcID() != rhs.getSrcID()) {
    return false;
  }
  if (getDstID() != rhs.getDstID()) {
    return false;
  }

  // if this is a contains edge, we also compare the member position
  if (const ContainsEPTGEdge* containsEdge = SVFUtil::dyn_cast<ContainsEPTGEdge>(this)) {
    const ContainsEPTGEdge* rhsContainsEdge = SVFUtil::cast<ContainsEPTGEdge>(&rhs);
    return containsEdge->getMemberPosition() == rhsContainsEdge->getMemberPosition();
  }
  return true;
}

void MemberPosition::print(llvm::raw_ostream& os) const
{
  if (empty()) {
    os << "[]";
    return;
  }
  os << '[' << pos.front();
  for (std::size_t i = 1, n = size(); i < n; ++i) {
    os << ',' << pos[i];
  }
  os << ']';
}

const std::string ContainsEPTGEdge::toString() const
{
  std::string str;
  std::stringstream rawstr(str);
  rawstr << "ContainsEPTGEdge: [EPTGNode" << getDstID() << " <-- EPTGNode" << getSrcID() << "] (" + pos.toString() + ")\t";
  return rawstr.str();
}

const std::string PointsToEPTGEdge::toString() const
{
  std::string str;
  std::stringstream rawstr(str);
  rawstr << "PointsToEPTGEdge: [EPTGNode" << getDstID() << " <-- EPTGNode" << getSrcID() << "]\t";
  return rawstr.str();
}

const std::string CopyEPTGEdge::toString() const
{
  std::string str;
  std::stringstream rawstr(str);
  rawstr << "CopyEPTGEdge: [EPTGNode" << getDstID() << " <-- EPTGNode" << getSrcID() << "]\t";
  return rawstr.str();
}

const std::string AllocEPTGEdge::toString() const
{
  std::string str;
  std::stringstream rawstr(str);
  rawstr << "AllocEPTGEdge: [EPTGNode" << getDstID() << " <-- EPTGNode" << getSrcID() << "]\t";
  return rawstr.str();
}

const std::string LoadEPTGEdge::toString() const
{
  std::string str;
  std::stringstream rawstr(str);
  rawstr << "LoadEPTGEdge: [EPTGNode" << getDstID() << " <-- EPTGNode" << getSrcID() << "]\t";
  return rawstr.str();
}

const std::string StoreEPTGEdge::toString() const
{
  std::string str;
  std::stringstream rawstr(str);
  rawstr << "StoreEPTGEdge: [EPTGNode" << getDstID() << " <-- EPTGNode" << getSrcID() << "]\t";
  return rawstr.str();
}

const std::string EPTGNode::toString() const
{
  std::string str;
  std::stringstream rawstr(str);
  rawstr << "EPTGNode: [ID: " << getId() << "]\t";
  return rawstr.str();
}
const std::string EPTGNode::getNodeTitle() const
{
  return toString();
}
const std::string EPTGNode::getNodeBackingValueDescription() const
{
  std::string result;
  llvm::raw_string_ostream os(result);
  populateAuxiliaryInfo(os);
  return result;
}

llvm::DenseMap<EPTGNode*, llvm::SmallVector<std::shared_ptr<std::string>>> EPTGNode::auxiliaryInfoMap;

void EPTGNode::populateAuxiliaryInfo(llvm::raw_ostream& os) const
{
  auto iter = auxiliaryInfoMap.find(this);
  if (iter != auxiliaryInfoMap.end()) {
    bool isFirst = true;
    for (const auto& ptr : iter->second) {
      const std::string& s = *ptr;
      if (isFirst) {
        os << s;
        isFirst = false;
      } else {
        os << "\n" << s;
      }
    }
  }
}

void EPTGNode::dump() const
{
  SVF::SVFUtil::outs() << this->toString() << "\n";
}

AllocEPTGNode::AllocEPTGNode(NodeID i, llvm::Value* AllocationSite) : EPTGNode(i, AllocNode), AllocationSite(AllocationSite)
{
  if (AllocationSite != nullptr) {
    assert (llvm::isa<llvm::AllocaInst>(AllocationSite) || llvm::isa<llvm::GlobalVariable>(AllocationSite)
         || llvm::isa<llvm::CallBase>(AllocationSite) || llvm::isa<llvm::Function>(AllocationSite));
  }
}

const std::string AllocEPTGNode::toString() const
{
  std::string str;
  llvm::raw_string_ostream rawstr(str);
  rawstr << "AllocEPTGNode: [ID: " << getId() << "] " << "TmpA#" << getDebugIndex() << " ";
  if (AllocationSite) {
    AllocationSite->print(rawstr, FastDebugDumper::getSlotTracker(FastDebugDumper::getModuleFromVal(AllocationSite)));
    rawstr << "\t";
  } else {
    rawstr << "(Unknown)\t";
  }

  return rawstr.str();
}

const std::string AllocEPTGNode::getNodeTitle() const
{
  std::string str;
  llvm::raw_string_ostream rawstr(str);
  rawstr << "A#" << getId() << " " << "[TmpA#" << getDebugIndex() << "] ";
  if (AllocationSite) {
    writeValue(rawstr, AllocationSite, false);
  } else {
    rawstr << "(Unknown)";
  }

  return rawstr.str();
}

const std::string AllocEPTGNode::getNodeBackingValueDescription() const
{
  std::string str;
  llvm::raw_string_ostream rawstr(str);
  if (AllocationSite) {
    if (llvm::Function* func = llvm::dyn_cast<llvm::Function>(AllocationSite)) {
      func->printAsOperand(rawstr, true, FastDebugDumper::getSlotTracker(func->getParent()));
    } else {
      AllocationSite->print(rawstr, FastDebugDumper::getSlotTracker(FastDebugDumper::getModuleFromVal(AllocationSite)));
    }
  }
  populateAuxiliaryInfo(rawstr);
  return str;
}

CellEPTGNode* AllocEPTGNode::getCell() const
{
  for (auto iter = OutEdgeBegin(); iter != OutEdgeEnd(); ++iter) {
    if (AllocEPTGEdge* allocEdge = SVFUtil::dyn_cast<AllocEPTGEdge>(*iter)) {
      auto* dstNode = allocEdge->getDstNode();
      return SVFUtil::cast<CellEPTGNode>(dstNode);
    }
  }
  psan_unreachable("AllocEPTGNode has no cell");
  return nullptr;
}

const std::string CellEPTGNode::toString() const
{
  std::string str;
  llvm::raw_string_ostream rawstr(str);
  rawstr << "CellEPTGNode: [ID: " << getId() << "] "<< "TmpC#" << getDebugIndex();
  if (ty) {
    rawstr << " ";
    ty->print(rawstr);
  }
  if (flags) {
    if (isExposed()) {
      rawstr << " (Exposed)";
    }
  }
  rawstr << "\t";
  return rawstr.str();
}

const std::string CellEPTGNode::getNodeTitle() const
{
  std::string str;
  llvm::raw_string_ostream rawstr(str);
  rawstr << "C#" << getId() << " " << "[TmpC#" << getDebugIndex() << "] ";
  if (ty) {
    ty->print(rawstr);
  } else {
    rawstr << "(Unknown)";
  }
  if (flags) {
    if (isExposed()) {
      rawstr << " (Exposed)";
    }
  }
  return rawstr.str();
}

const std::string CellEPTGNode::getNodeBackingValueDescription() const
{
  return EPTGNode::getNodeBackingValueDescription();
}

CellEPTGNode* CellEPTGNode::getSubObjectIfAvailable(const MemberPosition& pos) const
{
  for (auto iter = OutEdgeBegin(); iter != OutEdgeEnd(); ++iter) {
    if (ContainsEPTGEdge* containsEdge = SVFUtil::dyn_cast<ContainsEPTGEdge>(*iter)) {
      if (containsEdge->getMemberPosition() == pos) {
        auto* dstNode = containsEdge->getDstNode();
        return SVFUtil::cast<CellEPTGNode>(dstNode);
      }
    }
  }
  return nullptr;

}

CellEPTGNode* CellEPTGNode::getPointsTo() const
{
  for (auto iter = OutEdgeBegin(); iter != OutEdgeEnd(); ++iter) {
    if (PointsToEPTGEdge* pointsToEdge = SVFUtil::dyn_cast<PointsToEPTGEdge>(*iter)) {
      auto* dstNode = pointsToEdge->getDstNode();
      return SVFUtil::cast<CellEPTGNode>(dstNode);
    }
  }
  return nullptr;
}

CellEPTGNode* ExpressionEPTGNode::getPointsTo() const
{
  for (auto iter = OutEdgeBegin(); iter != OutEdgeEnd(); ++iter) {
    if (PointsToEPTGEdge* pointsToEdge = SVFUtil::dyn_cast<PointsToEPTGEdge>(*iter)) {
      auto* dstNode = pointsToEdge->getDstNode();
      return SVFUtil::cast<CellEPTGNode>(dstNode);
    }
  }
  return nullptr;
}

ExpressionEPTGNode::ExpressionEPTGNode(NodeID i, llvm::Value* expr, SVF::SVFGNode* def) : EPTGNode(i, ExpressionNode), expr(expr), svfgDefNode(def)
{
  // assert (expr != nullptr || def != nullptr);
}

const std::string ExpressionEPTGNode::toString() const
{
  std::string str;
  llvm::raw_string_ostream rawstr(str);
  rawstr << "ExpressionEPTGNode: [ID: " << getId() << "] " << "TmpE#" << getDebugIndex() << " ";
  if (expr) {
    expr->print(rawstr, FastDebugDumper::getSlotTracker(FastDebugDumper::getModuleFromVal(expr)));
    rawstr << "\t";
  }
  if (svfgDefNode) {
    rawstr << svfgDefNode->toString();
  }
  return rawstr.str();
}

const std::string ExpressionEPTGNode::getNodeTitle() const
{
  std::string str;
  llvm::raw_string_ostream rawstr(str);
  rawstr << "E#" << getId() << " "<< "[TmpE#" << getDebugIndex() << "] ";
  if (expr) {
    writeValue(rawstr, expr, false);
  } else {
    rawstr << "(Unknown)";
  }
  return rawstr.str();
}

const std::string ExpressionEPTGNode::getNodeBackingValueDescription() const
{
  std::string str;
  llvm::raw_string_ostream rawstr(str);
  if (expr) {
    if (llvm::Function* func = llvm::dyn_cast<llvm::Function>(expr)) {
      func->printAsOperand(rawstr, true, FastDebugDumper::getSlotTracker(func->getParent()));
    } else {
      expr->print(rawstr, FastDebugDumper::getSlotTracker(FastDebugDumper::getModuleFromVal(expr)));
    }
  }
  populateAuxiliaryInfo(rawstr);
  return str;
}

EPTG::EPTG(llvm::Module* module) : module(module)
{

}

EPTG::~EPTG()
{

}

EPTGEdge* EPTG::getEPTGEdge(const EPTGNode* src, const EPTGNode* dst, EPTGEdge::EPTGEdgeK kind)
{
  EPTGEdge * edge = nullptr;
  u32_t counter = 0;
  for (EPTGEdge::EPTGEdgeSetTy::iterator iter = src->OutEdgeBegin(); iter != src->OutEdgeEnd(); ++iter)
  {
    if ((*iter)->getDstID() == dst->getId() && (*iter)->getEdgeKind() == kind)
    {
      counter++;
      edge = (*iter);
    }
  }
  assert(counter <= 1 && "there's more than one edge between two EPTG nodes");
  return edge;
}

void EPTG::dump(const std::string& file, bool simple)
{
  GraphPrinter::WriteGraphToFile(SVFUtil::outs(), file, this, simple);
}

void EPTG::view()
{
  SVF::ViewGraph(this, "Extended Points-To Graph");
}

ExpressionEPTGNode* EPTG::getExpressionNode(llvm::Value* srcValue)
{
  auto iter = valueToExpressionNodeMap.find(srcValue);
  if (iter != valueToExpressionNodeMap.end()) {
    auto* node = iter->second;
    // we only return the node if it is not tainted
    if (!node->getIsTainted()) {
      return node;
    }
  }
  return nullptr;
}

void EPTG::addEPTGNode(EPTGNode* node)
{
  if (ExpressionEPTGNode* expr = llvm::dyn_cast<ExpressionEPTGNode>(node)) {
    if (llvm::Value* v = expr->getExpression()) {
      // first, check if the value belongs to the current module
      // if not, just error
      if (llvm::GlobalVariable* gv = llvm::dyn_cast<llvm::GlobalVariable>(v)) {
        if (gv->getParent() != module) {
          psan_unreachable("Global variable not from source module");
        }
      } else if (llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(v)) {
        if (instr->getModule() != module) {
          psan_unreachable("Instruction not from source module");
        }
      }
      // then add the value to the map
      auto p = valueToExpressionNodeMap.insert(std::make_pair(v, expr));
      assert (p.second && "ExpressionEPTGNode already exists for the given value");
    }
  }
  return addGNode(node->getId(), node);
}

MemberPosition MemberPosition::get(const llvm::GetElementPtrInst* gep)
{
  MemberPosition::PositionType result;
  if (gep->getNumIndices() < 2)
    return MemberPosition(result);
  llvm::Type* curType = getPointerElementType(gep->getPointerOperand()->getType());
  for (unsigned i = 1, n = gep->getNumIndices(); i < n; ++i) {
    llvm::Value* curIndex = gep->getOperand(1+i);
    if (llvm::StructType* sty = llvm::dyn_cast<llvm::StructType>(curType)) {
      llvm::ConstantInt* idx = llvm::cast<llvm::ConstantInt>(curIndex);
      std::uint64_t idxValue = idx->getZExtValue();
      curType = sty->getTypeAtIndex(idxValue);
      result.push_back(idxValue);
    } else if (llvm::ArrayType* aty = llvm::dyn_cast<llvm::ArrayType>(curType)) {
      curType = aty->getElementType();
      result.push_back(0);
    } else if (llvm::VectorType* vty = llvm::dyn_cast<llvm::VectorType>(curType)) {
      curType = vty->getElementType();
      result.push_back(0);
    } else {
      psan_unreachable("Unexpected type for GEP instruction");
    }
  }
  assert(curType == getPointerElementType(llvm::cast<llvm::PointerType>(gep->getType())));
  return MemberPosition(result);
}

MemberPosition MemberPosition::get(const llvm::Value* gepValue)
{
  // case for GEP instruction
  if (const llvm::GetElementPtrInst* gep = llvm::dyn_cast<const llvm::GetElementPtrInst>(gepValue)) {
    return get(gep);
  }
  // case for special intrinsics (e.g., memset)
  if (const llvm::CallInst* call = llvm::dyn_cast<const llvm::CallInst>(gepValue)) {
    switch (call->getIntrinsicID())
    {
    default: psan_unreachable("Unexpected callee for calls yielding gep node");
    case llvm::Intrinsic::memmove_element_unordered_atomic:
    case llvm::Intrinsic::memmove:
    case llvm::Intrinsic::memcpy_element_unordered_atomic:
    case llvm::Intrinsic::memcpy:
    case llvm::Intrinsic::memset_element_unordered_atomic:
    case llvm::Intrinsic::memset:
      return MemberPosition();
    case llvm::Intrinsic::not_intrinsic: {
      if (llvm::Function* callee = call->getCalledFunction()) {
        (void) callee;
        return MemberPosition();
      }
      psan_unreachable("Unexpected callee for calls yielding gep node");
    } break;
    }
  }
  // if there is a global struct with initializer, SVFG will contain GEP nodes for the initialization
  // we will just ignore them
  if (const llvm::GlobalVariable* gv = llvm::dyn_cast<const llvm::GlobalVariable>(gepValue)) {
    (void) gv;
    return MemberPosition();
  }
  // case for GEP constexpr
  const llvm::ConstantExpr* expr = llvm::cast<const llvm::ConstantExpr>(gepValue);
  assert(expr->getOpcode() == llvm::Instruction::GetElementPtr);
  unsigned numIndices = expr->getNumOperands() - 1;
  if (numIndices < 2)
    return MemberPosition();

  MemberPosition::PositionType result;
  llvm::Type* curType = getPointerElementType(expr->getOperand(0)->getType());
  for (unsigned i = 1; i < numIndices; ++i) {
    llvm::Value* curIndex = expr->getOperand(1+i);
    if (llvm::StructType* sty = llvm::dyn_cast<llvm::StructType>(curType)) {
      llvm::ConstantInt* idx = llvm::cast<llvm::ConstantInt>(curIndex);
      std::uint64_t idxValue = idx->getZExtValue();
      curType = sty->getTypeAtIndex(idxValue);
      result.push_back(idxValue);
    } else if (llvm::ArrayType* aty = llvm::dyn_cast<llvm::ArrayType>(curType)) {
      curType = aty->getElementType();
      result.push_back(0);
    }
  }
  assert(curType == getPointerElementType(llvm::cast<llvm::PointerType>(expr->getType())));
  return MemberPosition(result);
}

MemberPosition MemberPosition::get(const SVF::GepSVFGNode* node)
{
  // GepSVFGNode should only have 1 incoming edge that is direct
  // and the source should have an llvm::value
  // if we found that the source pointer to the gep instr / constexpr does not match with the value from GepSVFGNode upstream,
  // we need to traverse over the gep instr / constexpr to discover collapsed intermediate geps
  const SVF::SVFGNode* srcNode = nullptr;
  {
    const auto& edgeSet = node->getInEdges();
    assert(edgeSet.size() == 1);
    SVF::SVFGEdge* edge = *edgeSet.begin();
    assert(edge->isDirectVFGEdge());
    srcNode = edge->getSrcNode();
    assert(node == edge->getDstNode());
  }
  const llvm::Value* srcValue = getLLVMValue(srcNode->getValue());
  const llvm::Value* currentValue = getLLVMValue(node->getValue());
  MemberPosition result = get(currentValue);
  const llvm::User* u = llvm::cast<const llvm::User>(currentValue);

  // special handling for library function calls
  if (const llvm::CallInst* call = llvm::dyn_cast<const llvm::CallInst>(u)) {
    (void) call;
    return result;
  }
  // and for gv initializers
  if (const llvm::GlobalVariable* gv = llvm::dyn_cast<llvm::GlobalVariable>(u)) {
    (void) gv;
    return result;
  }
  // special case for gep-ing on null pointer (srcNode is NullPtrSVFGNode)
  if (!srcValue) {
    return result;
  }

  assert (llvm::isa<const llvm::GetElementPtrInst>(u) || llvm::isa<const llvm::ConstantExpr>(u));
  const llvm::Value* curSrcValue = u->getOperand(0); // both for gep instruction and gep constexpr
  while(curSrcValue != srcValue) {
    currentValue = curSrcValue;
    MemberPosition prefix = get(currentValue);
    result = result.addPrefix(prefix);
    u = llvm::cast<const llvm::User>(currentValue);
    curSrcValue = u->getOperand(0);
  }
  return result;
}

llvm::Type* MemberPosition::getTypeAtPos(llvm::Type* Ty, const MemberPosition& pos)
{
  llvm::Type* curType = Ty;
  for (auto idx : pos) {
    assert(idx >= 0 && "MemberPosition::getTypeAtPos() with negative index!");
    if (llvm::StructType* sty = llvm::dyn_cast<llvm::StructType>(curType)) {
      curType = sty->getTypeAtIndex(idx);
    } else if (llvm::ArrayType* aty = llvm::dyn_cast<llvm::ArrayType>(curType)) {
      assert(idx == 0 && "MemberPosition::getTypeAtPos(): non-zero index for array member access!");
      curType = aty->getElementType();
    }
  }
  return curType;
}
