#ifndef PSAN_S2_H
#define PSAN_S2_H

#include "psan.h"

namespace PSan {

extern const char PSAN_PLACEHOLDER_NAME_PREFIX[];

struct FunctionCFGPruneState {
  enum BasicBlockState {
    USED,
    CALLONLY,
    EMPTY
  };
  // map each basic block to an index
  // entry block always has the index of zero
  llvm::DenseMap<llvm::BasicBlock*, unsigned> blockIndexMap;
  llvm::SmallVector<llvm::BasicBlock*> blockList;

  // for each block, what is the state
  // if the block has the used bit, it cannot be removed
  // if the block has the callonly bit, when we remove instructions,
  //    we check whether we should update the state of the block
  // otherwise, the block is empty, and all blocks jumping to it must be redirected
  llvm::BitVector callonly_blocks;
  llvm::BitVector usedblocks;

  // for each basic block, what's the descendents
  // (if it becomes empty, where should other blocks jump to)
  // llvm::SmallVector<llvm::SmallVector<unsigned, 2>> descendents;

  // set to true if the function only contains empty blocks
  bool isFunctionDead = false;
  // for efficiency
  std::size_t numCallonlyBlocks = 0;
  std::size_t numUsedBlocks = 0;
};

class PlaceholderFunctionManager {
private:
  llvm::Module* clonedModule;
  llvm::DenseMap<llvm::Type*, llvm::Function*> placeholderFunctions;
  llvm::DenseMap<llvm::Function*, llvm::DenseMap<llvm::Type*, llvm::WeakTrackingVH>> globalPlaceholderCalls;
public:
  explicit PlaceholderFunctionManager(llvm::Module* clonedModule) : clonedModule(clonedModule) {}
  llvm::Function* getPlaceholderFunction(llvm::Type* ty) {
    auto iter = placeholderFunctions.find(ty);
    if (iter != placeholderFunctions.end()) {
      return iter->second;
    }
    llvm::Function* func = llvm::Function::Create(llvm::FunctionType::get(ty, false), llvm::GlobalValue::LinkageTypes::ExternalLinkage,
      llvm::Twine(PSAN_PLACEHOLDER_NAME_PREFIX, std::to_string(placeholderFunctions.size())),
      *clonedModule);
    placeholderFunctions.insert(std::make_pair(ty, func));
    return func;
  };
  llvm::Value* getPlaceholderValue(llvm::Function* func, llvm::Type* ty) {
    auto& placeholderCalls = globalPlaceholderCalls[func];
    auto iter = placeholderCalls.find(ty);
    if (iter != placeholderCalls.end() && iter->second.pointsToAliveValue()) {
      return iter->second;
    }
    llvm::Function* callee = getPlaceholderFunction(ty);
    llvm::CallInst* call = llvm::CallInst::Create(callee->getFunctionType(), callee, {}, "placeholder", &*func->getEntryBlock().getFirstInsertionPt());
    placeholderCalls[ty] = call;
    //placeholderCalls.insert(std::make_pair(ty, call));
    return call;
  };
};

bool step2_pruning_isInstrTriviallyDead(llvm::Instruction* instr);
void step2_pruning_dropDeadInstr(llvm::Instruction* instr);
void step2_pruning_trivialDCE(llvm::Function* clonedFunc);
void step2_pruning_trivialDCE(llvm::BasicBlock* block);
void step2_pruning_buildFunctionInfo(llvm::Function* func, FunctionCFGPruneState& state);
void step2_pruning_cleanup(llvm::Function* func, FunctionCFGPruneState& state, PlaceholderFunctionManager& placeholders);
void step2_pruning_entry(llvm::Module* dstModule, PreTransformResult& decisions, llvm::ValueToValueMapTy& mapping, llvm::DenseMap<llvm::Value*,llvm::Value*>& taintedClones, StaticStats& stats, PlaceholderFunctionManager& placeholders);

} // end namespace PSan

#endif // PSAN_S2_H
