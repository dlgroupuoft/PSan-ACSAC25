#include "psan.h"
#include "Graphs/DOTGraphTraits.h"
#include "SVFIR/SVFModule.h"
#include "Util/SVFUtil.h"
#include "Graphs/SVFG.h"
#include "Graphs/SVFGOPT.h"
#include "Graphs/SVFGStat.h"
#include "Graphs/ICFG.h"
#include "Util/Options.h"

using namespace PSan;
using namespace SVF;
using namespace SVF::SVFUtil;

namespace SVF {

template<>
struct DOTGraphTraits<SVFG*> : public DOTGraphTraits<SVFIR*>
{

    typedef SVFGNode NodeType;
    DOTGraphTraits(bool isSimple = false) :
        DOTGraphTraits<SVFIR*>(isSimple)
    {
    }

    /// Return name of the graph
    static std::string getGraphName(SVFG*)
    {
        return "SVFG";
    }

    /// isNodeHidden - If the function returns true, the given node is not
    /// displayed in the graph
    static bool isNodeHidden(SVFGNode *node, SVFG *)
    {
        if (Options::ShowHiddenNode()) return false;
        else return node->getInEdges().empty() && node->getOutEdges().empty();
    }

    std::string getNodeLabel(NodeType *node, SVFG *graph)
    {
        if (isSimple())
            return getSimpleNodeLabel(node, graph);
        else
            return getCompleteNodeLabel(node, graph);
    }

    /// Return label of a VFG node without MemSSA information
    static std::string getSimpleNodeLabel(NodeType *node, SVFG*)
    {
        std::string str;
        std::stringstream rawstr(str);
        if(StmtSVFGNode* stmtNode = SVFUtil::dyn_cast<StmtSVFGNode>(node))
        {
            rawstr << stmtNode->toString();
        }
        else if(PHISVFGNode* tphi = SVFUtil::dyn_cast<PHISVFGNode>(node))
        {
            rawstr << tphi->toString();
        }
        else if(FormalParmSVFGNode* fp = SVFUtil::dyn_cast<FormalParmSVFGNode>(node))
        {
            rawstr << fp->toString();
        }
        else if(ActualParmSVFGNode* ap = SVFUtil::dyn_cast<ActualParmSVFGNode>(node))
        {
            rawstr << ap->toString();
        }
        else if (ActualRetSVFGNode* ar = SVFUtil::dyn_cast<ActualRetSVFGNode>(node))
        {
            rawstr << ar->toString();
        }
        else if (FormalRetSVFGNode* fr = SVFUtil::dyn_cast<FormalRetSVFGNode>(node))
        {
            rawstr << fr->toString();
        }
        else if(FormalINSVFGNode* fi = SVFUtil::dyn_cast<FormalINSVFGNode>(node))
        {
            rawstr << fi->toString();
        }
        else if(FormalOUTSVFGNode* fo = SVFUtil::dyn_cast<FormalOUTSVFGNode>(node))
        {
            rawstr << fo->toString();
        }
        else if(ActualINSVFGNode* ai = SVFUtil::dyn_cast<ActualINSVFGNode>(node))
        {
            rawstr << ai->toString();
        }
        else if(ActualOUTSVFGNode* ao = SVFUtil::dyn_cast<ActualOUTSVFGNode>(node))
        {
            rawstr << ao->toString();
        }
        else if(MSSAPHISVFGNode* mphi = SVFUtil::dyn_cast<MSSAPHISVFGNode>(node))
        {
            rawstr << mphi->toString();
        }
        else if(SVFUtil::isa<NullPtrSVFGNode>(node))
        {
            rawstr << "NullPtr";
        }
        else if(BinaryOPVFGNode* bop = SVFUtil::dyn_cast<BinaryOPVFGNode>(node))
        {
            rawstr << bop->toString();
        }
        else if(UnaryOPVFGNode* uop = SVFUtil::dyn_cast<UnaryOPVFGNode>(node))
        {
            rawstr << uop->toString();
        }
        else if(CmpVFGNode* cmp = SVFUtil::dyn_cast<CmpVFGNode>(node))
        {
            rawstr << cmp->toString();
        }
        else
            assert(false && "what else kinds of nodes do we have??");

        return rawstr.str();
    }

    /// Return label of a VFG node with MemSSA information
    static std::string getCompleteNodeLabel(NodeType *node, SVFG*)
    {

        std::string str;
        std::stringstream rawstr(str);
        if(StmtSVFGNode* stmtNode = SVFUtil::dyn_cast<StmtSVFGNode>(node))
        {
            rawstr << stmtNode->toString();
        }
        else if(BinaryOPVFGNode* bop = SVFUtil::dyn_cast<BinaryOPVFGNode>(node))
        {
            rawstr << bop->toString();
        }
        else if(UnaryOPVFGNode* uop = SVFUtil::dyn_cast<UnaryOPVFGNode>(node))
        {
            rawstr << uop->toString();
        }
        else if(CmpVFGNode* cmp = SVFUtil::dyn_cast<CmpVFGNode>(node))
        {
            rawstr << cmp->toString();
        }
        else if(MSSAPHISVFGNode* mphi = SVFUtil::dyn_cast<MSSAPHISVFGNode>(node))
        {
            rawstr << mphi->toString();
        }
        else if(PHISVFGNode* tphi = SVFUtil::dyn_cast<PHISVFGNode>(node))
        {
            rawstr << tphi->toString();
        }
        else if(FormalINSVFGNode* fi = SVFUtil::dyn_cast<FormalINSVFGNode>(node))
        {
            rawstr	<< fi->toString();
        }
        else if(FormalOUTSVFGNode* fo = SVFUtil::dyn_cast<FormalOUTSVFGNode>(node))
        {
            rawstr << fo->toString();
        }
        else if(FormalParmSVFGNode* fp = SVFUtil::dyn_cast<FormalParmSVFGNode>(node))
        {
            rawstr	<< fp->toString();
        }
        else if(ActualINSVFGNode* ai = SVFUtil::dyn_cast<ActualINSVFGNode>(node))
        {
            rawstr << ai->toString();
        }
        else if(ActualOUTSVFGNode* ao = SVFUtil::dyn_cast<ActualOUTSVFGNode>(node))
        {
            rawstr <<  ao->toString();
        }
        else if(ActualParmSVFGNode* ap = SVFUtil::dyn_cast<ActualParmSVFGNode>(node))
        {
            rawstr << ap->toString();
        }
        else if(NullPtrSVFGNode* nptr = SVFUtil::dyn_cast<NullPtrSVFGNode>(node))
        {
            rawstr << nptr->toString();
        }
        else if (ActualRetSVFGNode* ar = SVFUtil::dyn_cast<ActualRetSVFGNode>(node))
        {
            rawstr << ar->toString();
        }
        else if (FormalRetSVFGNode* fr = SVFUtil::dyn_cast<FormalRetSVFGNode>(node))
        {
            rawstr << fr->toString();
        }
        else if (BranchVFGNode* br = SVFUtil::dyn_cast<BranchVFGNode>(node))
        {
            rawstr << br->toString();
        }
        else
            assert(false && "what else kinds of nodes do we have??");

        return rawstr.str();
    }

    static std::string getNodeAttributes(NodeType *node, SVFG *graph)
    {
        std::string str;
        std::stringstream rawstr(str);

        if(StmtSVFGNode* stmtNode = SVFUtil::dyn_cast<StmtSVFGNode>(node))
        {
            const PAGEdge* edge = stmtNode->getPAGEdge();
            if (SVFUtil::isa<AddrStmt>(edge))
            {
                rawstr <<  "color=green";
            }
            else if (SVFUtil::isa<CopyStmt>(edge))
            {
                rawstr <<  "color=black";
            }
            else if (SVFUtil::isa<RetPE>(edge))
            {
                rawstr <<  "color=black,style=dotted";
            }
            else if (SVFUtil::isa<GepStmt>(edge))
            {
                rawstr <<  "color=purple";
            }
            else if (SVFUtil::isa<StoreStmt>(edge))
            {
                rawstr <<  "color=blue";
            }
            else if (SVFUtil::isa<LoadStmt>(edge))
            {
                rawstr <<  "color=red";
            }
            else
            {
                assert(0 && "No such kind edge!!");
            }
            rawstr <<  "";
        }
        else if(SVFUtil::isa<MSSAPHISVFGNode>(node))
        {
            rawstr <<  "color=black";
        }
        else if(SVFUtil::isa<PHISVFGNode>(node))
        {
            rawstr <<  "color=black";
        }
        else if(SVFUtil::isa<NullPtrSVFGNode>(node))
        {
            rawstr <<  "color=grey";
        }
        else if(SVFUtil::isa<FormalINSVFGNode>(node))
        {
            rawstr <<  "color=yellow,penwidth=2";
        }
        else if(SVFUtil::isa<FormalOUTSVFGNode>(node))
        {
            rawstr <<  "color=yellow,penwidth=2";
        }
        else if(SVFUtil::isa<FormalParmSVFGNode>(node))
        {
            rawstr <<  "color=yellow,penwidth=2";
        }
        else if(SVFUtil::isa<ActualINSVFGNode>(node))
        {
            rawstr <<  "color=yellow,penwidth=2";
        }
        else if(SVFUtil::isa<ActualOUTSVFGNode>(node))
        {
            rawstr <<  "color=yellow,penwidth=2";
        }
        else if(SVFUtil::isa<ActualParmSVFGNode>(node))
        {
            rawstr <<  "color=yellow,penwidth=2";
        }
        else if (SVFUtil::isa<ActualRetSVFGNode>(node))
        {
            rawstr <<  "color=yellow,penwidth=2";
        }
        else if (SVFUtil::isa<FormalRetSVFGNode>(node))
        {
            rawstr <<  "color=yellow,penwidth=2";
        }
        else if (SVFUtil::isa<BinaryOPVFGNode>(node))
        {
            rawstr <<  "color=black,penwidth=2";
        }
        else if (SVFUtil::isa<CmpVFGNode>(node))
        {
            rawstr <<  "color=black,penwidth=2";
        }
        else if (SVFUtil::isa<UnaryOPVFGNode>(node))
        {
            rawstr <<  "color=black,penwidth=2";
        }
        else if (SVFUtil::isa<BranchVFGNode>(node))
        {
            rawstr <<  "color=gold,penwidth=2";
        }
        else
            assert(false && "no such kind of node!!");

        /// dump slice information
        /*
        if(graph->getStat()->isSource(node))
        {
            rawstr << ",style=filled, fillcolor=red";
        }
        else if(graph->getStat()->isSink(node))
        {
            rawstr << ",style=filled, fillcolor=blue";
        }
        else if(graph->getStat()->inBackwardSlice(node))
        {
            rawstr << ",style=filled, fillcolor=yellow";
        }
        else if(graph->getStat()->inForwardSlice(node))
            rawstr << ",style=filled, fillcolor=gray";
        */

        rawstr <<  "";

        return rawstr.str();
    }

    template<class EdgeIter>
    static std::string getEdgeAttributes(NodeType*, EdgeIter EI, SVFG*)
    {
        SVFGEdge* edge = *(EI.getCurrent());
        assert(edge && "No edge found!!");
        if (SVFUtil::isa<DirectSVFGEdge>(edge))
        {
            if (SVFUtil::isa<CallDirSVFGEdge>(edge))
                return "style=solid,color=red";
            else if (SVFUtil::isa<RetDirSVFGEdge>(edge))
                return "style=solid,color=blue";
            else
                return "style=solid";
        }
        else if (SVFUtil::isa<IndirectSVFGEdge>(edge))
        {
            if (SVFUtil::isa<CallIndSVFGEdge>(edge))
                return "style=dashed,color=red";
            else if (SVFUtil::isa<RetIndSVFGEdge>(edge))
                return "style=dashed,color=blue";
            else
                return "style=dashed";
        }
        return "";
    }

    template<class EdgeIter>
    static std::string getEdgeSourceLabel(NodeType*, EdgeIter EI)
    {
        SVFGEdge* edge = *(EI.getCurrent());
        assert(edge && "No edge found!!");

        std::string str;
        std::stringstream rawstr(str);
        if (CallDirSVFGEdge* dirCall = SVFUtil::dyn_cast<CallDirSVFGEdge>(edge))
            rawstr << dirCall->getCallSiteId();
        else if (RetDirSVFGEdge* dirRet = SVFUtil::dyn_cast<RetDirSVFGEdge>(edge))
            rawstr << dirRet->getCallSiteId();
        else if (CallIndSVFGEdge* indCall = SVFUtil::dyn_cast<CallIndSVFGEdge>(edge))
            rawstr << indCall->getCallSiteId();
        else if (RetIndSVFGEdge* indRet = SVFUtil::dyn_cast<RetIndSVFGEdge>(edge))
            rawstr << indRet->getCallSiteId();

        return rawstr.str();
    }
};

// adapted from SVF::GraphWriter, echanging only on what nodes to include
class SVFGDebugGraphWriter {
public:
  using GraphType = SVF::SVFG*;

private:
  std::ofstream &O;
  const GraphType G;
  const llvm::DenseSet<SVF::SVFGNode*>& nodesToInclude;

  using DOTTraits = DOTGraphTraits<SVF::SVFG*>;
  using GTraits = GenericGraphTraits<GraphType>;
  using NodeRef = typename GTraits::NodeRef;
  using node_iterator = typename GTraits::nodes_iterator;
  using child_iterator = typename GTraits::ChildIteratorType;
  DOTTraits DTraits;

  static_assert(std::is_pointer<NodeRef>::value,
                "FIXME: Currently GraphWriter requires the NodeRef type to be "
                "a pointer.\nThe pointer usage should be moved to "
                "DOTGraphTraits, and removed from GraphWriter itself.");

    // Writes the edge labels of the node to O and returns true if there are any
    // edge labels not equal to the empty string "".
    bool getEdgeSourceLabels(std::stringstream &O2, NodeRef Node)
    {
        child_iterator EI = GTraits::child_begin(Node);
        child_iterator EE = GTraits::child_end(Node);
        bool hasEdgeSourceLabels = false;

        for (unsigned i = 0; EI != EE && i != 64; ++EI, ++i)
        {
            std::string label = DTraits.getEdgeSourceLabel(Node, EI);

            if (label.empty())
                continue;

            hasEdgeSourceLabels = true;

            if (i)
                O2 << "|";

            O2 << "<s" << i << ">" << DOT::EscapeStr(label);
        }

        if (EI != EE && hasEdgeSourceLabels)
            O2 << "|<s64>truncated...";

        return hasEdgeSourceLabels;
    }

public:
    SVFGDebugGraphWriter(std::ofstream &o, SVF::SVFG* g, bool SN, const llvm::DenseSet<SVF::SVFGNode*>& nodesToInclude)
    : O(o), G(g), nodesToInclude(nodesToInclude), DTraits(SN) {}

    void writeGraph(const std::string &Title = "")
    {
        // Output the header for the graph...
        writeHeader(Title);

        // Emit all of the nodes in the graph...
        writeNodes();

        // Output any customizations on the graph
        DOTGraphTraits<GraphType>::addCustomGraphFeatures(G, *this);

        // Output the end of the graph
        writeFooter();
    }

    void writeHeader(const std::string &Title)
    {
        std::string GraphName(DTraits.getGraphName(G));

        if (!Title.empty())
            O << "digraph \"" << DOT::EscapeStr(Title) << "\" {\n";
        else if (!GraphName.empty())
            O << "digraph \"" << DOT::EscapeStr(GraphName) << "\" {\n";
        else
            O << "digraph unnamed {\n";

        if (DTraits.renderGraphFromBottomUp())
            O << "\trankdir=\"BT\";\n";

        if (!Title.empty())
            O << "\tlabel=\"" << DOT::EscapeStr(Title) << "\";\n";
        else if (!GraphName.empty())
            O << "\tlabel=\"" << DOT::EscapeStr(GraphName) << "\";\n";
        O << DTraits.getGraphProperties(G);
        O << "\n";
    }

    void writeFooter()
    {
        // Finish off the graph
        O << "}\n";
    }

    void writeNodes()
    {
      for (SVF::SVFGNode* node : nodesToInclude) {
        writeNode(node);
      }
    }

    bool isNodeHidden(NodeRef Node)
    {
        return DTraits.isNodeHidden(Node, G) || !nodesToInclude.count(Node);
    }

    void writeNode(NodeRef Node)
    {
        std::string NodeAttributes = DTraits.getNodeAttributes(Node, G);

        O << "\tNode" << static_cast<const void*>(Node) << " [shape=record,";
        if (!NodeAttributes.empty()) O << NodeAttributes << ",";
        O << "label=\"{";

        if (!DTraits.renderGraphFromBottomUp())
        {
            O << DOT::EscapeStr(DTraits.getNodeLabel(Node, G));

            // If we should include the address of the node in the label, do so now.
            std::string Id = DTraits.getNodeIdentifierLabel(Node, G);
            if (!Id.empty())
                O << "|" << DOT::EscapeStr(Id);

            std::string NodeDesc = DTraits.getNodeDescription(Node, G);
            if (!NodeDesc.empty())
                O << "|" << DOT::EscapeStr(NodeDesc);
        }

        std::string edgeSourceLabels;
        std::stringstream EdgeSourceLabels(edgeSourceLabels);
        bool hasEdgeSourceLabels = getEdgeSourceLabels(EdgeSourceLabels, Node);

        if (hasEdgeSourceLabels)
        {
            if (!DTraits.renderGraphFromBottomUp()) O << "|";

            O << "{" << EdgeSourceLabels.str() << "}";

            if (DTraits.renderGraphFromBottomUp()) O << "|";
        }

        if (DTraits.renderGraphFromBottomUp())
        {
            O << DOT::EscapeStr(DTraits.getNodeLabel(Node, G));

            // If we should include the address of the node in the label, do so now.
            std::string Id = DTraits.getNodeIdentifierLabel(Node, G);
            if (!Id.empty())
                O << "|" << DOT::EscapeStr(Id);

            std::string NodeDesc = DTraits.getNodeDescription(Node, G);
            if (!NodeDesc.empty())
                O << "|" << DOT::EscapeStr(NodeDesc);
        }

        if (DTraits.hasEdgeDestLabels())
        {
            O << "|{";

            unsigned i = 0, e = DTraits.numEdgeDestLabels(Node);
            for (; i != e && i != 64; ++i)
            {
                if (i) O << "|";
                O << "<d" << i << ">"
                  << DOT::EscapeStr(DTraits.getEdgeDestLabel(Node, i));
            }

            if (i != e)
                O << "|<d64>truncated...";
            O << "}";
        }

        O << "}\"];\n";   // Finish printing the "node" line

        // Output all of the edges now
        child_iterator EI = GTraits::child_begin(Node);
        child_iterator EE = GTraits::child_end(Node);
        for (unsigned i = 0; EI != EE && i != 64; ++EI, ++i)
            if (!isNodeHidden(*EI))
                writeEdge(Node, i, EI);
        for (; EI != EE; ++EI)
            if (!isNodeHidden(*EI))
                writeEdge(Node, 64, EI);
    }

    void writeEdge(NodeRef Node, unsigned edgeidx, child_iterator EI)
    {
        if (NodeRef TargetNode = *EI)
        {
            int DestPort = -1;
            if (DTraits.edgeTargetsEdgeSource(Node, EI))
            {
                child_iterator TargetIt = DTraits.getEdgeTarget(Node, EI);

                // Figure out which edge this targets...
                unsigned Offset =
                    (unsigned)std::distance(GTraits::child_begin(TargetNode), TargetIt);
                DestPort = static_cast<int>(Offset);
            }

            if (DTraits.getEdgeSourceLabel(Node, EI).empty())
                edgeidx = -1;

            emitEdge(static_cast<const void*>(Node), edgeidx,
                     static_cast<const void*>(TargetNode), DestPort,
                     DTraits.getEdgeAttributes(Node, EI, G));
        }
    }

    /// emitSimpleNode - Outputs a simple (non-record) node
    void emitSimpleNode(const void *ID, const std::string &Attr,
                        const std::string &Label, unsigned NumEdgeSources = 0,
                        const std::vector<std::string> *EdgeSourceLabels = nullptr)
    {
        O << "\tNode" << ID << "[ ";
        if (!Attr.empty())
            O << Attr << ",";
        O << " label =\"";
        if (NumEdgeSources) O << "{";
        O << DOT::EscapeStr(Label);
        if (NumEdgeSources)
        {
            O << "|{";

            for (unsigned i = 0; i != NumEdgeSources; ++i)
            {
                if (i) O << "|";
                O << "<s" << i << ">";
                if (EdgeSourceLabels) O << DOT::EscapeStr((*EdgeSourceLabels)[i]);
            }
            O << "}}";
        }
        O << "\"];\n";
    }

    /// emitEdge - Output an edge from a simple node into the graph...
    void emitEdge(const void *SrcNodeID, int SrcNodePort,
                  const void *DestNodeID, int DestNodePort,
                  const std::string &Attrs)
    {
        if (SrcNodePort  > 64) return;             // Eminating from truncated part?
        if (DestNodePort > 64) DestNodePort = 64;  // Targeting the truncated part?

        O << "\tNode" << SrcNodeID;
        if (SrcNodePort >= 0)
            O << ":s" << SrcNodePort;
        O << " -> Node" << DestNodeID;
        if (DestNodePort >= 0 && DTraits.hasEdgeDestLabels())
            O << ":d" << DestNodePort;

        if (!Attrs.empty())
            O << "[" << Attrs << "]";
        O << ";\n";
    }

    /// getOStream - Get the raw output stream into the graph file. Useful to
    /// write fancy things using addCustomGraphFeatures().
    std::ofstream &getOStream()
    {
        return O;
    }

  // ---------------------------------------------------------------------
  static void write(const std::string &GraphName, SVF::SVFG* svfg, const llvm::DenseSet<SVF::SVFGNode*>& nodesToInclude) {
    std::string Filename = GraphName + ".dot";
    std::ofstream outFile(Filename);
    if (outFile.fail()) {
      SVFUtil::outs() << "  error opening file for writing!\n";
      outFile.close();
      return;
    }
    SVFUtil::outs() << "Writing '" << Filename << "'...";
    SVFGDebugGraphWriter writer(outFile, svfg, false, nodesToInclude);
    writer.writeGraph();
    outFile.close();
  }
};
} // end namespace SVF

void PSan::debugDumpSVFG(const std::string& filename, SVF::SVFG* svfg, const llvm::DenseSet<SVF::SVFGNode*>& nodesToInclude)
{
  SVFGDebugGraphWriter::write(filename, svfg, nodesToInclude);
}