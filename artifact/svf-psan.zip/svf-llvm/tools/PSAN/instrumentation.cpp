#include "instrumentation.h"
#include "psan.h"
#include <llvm/IR/Constants.h>
#include <llvm/IR/Instructions.h>
#include <llvm/IR/Operator.h>
#include "Util/CommandLine.h"

using namespace PSan;
using namespace SVF;
using namespace SVF::SVFUtil;

// ================================================================================
// InstrumentationBase
// ================================================================================

void InstrumentationBase::initInstrumentationID(unsigned id)
{
  ID = id;
  metadataTyInReg = createPointerMetadataTypes();
  nullptrMetadata = createNullPointerMetadata();
  metadataStructTy = createMetadataStructType();
  unanalyzablePtrMetadata = createUnanalyzablePointerMetadata();
  if (nullptrMetadata.size() != metadataTyInReg.size() || unanalyzablePtrMetadata.size() != metadataTyInReg.size()) {
    psan_unreachable("metadata size mismatch");
  }
  for (unsigned i = 0, n = metadataTyInReg.size(); i < n; ++i) {
    if (metadataTyInReg[i] != nullptrMetadata[i]->getType()) {
      psan_unreachable("nullptrMetadata type mismatch");
    }
    if (metadataTyInReg[i] != unanalyzablePtrMetadata[i]->getType()) {
      psan_unreachable("unanalyzablePtrMetadata type mismatch");
    }
  }
}

llvm::Type* InstrumentationBase::createMetadataStructType()
{
  const auto& ty = getPointerMetadataTypesInRegisters();
  if (ty.empty())
    return nullptr;
  if (ty.size() == 1)
    return ty[0];
  std::string name = "__psan_md_" + std::to_string(ID);
  llvm::StructType* retTy = llvm::StructType::create(ctx, name);
  retTy->setBody(ty);
  return retTy;
}

void InstrumentationBase::emitMetadataLoad(llvm::Instruction* insertBefore, llvm::Value* mdaddr, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  llvm::Type* mdTy = getPointerMetadataTypeInMemory();
  if (!mdTy)
    return;
  if (getPointerElementType(mdaddr->getType()) != mdTy) {
    psan_unreachable("metadata address type mismatch");
  }
  llvm::SmallVector<llvm::Value*> mdvalues;
  if (llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(mdTy)) {
    llvm::IntegerType* i64Ty = llvm::Type::getInt64Ty(ctx);
    llvm::IntegerType* i32Ty = llvm::Type::getInt32Ty(ctx);
    llvm::ConstantInt* i64zero = llvm::ConstantInt::get(i64Ty, 0);
    for (unsigned i = 0; i < sTy->getNumElements(); ++i) {
      llvm::ConstantInt* index = llvm::ConstantInt::get(i32Ty, i);
      llvm::GetElementPtrInst* gep = llvm::GetElementPtrInst::CreateInBounds(sTy, mdaddr, {i64zero, index}, "", insertBefore);
      llvm::LoadInst* load = new llvm::LoadInst(sTy->getElementType(i), gep, "", insertBefore);
      mdvalues.push_back(load);
    }
  } else {
    llvm::LoadInst* load = new llvm::LoadInst(mdTy, mdaddr, "", insertBefore);
    mdvalues.push_back(load);
  }
  if (!md.empty()) {
    if (md.size() != mdvalues.size()) {
      psan_unreachable("metadata size mismatch");
    }
    for (unsigned i = 0; i < md.size(); ++i) {
      llvm::Value* placeholder = md[i];
      llvm::Value* mdvalue = mdvalues[i];
      placeholder->replaceAllUsesWith(mdvalue);
      if (llvm::Instruction* inst = llvm::dyn_cast<llvm::Instruction>(placeholder)) {
        inst->eraseFromParent();
      }
    }
  }
  md = mdvalues;
}

void InstrumentationBase::emitMetadataStore(llvm::Instruction* insertBefore, llvm::Value* mdaddr, llvm::SmallVectorImpl<llvm::Value*>& md)
{
  llvm::Type* mdTy = getPointerMetadataTypeInMemory();
  if (!mdTy)
    return;
  if (getPointerElementType(mdaddr->getType()) != mdTy) {
    psan_unreachable("metadata address type mismatch");
  }
  if (llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(mdTy)) {
    if (md.size() != sTy->getNumElements()) {
      psan_unreachable("metadata size mismatch");
    }
    llvm::IntegerType* i64Ty = llvm::Type::getInt64Ty(ctx);
    llvm::IntegerType* i32Ty = llvm::Type::getInt32Ty(ctx);
    llvm::ConstantInt* i64zero = llvm::ConstantInt::get(i64Ty, 0);
    for (unsigned i = 0; i < sTy->getNumElements(); ++i) {
      llvm::ConstantInt* index = llvm::ConstantInt::get(i32Ty, i);
      llvm::GetElementPtrInst* gep = llvm::GetElementPtrInst::CreateInBounds(sTy, mdaddr, {i64zero, index}, "", insertBefore);
      llvm::Value* mdvalue = md[i];
      llvm::StoreInst* store = new llvm::StoreInst(mdvalue, gep, false, insertBefore);
      (void) store;
    }
  } else {
    if (md.size() != 1) {
      psan_unreachable("metadata size mismatch");
    }
    llvm::StoreInst* store = new llvm::StoreInst(md.front(), mdaddr, false, insertBefore);
    (void) store;
  }
}

void InstrumentationBase::createDummyCastAsCopy(llvm::SmallVectorImpl<llvm::Value*>& dest, const llvm::SmallVectorImpl<llvm::Value*>& src, llvm::Instruction* insertAfter)
{
  if (!dest.empty()) {
    psan_unreachable("dest not empty");
  }
  llvm::Instruction* prev = insertAfter;
  for (llvm::Value* value : src) {
    llvm::BitCastInst* cast = new llvm::BitCastInst(value, value->getType(), "psan_copy");
    cast->insertAfter(prev);
    prev = cast;
    dest.push_back(cast);
  }
}

bool InstrumentationBase::hasMemoryAccess(llvm::Instruction* inst, std::uint64_t& fixedAccessSize, llvm::Value*& variableAccessSize, llvm::SmallVectorImpl<llvm::Use*>& ptrArgs)
{
  if (llvm::LoadInst* load = llvm::dyn_cast<llvm::LoadInst>(inst)) {
    fixedAccessSize = getLoadStoreSize(load->getType());
    variableAccessSize = nullptr;
    ptrArgs.push_back(&load->getOperandUse(load->getPointerOperandIndex()));
    return true;
  } else if (llvm::StoreInst* store = llvm::dyn_cast<llvm::StoreInst>(inst)) {
    fixedAccessSize = getLoadStoreSize(store->getValueOperand()->getType());
    variableAccessSize = nullptr;
    ptrArgs.push_back(&store->getOperandUse(store->getPointerOperandIndex()));
    return true;
  } else if (llvm::CallInst* call = llvm::dyn_cast<llvm::CallInst>(inst)) {
    switch (call->getIntrinsicID()) {
    default: break;
    case llvm::Intrinsic::memcpy:
    case llvm::Intrinsic::memcpy_element_unordered_atomic:
    case llvm::Intrinsic::memcpy_inline:
    case llvm::Intrinsic::memmove:
    case llvm::Intrinsic::memmove_element_unordered_atomic: {
      llvm::Value* size = call->getArgOperand(2);
      if (llvm::ConstantInt* cSize = llvm::dyn_cast<llvm::ConstantInt>(size)) {
        fixedAccessSize = cSize->getZExtValue();
        variableAccessSize = nullptr;
      } else {
        fixedAccessSize = 0;
        variableAccessSize = size;
      }
      ptrArgs.push_back(&call->getOperandUse(0));
      ptrArgs.push_back(&call->getOperandUse(1));
      return true;
    } break;
    case llvm::Intrinsic::memset:
    case llvm::Intrinsic::memset_element_unordered_atomic:
    case llvm::Intrinsic::memset_inline: {
      llvm::Value* size = call->getArgOperand(2);
      if (llvm::ConstantInt* cSize = llvm::dyn_cast<llvm::ConstantInt>(size)) {
        fixedAccessSize = cSize->getZExtValue();
        variableAccessSize = nullptr;
      } else {
        fixedAccessSize = 0;
        variableAccessSize = size;
      }
      ptrArgs.push_back(&call->getOperandUse(0));
      return true;
    } break;
    }
  }
  return false;
}

llvm::Instruction* InstrumentationBase::getInsertionPointAfter(llvm::Instruction* inst)
{
  llvm::Instruction* next = inst->getNextNode();
  if (llvm::InvokeInst* invoke = llvm::dyn_cast<llvm::InvokeInst>(inst)) {
    next = &*invoke->getNormalDest()->getFirstInsertionPt();
  }
  while (llvm::isa<llvm::DbgInfoIntrinsic>(next) || llvm::isa<llvm::AllocaInst>(next)) {
    next = next->getNextNode();
  }
  return next;
}

llvm::Value* InstrumentationBase::buildAllocationSize(std::uint64_t size, llvm::Value* numArg, llvm::Instruction* insertBefore)
{
  llvm::IntegerType* i64Ty = llvm::Type::getInt64Ty(ctx);
  if (!numArg) {
    return llvm::ConstantInt::get(i64Ty, size);
  }
  if (llvm::ConstantInt* cArraySize = llvm::dyn_cast<llvm::ConstantInt>(numArg)) {
    return llvm::ConstantInt::get(i64Ty, cArraySize->getZExtValue() * size);
  }
  if (size == 1) {
    return numArg;
  }
  llvm::Value* arraySizeConverted = numArg;
  if (numArg->getType() != i64Ty) {
    arraySizeConverted = llvm::CastInst::CreateIntegerCast(numArg, i64Ty, false, "", insertBefore);
  }
  return llvm::BinaryOperator::Create(llvm::Instruction::Mul, arraySizeConverted, llvm::ConstantInt::get(i64Ty, size), "", insertBefore);
}

llvm::Value* InstrumentationBase::buildAllocationSize(llvm::Value* size, llvm::Value* numArg, llvm::Instruction* insertBefore)
{
  llvm::IntegerType* i64Ty = llvm::Type::getInt64Ty(size->getContext());
  if (!numArg) {
    return size;
  }
  if (llvm::ConstantInt* cArraySize = llvm::dyn_cast<llvm::ConstantInt>(numArg)) {
    return llvm::BinaryOperator::Create(llvm::Instruction::Mul, size, cArraySize, "", insertBefore);
  }
  llvm::Value* arraySizeConverted = numArg;
  if (numArg->getType() != i64Ty) {
    arraySizeConverted = llvm::CastInst::CreateIntegerCast(numArg, i64Ty, false, "", insertBefore);
  }
  return llvm::BinaryOperator::Create(llvm::Instruction::Mul, size, arraySizeConverted, "", insertBefore);
}

llvm::Value* InstrumentationBase::getAllocationSizeInBytes(llvm::Value* ptr, llvm::Instruction* insertBefore)
{
  llvm::IntegerType* i64Ty = llvm::Type::getInt64Ty(ctx);
  if (llvm::AllocaInst* alloca = llvm::dyn_cast<llvm::AllocaInst>(ptr)) {
    llvm::Value* arraySize = alloca->getArraySize();
    auto elementSize = M.getDataLayout().getTypeAllocSize(alloca->getAllocatedType());
    return buildAllocationSize(elementSize, arraySize, insertBefore);
  }
  if (llvm::GlobalVariable* gv = llvm::dyn_cast<llvm::GlobalVariable>(ptr)) {
    auto size = M.getDataLayout().getTypeAllocSize(gv->getValueType());
    return llvm::ConstantInt::get(i64Ty, size);
  }
  if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(ptr)) {
    if (llvm::Function* callee = call->getCalledFunction()) {
      // first, try to look at the allocsize attribute if present
      auto allocsizeAttr = callee->getFnAttribute(llvm::Attribute::AttrKind::AllocSize);
      if (allocsizeAttr.isValid()) {
        auto args = allocsizeAttr.getAllocSizeArgs();
        unsigned sizeArgno = args.first;
        llvm::Optional<unsigned> numArgno = args.second;
        llvm::Value* sizeArg = call->getArgOperand(sizeArgno);
        llvm::Value* numArg = nullptr;
        if (numArgno.has_value()) {
          numArg = call->getArgOperand(*numArgno);
        }
        return buildAllocationSize(sizeArg, numArg, insertBefore);
      }
      // then try to test the callee against known allocation functions
      if (callee->getName() == "malloc") {
        return call->getArgOperand(0);
      }
      if (callee->getName() == "calloc") {
        llvm::Value* num = call->getArgOperand(0);
        llvm::Value* size = call->getArgOperand(1);
        return buildAllocationSize(size, num, insertBefore);
      }
      if (callee->getName() == "realloc") {
        return call->getArgOperand(1);
      }
    }
  }
  psan_unreachable("unsupported allocation");
}

llvm::Value* InstrumentationBase::getSrcValue(llvm::Value* cloned) {
  if (!cloned2srcmap) {
    psan_unreachable("Graph not available");
  }
  auto it = cloned2srcmap->find(cloned);
  assert(it != cloned2srcmap->end());
  return it->second;
}

llvm::Value* InstrumentationBase::getClonedValue(llvm::Value* src) {
  if (!src2clonedmap) {
    psan_unreachable("Graph not available");
  }
  auto it = src2clonedmap->find(src);
  assert(it != src2clonedmap->end());
  return it->second;
}
