#ifndef PSAN_H
#define PSAN_H

#include <llvm/ADT/DenseMap.h>
#include <llvm/ADT/DenseSet.h>
#include <llvm/ADT/StringMap.h>
#include <llvm/ADT/SmallSet.h>
#include <llvm/ADT/DenseSet.h>
#include <llvm/ADT/SetVector.h>
#include <llvm/ADT/BitVector.h>
#include <llvm/ADT/StringSet.h>
#include <llvm/IR/Constants.h>
#include <llvm/IR/Function.h>
#include <llvm/IR/Dominators.h>
#include <llvm/IR/Intrinsics.h>
#include <llvm/Transforms/Utils/Cloning.h>
#include <llvm/Analysis/AssumptionCache.h>
#include <llvm/Analysis/LoopInfo.h>
#include <llvm/Analysis/ScalarEvolution.h>
#include <llvm/Analysis/TargetLibraryInfo.h>
#include <llvm/Analysis/LazyValueInfo.h>
#include <llvm/Support/raw_ostream.h>
#include <llvm/Support/Alignment.h>
#include "MSSA/SVFGBuilder.h"
#include "Graphs/SVFG.h"
#include "Util/WorkList.h"
#include "SVF-LLVM/LLVMModule.h"
#include "eptg.h"
#include "instrumentation.h"
#include "InstrumentOptions.h"

#include <chrono>

namespace PSan {

// LLVM 15 has no llvm::PointerType::getElementType(), so we use this wrapper
inline llvm::Type* getPointerElementType(llvm::PointerType* ty) {return ty->getNonOpaquePointerElementType();}
inline llvm::Type* getPointerElementType(llvm::Type* ty) {return ty->getNonOpaquePointerElementType();}
inline bool isDataPointerTy(llvm::Type* ty) {
  if (llvm::PointerType* ptrTy = llvm::dyn_cast<llvm::PointerType>(ty)) {
    return !getPointerElementType(ptrTy)->isFunctionTy();
  }
  return false;
}
inline bool isDataPointerTy(llvm::Value* value) {return isDataPointerTy(value->getType());}

// get log base 2 of x for size calculation
// 2^getP2(x) >= x and 2^(getP2(x)-1) < x
inline std::size_t getP2Size(std::size_t x) {
  std::size_t p2 = 0;
  std::size_t x_copy = x - 1;
  while (x_copy > 0) {
    p2++;
    x_copy >>= 1;
  }
  return p2;
}

bool isNoDebugPrint();
#define PSAN_DEBUG(x) if (!isNoDebugPrint()) (x)
#define PSAN_DEBUG_ENABLED() (!isNoDebugPrint())

llvm::raw_ostream& outs();
llvm::raw_ostream& errs();
void flush_debug_outs();

inline llvm::raw_ostream& outs_before_unreachable() {
  flush_debug_outs();
  return outs();
}

#define psan_unreachable(msg) do {PSan::flush_debug_outs(); llvm_unreachable(msg);} while (0)

// return true if we are enabling checks with > O(n) complexity
bool isEnableExpensiveVerification();
#define EXPENSIVE_VERIFICATION(x) if (isEnableExpensiveVerification()) (x)

// for helpers with complex logic that benefit from IR dump for debugging
void dumpIR(llvm::Module* module, const char* stagename);

void linkInLibrary(llvm::Module* destModule, llvm::StringRef path);

// set the debug location of newInst if needed
void handleDebugLoc(llvm::Instruction* newInst, llvm::Instruction* insertPoint);

// class for wrapping reference of a std::vector / llvm::SmallVector element
// sometimes the reference may be used when the vector is resized and the reference is invalidated
// we want to be able to catch this error
template<typename ElemT, typename VecT = llvm::SmallVector<ElemT>>
class ElementRef {
private:
  VecT* vec;
  ElemT* elem;
  std::size_t originalSize;
private:
  void check() {
    if (vec->size() != originalSize) {
      psan_unreachable("ElementRef: vector size changed after creation");
    }
  }
public:
  ElementRef(VecT& vec, ElemT& elem) : vec(&vec), elem(&elem), originalSize(vec.size()) {}
  ~ElementRef() = default;
  ElementRef(const ElementRef&) = default;
  ElementRef(ElementRef&&) = default;
  ElementRef& operator=(const ElementRef&) = default;

        ElemT* operator->()       {check(); return elem;}
  const ElemT* operator->() const {check(); return elem;}

  static ElementRef get(VecT& vec, std::size_t index) {
    if (index >= vec.size()) {
      psan_unreachable("ElementRef: index out of range");
    }
    return ElementRef(vec, vec[index]);
  }
};

// how we consider PtrToInt
enum class PtrToIntPolicy {
  CONSERVATIVE, // any ptrtoint makes the pointer escape and assigned to the opaque region
  AGGRESSIVE, // all ptrtoint instructions are assumed to only use the value of the pointer
  AUTO, // use conservative policy if any inttoptr instruction is found, aggressive policy otherwise
};

PtrToIntPolicy getPtrToIntPolicy();

enum class S2PrunePolicy {
  P0, // disable all pruning
  P1, // prune with trivial Dead-Code Elimination
  P2, // remove empty functions in addition to P1
  P3  // remove empty basic blocks in addition to P2
};

S2PrunePolicy getS2PrunePolicy();

// return true if the user does not want any (compile-time) stats
bool isNoStaticStats();

// return true if the user wants to collect runtime stats (this incurs overhead)
bool isCollectRuntimeStats();

// return true if we enable the runtime print debugging
bool isEnableRuntimePrintDebug();

// return true if we want to have an additional metadata check for every metadata store
bool isEnableRuntimeMDStoreCheckDebug();

// return true if we only use out-of-band metadata scheme and do not use EPTG
bool isDisableEPTG();

// return true if we use no-op checks
bool isNoopCheck();

// return true if the out-of-band metadata scheme should be conservative for correctness
bool isConservativeOOB();

struct TaintStatPair {
  // not only for tainted/total but also for other stats with partial/total values
  unsigned Tainted = 0;
  unsigned Total = 0;
  inline void increment(bool isTainted) {Total += 1; if (isTainted) Tainted += 1;}
  void print(llvm::raw_ostream& os);
};

struct DeltaStatPair {
  unsigned FromValue = 0;
  unsigned ToValue = 0;
  inline void increment(bool isFrom) {if (isFrom) FromValue += 1; else ToValue += 1;}
  void print(llvm::raw_ostream& os);
};

struct EnumStatType {
  llvm::SmallVector<std::size_t> values;
  llvm::SmallVector<std::string> names;

  // if some category have additional data (e.g., if we taint a value because it is used in an external call, what is the callee name),
  // we store them in additionalInfo. The index of the additionalInfo corresponds to the index of the values
  llvm::SmallVector<llvm::StringMap<std::size_t>> additionalInfo;

  inline void init(llvm::SmallVectorImpl<std::string>& srcNames) {
    values.resize(srcNames.size(), 0);
    names.append(srcNames.begin(), srcNames.end());
  }

  inline void increment(std::size_t index) {values[index] += 1;}
  inline void increment(std::size_t index, llvm::StringRef msg) {
    values[index] += 1;
    if (additionalInfo.size() <= index) {
      additionalInfo.resize(index + 1);
    }
    additionalInfo[index][msg] += 1;
  }
  void print(llvm::raw_ostream& os);
  void printJSON(llvm::raw_ostream& os);
};

using TimePointType = decltype(std::chrono::high_resolution_clock::now());

struct StaticStats {
  TaintStatPair PtrTypeInstrCount;
  TaintStatPair PtrTypeParameterCount;
  TaintStatPair GlobalValueCount;
  TaintStatPair AllocaCount;
  TaintStatPair DynamicAllocationCount;
  std::size_t   S1PreTransform_allocSizeFuncInlinedCount = 0;
  EnumStatType  S1Taint_InitialCause;
  DeltaStatPair S2Prune_GlobalVariableCount;
  DeltaStatPair S2Prune_FunctionCount;
  DeltaStatPair S2Prune_BasicBlockCount;
  DeltaStatPair S2Prune_InstructionCount;
  TaintStatPair S3_CellNodeCount;
  EnumStatType  S4_RequestedChecks;
  TaintStatPair S4_PtrLoadInEPTGCount; // number of distinct pointer load (regardless of their use) that are covered in EPTG
  TaintStatPair S4_PtrFromEPTGCheckCount; // number of pointer checks whose pointer operand is from a load and is covered in EPTG
  TaintStatPair S5_EPTGStat_FunctionCount; // number of functions in EPTG / total
  TaintStatPair S5_EPTGStat_GlobalVarCount; // number of global variables in EPTG / total
  TaintStatPair S5_EPTGStat_LocalVarCount; // number of local variables in EPTG / total
  TaintStatPair S5_EPTGStat_DynamicAllocCount; // number of dynamic allocations in EPTG / total
  TaintStatPair S5_EPTGStat_LoadCount; // number of loads in EPTG / total
  TaintStatPair S5_EPTGStat_StoreCount; // number of stores in EPTG / total
  EnumStatType  S5_TaintedAllocTypes; // tainted types string for global and local variables
  TimePointType initTime;
  TimePointType loadFinishTime;
  TimePointType s1_presolveTime;
  TimePointType s1_finishTime;
  TimePointType s1_dumpTime;
  TimePointType s2_cloneTime;
  TimePointType s2_finishTime;
  TimePointType s2_dumpTime;
  TimePointType s3_svfAnalysisTime;
  TimePointType s3_initialConstructionTime;
  TimePointType s3_finishTime;
  TimePointType s4_analysisTime;
  TimePointType s4_finishTime;
  TimePointType s5_prepTime;
  TimePointType s5_transformTime;
  TimePointType s5_mdpropTime;
  TimePointType s5_finishTime;

  // to ease implementation, we also store info about instrumenters here for runtime stats collection
  llvm::SmallVector<std::string> instrumentationNames; // all instrumentation's names, including disabled ones
  llvm::DenseMap<std::size_t, std::size_t> instrumentID2GlobalInstrumentationID; // instrumentID (in enabled instrumentation vec) -> globalInstrumentationID (in instrumentationNames)
  std::size_t maxGlobalInstrumentIDForRuntimeStats = 0; // if the global instrumentation ID >= this value, we don't collect runtime stats for it

  void print(llvm::raw_ostream& os);
  inline static void setTime(TimePointType& t) {
    t = std::chrono::high_resolution_clock::now();
  }
};

#define STATICSTAT_LIST \
  TAINT_STAT_PAIR(PtrTypeInstrCount) \
  TAINT_STAT_PAIR(PtrTypeParameterCount) \
  TAINT_STAT_PAIR(GlobalValueCount) \
  TAINT_STAT_PAIR(AllocaCount) \
  TAINT_STAT_PAIR(DynamicAllocationCount) \
  COUNT_STAT     (S1PreTransform_allocSizeFuncInlinedCount) \
  ENUM_STAT      (S1Taint_InitialCause) \
  DELTA_STAT_PAIR(S2Prune_GlobalVariableCount) \
  DELTA_STAT_PAIR(S2Prune_FunctionCount) \
  DELTA_STAT_PAIR(S2Prune_BasicBlockCount) \
  DELTA_STAT_PAIR(S2Prune_InstructionCount) \
  TAINT_STAT_PAIR(S3_CellNodeCount) \
  ENUM_STAT      (S4_RequestedChecks) \
  TAINT_STAT_PAIR(S4_PtrLoadInEPTGCount) \
  TAINT_STAT_PAIR(S4_PtrFromEPTGCheckCount) \
  TAINT_STAT_PAIR(S5_EPTGStat_FunctionCount) \
  TAINT_STAT_PAIR(S5_EPTGStat_GlobalVarCount) \
  TAINT_STAT_PAIR(S5_EPTGStat_LocalVarCount) \
  TAINT_STAT_PAIR(S5_EPTGStat_DynamicAllocCount) \
  TAINT_STAT_PAIR(S5_EPTGStat_LoadCount) \
  TAINT_STAT_PAIR(S5_EPTGStat_StoreCount) \
  ENUM_STAT      (S5_TaintedAllocTypes) \
  TIME_PERIOD("IRLoad", initTime, loadFinishTime) \
  TIME_PERIOD("S1_BeforeSolve", loadFinishTime, s1_presolveTime) \
  TIME_PERIOD("S1_Solve", s1_presolveTime, s1_finishTime) \
  TIME_PERIOD("S1_Dump", s1_finishTime, s1_dumpTime) \
  TIME_PERIOD("S2_ClonePartition", s1_dumpTime, s2_cloneTime) \
  TIME_PERIOD("S2_Prune", s2_cloneTime, s2_finishTime) \
  TIME_PERIOD("S2_Dump", s2_finishTime, s2_dumpTime) \
  TIME_PERIOD("S3_SVF", s2_dumpTime, s3_svfAnalysisTime) \
  TIME_PERIOD("S3_InitialConstruction", s3_svfAnalysisTime, s3_initialConstructionTime) \
  TIME_PERIOD("S3_Finish", s3_initialConstructionTime, s3_finishTime) \
  TIME_PERIOD("S4_Analysis", s3_finishTime, s4_analysisTime) \
  TIME_PERIOD("S4_TypeSolving", s4_analysisTime, s4_finishTime) \
  TIME_PERIOD("S5_Preparation", s4_finishTime, s5_prepTime) \
  TIME_PERIOD("S5_Transform", s5_prepTime, s5_transformTime) \
  TIME_PERIOD("S5_MDProp", s5_transformTime, s5_mdpropTime) \
  TIME_PERIOD("S5_Wrapup", s5_mdpropTime, s5_finishTime)

// done

// =========================================================
// step 1: pretransform
// =========================================================

struct PreTransformResult {
  // analysis helper
  llvm::DenseMap<llvm::Function*, llvm::DominatorTree> dtmap; // all dominator trees

  // output for performing clone+trimming
  // We currently disable the following two because:
  // 1. gvToExclude is a subset of taintedValues and we don't need special handling on them
  // 2. Currently we never exclude functions. Even address-taken functions may work with pointers in analyzable region. Therefore, functionsToExclude is always empty
  // llvm::DenseSet<llvm::GlobalVariable*> gvToExclude;
  // llvm::DenseSet<llvm::Function*> functionsToExclude;
  llvm::DenseSet<llvm::Value*> taintedValues;

  enum ExcludeValueKind {
    // for each associated excluded value, why are they excluded and how we should handle them

    // for vararg
    VA_INTERNAL,  // the code that implements vararg
    VA_VALUE,    // the associated value represents a vararg argument being retrieved
    // for switch table related code (llvm.load.relative)
    // if we have source code like:
    // void foo() {
    //   ...
    //   switch(val) {
    //   case 0: puts("A"); break;
    //   case 1: puts("B"); break;
    //     ...
    //   }
    // }
    // we will probably see something like this:
    //   @reltable.foo = [N x i32] [i32 trunc (i64 sub (i64 ptrtoint (@.str to i64), i64 ptrtoint (@reltable.foo to i64)) to i32), ...]
    //   ...
    //   %reltable.shift = shl i64 %9, 2
    //   %reltable.intrinsic = call i8* @llvm.load.relative.i64(i8* bitcast (@reltable.foo to i8*), i64 %reltable.shift)
    //   call puts(%reltable.intrinsic)
    // Basically the put() call is hoisted to outside of switch() and we are switch()ing the parameters. The reltable is the offset from the table to the actual value.
    // We know this is compiler-introduced code and there is no way to have memory errors
    RELTABLE_VALUE, // this is the value read from the reltable (probably the call to llvm.load.relative)
    RELTABLE_INTERNAL, // this is the definition of reltable (a global constant array) and depended values (probably global constant strings)

    LLVM_INTRINSIC_GLOBAL, // llvm intrinsic global variables (e.g., llvm.global_ctors)
  };
  inline static bool canExcludeValueKindHaveTaint(ExcludeValueKind kind) {
    switch (kind)
    {
    case ExcludeValueKind::VA_INTERNAL:
    case ExcludeValueKind::RELTABLE_INTERNAL:
      return false;
    default:
      return true;
    }
  }
  inline static void printExcludeKind(llvm::raw_ostream& os, ExcludeValueKind kind) {
    switch (kind)
    {
    case ExcludeValueKind::VA_INTERNAL:
      os << "VA_INTERNAL";
      break;
    case ExcludeValueKind::VA_VALUE:
      os << "VA_VALUE";
      break;
    case ExcludeValueKind::RELTABLE_VALUE:
      os << "RELTABLE_VALUE";
      break;
    case ExcludeValueKind::RELTABLE_INTERNAL:
      os << "RELTABLE_INTERNAL";
      break;
    case ExcludeValueKind::LLVM_INTRINSIC_GLOBAL:
      os << "LLVM_INTRINSIC_GLOBAL";
      break;
    default:
      os << "UNKNOWN";
      break;
    }
  }

  struct ExcludeValueInfo {
    ExcludeValueKind kind;

    explicit ExcludeValueInfo(ExcludeValueKind kind) : kind(kind) {}
    ExcludeValueInfo(const ExcludeValueInfo&) = default;
    ExcludeValueInfo(ExcludeValueInfo&&) = default;
  };

  llvm::DenseMap<llvm::Value*, ExcludeValueInfo> excludeValues;

  // in many non-pointer codes, the only code remaining after regular trimming is accessing global variables
  // to completely trim aray these functions, we put all gvs that are (1) without pointers, (2) not address taken into this structure
  // so that we do not need to keep them in the trimmed IR
  llvm::DenseSet<llvm::GlobalVariable*> safeGVs;

  // functions referenced by llvm.global_ctors and llvm.global_dtors, etc.
  llvm::StringSet<> functionsWithHiddenCalls;
};

PreTransformResult step1_pretransform(llvm::Module* srcModule, StaticStats& stats);
llvm::StringSet<> step1_getFunctionsWithHiddenCalls(llvm::Module* srcModule);

// =========================================================
// step 2: clone + trim
// =========================================================

// can be null if no function is in the analyzable region
// We may have some constructs that must be in the cloned IR but is tainted (e.g., function calls whose return value is tainted)
// so here we also pass in taintedClones to record these values
llvm::Module* step2_clone(llvm::Module* srcModule, PreTransformResult& decisions, llvm::ValueToValueMapTy& mapping, llvm::DenseMap<llvm::Value*,llvm::Value*>& taintedClones, StaticStats& stats);
// shared helper functions
bool step2_pruning_isPlaceholderCall(llvm::Value* v);
bool step2_pruning_isPlaceholderFunction(llvm::Function* func);
bool step2_pruning_isFunctionHaveHiddenCalls(const llvm::StringSet<>& functionsWithHiddenCalls, llvm::Function* func); // return true for functions like main() that have hidden calls

// =========================================================
// step 3: SVFG+EPTG construction
// =========================================================

struct GraphConstructionResults {
  llvm::DenseMap<llvm::Value*, llvm::Value*> src2cloned;
  llvm::DenseMap<llvm::Value*, llvm::Value*> cloned2src;

  // for subsequent (memset/memcpy/memmove, etc) size operand updates
  llvm::SmallVector<std::tuple<llvm::Instruction*, unsigned, unsigned>> sizeOperands; // <src instr, ptrArgIndex, sizeArgIndex>

  SVF::SVFIR* svfir = nullptr;
  SVF::PointerAnalysis* pta = nullptr;
  SVF::SVFG* svfg = nullptr;
  EPTG* eptg = nullptr;

  // not used but need to be kept alive
  SVF::SVFGBuilder* svfgBuilder = nullptr;
};
GraphConstructionResults step3_graph_construction(llvm::Module* srcModule, llvm::Module* clonedModule, llvm::ValueToValueMapTy& srcMapping, llvm::DenseMap<llvm::Value*,llvm::Value*>& taintedClones, StaticStats& stats, llvm::StringRef dumpNamePrefix, bool dumpGraphs);

// =========================================================
// step 4: security analysis + instrumentation planning
// =========================================================

// For pointers passed through function call/return values, we always move the function body to a new function
// that can take more parameters, and the old function is left as a stub for compatibility
// (if a fat pointer is returned, we add a function parameter that takes the address of the metadata the function should write to)
// if a function is not address-taken, we can do the modification to the function interface in place without another function
// Later in the instrumentation, we will:
// 1. apply all type changes on EPTG, including ones on function interfaces. We apply this first to handle f(U*) -> f(V*)
//    at the end of this step, we only add placeholder for load/store/call/ret
// 2. apply other changes on traditional analysis, including (1) changes to function interface (again), and (2) metadata load/store
// 3. reconnect the intra-procedural value edges.
// steps 1 and 2 are updating the value nodes on function/memory interface (different logic for EPTG and traditional) and step 3 are unified

// when expressing where to instrument, we will:
// (1) for both EPTG transforms and traditional instrumentation (Out-of-Band metadata), the pending checks are all stored below
// (2) we store EPTG-based type changes in this structure
// This structure therefore mainly stores the EPTG-based type changes
struct InstrumentationPlan {
  struct CheckInfo {
    llvm::Instruction* insertBefore = nullptr;
    llvm::Value* ptr = nullptr;
    llvm::SmallVector<llvm::Use*, 2> uselist;
    std::size_t internalID = 0; // the ID of the check in the instrumentation (in case it needs extra info)
  };
  llvm::SmallVector<llvm::SmallVector<CheckInfo>> checkInfoVec; // instrumentationID -> localCheckID -> CheckInfo

  // when we expand pointers in EPTG, we create a new struct type that contains all the metadata to replace the original pointer type
  // eptgPointerExpandInfo describes how to find the metadata from the new struct type
  // struct index zero is the pointer itself, and the rest are metadata
  // each instrumentation's metadata is ordered by the instrumentation ID; lower ID means the metadata is closer to the pointer

  // when doing EPTG-based type transform, we will first group cell nodes into partitions
  // where all nodes in the same partition will have the same in-memory type
  // this struct describe the cell node type changes in EPTG
  struct EPTGCellTypeChangePartitionInfo {
    // the original EPTG cell node type
    llvm::Type* srcType = nullptr;

    // the new in-memory type for the cell node.
    // Note that we will not use this type for function interface change if the cell is a pointer argument and the new type is a struct.
    // (In this case we will flatten the struct and append all metadata to the parameter list)
    llvm::Type* finalType = nullptr;

    // if the partition is a pointer, this is the instrumentation binary vector which has the metadata for the pointer
    // the bit is set only for instrumentations with metadata
    // we can use this to find the GEP offset of the metadata of each instrumentation scheme from the final type (probably a struct)
    unsigned pointerMDBitVec = 0;
  };
  llvm::DenseMap<std::size_t, EPTGCellTypeChangePartitionInfo> cellPartitions; // the new types for all cell nodes whose type is changed
  llvm::DenseMap<CellEPTGNode*, std::size_t> cellTypeConversions; // the type change partition index for each cell (N-to-1 mapping)

  // for each pointer (not only for cells but also for instructions), this is the instrumentation binary vector (only for instrumentations with metadata)
  llvm::DenseMap<EPTGNode*, unsigned> eptgPointerExpandInfo;

  // describe the function interface changes in eptg
  // for function interface changes, each function is either completely managed by EPTG or is not managed by EPTG at all
  // here we only record the function interface changes in EPTG, since there is no difference in handling function changes in traditional instrumentation
  struct FunctionTypeChangeInfo {
    // we use the following way to change the function declaration:
    // For every pointer enlarged into a struct (no matter it is the return value or function argument), we add additional parameters:
    //    * if the pointer is an argument, the pointer metadata (which may **NOT** be the same as struct members) are expanded and layed out as additional arguments
    //    * if the pointer is the return value, we add a new parameter: a pointer to the struct type, and all values (including the "canonical" returned pointer) are saved to the location
    //      however, if the struct only has two member (the main pointer and another value), then only the pointer to that additional value is added as the parameter

    struct ArgumentPointerExpandInfo {
      std::size_t pointerPartitionIndex_withOffset = 0; // the partition index of the pointer
      unsigned argumentIndex = 0; // the argument index of the canonical pointer argument
      unsigned expandStartArgIndex = 0; // the first argument created from expanding this pointer argument
      unsigned expandEndArgPos = 0; // one past the last argument created from expanding this pointer
    };
    // inputs
    std::size_t partitionIndex = 0; // each partition of function types share such an entry
    llvm::FunctionType* oldTy = nullptr; // old function type
    llvm::FunctionType* newTy = nullptr; // result function type
    // helper info for instrumentations
    int retExpandArgIndex = -1; // if the returned pointer is expanded, this is the index of the "return value store destination" argument
    std::size_t retPartitionIndex = 0; // partition index of returned pointer. this is required even if no additional parameter is added because of the return value
    llvm::SmallVector<ArgumentPointerExpandInfo> argumentExpandArgInfo;
    // misc
    llvm::DenseMap<unsigned, unsigned> argIndexToExpandInfoMap; // map from argument index to the index into argumentExpandArgInfo
  };
  llvm::DenseMap<std::size_t, FunctionTypeChangeInfo> functionTypeChanges; // the new types for all functions whose type is changed (key is partition index)
  llvm::DenseMap<llvm::Function*, std::size_t> funcInterfaceChanges; // function to function type change partition index
};

typedef llvm::SmallVector<InstrumentationBase*> InstrumentationListType;
InstrumentationPlan step4_analysis(llvm::Module* srcModule, GraphConstructionResults& graphs, InstrumentationListType& instrumentations, StaticStats& stats);

// =========================================================
// step 5: final instrumentation
// =========================================================

// expand the instrumentation scheme bit vector into individual schemes; call the callback for each scheme
inline void forEachScheme(unsigned mdBitVec, std::function<void(unsigned)> cb) {
  unsigned curVec = mdBitVec;
  unsigned schemeIndex = 0;
  while (curVec) {
    if (curVec & 1) {
      cb(schemeIndex);
    }
    curVec >>= 1;
    schemeIndex += 1;
  }
}

llvm::Module* step5_instrument(llvm::Module* srcModule, GraphConstructionResults& graphs, InstrumentationListType& instrumentations, const InstrumentationOptions& options, InstrumentationPlan& plan, StaticStats& stats);

// =========================================================
// Utility functions
// =========================================================

inline SVF::SVFInstruction* getSVFInstruction(llvm::Instruction* inst) {
  return SVF::LLVMModuleSet::getLLVMModuleSet()->getSVFInstruction(inst);
}
inline llvm::Function* getLLVMFunction(const SVF::SVFFunction* func) {
  return llvm::cast_or_null<llvm::Function>(const_cast<llvm::Value*>(SVF::LLVMModuleSet::getLLVMModuleSet()->getLLVMValue(func)));
}
inline llvm::BasicBlock* getLLVMBasicBlock(const SVF::SVFBasicBlock* bb) {
  return llvm::cast_or_null<llvm::BasicBlock>(const_cast<llvm::Value*>(SVF::LLVMModuleSet::getLLVMModuleSet()->getLLVMValue(bb)));
}
inline llvm::Instruction* getLLVMInstruction(const SVF::SVFInstruction* inst) {
  return llvm::cast_or_null<llvm::Instruction>(const_cast<llvm::Value*>(SVF::LLVMModuleSet::getLLVMModuleSet()->getLLVMValue(inst)));
}
inline llvm::Value* getLLVMValue(const SVF::SVFValue* value) {
  if (value)
    return const_cast<llvm::Value*>(SVF::LLVMModuleSet::getLLVMModuleSet()->getLLVMValue(value));
  return nullptr;
}
// deprecated
/*
inline llvm::Type* getLLVMType(const SVF::SVFType* ty) {
  return const_cast<llvm::Type*>(SVF::LLVMModuleSet::getLLVMModuleSet()->getLLVMType(ty));
}
*/
inline SVF::SVFType* getSVFType(const llvm::Type* ty) {
  return SVF::LLVMModuleSet::getLLVMModuleSet()->getSVFType(ty);
}

/**
 * @brief check if the upstream instruction dominates the downstream instruction
 */
bool isInstrDominates(llvm::Instruction* upstream, llvm::Instruction* downstream, const llvm::DominatorTree& DT);

/**
 * @brief finding an insertion position (insert before the returned instr) that dominates all uses of def in the useScope function
 *
 * if uselistOverride is provided, we will use it instead of the actual uses of def
 */
llvm::Instruction* getInsertingPointDominatingUses(llvm::Value* def, llvm::Function* useScope, llvm::Instruction* initialHint, const llvm::DominatorTree& DT, const llvm::SmallVectorImpl<llvm::Use*>* uselistOverride = nullptr);

// shorthand for the simplest case
inline llvm::Instruction* getInsertingPointForInstrHoisting(const llvm::DominatorTree& DT, llvm::Instruction* def) {
  return getInsertingPointDominatingUses(def, def->getFunction(), def, DT);
}

// get first instruction in the block that is not PHI, alloca, debug intrinsics, etc
inline llvm::Instruction* getBlockInsertPoint(llvm::BasicBlock* bb) {
  llvm::Instruction* insertPoint = bb->getFirstNonPHI();
  while (llvm::isa<llvm::AllocaInst>(insertPoint)
    || insertPoint->isLifetimeStartOrEnd()
    || insertPoint->isDebugOrPseudoInst()
    || llvm::isa<llvm::LandingPadInst>(insertPoint)) {
    insertPoint = insertPoint->getNextNode();
  }
  return insertPoint;
}

/**
 * @brief For a pointer-type constant, try to get the root GlobalVariable; return null if not backed by GlobalVariable
*/
llvm::GlobalVariable* getBackingGlobalVariable(llvm::Constant* constptr);

// return true iff (1) the cast does not cause inaccurate value flow in SVFG, (2) does not create problem for EPTG construction
bool isPointerCastSafe(llvm::PointerType* fromTy, llvm::PointerType* toTy);

// check if this type is a pointer or it is an aggregate type with pointer inside
bool isTypeContainPointer(llvm::Type* ty);

// annotate instruction with a string
void annotateInstr(llvm::Instruction* instr, const char* msg);
bool isInstrAnnotatedWith(llvm::Instruction* instr, const char* msg);
// or annotate with some value (mainly for EPTG)
void annotateInstr(llvm::Instruction* instr, const char* msg, std::size_t id);

bool isAllocatorCall(llvm::CallBase* call);
bool isAllocatorCallee(llvm::Function* func);
bool isDeallocationCallee(llvm::Function* func);
bool isReallocCallee(llvm::Function* func);

LLVM_DUMP_METHOD
std::string getValueStrWithParent(const llvm::Value* value);

LLVM_DUMP_METHOD
void printValueStrWithParent(const llvm::Value* value, llvm::raw_ostream& os);

// dump the SVFG but with only a subset of nodes
void debugDumpSVFG(const std::string& filename, SVF::SVFG* svfg, const llvm::DenseSet<SVF::SVFGNode*>& nodesToInclude);

// printing llvm value and SVFGNode, etc are VERY SLOW
// to speed up dumping, we:
// 1. store log events in a compact struct when running the algorithm,
// 2. when dumping, we only print the log events

} // end namespace PSan

namespace SVF {

/// make SVFUtil::outs()/errors() (std::ostream&) to print llvm::StringRef
inline std::ostream& operator<<(std::ostream& os, llvm::StringRef s) {
  os.write(s.data(), s.size());
  return os;
}

/// make SVFUtil::outs()/errors() (std::ostream&) to print llvm::Twine
inline std::ostream& operator<<(std::ostream& os, llvm::Twine t) {
  if (t.isTriviallyEmpty())
    return os;
  if (t.isSingleStringRef()) {
    os << t.getSingleStringRef();
    return os;
  }
  os << t.str();
  return os;
}

/// make SVFUtil::outs()/errors() (std::ostream&) to print llvm::Type*
inline std::ostream& operator<<(std::ostream& os, llvm::Type* ty) {
  std::string buf;
  {
    llvm::raw_string_ostream os(buf);
    ty->print(os, /* IsForDebug */true, /* NoDetails */ false);
  }
  os << buf;
  return os;
}

/// make SVFUtil::outs()/errors() (std::ostream&) to print llvm::Value*
std::ostream& operator<<(std::ostream& os, llvm::Value* val);

} // end namespace SVF

inline llvm::raw_ostream& operator<<(llvm::raw_ostream& os, llvm::Type* ty) {
  ty->print(os, /* IsForDebug */true, /* NoDetails */ false);
  return os;
}

llvm::raw_ostream& operator<<(llvm::raw_ostream& os, llvm::Value* val);

template<typename T>
inline llvm::raw_ostream& operator<<(llvm::raw_ostream& os, const llvm::SmallVectorImpl<T>& vec) {
  os << "[";
  bool first = true;
  for (const T& elem : vec) {
    if (!first) os << ", ";
    os << elem;
    first = false;
  }
  os << "]";
  return os;
}

inline llvm::raw_ostream& operator<<(llvm::raw_ostream& os, const llvm::BitVector& bv) {
  os << "[";
  int cur = bv.find_first();
  bool first = true;
  while (cur != -1) {
    if (!first) os << ", ";
    os << cur;
    first = false;
    cur = bv.find_next(cur);
  }
  os << "]";
  return os;
}

#endif /* PSAN_H */