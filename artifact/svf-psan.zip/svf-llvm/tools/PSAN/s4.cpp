#include "psan.h"
#include "FastDebugDumper.h"

using namespace PSan;
using namespace SVF;
using namespace SVF::SVFUtil;

namespace {
void populateEPTGCellTransformTypes(PSan::InstrumentationPlan& result, llvm::Module* srcModule, EPTG* eptg, InstrumentationListType& instrumentations);
} // end anonymous namespace

PSan::InstrumentationPlan PSan::step4_analysis(llvm::Module* srcModule, GraphConstructionResults& graphs, InstrumentationListType& instrumentations, StaticStats& stats)
{
  // in this function, we:
  // 1. run all the analyses and get an initial set of pointer widening requests
  // 2. run backward analysis to find all pointers that should be widened
  // 3. populate the result instrumentation plan for the next step

  // we first collect the stats for EPTG coverage
  if (graphs.eptg) {
    for (auto& F : *srcModule) {
      if (F.isDeclaration())
        continue;
      for (auto& BB : F) {
        for (auto& I : BB) {
          if (llvm::LoadInst* load = llvm::dyn_cast<llvm::LoadInst>(&I)) {
            if (isDataPointerTy(load->getType())) {
              auto* node = graphs.eptg->getExpressionNode(load);
              stats.S4_PtrLoadInEPTGCount.increment(node != nullptr);
            }
          }
        }
      }
    }
  }

  // now we can run the analysis

  // because it is hard (if ever possible) to propagate widening requests from non-EPTG partition to EPTG,
  // whenever we find an EPTG expression node without points-to target (it is probably tainted but the metadata can still be propagated from EPTG),
  // we will consider it as requesting all possible metadata, so that non-EPTG users can still pick them up

  // compute the bit vector for all instrumentations that have metadata
  unsigned mdvecWithAll = 0;
  {
    unsigned curbit = 1;

    for (auto* instrumentation : instrumentations) {
      const auto& mdTypes = instrumentation->getPointerMetadataTypesInRegisters();
      if (!mdTypes.empty()) {
        mdvecWithAll |= curbit;
      }
      curbit <<= 1;
    }
  }

  // we need to identify instrumentations that does not need metadata
  // we will not change pointer memory layout for them
  llvm::BitVector instrumentationWithNoMetadata;
  for (auto* instrumentation : instrumentations) {
    llvm::Type* mdty = instrumentation->getPointerMetadataTypeInMemory();
    instrumentationWithNoMetadata.push_back(mdty == nullptr);
  }

  // data structures for subsequent solving
  // because we instrument all pointers in the opaque region/slice and do selective instrumentation in the analyzable region,
  // here we only need to maintain data structures for the analyzable region
  SVF::FIFOWorkList<EPTGNode*> worklist; // the current EPTG nodes whose size should be widened and haven't went through the backward analysis
  llvm::DenseMap<EPTGNode*, unsigned> eptgNodeWidthInfo;
  llvm::DenseSet<CellEPTGNode*> byvalArgumentCells; // cells representing byval/sret arguments (we can reconstruct metadata ondemand; no need to widen them here)

  auto addToWorklist = [&](llvm::Value* v, unsigned id) -> bool {
    // return true if the value corresponds to a pointer in EPTG
    // sanity check
    if (!v->getType()->isPointerTy()) {
      psan_unreachable("Non-pointer value in the check request");
    }
    if (llvm::GlobalVariable* gv = llvm::dyn_cast<llvm::GlobalVariable>(v)) {
      if (gv->getParent() != srcModule) {
        psan_unreachable("Global variable not from source module in the check request");
      }
    } else if (llvm::Instruction* instr = llvm::dyn_cast<llvm::Instruction>(v)) {
      if (instr->getModule() != srcModule) {
        psan_unreachable("Instruction not from source module in the check request");
      }
    }
    ExpressionEPTGNode* eptgNode = graphs.eptg->getExpressionNode(v);
    if (!eptgNode) {
      return false;
    }
    // skip the instrumentations that does not have metadata
    if (instrumentationWithNoMetadata.test(id)) {
      return true;
    }
    // this value has a corresponding EPTG node
    // we need to update the data structures for EPTGNode*
    unsigned targetWidthSet = 1 << id;
    auto iter = eptgNodeWidthInfo.find(eptgNode);
    if (iter == eptgNodeWidthInfo.end()) {
      // this is the first time we see this EPTG node
      eptgNodeWidthInfo.insert(std::make_pair(eptgNode, targetWidthSet));
      static DumpEventDecl<unsigned, EPTGNode*> addWorklistEvent([](llvm::raw_ostream& os, const EventData<unsigned, EPTGNode*>& data) {
        os << "Adding to worklist (WidthSet=" << data.get<0>() << "): " << data.get<1>() << "\n";
      });
      PSAN_DEBUG(addWorklistEvent(targetWidthSet, eptgNode));
      worklist.push(eptgNode);
    } else {
      // we have seen this EPTG node before, we need to check if we need to add the id to the flag set
      unsigned oldWidthSet = iter->second;
      if ((oldWidthSet & targetWidthSet) != targetWidthSet) {
        // we need to add the id to the flag set
        iter->second = oldWidthSet | targetWidthSet;
        static DumpEventDecl<unsigned, unsigned, EPTGNode*> updateWorklistEvent([](llvm::raw_ostream& os, const EventData<unsigned, unsigned, EPTGNode*>& data) {
          os << "Update (" << data.get<0>() << " -> " << data.get<1>() << "): " << data.get<2>() << "\n";
        });
        PSAN_DEBUG(updateWorklistEvent(oldWidthSet, iter->second, eptgNode));
        worklist.push(eptgNode);
      }
    }
    return true;
  };
  InstrumentationPlan result;
  result.checkInfoVec.resize(instrumentations.size());
  auto checkRequestHandler = [&](llvm::Instruction* insertBefore, llvm::Value* ptr, llvm::ArrayRef<llvm::Use*> uselist, std::size_t internalID, unsigned instrumentationID) {
    // first, we need to add the check request to ptr width solving data structures
    llvm::Value* v = ptr;
    bool isValueInEPTG = graphs.eptg? addToWorklist(v, instrumentationID) : false;
    stats.S4_PtrFromEPTGCheckCount.increment(isValueInEPTG);

    if (!isNoStaticStats()){
      auto remappedID = stats.instrumentID2GlobalInstrumentationID.find(instrumentationID);
      if (remappedID != stats.instrumentID2GlobalInstrumentationID.end()) {
        stats.S4_RequestedChecks.increment(remappedID->second);
      } else {
        psan_unreachable("Instrumentation ID not found in remapping table");
      }
    }

    InstrumentationPlan::CheckInfo info;
    info.insertBefore = insertBefore;
    info.ptr = ptr;
    info.uselist.append(uselist.begin(), uselist.end());
    info.internalID = internalID;
    result.checkInfoVec[instrumentationID].push_back(info);
  };
  // widen all EPTG expressions whose value has user but not in EPTG
  if (mdvecWithAll && graphs.eptg) {
    graphs.eptg->forAllExpressionNodes([&](ExpressionEPTGNode* expr, llvm::Value* value) {
      if (!isDataPointerTy(value->getType())) {
        return;
      }
      // in these cases, later uses may be dropped when constructing EPTG, so we conservatively assume that they need metadata
      bool isShouldWiden = expr->getIsTainted() || (expr->getPointsTo() == nullptr);
      if (isShouldWiden) {
        static DumpEventDecl<EPTGNode*> addWorklistEvent([](llvm::raw_ostream& os, const EventData<EPTGNode*>& data) {
          os << "Adding to worklist (all): " << data.get<0>() << "\n";
        });
        PSAN_DEBUG(addWorklistEvent(expr));
        eptgNodeWidthInfo.insert(std::make_pair(expr, mdvecWithAll));
        worklist.push(expr);
      }
    });
  }
  // special handling for function argument and return values
  if (graphs.eptg) {
    for (auto& F : *srcModule) {
      if (F.isDeclaration())
        continue;
      ExpressionEPTGNode* funcPtr = graphs.eptg->getExpressionNode(&F);
      if (!funcPtr) {
        continue;
      }
      CellEPTGNode* funcCell = funcPtr->getPointsTo();
      if (!funcCell) {
        psan_unreachable("Function pointer has expression node but not cell node");
      }
      // check if any byval/sret arguments are used in the function
      // if yes, add the cell to the byvalArgumentCells set so that we do not widen them later (we can reconstruct metadata ondemand)
      // also check if we have the expression node for the argument; if not, we need to widen the cell representing the argument
      static DumpEventDecl<llvm::StringRef> specialHandlingEvent([](llvm::raw_ostream& os, const EventData<llvm::StringRef>& data) {
        os << "Special handling checking: " << data.get<0>() << "\n";
      });
      PSAN_DEBUG(specialHandlingEvent(F.getName()));
      for (auto& arg : F.args()) {
        if (!isDataPointerTy(arg.getType())) {
          if (arg.hasByValAttr() || arg.hasStructRetAttr()) {
            psan_unreachable("Byval/sret argument is not a data pointer");
          }
          continue;
        }
        unsigned argno = arg.getArgNo();
        CellEPTGNode* argcell = funcCell->getSubObjectIfAvailable(MemberPosition::getWithSingleIndex(argno));
        if (!argcell) {
          psan_unreachable("Pointer argument missing cell node");
        }
        if (arg.hasByValAttr() || arg.hasStructRetAttr()) {
          byvalArgumentCells.insert(argcell);
          static DumpEventDecl<unsigned, llvm::Value*> byvalArgumentEvent([](llvm::raw_ostream& os, const EventData<unsigned, llvm::Value*>& data) {
            os << "Byval/sret argument [" << data.get<0>() << "]: " << data.get<1>() << "\n";
          });
          PSAN_DEBUG(byvalArgumentEvent(argno, &arg));
          // sanity check: these argument cells should only has one incoming contains edge
          // (otherwise it is both a byval/sret argument and something else (in-memory pointer, argument of another function, etc))
          unsigned numContainsEdgeIn = 0;
          for (auto e : argcell->getInEdges()) {
            if (e->getEdgeKind() == EPTGEdge::ContainsEdge) {
              ++numContainsEdgeIn;
            }
          }
          if (numContainsEdgeIn != 1) {
            psan_unreachable("Byval/sret argument cell has unexpected incoming edges");
          }
        }
        bool isExprInEPTG = false;
        for (auto e : argcell->getOutEdges()) {
          if (e->getEdgeKind() == EPTGEdge::LoadEdge) {
            isExprInEPTG = true;
            break;
          }
        }
        if (!isExprInEPTG && !arg.use_empty() && !arg.hasByValAttr() && !arg.hasStructRetAttr()) {
          // the argument is used in the function but not in EPTG
          // we need to widen the cell
          static DumpEventDecl<EPTGNode*> addWorklistEvent([](llvm::raw_ostream& os, const EventData<EPTGNode*>& data) {
            os << "Adding to worklist (arg): " << data.get<0>() << "\n";
          });
          PSAN_DEBUG(addWorklistEvent(argcell));
          eptgNodeWidthInfo.insert(std::make_pair(argcell, mdvecWithAll));
          worklist.push(argcell);
        } else {
          static DumpEventDecl<llvm::Value*, unsigned, bool, bool, bool, bool> specialHandlingResultEvent([](llvm::raw_ostream& os, const EventData<llvm::Value*, unsigned, bool, bool, bool, bool>& data) {
            os << "Arg[" << data.get<0>() << "] " << data.get<1>() << " not widened:";
            if (data.get<2>()) os << " InEPTG";
            if (data.get<3>()) os << " NoUse";
            if (data.get<4>()) os << " Byval";
            if (data.get<5>()) os << " Sret";
            os << "\n";
          });
          PSAN_DEBUG(specialHandlingResultEvent(&arg, argno, isExprInEPTG, arg.use_empty(), arg.hasByValAttr(), arg.hasStructRetAttr()));
        }
      }
      // also, for all function definitions, if they return pointers and there is no store to the returned cell,
      // this is likely because we were returning a placeholder value in the trimmed IR, and we need to widen the return value
      if (mdvecWithAll && isDataPointerTy(F.getReturnType())) {
        if (CellEPTGNode* retCell = funcCell->getSubObjectIfAvailable(MemberPosition::getWithSingleIndex(F.getFunctionType()->getNumParams()))) {
          // if there is a store to the return cell, it should be tainted already
          bool hasStoreToReturnCell = false;
          for (auto e : retCell->getInEdges()) {
            if (e->getEdgeKind() == EPTGEdge::StoreEdge) {
              hasStoreToReturnCell = true;
              break;
            }
          }
          // check if this function is called somewhere and the return value is used
          // if all return values are discarded, we still do not need to taint the return value
          bool isReturnValueUsed = false;
          for (auto& u : F.uses()) {
            bool isCurrentUseDiscarded = false;
            if (llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(u.getUser())) {
              if (call->use_empty()) {
                isCurrentUseDiscarded = true;
              }
            }
            if (!isCurrentUseDiscarded) {
              isReturnValueUsed = true;
              break;
            }
          }
          if (isReturnValueUsed && (!hasStoreToReturnCell || retCell->getIsTainted())) {
            // we need to widen the return value
            static DumpEventDecl<EPTGNode*> addWorklistEvent([](llvm::raw_ostream& os, const EventData<EPTGNode*>& data) {
              os << "Adding to worklist (ret): " << data.get<0>() << "\n";
            });
            PSAN_DEBUG(addWorklistEvent(retCell));
            eptgNodeWidthInfo.insert(std::make_pair(retCell, mdvecWithAll));
            worklist.push(retCell);
          } else {
            static DumpEventDecl<bool, bool, bool> returnUnwidenedEvent([](llvm::raw_ostream& os, const EventData<bool, bool, bool>& data) {
              os << "Return value not widened:";
              if (!data.get<0>()) os << " ReturnUnused";
              if (data.get<1>()) os << " HaveStore";
              if (!data.get<2>()) os << " Untainted";
              os << "\n";
            });
            PSAN_DEBUG(returnUnwidenedEvent(isReturnValueUsed, hasStoreToReturnCell, retCell->getIsTainted()));
          }
        } else {
          static DumpEventDecl<llvm::StringRef> returnValueCellNotFoundEvent([](llvm::raw_ostream& os, const EventData<llvm::StringRef>& data) {
            os << "Return value cell not found: " << data.get<0>() << "\n";
          });
          PSAN_DEBUG(returnValueCellNotFoundEvent(F.getName()));
        }
      }
    }
  }

  // now run the rest of initial analysis
  for (InstrumentationBase* inst : instrumentations) {
    auto curHandler = std::bind(checkRequestHandler, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3, std::placeholders::_4, inst->getInstrumentationID());
    inst->initCheckRequestCallback(curHandler);
    inst->analysis();
  }
  stats.setTime(stats.s4_analysisTime);

  // sanity check: no cells representing byval arguments should be in the worklist
  for (CellEPTGNode* cell : byvalArgumentCells) {
    if (eptgNodeWidthInfo.find(cell) != eptgNodeWidthInfo.end()) {
      psan_unreachable("Byval argument cells should not be in the worklist");
    }
  }

  // after running the instrumentation analysis, we have the initial set of check requests
  // start to determine EPTG type transforms

  // early exit if EPTG is not enabled
  if (!graphs.eptg) {
    if (!eptgNodeWidthInfo.empty()) {
      psan_unreachable("EPTG is not enabled but we have EPTG nodes in the worklist");
    }
    return result;
  }

  auto handleEPTGEdge = [&](EPTGNode* fromNode, EPTGNode* toNode, unsigned targetWidthSet) -> void {
    (void) fromNode;
    // we ignore requests to tainted cells
    CellEPTGNode* toCell = SVFUtil::dyn_cast<CellEPTGNode>(toNode);
    if (toNode->getIsTainted() && toCell) {
      return;
    }
    // also ignore if it is a byval argument cell
    if (toCell && byvalArgumentCells.contains(toCell)) {
      return;
    }
    bool isChanged = false;
    auto iter = eptgNodeWidthInfo.find(toNode);
    if (iter == eptgNodeWidthInfo.end()) {
      // this is the first time we see this EPTG node
      auto p = eptgNodeWidthInfo.insert(std::make_pair(toNode, targetWidthSet));
      worklist.push(toNode);
      iter = p.first;
      isChanged = true;
    } else {
      // we have seen this EPTG node before, we need to check if we need to add the id to the flag set
      unsigned oldWidthSet = iter->second;
      if ((oldWidthSet & targetWidthSet) != targetWidthSet) {
        // we need to add the id to the flag set
        iter->second = oldWidthSet | targetWidthSet;
        worklist.push(toNode);
        isChanged = true;
      }
    }
    if (isChanged) {
      static DumpEventDecl<EPTGNode*, unsigned> updateWorklistEvent([](llvm::raw_ostream& os, const EventData<EPTGNode*, unsigned>& data) {
        os << "Update (WidthSet=" << data.get<1>() << "): " << data.get<0>() << "\n";
      });
      PSAN_DEBUG(updateWorklistEvent(toNode, iter->second));
    }
  };

  // now we run the backward analysis
  while (!worklist.empty()) {
    // handle EPTG entries
    // Note that here we only deal with changes to function/memory interface that are in the analyzable slice
    // we do not handle intra-function dataflow here (so no edges between expression nodes)
    EPTGNode* eptgNode = worklist.pop();
    unsigned targetWidthSet = eptgNodeWidthInfo.find(eptgNode)->second;
    static DumpEventDecl<unsigned, EPTGNode*> processWorklistEvent([](llvm::raw_ostream& os, const EventData<unsigned, EPTGNode*>& data) {
      os << "Worklist (WidthSet=" << data.get<0>() << "): " << data.get<1>() << "\n";
    });
    PSAN_DEBUG(processWorklistEvent(targetWidthSet, eptgNode));
    // go to the upstream (def)
    if (ExpressionEPTGNode* expr = llvm::dyn_cast<ExpressionEPTGNode>(eptgNode)) {
      // For expression nodes, we expect the upstream to be load edges or copy edges
      for (EPTGEdge* edge : eptgNode->getInEdges()) {
        switch (edge->getEdgeKind())
        {
        default: psan_unreachable("Unexpected edge type for expression nodes");
        case EPTGEdge::LoadEdge: {
          CellEPTGNode* cell = llvm::dyn_cast<CellEPTGNode>(edge->getSrcNode());
          if (!cell) {
            psan_unreachable("Unexpected edge source for expression nodes");
          }
          handleEPTGEdge(expr, cell, targetWidthSet);
        } break;
        case EPTGEdge::CopyEdge: {
          ExpressionEPTGNode* srcExpr = llvm::dyn_cast<ExpressionEPTGNode>(edge->getSrcNode());
          if (!srcExpr) {
            psan_unreachable("Unexpected edge source for expression nodes");
          }
          handleEPTGEdge(expr, srcExpr, targetWidthSet);
        } break;
        }
      }
      // now we check the SVFG
      // UPDATE: now we use copy edges in EPTG, so we no longer need SVFG here
      //if (SVF::SVFGNode* svfgNode = expr->getSVFGDefNode()) {
        // we walk through all incoming edges and try to find upstream SVFG nodes that have EPTG nodes
        // we only use the nodes if the points-to sets match
        // (some MRSVFGNode nodes will be shared by multiple distinct pointers and we won't have corresponding EPTG nodes for them)
      //}
    } else if (CellEPTGNode* cell = SVFUtil::dyn_cast<CellEPTGNode>(eptgNode)) {
      // incoming edges can be contains, store, or alloc edges
      // we only need to handle store edges here
      for (EPTGEdge* edge : cell->getInEdges()) {
        if (edge->getEdgeKind() != EPTGEdge::StoreEdge) {
          continue;
        }
        ExpressionEPTGNode* expr = llvm::dyn_cast<ExpressionEPTGNode>(edge->getSrcNode());
        if (!expr) {
          psan_unreachable("Unexpected edge source for cell nodes");
        }
        handleEPTGEdge(cell, expr, targetWidthSet);
      }
    }
  }

  // start to populate results
  result.eptgPointerExpandInfo.swap(eptgNodeWidthInfo);
  // one last thing: create all the new cell types
  populateEPTGCellTransformTypes(result, srcModule, graphs.eptg, instrumentations);
  stats.setTime(stats.s4_finishTime);
  return result;
}

namespace {
struct TypeChangePartitionCommon {
  llvm::Type* srcType = nullptr;
  llvm::Type* finalType = nullptr;
  llvm::DenseSet<std::uint64_t> dependedPartitions;
};
struct ObjectTypeChangePartition : public TypeChangePartitionCommon {
  llvm::DenseMap<MemberPosition, std::uint64_t> changes; // [pos] -> member partition index
  llvm::DenseSet<CellEPTGNode*> partitionMembers;
};
struct PointerTypeChangePartition : public TypeChangePartitionCommon {
  unsigned destWidthType = 0;
  std::size_t pointToPartition = 0;
  llvm::DenseMap<CellEPTGNode*, llvm::SmallVector<CellEPTGNode*>> partitionMembers; // points-to targets -> set of pointer members pointing to them
};

llvm::StructType* populateTransformedStructType(llvm::StructType* structTy, const llvm::DenseMap<MemberPosition, llvm::Type*>& memberTypes, llvm::StructType* placeholder);

void populateEPTGCellTransformTypes(PSan::InstrumentationPlan& result, llvm::Module* srcModule, EPTG* eptg, InstrumentationListType& instrumentations)
{
  if (!eptg) {
    psan_unreachable("calling populateEPTGCellTransformTypes() without enabling EPTG");
  }
  // in this function, we need to get a mapping from cells to their transformed type
  // we want to avoid creating multiple types for a set of cells with identical type changes
  // so we need ways to "collapse" the cells again

  // we put cells (representing objects and pointers) into partitions, where each partition has a unique destination type after transformation
  // initially, all cells with identical source types are put into a single partition, and we store their type dependencies
  // then the algorithm will keep checking whether all type dependencies are satisfied. If one partition has conflicting dependencies, we split it into two

  // to distinguish objects and pointers, we also call pointer-type cell nodes as abstract pointers and object-type cell nodes as abstract objects
  // (actually the code is ported from MIFP project)
  using AbstractObject = CellEPTGNode;
  using PointerMember = CellEPTGNode;
  // MIFP project use PtrType (an enum) to represent the desired type change of a pointer. In PSAN, we use a bit flag to represent the same thing
  using PtrType = unsigned;

  // to simplify the data structures, we use a single index for both object partitions and pointer partitions

  std::size_t PointerPartitionBegin = eptg->getTotalNodeNum() * 2;
  std::vector<ObjectTypeChangePartition> objectPartitions;
  std::vector<PointerTypeChangePartition> pointerPartitions;

  llvm::DenseMap<CellEPTGNode*, std::size_t> AOToParitionMap;

  auto addAOToPartitionMapping = [&](CellEPTGNode* ao, std::size_t partition) -> void {
    auto tempPair = AOToParitionMap.insert(std::make_pair(ao, partition));
    if (!tempPair.second) {
      std::size_t existingMapping = tempPair.first->second;
      assert (existingMapping == partition && "AOPartition insert failed!");
    }
  };
  auto addOrModifyAOToPartitionMapping = [&](CellEPTGNode* ao, std::size_t partition) -> void {
    auto iter = AOToParitionMap.find(ao);
    if (iter != AOToParitionMap.end()) {
      std::size_t oldPartition = iter->second;

      // for debug
      // assert (partition != 4100);

      iter->second = partition;
      (void) oldPartition;
    } else {
      auto p = AOToParitionMap.insert(std::make_pair(ao, partition));
      assert (p.second);
    }
  };

  const std::size_t InvalidPartitionIndex = 0;
  objectPartitions.emplace_back();

  // when we clone the LLVM module, the context should remain the same one, so we can create types before we actually doing the clone
  // the created types remain valid in the cloned module
  llvm::LLVMContext& context = srcModule->getContext();

  static DumpEventDecl<std::size_t> transformStartEvent([](llvm::raw_ostream& os, const EventData<std::size_t>& data) {
    os << "populateEPTGCellTransformTypes() start: PointerPartitionBegin=" << data.get<0>() << "\n";
  });
  PSAN_DEBUG(transformStartEvent(PointerPartitionBegin));

  auto isTaintedForTypeTransform = [&](EPTGNode* node) -> bool {
    if (!node->getIsTainted()) {
      return false;
    }
    if (CellEPTGNode* cell = dyn_cast<CellEPTGNode>(node)) {
      // we want to transform argument cell's type even if it is tainted
      return !cell->isArgumentCell();
    }
    return true;
  };

  // step 1: go through all abstract objects, create partitions during traversal
  // in the first pass, we assume that all abstract objects with the same source type will have the same change, so that all paritions are collapsed
  // we only properly handle pointer paritions such that all pointer partitions are forked by the instrumentation requirement (we don't have circular dependencies for them)

  // partition node for object types; only used in initial stage where all abstract objects with same source types but different changes are still in the same partition
  llvm::DenseMap<llvm::Type*, std::size_t> initialTypeParitionMap;
  // the one for pointers that do not depend on type change of other objects
  // how are we modifying the current pointer (PtrType) is also part of the key
  llvm::DenseMap<std::pair<llvm::PointerType*, PtrType>, std::size_t> initialPointerPartitionMap;
  // the one for pointers that depends on type change of another partition
  llvm::DenseMap<std::tuple<llvm::PointerType*, PtrType, std::size_t>, std::size_t> initialPointerPartitionWithAOMap;

  auto checkDependency = [&](std::size_t dependedPartition, std::size_t fromPartition) -> void {
    if (dependedPartition >= PointerPartitionBegin) {
      std::size_t realIndex = dependedPartition - PointerPartitionBegin;
      auto& partition = pointerPartitions.at(realIndex);
      assert (partition.dependedPartitions.contains(fromPartition));
    } else {
      auto& partition = objectPartitions.at(dependedPartition);
      assert (partition.dependedPartitions.contains(fromPartition));
    }
  };
  auto invariantsCheck = [&]() -> void {
    for (std::size_t i = 0, n = pointerPartitions.size(); i < n; ++i) {
      assert (objectPartitions.size() <= PointerPartitionBegin);
      std::size_t partitionIndex = i + PointerPartitionBegin;
      auto& partition = pointerPartitions.at(i);
      std::size_t dependedPartition = partition.pointToPartition;
      if (dependedPartition != InvalidPartitionIndex) {
        checkDependency(dependedPartition, partitionIndex);
      }
      for (const auto& p : partition.partitionMembers) {
        if (AbstractObject* ao = p.first) {
          auto iter = AOToParitionMap.find(ao);
          assert (iter != AOToParitionMap.end());
          std::size_t mappedPartition = iter->second;
          assert (mappedPartition == dependedPartition);
        }
        for (const PointerMember* ap : p.second) {
          auto iter = AOToParitionMap.find(ap);
          assert (iter != AOToParitionMap.end());
          std::size_t mappedPartition = iter->second;
          assert (mappedPartition == partitionIndex);
        }
      }
    }
    for (std::size_t i = 0, n = objectPartitions.size(); i < n; ++i) {
      auto& partition = objectPartitions.at(i);
      for (const auto& p : partition.changes) {
        std::size_t dependedPartition = p.second;
        checkDependency(dependedPartition, i);
      }
      for (AbstractObject* ao : partition.partitionMembers) {
        auto iter = AOToParitionMap.find(ao);
        assert (iter != AOToParitionMap.end());
        std::size_t mappedPartition = iter->second;
        assert (mappedPartition == i);
      }
    }
  };

  auto addDependency = [&](std::size_t dependedPartition, std::size_t fromPartition) -> void {
    if (dependedPartition >= PointerPartitionBegin) {
      std::size_t realIndex = dependedPartition - PointerPartitionBegin;
      auto& partition = pointerPartitions.at(realIndex);
      partition.dependedPartitions.insert(fromPartition);
    } else {
      auto& partition = objectPartitions.at(dependedPartition);
      partition.dependedPartitions.insert(fromPartition);
    }
  };
  auto removeDependency = [&](std::size_t dependedPartition, std::size_t fromPartition) -> void {
    if (dependedPartition >= PointerPartitionBegin) {
      std::size_t realIndex = dependedPartition - PointerPartitionBegin;
      auto& partition = pointerPartitions.at(realIndex);
      partition.dependedPartitions.erase(fromPartition);
    } else {
      auto& partition = objectPartitions.at(dependedPartition);
      partition.dependedPartitions.erase(fromPartition);
    }
  };

  // helper function to get the parititon ID of the abstract object
  // this function does not handle abstract pointers
  auto getAOPartition = [&](AbstractObject* ao) -> std::size_t {
    if (isTaintedForTypeTransform(ao)) {
      psan_unreachable("Tainted abstract object should not be in the partition");
    }
    {
      auto iter = AOToParitionMap.find(ao);
      if (iter != AOToParitionMap.end()) {
        return iter->second;
      }
    }
    // the AO does not have a partition yet
    llvm::Type* srcType = ao->getType();
    {
      auto iter = initialTypeParitionMap.find(srcType);
      if (iter != initialTypeParitionMap.end()) {
        std::size_t partition = iter->second;
        assert(partition < PointerPartitionBegin);
        objectPartitions.at(partition).partitionMembers.insert(ao);
        addAOToPartitionMapping(ao, partition);
        return partition;
      }
    }
    // the type does not have a partition yet
    std::size_t partition = objectPartitions.size();
    initialTypeParitionMap.insert(std::make_pair(srcType, partition));
    objectPartitions.emplace_back();
    auto& partitionInfo = objectPartitions.back();
    partitionInfo.srcType = srcType;
    partitionInfo.partitionMembers.insert(ao);
    addAOToPartitionMapping(ao, partition);
    return partition;
  };

  llvm::DenseSet<PointerMember*> initVisitedAPSet;
  std::function<std::size_t(PointerMember*)> initVisitAP = [&](PointerMember* ap) -> std::size_t {
    if (isTaintedForTypeTransform(ap)) {
      psan_unreachable("Tainted abstract pointer should not be in the partition");
    }
    initVisitedAPSet.insert(ap);
    llvm::PointerType* srcTy = llvm::cast<llvm::PointerType>(ap->getType());
    PtrType curTy = 0;
    PtrType targetTy = curTy;
    {
      auto iter = result.eptgPointerExpandInfo.find(ap);
      if (iter != result.eptgPointerExpandInfo.end()) {
        targetTy = iter->second;
      }
    }
    static DumpEventDecl<EPTGNode*, PtrType, PtrType> initVisitAPEvent([](llvm::raw_ostream& os, const EventData<EPTGNode*, PtrType, PtrType>& data) {
      os << "  InitVisitAP " << data.get<0>() << " " << data.get<1>() << " -> " << data.get<2>() << "\n";
    });
    PSAN_DEBUG(initVisitAPEvent(ap, curTy, targetTy));
    std::size_t resultPartitionIndex = 0;
    CellEPTGNode* pointToObj = ap->getPointsTo();
    // refIndex, srcTy, targetTy
    static DumpEventDecl<std::size_t, llvm::Type*, PtrType> initVisitAPNewEvent([](llvm::raw_ostream& os, const EventData<std::size_t, llvm::Type*, PtrType>& data) {
      os << "    Creating #" << data.get<0>() << " " << data.get<1>() << " " << data.get<2>() << "\n";
    });
    if (pointToObj && !isTaintedForTypeTransform(pointToObj)) {
      // we do have a unique point-to target
      std::size_t pointToObjPartition = 0;
      if (pointToObj->isPointerTy()) {
        PointerMember* pointToPtr = pointToObj;
        // the current pointer is a double pointer; get the point-to info
        if (!initVisitedAPSet.contains(pointToPtr)) {
          pointToObjPartition = initVisitAP(pointToPtr);
        } else {
          auto iter = AOToParitionMap.find(pointToPtr);
          assert (iter != AOToParitionMap.end());
          pointToObjPartition = iter->second;
        }
        assert (pointToObjPartition >= PointerPartitionBegin);
      } else {
        pointToObjPartition = getAOPartition(pointToObj);
        assert (pointToObjPartition < PointerPartitionBegin);
      }
      static DumpEventDecl<std::size_t, EPTGNode*> initVisitAPPointToEvent([](llvm::raw_ostream& os, const EventData<std::size_t, EPTGNode*>& data) {
        os << "    PointTo #" << data.get<0>() << " " << data.get<1>() << "\n";
      });
      PSAN_DEBUG(initVisitAPPointToEvent(pointToObjPartition, pointToObj));

      std::tuple<llvm::PointerType*, PtrType, std::size_t> key(srcTy, targetTy, pointToObjPartition);
      auto iter = initialPointerPartitionWithAOMap.find(key);
      if (iter == initialPointerPartitionWithAOMap.end()) {
        // need to create a new one
        std::size_t index = pointerPartitions.size();
        std::size_t refIndex = index + PointerPartitionBegin;
        pointerPartitions.emplace_back();
        auto& partitionInfo = pointerPartitions.back();
        partitionInfo.srcType = srcTy;
        partitionInfo.destWidthType = targetTy;
        partitionInfo.pointToPartition = pointToObjPartition;
        partitionInfo.partitionMembers[pointToObj].push_back(ap);
        initialPointerPartitionWithAOMap.insert(std::make_pair(key, refIndex));
        resultPartitionIndex = refIndex;
        PSAN_DEBUG(initVisitAPNewEvent(refIndex, srcTy, targetTy));
      } else {
        resultPartitionIndex = iter->second;
        assert(resultPartitionIndex >= PointerPartitionBegin);
        std::size_t realIndex = resultPartitionIndex - PointerPartitionBegin;
        auto& partitionInfo = pointerPartitions.at(realIndex);
        partitionInfo.partitionMembers[pointToObj].push_back(ap);
      }
      // register current partition in the depended partition
      addDependency(pointToObjPartition, resultPartitionIndex);
    } else {
      // no unique point-to target; do not consider type changes for them
      std::pair<llvm::PointerType*, PtrType> key(srcTy, targetTy);
      auto iter = initialPointerPartitionMap.find(key);
      if (iter == initialPointerPartitionMap.end()) {
        // need to create a new one
        std::size_t index = pointerPartitions.size();
        std::size_t refIndex = index + PointerPartitionBegin;
        pointerPartitions.emplace_back();
        auto& partitionInfo = pointerPartitions.back();
        partitionInfo.srcType = srcTy;
        partitionInfo.destWidthType = targetTy;
        partitionInfo.pointToPartition = InvalidPartitionIndex;
        partitionInfo.partitionMembers[nullptr].push_back(ap);
        initialPointerPartitionMap.insert(std::make_pair(key, refIndex));
        resultPartitionIndex = refIndex;
        PSAN_DEBUG(initVisitAPNewEvent(refIndex, srcTy, targetTy));
      } else {
        resultPartitionIndex = iter->second;
        assert(resultPartitionIndex >= PointerPartitionBegin);
        std::size_t realIndex = resultPartitionIndex - PointerPartitionBegin;
        auto& partitionInfo = pointerPartitions.at(realIndex);
        partitionInfo.partitionMembers[nullptr].push_back(ap);
      }
    }
    addAOToPartitionMapping(ap, resultPartitionIndex);
    static DumpEventDecl<std::size_t, EPTGNode*> initVisitAPResultEvent([](llvm::raw_ostream& os, const EventData<std::size_t, EPTGNode*>& data) {
      os << "  InitVisitAP Assign #" << data.get<0>() << " <- " << data.get<1>() << "\n";
    });
    PSAN_DEBUG(initVisitAPResultEvent(resultPartitionIndex, ap));
    return resultPartitionIndex;
  };
  // first traversal, create partitions for pointers
  for (auto& p : *eptg) {
    EPTGNode* node = p.second;
    if (isTaintedForTypeTransform(node)) {
      continue;
    }
    if (CellEPTGNode* ap = SVFUtil::dyn_cast<CellEPTGNode>(node)) {
      if (ap->isPointerTy()) {
        // if this pointer has already been visited, we are done
        if (initVisitedAPSet.contains(ap)) {
          continue;
        }
        std::size_t partitionIndex = initVisitAP(ap);
        (void) partitionIndex;
        static DumpEventDecl<std::size_t, EPTGNode*> initVisitAPResultEvent([](llvm::raw_ostream& os, const EventData<std::size_t, EPTGNode*>& data) {
          os << "Init #" << data.get<0>() << ": " << data.get<1>() << "\n";
        });
        PSAN_DEBUG(initVisitAPResultEvent(partitionIndex, ap));
      }
    }
  }
  PSAN_DEBUG(invariantsCheck());

  // second traversal, create partitions for objects
  // we go from root type (struct, etc) to member types
  // we may fork partitions along the way, so we use a worklist to queue depended partitions
  SVF::FIFOWorkList<std::size_t> recheckWorklist; // workset of partition indices that need recheck
  llvm::DenseMap<llvm::Type*, llvm::DenseSet<std::size_t>> objectTypeToPartitionMap; // for each (non-pointer) object type, what partitions are out there (only for those with members)
  llvm::DenseSet<AbstractObject*> initVisitedAOSet;
  std::function<std::size_t(AbstractObject*)> initAbstractObjectPartition = [&](AbstractObject* ao) -> std::size_t {
    // TODO ignore abstract objects that would not have type change (e.g., those that does not have pointers)
    // currently all abstract objects with member maps will be involved in this partitionning stuff; it is not necessary
    // get the stub partition first
    if (isTaintedForTypeTransform(ao)) {
      psan_unreachable("Tainted abstract object should not be in the partition");
    }
    initVisitedAOSet.insert(ao);
    llvm::DenseMap<MemberPosition, std::size_t> memberPartitions;
    for (auto iterEdge = ao->OutEdgeBegin(), iterEdgeEnd = ao->OutEdgeEnd(); iterEdge != iterEdgeEnd; ++iterEdge) {
      if ((*iterEdge)->getEdgeKind() != EPTGEdge::EPTGEdgeK::ContainsEdge) {
        continue;
      }
      ContainsEPTGEdge* edge = SVFUtil::cast<ContainsEPTGEdge>(*iterEdge);
      const MemberPosition& pos = edge->getMemberPosition();
      if (pos.size() > 1) {
        psan_unreachable("Member position with more than one step is not supported");
      }
      CellEPTGNode* memberObj = SVFUtil::cast<CellEPTGNode>(edge->getDstNode());
      if (isTaintedForTypeTransform(memberObj)) {
        static DumpEventDecl<std::size_t, int64_t, EPTGNode*> memberTaintedEvent([](llvm::raw_ostream& os, const EventData<std::size_t, int64_t, EPTGNode*>& data) {
          os << "    InitAO @ C#" << data.get<0>() << " [" << data.get<1>() << "]: Member tainted: " << data.get<2>() << "\n";
        });
        PSAN_DEBUG(memberTaintedEvent(ao->getId(), pos.front(), memberObj));
        continue;
      }
      std::size_t partitionIndex = 0;
      if (memberObj->isPointerTy()) {
        // we must have already got that
        auto iter = AOToParitionMap.find(memberObj);
        assert (iter != AOToParitionMap.end());
        partitionIndex = iter->second;
      } else {
        if (initVisitedAOSet.contains(memberObj)) {
          auto iter = AOToParitionMap.find(memberObj);
          assert (iter != AOToParitionMap.end());
          partitionIndex = iter->second;
        } else {
          partitionIndex = initAbstractObjectPartition(memberObj);
        }
      }
      memberPartitions.insert(std::make_pair(pos, partitionIndex));
      static DumpEventDecl<std::size_t, EPTGNode*, std::size_t> initAbstractObjectMemberEvent([](llvm::raw_ostream& os, const EventData<std::size_t, EPTGNode*, std::size_t>& data) {
        os << "    InitAO @ C#" << data.get<0>() << ": Member " << data.get<1>() << " -> #" << data.get<2>() << "\n";
      });
      PSAN_DEBUG(initAbstractObjectMemberEvent(ao->getId(), memberObj, partitionIndex));
    }
    if (memberPartitions.empty()) {
      // simple case; there are no members
      std::size_t partition = getAOPartition(ao);
      addAOToPartitionMapping(ao, partition);
      objectPartitions.at(partition).partitionMembers.insert(ao);
      static DumpEventDecl<std::size_t, EPTGNode*> initAbstractObjectNoMemberEvent([](llvm::raw_ostream& os, const EventData<std::size_t, EPTGNode*>& data) {
        os << "  InitAO NoMember #" << data.get<0>() << " <- " << data.get<1>() << "\n";
      });
      PSAN_DEBUG(initAbstractObjectNoMemberEvent(partition, ao));
      return partition;
    }

    // now we have the member partitions
    llvm::Type* ty = ao->getType();

    // go through all candidates from the same souce type, check if there is a partition that already has an identical memberPartitions
    // if there is one, add to it
    // otherwise we create one
    // note that we may already have a stub partiton from the last stage
    auto iterTypeEntry = objectTypeToPartitionMap.find(ty);
    if (iterTypeEntry != objectTypeToPartitionMap.end()) {
      for (std::size_t partitionID : iterTypeEntry->second) {
        assert (partitionID < PointerPartitionBegin);
        auto& partitionInfo = objectPartitions.at(partitionID);
        if (partitionInfo.changes == memberPartitions) {
          static DumpEventDecl<std::size_t, std::size_t> initAbstractObjectExistingEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
            os << "  InitAO @ C#" << data.get<0>() << ": Found existing partition #" << data.get<1>();
          });
          PSAN_DEBUG(initAbstractObjectExistingEvent(ao->getId(), partitionID));
          // we found the partition
          // note that we may have already been assigned to a less accurate partition (due to calls to getAOParittion())
          // so if this is the case, we are basically doing a fork here
          {
            bool isForkDone = false;
            auto iterExistingMapping = AOToParitionMap.find(ao);
            if (iterExistingMapping != AOToParitionMap.end()) {
              std::size_t oldPartitionID = iterExistingMapping->second;
              if (oldPartitionID != partitionID) {
                auto& oldPartitionInfo = objectPartitions.at(oldPartitionID);
                oldPartitionInfo.partitionMembers.erase(ao);
                for (auto depended : oldPartitionInfo.dependedPartitions) {
                  recheckWorklist.push(depended);
                }
                AOToParitionMap.erase(iterExistingMapping);
                isForkDone = true;
                static DumpEventDecl<std::size_t> initAbstractObjectForkEvent([](llvm::raw_ostream& os, const EventData<std::size_t>& data) {
                  os << " (Fork from #" << data.get<0>() << ")" << "\n";
                });
                PSAN_DEBUG(initAbstractObjectForkEvent(oldPartitionID));
              }
            }
            if (!isForkDone) {
              static DumpEventDecl<> noForkEvent(" (No fork)\n");
              PSAN_DEBUG(noForkEvent());
            }
          }
          partitionInfo.partitionMembers.insert(ao);
          addAOToPartitionMapping(ao, partitionID);
          return partitionID;
        }
      }
    }
    // ok, none of the existing parition has that
    // if there is a partition without member change and we are assigned to it, we need to detach from it
    {
      auto iterExistingMapping = AOToParitionMap.find(ao);
      if (iterExistingMapping != AOToParitionMap.end()) {
        std::size_t oldPartitionID = iterExistingMapping->second;
        static DumpEventDecl<std::size_t, std::size_t> initAbstractObjectDetachEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
          os << "  InitAO @ C#" << data.get<0>() << ": detaching from partition #" << data.get<1>() << "\n";
        });
        PSAN_DEBUG(initAbstractObjectDetachEvent(ao->getId(), oldPartitionID));
        auto& oldPartitionInfo = objectPartitions.at(oldPartitionID);
        // we have not visited this element before so the old partition should be a stub
        assert (oldPartitionInfo.changes.empty());
        oldPartitionInfo.partitionMembers.erase(ao);
        for (auto depended : oldPartitionInfo.dependedPartitions) {
          recheckWorklist.push(depended);
        }
        AOToParitionMap.erase(iterExistingMapping);
      }
    }
    // now create a new partition
    std::size_t partitionID = objectPartitions.size();
    assert (partitionID < PointerPartitionBegin);
    objectPartitions.emplace_back();
    auto& partitionInfo = objectPartitions.back();
    partitionInfo.srcType = ty;
    partitionInfo.changes = memberPartitions;
    partitionInfo.partitionMembers.insert(ao);
    addAOToPartitionMapping(ao, partitionID);
    for (auto iter = memberPartitions.begin(), iterEnd = memberPartitions.end(); iter != iterEnd; ++iter) {
      std::size_t memberIndex = iter->second;
      addDependency(memberIndex, partitionID);
    }
    objectTypeToPartitionMap[ty].insert(partitionID);
    static DumpEventDecl<std::size_t, std::size_t> initAbstractObjectNewEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
      os << "  InitAO @ C#" << data.get<0>() << ": created partition #" << data.get<1>() << "\n";
    });
    PSAN_DEBUG(initAbstractObjectNewEvent(ao->getId(), partitionID));
    return partitionID;
  };
  for (auto& p : *eptg) {
    EPTGNode* node = p.second;
    if (isTaintedForTypeTransform(node)) {
      continue;
    }
    if (CellEPTGNode* ao = SVFUtil::dyn_cast<CellEPTGNode>(node)) {
      if (ao->isPointerTy()) {
        // skip pointers since they should already have the partitions
        continue;
      }
      // skip objects we already visited
      if (initVisitedAOSet.contains(ao)) {
        continue;
      }
      initAbstractObjectPartition(ao);
    }
  }
  // since the recheckWorklist is not drained yet, we can have half-forked partitions, so we disable the invariants check here
  // invariantsCheck();

  // last step: keep checking if we need to fork any partitions
  // TODO add more debug prints
  while (!recheckWorklist.empty()) {
    std::size_t curPartition = recheckWorklist.pop();
    if (curPartition >= PointerPartitionBegin) {
      // handling for pointer partition
      std::size_t realIndex = curPartition - PointerPartitionBegin;
      auto& partition = pointerPartitions.at(realIndex);
      llvm::Type* srcType = partition.srcType;
      auto destWidthType = partition.destWidthType;
      std::size_t targetPartitionIndex = partition.pointToPartition;
      // this partition should be enqueued when we fork point-to partition
      // if there is no point-to partition, this should not be enqueued
      assert (targetPartitionIndex != InvalidPartitionIndex);

      // for pointers that need to be forked
      llvm::DenseMap<std::size_t, llvm::DenseMap<AbstractObject*, llvm::SmallVector<PointerMember*>>> forkMap;
      bool isKeepOldOne = false;
      for (auto iter = partition.partitionMembers.begin(), iterEnd = partition.partitionMembers.end(); iter != iterEnd; ++iter) {
        AbstractObject* pointToObj = iter->first;
        auto iterEntry = AOToParitionMap.find(pointToObj);
        assert (iterEntry != AOToParitionMap.end());
        std::size_t recordedTargetPartitionIndex = iterEntry->second;
        if (recordedTargetPartitionIndex != targetPartitionIndex) {
          forkMap[recordedTargetPartitionIndex].insert(std::make_pair(iter->first, iter->second));
        } else {
          isKeepOldOne = true;
        }
      }
      if (PSAN_DEBUG_ENABLED()) {
        if (!forkMap.empty()) {
          static DumpEventDecl<std::size_t, llvm::Type*, std::size_t, bool> initAbstractObjectForkEvent([](llvm::raw_ostream& os, const EventData<std::size_t, llvm::Type*, std::size_t, bool>& data) {
            os << "Fork PtrPartition #" << data.get<0>() << ": (srcType: " << data.get<1>() << ", PointTo partition: #" << data.get<2>();
            if (!data.get<3>()) {
              os << ", [NoKeepOld]";
            }
            os << ")" << "\n";
          });
          initAbstractObjectForkEvent(curPartition, srcType, targetPartitionIndex, isKeepOldOne);
          for (const auto& p : forkMap) {
            static DumpEventDecl<std::size_t, llvm::SmallVector<std::size_t>> initAbstractObjectForkMemberEvent([](llvm::raw_ostream& os, const EventData<std::size_t, llvm::SmallVector<std::size_t>>& data) {
              os << "  New PointTo partition #" << data.get<0>() << " {";
              bool isFirst = true;
              for (std::size_t id : data.getref<1>().data) {
                if (isFirst) {
                  isFirst = false;
                } else {
                  os << ",";
                }
                os << "C#" << id;
              }
              os << "}" << "\n";
            });
            llvm::SmallVector<std::size_t> memberPartitions;
            for (const auto& member : p.second) {
              memberPartitions.push_back(member.first->getId());
            }
            initAbstractObjectForkMemberEvent(p.first, memberPartitions);
          }
        }
      }

      // small optimization: if all point-to objects still map to the same partition, just update the point-to partition and nothing happens
      if (forkMap.size() == 1 && !isKeepOldOne) {
        removeDependency(partition.pointToPartition, curPartition);
        partition.pointToPartition = forkMap.begin()->first;
        addDependency(partition.pointToPartition, curPartition);
        forkMap.clear();
        isKeepOldOne = true;
      }
      if (!forkMap.empty()) {
        for (std::size_t depended : partition.dependedPartitions) {
          recheckWorklist.push(depended);
        }
        // if we do not need to keep the old one, redirect one of the entry to use the old node
        if (!isKeepOldOne) {
          for (auto iter = forkMap.begin(), iterEnd = forkMap.end(); iter != iterEnd; ++iter) {
            if (iter == forkMap.begin()) {
              std::size_t newPartitionIndex = iter->first;
              removeDependency(partition.pointToPartition, curPartition);
              partition.pointToPartition = newPartitionIndex;
              addDependency(partition.pointToPartition, curPartition);
            } else {
              // as usual
              const auto& newPartitionMembers = iter->second;
              for (const auto& member : newPartitionMembers) {
                for (PointerMember* ap : member.second) {
                  AOToParitionMap.erase(ap);
                }
                partition.partitionMembers.erase(member.first);
              }
            }
          }
          // we are not creating a new partition for the first one, so erase it here
          forkMap.erase(partition.pointToPartition);
        } else {
          // the old one is still used; just move all nodes
          for (auto iter = forkMap.begin(), iterEnd = forkMap.end(); iter != iterEnd; ++iter) {
            // std::size_t newPartitionIndex = iter->first;
            const auto& newPartitionMembers = iter->second;
            for (const auto& member : newPartitionMembers) {
              for (PointerMember* ap : member.second) {
                AOToParitionMap.erase(ap);
              }
              partition.partitionMembers.erase(member.first);
            }
          }
        }
        // okay, after this moment we should no longer access the old partition reference; it will be invalidated
        for (auto iter = forkMap.begin(), iterEnd = forkMap.end(); iter != iterEnd; ++iter) {
          std::size_t currentTargetPartitionIndex = iter->first;
          std::size_t currentIndex = pointerPartitions.size() + PointerPartitionBegin;
          pointerPartitions.emplace_back();
          auto& partition = pointerPartitions.back();
          partition.srcType = srcType;
          partition.destWidthType = destWidthType;
          partition.pointToPartition = currentTargetPartitionIndex;
          partition.partitionMembers = iter->second;
          for (const auto& p : partition.partitionMembers) {
            for (PointerMember* memberAP : p.second) {
              addOrModifyAOToPartitionMapping(memberAP, currentIndex);
            }
          }
          addDependency(currentTargetPartitionIndex, currentIndex);
        }
      }
    } else {
      // handling for object partition
      // for each member object, check if the member modification mapping is still consistent with the partition
      // for those that no longer consistent, create a new partition
      auto& partition = objectPartitions.at(curPartition);
      // we should only be enqueued if members have partition changed, which means we must have members
      assert (!partition.changes.empty());
      llvm::DenseMap<llvm::DenseMap<MemberPosition, std::size_t>, llvm::SmallVector<AbstractObject*>> forkMap;
      bool isKeepOldOne = false;
      for (AbstractObject* ao : partition.partitionMembers) {
        llvm::DenseMap<MemberPosition, std::size_t> memberPartitions;
        for (auto iter = ao->OutEdgeBegin(), iterEnd = ao->OutEdgeEnd(); iter != iterEnd; ++iter) {
          EPTGEdge* edge = *iter;
          if (edge->getEdgeKind() != EPTGEdge::EPTGEdgeK::ContainsEdge) {
            continue;
          }
          ContainsEPTGEdge* containsEdge = SVFUtil::cast<ContainsEPTGEdge>(edge);
          const MemberPosition& pos = containsEdge->getMemberPosition();
          CellEPTGNode* memberObj = SVFUtil::cast<CellEPTGNode>(containsEdge->getDstNode());
          std::size_t targetPartition = InvalidPartitionIndex;
          {
            auto iter = AOToParitionMap.find(memberObj);
            assert (iter != AOToParitionMap.end());
            targetPartition = iter->second;
          }
          memberPartitions.insert(std::make_pair(pos, targetPartition));
        }
        if (memberPartitions == partition.changes) {
          isKeepOldOne = true;
          continue;
        }
        forkMap[memberPartitions].push_back(ao);
      }
      // helper function for debugging (unused for now)
      auto dumpForkMap = [&]() -> void {
        PSan::errs() << "ObjectPartition #" << curPartition << " forkmap: " << forkMap.size() << " entries:\n";
        for (auto iter = forkMap.begin(), iterEnd = forkMap.end(); iter != iterEnd; ++iter) {
          const auto& partitionChanges = iter->first;
          const auto& memberAOs = iter->second;
          PSan::errs() << "  Entry: " << partitionChanges.size() << " children, " << memberAOs.size() << " members:\n";
          for (auto iter = partitionChanges.begin(), iterEnd = partitionChanges.end(); iter != iterEnd; ++iter) {
            const auto& pos = iter->first;
            std::size_t newPartition = iter->second;
            std::size_t oldPartition = 0;
            auto iterOld = partition.changes.find(pos);
            if (iterOld != partition.changes.end()) {
              oldPartition = iterOld->second;
            }
           PSan::errs() << "    " << pos.toString() << ": " << oldPartition << " -> " << newPartition << "\n";
          }
          for (auto iter = memberAOs.begin(), iterEnd = memberAOs.end(); iter != iterEnd; ++iter) {
            PSan::errs() << "    " << (*iter)->toString() << "\n";
          }
        }
        PSan::errs() << "Current members: " << partition.partitionMembers.size() << "\n";
        for (AbstractObject* ao : partition.partitionMembers) {
          PSan::errs() << "  " << ao->toString() << '\n';
        }
      };
      (void) dumpForkMap;
      if (PSAN_DEBUG_ENABLED()) {
        if (!forkMap.empty()) {
          static DumpEventDecl<std::size_t, llvm::Type*, bool> initAbstractObjectForkEvent([](llvm::raw_ostream& os, const EventData<std::size_t, llvm::Type*, bool>& data) {
            os << "Fork ObjPartition #" << data.get<0>() << ": (srcType: " << data.get<1>();
            if (!data.get<2>()) {
              os << ", [NoKeepOld]";
            }
            os << ")" << "\n";
          });
          initAbstractObjectForkEvent(curPartition, partition.srcType, isKeepOldOne);
        }
      }
      if (!isKeepOldOne && !forkMap.empty()) {
        // adopt the member changes of the first one
        for (auto iter = partition.changes.begin(), iterEnd = partition.changes.end(); iter != iterEnd; ++iter) {
          removeDependency(iter->second, curPartition);
        }
        partition.changes = forkMap.begin()->first;
        for (auto iter = partition.changes.begin(), iterEnd = partition.changes.end(); iter != iterEnd; ++iter) {
          addDependency(iter->second, curPartition);
        }
        forkMap.erase(forkMap.begin());
      }
      if (!forkMap.empty()) {
        // we need to do the fork
        llvm::Type* srcType = partition.srcType;
        for (const auto& p : forkMap) {
          for (AbstractObject* ao : p.second) {
            partition.partitionMembers.erase(ao);
            AOToParitionMap.erase(ao);
          }
        }
        // ok, we should stop using partition reference; we are going to create new partitions
        for (const auto& p : forkMap) {
          std::size_t partitionIndex = objectPartitions.size();
          assert (partitionIndex < PointerPartitionBegin);
          objectPartitions.emplace_back();
          auto& partition = objectPartitions.back();
          partition.srcType = srcType;
          partition.changes = p.first;
          for (AbstractObject* ao : p.second) {
            partition.partitionMembers.insert(ao);
            addOrModifyAOToPartitionMapping(ao, partitionIndex);
          }
          for (auto iter = partition.changes.begin(), iterEnd = partition.changes.end(); iter != iterEnd; ++iter) {
            addDependency(iter->second, partitionIndex);
          }
        }
      }
    }
  }
  invariantsCheck();
  static DumpEventDecl<std::size_t, std::size_t> initEndEvent([](llvm::raw_ostream& os, const EventData<std::size_t, std::size_t>& data) {
    os << "Number of partitions: " << data.get<0>() << " objs, " << data.get<1>() << " ptrs\n";
  });
  PSAN_DEBUG(initEndEvent(objectPartitions.size(), pointerPartitions.size()));

  // next, create all the types
  // we want to avoid creating extra types whenever possible
  // here we first start from pointers having size type expansion, and traverse over all dependent types and mark them as requiring new type, and we do this recursively
  // any types NOT visited during traversal does not need their type to be modified

  // if the corresponding bit is set, it means their partition.finalType is the one to use
  llvm::BitVector isFinalized_obj(objectPartitions.size(), false);
  llvm::BitVector isFinalized_ptr(pointerPartitions.size(), false);
  {
    llvm::DenseSet<std::size_t> visitedSet;
    SVF::FIFOWorkList<std::size_t> worklist;
    for (std::size_t i = 0, n = pointerPartitions.size(); i < n; ++i) {
      auto& partition = pointerPartitions.at(i);
      if (partition.destWidthType != 0) {
        worklist.push(i + PointerPartitionBegin);
      }
    }
    static DumpEventDecl<std::size_t> worklistStatEvent([](llvm::raw_ostream& os, const EventData<std::size_t>& data) {
      os << "Number of pointer partitions expanding: " << data.get<0>() << "\n";
    });
    PSAN_DEBUG(worklistStatEvent(worklist.size()));
    while (!worklist.empty()) {
      std::size_t partitionIndex = worklist.pop();
      if (visitedSet.contains(partitionIndex)) {
        continue;
      }
      visitedSet.insert(partitionIndex);
      // go to all depended types and mark them as visited as well
      if (partitionIndex >= PointerPartitionBegin) {
        std::size_t realIndex = partitionIndex - PointerPartitionBegin;
        auto& partition = pointerPartitions.at(realIndex);
        for (auto depended : partition.dependedPartitions) {
          if (!visitedSet.contains(depended)) {
            worklist.push(depended);
          }
        }
      } else {
        auto& partition = objectPartitions.at(partitionIndex);
        for (auto depended : partition.dependedPartitions) {
          if (!visitedSet.contains(depended)) {
            worklist.push(depended);
          }
        }
      }
    }
    for (std::size_t i = 0, n = objectPartitions.size(); i < n; ++i) {
      auto& partition = objectPartitions.at(i);
      if (!visitedSet.contains(i)) {
        assert (!partition.finalType);
        partition.finalType = partition.srcType;
        isFinalized_obj.set(i);
      } else {
        static DumpEventDecl<std::size_t, llvm::Type*> initVisitAPResultEvent([](llvm::raw_ostream& os, const EventData<std::size_t, llvm::Type*>& data) {
          os << "ObjPartition #" << data.get<0>() << " (" << data.get<1>() << ") need new type\n";
        });
        PSAN_DEBUG(initVisitAPResultEvent(i, partition.srcType));
      }
    }
    for (std::size_t i = 0, n = pointerPartitions.size(); i < n; ++i) {
      auto& partition = pointerPartitions.at(i);
      std::size_t refIndex = i + PointerPartitionBegin;
      if (!visitedSet.contains(refIndex)) {
        assert (!partition.finalType);
        partition.finalType = partition.srcType;
        isFinalized_ptr.set(i);
      } else {
        static DumpEventDecl<std::size_t, llvm::Type*> initVisitAPResultEvent([](llvm::raw_ostream& os, const EventData<std::size_t, llvm::Type*>& data) {
          os << "PtrPartition #" << data.get<0>() << " (" << data.get<1>() << ") need new type\n";
        });
        PSAN_DEBUG(initVisitAPResultEvent(refIndex, partition.srcType));
      }
    }
  }

  // okay, start to create new types
  // one problem of function type is that we cannot create stub function types; they MUST be created after all members are ready, just like other non-struct types
  // therefore our strategy is we first create stub types for structs, then walk through all the type partitions and use DFS to create dependent types
  // we should have a cycle detection mechanism to catch bugs...

  // we want to be able to compare IRs generated in different instrumentation modes
  // therefore, we want to ensure that the new type names are consistent and easy to compare
  // for now if we are recreating a struct, we append ".m" to the first struct type after type forking, and ".m2", ".m3" so on and so forth
  llvm::DenseMap<llvm::StructType*, unsigned> structForkingCountMap;
  llvm::DenseMap<std::tuple<unsigned, llvm::Type*, PtrType>, llvm::Type*> pointerTypeCache;
  std::function<void(llvm::Type*, llvm::raw_ostream&)> populateTypeNameForPtrType = [&](llvm::Type* ty, llvm::raw_ostream& os) -> void {
    if (ty->isVoidTy()) {
      os << "void";
    } else if (ty->isIntegerTy()) {
      os << "i" << ty->getIntegerBitWidth();
    } else if (ty->isPointerTy()) {
      populateTypeNameForPtrType(getPointerElementType(ty), os);
      os << "ptr";
    } else if (ty->isStructTy()) {
      llvm::StructType* structTy = llvm::cast<llvm::StructType>(ty);
      if (structTy->hasName()) {
        os << structTy->getName();
      } else {
        os << "anonstruct";
      }
    } else if (ty->isArrayTy()) {
      populateTypeNameForPtrType(ty->getArrayElementType(), os);
      os << "arr";
    } else if (ty->isVectorTy()) {
      populateTypeNameForPtrType(llvm::cast<llvm::VectorType>(ty)->getElementType(), os);
      os << "vec";
    } else if (ty->isFloatingPointTy()) {
      os << "f" << ty->getPrimitiveSizeInBits();
    } else {
      os << "unknown";
    }
  };
  auto getTransformedPointerType = [&](llvm::PointerType* srcPtrTy, llvm::Type* pointToType, PtrType destWidthType) -> llvm::Type* {
    if (destWidthType == 0) {
      return llvm::PointerType::get(pointToType, srcPtrTy->getAddressSpace());
    }
    auto key = std::make_tuple(srcPtrTy->getAddressSpace(), pointToType, destWidthType);
    auto iter = pointerTypeCache.find(key);
    if (iter != pointerTypeCache.end()) {
      return iter->second;
    }
    std::string ptrTypeName;
    llvm::raw_string_ostream os(ptrTypeName);
    os << "_ptr_";
    populateTypeNameForPtrType(getPointerElementType(srcPtrTy), os);
    llvm::StructType* newTy = llvm::StructType::create(context, ptrTypeName);
    llvm::SmallVector<llvm::Type*> elements;
    llvm::PointerType* newPtrTy = llvm::PointerType::get(pointToType, srcPtrTy->getAddressSpace());
    elements.push_back(newPtrTy);
    unsigned curID = 0;
    while (destWidthType != 0) {
      if (destWidthType & 1) {
        llvm::Type* curTy = instrumentations[curID]->getPointerMetadataTypeInMemory();
        if (!curTy) {
          psan_unreachable("Instrumentation with no metadata participating in EPTG conversion");
        }
        elements.push_back(curTy);
      }
      destWidthType >>= 1;
      curID += 1;
    }
    newTy->setBody(elements);
    pointerTypeCache.insert(std::make_pair(key, newTy));
    return newTy;
  };
  llvm::DenseMap<unsigned, llvm::PointerType*> retMDExtraParamTypeCache;
  auto getFunctionTransformedType = [&](std::size_t partitionIndex, llvm::FunctionType* oldTy, const llvm::DenseMap<MemberPosition, std::pair<std::size_t, llvm::Type*>>& memberTypeMap) -> llvm::FunctionType* {
    // this function should not be called on the same partition more than once
    assert (result.functionTypeChanges.find(partitionIndex) == result.functionTypeChanges.end());
    assert (partitionIndex < PointerPartitionBegin);
    auto& info = result.functionTypeChanges[partitionIndex];
    info.partitionIndex = partitionIndex;
    info.oldTy = oldTy;

    llvm::SmallVector<llvm::Type*> argumentTypes; // types that replace existing parameters
    llvm::SmallVector<llvm::Type*> appendedTypes; // types added for pointer expansion
    unsigned appendParamStartIndex = oldTy->getNumParams();
    argumentTypes.reserve(oldTy->getNumParams());
    for (unsigned i = 0, n = oldTy->getNumParams(); i < n; ++i) {
      llvm::Type* curTy = oldTy->getParamType(i);
      auto iter = memberTypeMap.find(MemberPosition(i));
      // first check if we don't need to change the type
      if (iter == memberTypeMap.end()) {
        argumentTypes.push_back(curTy);
        continue;
      }
      // if we do need to change the type, we check if only the points-to type is changed,
      // and there is no additional metadata passed along with the pointer
      // if yes, we can still just use the new type but not create any extra parameters
      llvm::Type* newTy = iter->second.second;
      std::size_t partitionIndex = iter->second.first;
      assert (partitionIndex >= PointerPartitionBegin);
      auto& partition = pointerPartitions.at(partitionIndex - PointerPartitionBegin);
      unsigned mdvec = partition.destWidthType;
      if (mdvec == 0) {
        // no metadata passed along with the pointer
        // we can still use the new type
        assert (newTy->isPointerTy());
        argumentTypes.push_back(newTy);
        continue;
      }
      // now we confirmed that the type is changed and there is metadata passed along with the pointer
      llvm::StructType* inMemTy = llvm::dyn_cast<llvm::StructType>(newTy);
      if (!inMemTy) {
        // we cannot handle other types for now
        psan_unreachable("Expanded pointer is not a struct??");
      }
      llvm::Type* typeToUse = inMemTy->getElementType(0);
      if (!typeToUse->isPointerTy()) {
        psan_unreachable("Expanded pointer not having first member as original pointer type");
      }
      if (inMemTy->getNumElements() < 2) {
        psan_unreachable("Expanded pointer not having enough elements");
      }
      argumentTypes.push_back(typeToUse);
      // now we need to create extra parameters
      InstrumentationPlan::FunctionTypeChangeInfo::ArgumentPointerExpandInfo argExpandInfo;
      argExpandInfo.pointerPartitionIndex_withOffset = partitionIndex;
      argExpandInfo.argumentIndex = i;
      argExpandInfo.expandStartArgIndex = appendParamStartIndex + appendedTypes.size();
      // we follow the same order as the metadata vector
      unsigned instrumentationIndex = 0;
      while (mdvec != 0) {
        if (mdvec & 1) {
          appendedTypes.append(instrumentations[instrumentationIndex]->getPointerMetadataTypesInRegisters());
        }
        mdvec >>= 1;
        instrumentationIndex += 1;
      }
      argExpandInfo.expandEndArgPos = appendParamStartIndex + appendedTypes.size();
      unsigned recordIndex = info.argumentExpandArgInfo.size();
      info.argumentExpandArgInfo.push_back(argExpandInfo);
      info.argIndexToExpandInfoMap.insert(std::make_pair(i, recordIndex));
    }
    // ok, now handle the return type
    llvm::Type* newRetTy = oldTy->getReturnType();
    {
      auto iter = memberTypeMap.find(MemberPosition(oldTy->getNumParams()));
      if (iter != memberTypeMap.end()) {
        info.retPartitionIndex = iter->second.first;
        llvm::Type* retTy = iter->second.second;
        if (retTy != oldTy->getReturnType()) {
          if (info.retPartitionIndex < PointerPartitionBegin) {
            // the return type is changed to a non-pointer type
            // we cannot handle this for now
            psan_unreachable("Unhandled transformed non-pointer type");
          } else {
            // pointer return type changed
            auto& partition = pointerPartitions.at(info.retPartitionIndex - PointerPartitionBegin);
            unsigned mdvec = partition.destWidthType;
            if (mdvec == 0) {
              // no additional metadata; just change the points-to type
              assert (retTy->isPointerTy());
              newRetTy = retTy;
            } else {
              // additional metadata; we need to create a struct type
              llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(retTy);
              if (!sTy) {
                psan_unreachable("Expanded pointer is not a struct??");
              }
              llvm::Type* typeToUse = sTy->getElementType(0);
              if (!typeToUse->isPointerTy()) {
                psan_unreachable("Expanded pointer not having first member as original pointer type");
              }
              if (sTy->getNumElements() < 2) {
                psan_unreachable("Expanded pointer not having enough elements");
              }
              newRetTy = typeToUse;
              info.retExpandArgIndex = appendParamStartIndex + appendedTypes.size();
              // now we need to create extra parameters
              llvm::PointerType* appendParamType = nullptr;
              auto iterRetMD = retMDExtraParamTypeCache.find(mdvec);
              if (iterRetMD != retMDExtraParamTypeCache.end()) {
                appendParamType = iterRetMD->second;
              } else {
                // this is the first occurrence of this metadata vector
                // if the returned metadata only have one element, we can just put a pointer to that element
                // otherwise, we create a pointer to the whole struct
                llvm::SmallVector<llvm::Type*> elements;
                unsigned originalMDVec = mdvec;
                // we follow the same order as the metadata vector
                unsigned instrumentationIndex = 0;
                while (mdvec != 0) {
                  if (mdvec & 1) {
                    elements.append(instrumentations[instrumentationIndex]->getPointerMetadataTypesInRegisters());
                  }
                  mdvec >>= 1;
                  instrumentationIndex += 1;
                }

                if (elements.size() == 1) {
                  appendParamType = llvm::PointerType::get(elements.front(), srcModule->getDataLayout().getAllocaAddrSpace());
                } else {
                  // we have more than one extra element
                  std::string structName("_psan_retmd_");
                  structName.append(std::to_string(originalMDVec));
                  llvm::StructType* mdStructTy = llvm::StructType::create(elements, structName);
                  appendParamType = llvm::PointerType::get(mdStructTy, srcModule->getDataLayout().getAllocaAddrSpace());
                }
                retMDExtraParamTypeCache.insert(std::make_pair(originalMDVec, appendParamType));
              }
              appendedTypes.push_back(appendParamType);
            }
          }
        }
      }
    }
    // now create the final type
    argumentTypes.append(appendedTypes);
    info.newTy = llvm::FunctionType::get(newRetTy, argumentTypes, oldTy->isVarArg());
    return info.newTy;
  };
  for (std::size_t i = 0, n = objectPartitions.size(); i < n; ++i) {
    auto& partition = objectPartitions.at(i);
    if (isFinalized_obj.test(i)) {
      continue;
    }
    // if there is no member, we should already resolved them
    assert (!partition.changes.empty());

    // okay, there are members. maybe a function type, array type, or struct type
    if (partition.srcType->isStructTy()) {
      // create a stub struct type
      // struct name is specified by the rule above
      llvm::StructType* sty = llvm::cast<llvm::StructType>(partition.srcType);
      auto iterCount = structForkingCountMap.find(sty);
      unsigned count = 0;
      if (iterCount == structForkingCountMap.end()) {
        structForkingCountMap.insert(std::make_pair(sty, 1u));
        count = 1;
      } else {
        iterCount->second += 1;
        count = iterCount->second;
      }
      std::string newName = sty->getName().str();
      newName.append(".m");
      if (count > 1) {
        newName.append(std::to_string(count));
      }
      partition.finalType = llvm::StructType::create(context, newName);
    }
  }
  llvm::BitVector isVisiting_obj(objectPartitions.size(), false);
  llvm::BitVector isVisiting_ptr(pointerPartitions.size(), false);
  // now walk through all types
  std::function<llvm::Type*(std::size_t)> generateType = [&](std::size_t partitionIndex) -> llvm::Type* {
    if (partitionIndex >= PointerPartitionBegin) {
      // visiting a pointer partition
      std::size_t realIndex = partitionIndex - PointerPartitionBegin;
      assert (!isVisiting_ptr.test(realIndex));
      auto& partition = pointerPartitions.at(realIndex);
      // early exit if we already got the type
      if (isFinalized_ptr.test(realIndex)) {
        assert(partition.finalType);
        return partition.finalType;
      }
      isVisiting_ptr.set(realIndex);
      llvm::Type* pointToType = nullptr;
      if (partition.pointToPartition == InvalidPartitionIndex) {
        pointToType = getPointerElementType(partition.srcType);
      } else {
        // if the target is a struct, avoid calling generateType (since we may have circular dependency)
        if (partition.pointToPartition < PointerPartitionBegin) {
          auto& pointToPartition = objectPartitions.at(partition.pointToPartition);
          if (pointToPartition.finalType) {
            pointToType = pointToPartition.finalType;
          }
        }
        // if that does not work, then we need to call generateType()
        if (!pointToType) {
          pointToType = generateType(partition.pointToPartition);
        }
      }
      llvm::PointerType* srcPtrTy = llvm::cast<llvm::PointerType>(partition.srcType);
      llvm::Type* destType = getTransformedPointerType(srcPtrTy, pointToType, partition.destWidthType);
      partition.finalType = destType;
      isFinalized_ptr.set(realIndex);
      isVisiting_ptr.flip(realIndex);
      assert(partition.finalType);
      return partition.finalType;
    } else {
      // visiting an object partition
      assert (!isVisiting_obj.test(partitionIndex));
      auto& partition = objectPartitions.at(partitionIndex);
      // early exit if we already got the type
      if (isFinalized_obj.test(partitionIndex)) {
        assert (partition.finalType);
        return partition.finalType;
      }
      // sanity check; if this type does not have members, we should already handled them in the first pass
      assert (!partition.changes.empty());
      isVisiting_obj.set(partitionIndex);
      llvm::DenseMap<MemberPosition, std::pair<std::size_t, llvm::Type*>> memberTypes;
      for (auto iter = partition.changes.begin(), iterEnd = partition.changes.end(); iter != iterEnd; ++iter) {
        const MemberPosition& pos = iter->first;
        std::size_t memberPartition = iter->second;
        llvm::Type* memberTy = generateType(memberPartition);
        memberTypes.insert(std::make_pair(pos, std::make_pair(memberPartition, memberTy)));
      }
      // now all member types are collected
      // deal with the actual types
      if (llvm::FunctionType* funcTy = llvm::dyn_cast<llvm::FunctionType>(partition.srcType)) {
        // only one of the handling code should be executed
        assert (!partition.finalType);
        partition.finalType = getFunctionTransformedType(partitionIndex, funcTy, memberTypes);
      }
      if (llvm::ArrayType* arrayTy = llvm::dyn_cast<llvm::ArrayType>(partition.srcType)) {
        // only one of the handling code should be executed
        assert (!partition.finalType);
        // for array type, there should be only a single member, which is the array element type
        if (memberTypes.size() != 1) {
          auto& os = PSan::outs_before_unreachable();
          for (auto& p : memberTypes) {
            os << "Member: " << p.first.toString() << " -> " << p.second.second << "\n";
          }
          psan_unreachable("Array type with more than one member??");
        }
        auto iterFirstElement = memberTypes.begin();
        assert (iterFirstElement->first.size() == 1 && iterFirstElement->first.at(0) == 0);
        llvm::Type* elementType = iterFirstElement->second.second;
        llvm::Type* resultType = nullptr;
        if (elementType == arrayTy->getElementType()) {
          // no change is ever needed
          resultType = arrayTy;
        } else {
          // create a new array type
          resultType = llvm::ArrayType::get(elementType, arrayTy->getNumElements());
        }
        partition.finalType = resultType;
      }
      if (llvm::StructType* structTy = llvm::dyn_cast<llvm::StructType>(partition.srcType)) {
        // for struct types, we may already have a stub type created
        // take it off from the finalType
        llvm::StructType* opaqueTy = nullptr;
        if (partition.finalType) {
          opaqueTy = llvm::cast<llvm::StructType>(partition.finalType);
          assert (opaqueTy->isOpaque());
        }
        llvm::DenseMap<MemberPosition, llvm::Type*> convertedMap;
        for (const auto& p : memberTypes) {
          convertedMap.insert(std::make_pair(p.first, p.second.second));
        }
        partition.finalType = populateTransformedStructType(structTy, convertedMap, opaqueTy);
      }
      // we do not handle other types for now...
      assert (partition.finalType);
      isFinalized_obj.set(partitionIndex);
      isVisiting_obj.flip(partitionIndex);
      return partition.finalType;
    }
  };
  for (std::size_t i = 0, n = objectPartitions.size(); i < n; ++i) {
    if (!isFinalized_obj.test(i)) {
      generateType(i);
    }
  }
  for (std::size_t i = 0, n = pointerPartitions.size(); i < n; ++i) {
    std::size_t refIndex = i + PointerPartitionBegin;
    if (!isFinalized_ptr.test(i)) {
      generateType(refIndex);
    }
  }

  // now all the partitions should have final types; start to write back results
  // skip object partition 0 since it represents the invalid partition
  for (std::size_t i = 1, n = objectPartitions.size(); i < n; ++i) {
    auto& partition = objectPartitions.at(i);
    assert (partition.finalType);
    InstrumentationPlan::EPTGCellTypeChangePartitionInfo resultPartition;
    resultPartition.srcType = partition.srcType;
    resultPartition.finalType = partition.finalType;
    result.cellPartitions.insert(std::make_pair(i, resultPartition));
    static DumpEventDecl<std::size_t, llvm::Type*, llvm::Type*> initObjPartitionResultEvent([](llvm::raw_ostream& os, const EventData<std::size_t, llvm::Type*, llvm::Type*>& data) {
      os << "ObjPartition #" << data.get<0>() << ": " << data.get<1>() << " -> " << data.get<2>() << "\n";
    });
    PSAN_DEBUG(initObjPartitionResultEvent(i, partition.srcType, partition.finalType));
    std::string infostr;
    llvm::raw_string_ostream os(infostr);
    os << "O#" << i << " -> " << partition.finalType;
    std::shared_ptr<std::string> infostrPtr = std::make_shared<std::string>(infostr);

    for (AbstractObject* ao : partition.partitionMembers) {
      result.cellTypeConversions.insert(std::make_pair(ao, i));
      EPTGNode::auxiliaryInfoMap[ao].push_back(infostrPtr);
      llvm::Type* ty = ao->getType();
      // sanity check: the source type should match
      if (ty != partition.srcType) {
        psan_unreachable("Source type mismatch??");
      }
      // sanity check: for elementary data types, we should not change their types
      if (ty->isIntegerTy() || ty->isFloatTy()) {
        if (ty != partition.finalType) {
          psan_unreachable("Elementary data type changed??");
        }
      }
    }
  }
  for (std::size_t i = 0, n = pointerPartitions.size(); i < n; ++i) {
    auto& partition = pointerPartitions.at(i);
    assert (partition.finalType);
    std::size_t refIndex = i + PointerPartitionBegin;
    InstrumentationPlan::EPTGCellTypeChangePartitionInfo resultPartition;
    resultPartition.srcType = partition.srcType;
    resultPartition.finalType = partition.finalType;
    resultPartition.pointerMDBitVec = partition.destWidthType;
    result.cellPartitions.insert(std::make_pair(refIndex, resultPartition));
    static DumpEventDecl<std::size_t, llvm::Type*, llvm::Type*> initPtrPartitionResultEvent([](llvm::raw_ostream& os, const EventData<std::size_t, llvm::Type*, llvm::Type*>& data) {
      os << "PtrPartition #" << data.get<0>() << ": " << data.get<1>() << " -> " << data.get<2>() << "\n";
    });
    PSAN_DEBUG(initPtrPartitionResultEvent(refIndex, partition.srcType, partition.finalType));
    std::string infostr;
    llvm::raw_string_ostream os(infostr);
    os << "P#" << i << " -> " << partition.finalType;
    std::shared_ptr<std::string> infostrPtr = std::make_shared<std::string>(infostr);
    for (const auto& p : partition.partitionMembers) {
      for (PointerMember* ap : p.second) {
        result.cellTypeConversions.insert(std::make_pair(ap, refIndex));
        EPTGNode::auxiliaryInfoMap[ap].push_back(infostrPtr);
        llvm::Type* ty = ap->getType();
        // sanity check: the source type should match
        if (ty != partition.srcType) {
          psan_unreachable("Source type mismatch??");
        }
        // sanity check: if the original pointer is pointing to elementary data types,
        // we should not change the points-to type
        if (llvm::PointerType* ptrTy = llvm::dyn_cast<llvm::PointerType>(ty)) {
          llvm::Type* oldPointsTo = getPointerElementType(ptrTy);
          if (oldPointsTo->isIntegerTy() || oldPointsTo->isFloatTy()) {
            // check the current pointer type
            llvm::Type* newPtrTy = partition.finalType;
            if (llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(newPtrTy)) {
              newPtrTy = sTy->getElementType(0);
            }
            if (!newPtrTy->isPointerTy()) {
              psan_unreachable("Pointer type cell transformed to a non-pointer type");
            }
            llvm::Type* newPointsTo = getPointerElementType(newPtrTy);
            if (oldPointsTo != newPointsTo) {
              psan_unreachable("Elementary points-to data type changed??");
            }
          }
        }
      }
    }
  }
  // also write back function type changes
  for (llvm::Function& F : *srcModule) {
    if (F.isDeclaration()) {
      continue;
    }
    if (ExpressionEPTGNode* node = eptg->getExpressionNode(&F)) {
      if (CellEPTGNode* funcCell = node->getPointsTo()) {
        if (!isTaintedForTypeTransform(funcCell)) {
          auto iter = result.cellTypeConversions.find(funcCell);
          if (iter == result.cellTypeConversions.end()) {
            psan_unreachable("Function cell not found in cellTypeConversions");
          }
          result.funcInterfaceChanges.insert(std::make_pair(&F, iter->second));
        }
      }
    }
  }
  // done
}
llvm::StructType* populateTransformedStructType(llvm::StructType* structTy, const llvm::DenseMap<MemberPosition, llvm::Type*>& memberTypes, llvm::StructType* placeholder)
{
  // we may have objects incompletely expanded (i.e., we have an edge with MemberPosition having more than one index)
  // in this case we need to recursively fill in the types
  llvm::SmallVector<llvm::Type*> resultMemberTypes(structTy->getNumElements(), nullptr);
  llvm::DenseMap<std::size_t, llvm::DenseMap<MemberPosition, llvm::Type*>> unresolvedMemberMap;
  for (const auto& p : memberTypes) {
    const MemberPosition& pos = p.first;
    llvm::Type* compType = p.second;
    assert (pos.size() >= 1);
    std::int64_t firstIndex = pos.at(0);
    assert (firstIndex >= 0 && firstIndex < static_cast<std::int64_t>(resultMemberTypes.size()));
    if (pos.size() == 1) {
      resultMemberTypes[firstIndex] = compType;
    } else {
      MemberPosition childPos = pos.dropPrefixWithSize(1);
      unresolvedMemberMap[firstIndex][childPos] = compType;
    }
  }
  for (unsigned i = 0, n = structTy->getNumElements(); i < n; ++i) {
    llvm::Type*& memberTypePtr = resultMemberTypes[i];
    auto iter = unresolvedMemberMap.find(i);
    if (memberTypePtr) {
      assert (iter == unresolvedMemberMap.end());
      // do nothing
    } else {
      llvm::Type* existingTy = structTy->getTypeAtIndex(i);
      if (iter == unresolvedMemberMap.end()) {
        // no type change
        memberTypePtr = existingTy;
      } else {
        const llvm::DenseMap<MemberPosition, llvm::Type*>& derivedMemberMap = iter->second;
        if (llvm::StructType* sTy = llvm::dyn_cast<llvm::StructType>(existingTy)) {
          memberTypePtr = populateTransformedStructType(sTy, derivedMemberMap, nullptr);
        } else if (llvm::ArrayType* aTy = llvm::dyn_cast<llvm::ArrayType>(existingTy)) {
          llvm::Type* elementTy = aTy->getElementType();
          (void) elementTy;
          // it is possible for derivedMemberMap to have more than one element (e.g., we index into array-of-struct in one shot)
          // but for now we assume this cannot happen..
          // we also assume that we won't handle array-of-arrays for now (we can break the GEP in pretransform and avoid this case)
          assert (derivedMemberMap.size() == 1);
          auto iterFirstEntry = derivedMemberMap.begin();
          const MemberPosition& pos = iterFirstEntry->first;
          assert (pos.size() == 1 && pos.at(0) == 0);
          llvm::Type* newElementTy = iterFirstEntry->second;
          memberTypePtr = llvm::ArrayType::get(newElementTy, aTy->getNumElements());
        }
      }
    }
    assert (memberTypePtr);
  }
  // placeholder
  llvm::StructType* newTy = nullptr;
  if (placeholder) {
    // there is already a type created; just populate the body
    newTy = placeholder;
    newTy->setBody(resultMemberTypes, structTy->isPacked());
  } else {
    // we need to create the type from scratch
    newTy = llvm::StructType::create(structTy->getContext(), resultMemberTypes, structTy->getName(), structTy->isPacked());
  }
  return newTy;
}
} // end anonymous namespace