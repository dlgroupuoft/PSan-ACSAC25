#include "s2.h"
#include "FastDebugDumper.h"
#include "Util/WorkList.h"
#include "llvm/ADT/StringSwitch.h"

using namespace PSan;

const char PSan::PSAN_PLACEHOLDER_NAME_PREFIX[] = "_psan_placeholder_";

bool PSan::step2_pruning_isPlaceholderCall(llvm::Value* v)
{
  if (llvm::CallInst* call = llvm::dyn_cast<llvm::CallInst>(v)) {
    if (llvm::Function* callee = call->getCalledFunction()) {
      if (callee->getName().startswith(PSAN_PLACEHOLDER_NAME_PREFIX)) {
        return true;
      }
    }
  }
  return false;
}

bool PSan::step2_pruning_isPlaceholderFunction(llvm::Function* func)
{
  return func->getName().startswith(PSAN_PLACEHOLDER_NAME_PREFIX);
}

bool PSan::step2_pruning_isFunctionHaveHiddenCalls(const llvm::StringSet<>& functionsWithHiddenCalls, llvm::Function* func)
{
  // we would only have functions with definitions here
  if (func->getBasicBlockList().empty()) {
    psan_unreachable("step2_pruning_isFunctionHaveHiddenCalls() expects definition only");
  }
  if (functionsWithHiddenCalls.count(func->getName())) {
    return true;
  }
  return llvm::StringSwitch<bool>(func->getName())
    .Case("main", true)
    .Default(false);
}

bool PSan::step2_pruning_isInstrTriviallyDead(llvm::Instruction* instr)
{
  // DCE adapted to drop placeholder calls as well
  if (!instr->use_empty())
    return false;
  if (instr->isTerminator())
    return false;
  // true if this is a placeholder call
  if (step2_pruning_isPlaceholderCall(instr))
    return true;
  // true if this is some known instructions that can be left over
  if (llvm::isa<llvm::BitCastInst>(instr)) {
    return true;
  }
  if (llvm::CallInst* call = llvm::dyn_cast<llvm::CallInst>(instr)) {
    switch (call->getIntrinsicID())
    {
    default: break;
    case llvm::Intrinsic::lifetime_start:
    case llvm::Intrinsic::lifetime_end:
    case llvm::Intrinsic::dbg_declare:
    case llvm::Intrinsic::dbg_value:
    case llvm::Intrinsic::dbg_label:
    case llvm::Intrinsic::dbg_addr:
    case llvm::Intrinsic::assume:
      return true;
    }
  }
  // otherwise just leave them as is
  return false;
}

void PSan::step2_pruning_dropDeadInstr(llvm::Instruction* instr)
{
  SVF::FIFOWorkList<llvm::Instruction*> worklist;
  llvm::Instruction* cur = instr;
  while(true) {
    for (unsigned i = 0, n = cur->getNumOperands(); i < n; ++i) {
      llvm::Value* srcOperand = cur->getOperand(i);
      cur->setOperand(i, nullptr);
      if (!srcOperand->use_empty() || srcOperand == cur)
        continue;
      if (llvm::Instruction* src = llvm::dyn_cast<llvm::Instruction>(srcOperand)) {
        if (step2_pruning_isInstrTriviallyDead(src)) {
          worklist.push(src);
        }
      }
    }
    cur->eraseFromParent();
    if (worklist.empty())
      break;
    cur = worklist.pop();
  }
}

void PSan::step2_pruning_trivialDCE(llvm::BasicBlock* block)
{
  for (auto iter = block->begin(), iterEnd = block->end(); iter != iterEnd; ) {
    llvm::Instruction* curInstr = &*iter;
    ++iter;
    if (step2_pruning_isInstrTriviallyDead(curInstr)) {
      step2_pruning_dropDeadInstr(curInstr);
    }
  }
}

void PSan::step2_pruning_trivialDCE(llvm::Function* clonedFunc)
{
  for (llvm::BasicBlock& B : clonedFunc->getBasicBlockList()) {
    step2_pruning_trivialDCE(&B);
  }
}

void PSan::step2_pruning_buildFunctionInfo(llvm::Function* func, FunctionCFGPruneState& state)
{
  unsigned blockIndex = 0;
  state.callonly_blocks.resize(func->getBasicBlockList().size(), false);
  state.usedblocks.resize(func->getBasicBlockList().size(), false);
  std::size_t numUsedBlocks = 0;
  std::size_t numCallonlyBlocks = 0;
  for (llvm::BasicBlock& BB : func->getBasicBlockList()) {
    state.blockList.push_back(&BB);
    state.blockIndexMap.insert(std::make_pair(&BB, blockIndex));

    // check if this block is used, callonly, or empty
    bool isBlockUsed = false;
    bool isBlockContainInternalCall = false;
    for (llvm::Instruction& I : BB) {
      llvm::Instruction* instr = &I;
      if (instr->isTerminator()) {
        // check if this is a return or invoke
        // if this is a return returning a non-placeholder pointer value, we consider the block as used
        // if this is an invoke, we also consider it as used
        // if this is a switch or branch, we need to peek the successor blocks
        // if any successor block contains a PHI that is value-dependent on this block, we also consider this block as used
        if (llvm::ReturnInst* ret = llvm::dyn_cast<llvm::ReturnInst>(instr)) {
          if (llvm::Value* retval = ret->getReturnValue()) {
            if (retval->getType()->isPointerTy()) {
              if (!step2_pruning_isPlaceholderCall(retval))
                isBlockUsed = true;
            }
          }
        } else if (llvm::isa<llvm::InvokeInst>(instr)) {
          isBlockUsed = true;
        } else {
          auto checkSuccessor = [&](llvm::BasicBlock* succ) -> bool {
            // return true if the successor block contains a PHI with an incoming edge from this block
            for (llvm::Instruction& I : *succ) {
              llvm::PHINode* phi = llvm::dyn_cast<llvm::PHINode>(&I);
              if (!phi) {
                return false;
              }
              if (phi->getBasicBlockIndex(&BB) >= 0)
                return true;
            }
            return false;
          };
          if (llvm::BranchInst* branch = llvm::dyn_cast<llvm::BranchInst>(instr)) {
            for (unsigned i = 0, n = branch->getNumSuccessors(); i < n; ++i) {
              if (checkSuccessor(branch->getSuccessor(i))) {
                isBlockUsed = true;
                break;
              }
            }
          } else if (llvm::SwitchInst* sw = llvm::dyn_cast<llvm::SwitchInst>(instr)) {
            for (unsigned i = 0, n = sw->getNumSuccessors(); i < n; ++i) {
              if (checkSuccessor(sw->getSuccessor(i))) {
                isBlockUsed = true;
                break;
              }
            }
          }
        }
      } else {
        // this is not a terminator
        if (llvm::CallInst* call = llvm::dyn_cast<llvm::CallInst>(instr)) {
          // skip placeholder calls
          if (step2_pruning_isPlaceholderCall(instr))
            continue;
          // check if this is a call to internally defined function
          // if yes then set the isBlockContainInternalCall flag
          if (llvm::Function* callee = call->getCalledFunction()) {
            if (!callee->getBasicBlockList().empty()) {
              isBlockContainInternalCall = true;
              continue;
            }
          }
        }
        // if we reach here, this is some other instructions we should not touch
        // we can early exit now
        isBlockUsed = true;
        break;
      }
    }
    // now all instructions are visited; set the block states
    if (isBlockUsed) {
      state.usedblocks.set(blockIndex);
      numUsedBlocks += 1;
    } else if (isBlockContainInternalCall) {
      state.callonly_blocks.set(blockIndex);
      numCallonlyBlocks += 1;
    }
    ++blockIndex;
  }
  state.numCallonlyBlocks = numCallonlyBlocks;
  state.numUsedBlocks = numUsedBlocks;
  state.isFunctionDead = !((numCallonlyBlocks > 0) || (numUsedBlocks > 0));
  static DumpEventDecl<llvm::StringRef, std::size_t, std::size_t> BlockStateEvent([](llvm::raw_ostream& os, const EventData<llvm::StringRef, std::size_t, std::size_t> data) {
    os << "Function " << data.get<0>() << ": " << data.get<1>() << " callonly, " << data.get<2>() << " used blocks\n";
  });
  PSAN_DEBUG(BlockStateEvent(func->getName(), numCallonlyBlocks, numUsedBlocks));
}

namespace {

class CFGSimplifyHelper {
  // we use the Tarjan's strongly connected components algorithm adapted to also record the visited nodes:
  // 1. Whenever we found an edge from used block to empty block, we run the algorithm on the empty block to get:
  //    (a) the SCC where the empty block is in
  //    (b) the set of used blocks reachable from the empty block
  //   The result (b) can be applied to any empty block in (a)
  // 2. We cache the mapping from empty block to set of equivalent (used) blolcks
  //    For each used blocks, we check whether the outgoing edges need modification; do the modification if needed
  // reference: https://en.wikipedia.org/wiki/Tarjan%27s_strongly_connected_components_algorithm
public:
  CFGSimplifyHelper(llvm::Function* func, PSan::FunctionCFGPruneState& state) : func(func), state(state) {
    (void) this->func;
    data.resize(state.usedblocks.size(), BlockState());
  }

  void strongConnect(unsigned startBlock) {
    auto& blkdata = data[startBlock];
    blkdata.index = currentIndex;
    blkdata.lowlink = currentIndex;
    ++currentIndex;
    stack.push_back(startBlock);
    blkdata.onStack = true;

    llvm::BasicBlock* block = state.blockList[startBlock];
    llvm::Instruction* terminator = block->getTerminator();
    auto handleSuccessor = [&](llvm::BasicBlock* succ) -> void {
      unsigned succIndex = state.blockIndexMap.find(succ)->second;

      // if this is an used block, we treat it as having no outgoing edges
      if (state.usedblocks.test(succIndex)) {
        resultSet.insert(succIndex);
        return;
      }


      auto& succData = data[succIndex];
      if (succData.index == 0) {
        strongConnect(succIndex);
        if (blkdata.lowlink > succData.lowlink) {
          blkdata.lowlink = succData.lowlink;
        }
      } else if (succData.onStack) {
        if (blkdata.lowlink > succData.index) {
          blkdata.lowlink = succData.index;
        }
      }
    };
    if (llvm::isa<llvm::UnreachableInst>(terminator)) {
      // do nothing
    } else if (llvm::BranchInst* branch = llvm::dyn_cast<llvm::BranchInst>(terminator)) {
      for (unsigned i = 0, n = branch->getNumSuccessors(); i < n; ++i) {
        handleSuccessor(branch->getSuccessor(i));
      }
    } else if (llvm::SwitchInst* sw = llvm::dyn_cast<llvm::SwitchInst>(terminator)) {
      for (unsigned i = 0, n = sw->getNumSuccessors(); i < n; ++i) {
        handleSuccessor(sw->getSuccessor(i));
      }
    }
    if (blkdata.lowlink == blkdata.index) {
      llvm::SmallVector<unsigned> scc;
      bool isRequestBlockInside = false;
      while (!stack.empty()) {
        unsigned itemIndex = stack.back();
        stack.pop_back();
        auto& itemData = data[itemIndex];
        itemData.onStack = false;
        if (itemIndex == requestNode) {
          isRequestBlockInside = true;
        }
        scc.push_back(itemIndex);
        if (itemIndex == startBlock)
          break;
      }
      if (isRequestBlockInside) {
        if (!sccWithRequestNode.empty()) {
          static DumpEventDecl<llvm::SmallVector<unsigned>, const char*> dumpVecEvent([](llvm::raw_ostream& os, const EventData<llvm::SmallVector<unsigned>, const char*>& data) {
            os << data.get<1>() << ":" << data.get<0>() << "\n";
          });
          dumpVecEvent(sccWithRequestNode, "sccWithRequestNode");
          dumpVecEvent(scc, "scc");
          static DumpEventDecl<unsigned> RequestEvent([](llvm::raw_ostream& os, const EventData<unsigned>& data) {
            os << "request on: " << data.get<0>() << "\n";
          });
          RequestEvent(requestNode);
          psan_unreachable("More than one SCC containing the start node?");
        }
        scc.swap(sccWithRequestNode);
      }
    }
  }
  void populateEmptyToUsedSuccessors(unsigned emptyBlockIndex, llvm::SmallVector<unsigned>& successors) {
    auto iter = emptyToUsedDestBlocks.find(emptyBlockIndex);
    if (iter != emptyToUsedDestBlocks.end()) {
      successors.append(iter->second);
      return;
    }
    if (!isClear) {
      data.clear();
      data.resize(state.usedblocks.size(), BlockState());
      stack.clear();
      resultSet.clear();
      sccWithRequestNode.clear();
    }
    isClear = false;
    currentIndex = 1;
    requestNode = emptyBlockIndex;
    strongConnect(emptyBlockIndex);
    // write back results
    llvm::SmallVector<unsigned> results(resultSet.begin(), resultSet.end());
    emptyToUsedDestBlocks[emptyBlockIndex].assign(results);
    if (!sccWithRequestNode.empty()) {
      for (unsigned sccBlock : sccWithRequestNode) {
        if (sccBlock == emptyBlockIndex)
          continue;
        if (emptyToUsedDestBlocks.count(sccBlock) > 0) {
          psan_unreachable("Overwriting SCC value?");
        }
        emptyToUsedDestBlocks[sccBlock].assign(results);
      }
    }
    successors.append(results);
  }
private:
  struct BlockState {
    unsigned index = 0; // since we
    unsigned lowlink = 0;
    bool onStack = false;
  };
  llvm::Function* func;
  PSan::FunctionCFGPruneState& state;
  llvm::DenseMap<unsigned, llvm::SmallVector<unsigned>> emptyToUsedDestBlocks;
  llvm::SmallVector<BlockState> data;
  llvm::SmallVector<unsigned> stack;
  llvm::SmallSet<unsigned, 4> resultSet;
  llvm::SmallVector<unsigned> sccWithRequestNode;
  unsigned requestNode = 0;
  unsigned currentIndex = 0;
  bool isClear = true;
};

class TDCEGuard {
  // ensure trivial DCE executed when destructing object
public:
  explicit TDCEGuard(llvm::BasicBlock* entryBlock):entryBlock(entryBlock){}
  ~TDCEGuard(){PSan::step2_pruning_trivialDCE(entryBlock);}
private:
  llvm::BasicBlock* entryBlock;
};

} // end anonymous namespace

void PSan::step2_pruning_cleanup(llvm::Function* func, FunctionCFGPruneState& state, PlaceholderFunctionManager& placeholders)
{
  // previously we only remove calls to dead functions
  // this is the place we actually remove dead functions, blocks, etc
  // for surviving blocks, we also need to redirect the branch targets
  if (state.isFunctionDead) {
    // if the function is still used (maybe it is address-taken), we clear the body
    // otherwise, we remove this function altogether
    if (func->use_empty()) {
      static DumpEventDecl<llvm::StringRef> RemoveEvent([](llvm::raw_ostream& os, const EventData<llvm::StringRef> data) {
        os << "Removing function " << data.get<0>() << "\n";
      });
      PSAN_DEBUG(RemoveEvent(func->getName()));
      func->eraseFromParent();
    } else {
      static DumpEventDecl<llvm::StringRef> KeepEvent([](llvm::raw_ostream& os, const EventData<llvm::StringRef> data) {
        os << "Function " << data.get<0>() << " not removed because of dangling use\n";
      });
      PSAN_DEBUG(KeepEvent(func->getName()));
      for (auto& U : func->uses()) {
        static DumpEventDecl<llvm::Value*> DanglingUseEvent([](llvm::raw_ostream& os, const EventData<llvm::Value*> data) {
          os << "  Dangling use: " << data.get<0>() << "\n";
        });
        PSAN_DEBUG(DanglingUseEvent(U.getUser()));
      }
      // clear the body
      // we remove all basic blocks except the first one, and we just return undef
      // first, go over all blocks and let them drop references
      for (llvm::BasicBlock& BB : func->getBasicBlockList()) {
        BB.dropAllReferences();
      }
      // then, erase all the blocks except the entry block
      llvm::BasicBlock* entryBlock = &func->getEntryBlock();
      for (auto iter = func->getBasicBlockList().begin(); iter != func->getBasicBlockList().end();) {
        llvm::BasicBlock* curBlock = &*iter;
        ++iter;
        if (curBlock == entryBlock) {
          continue;
        }
        curBlock->eraseFromParent();
      }
      auto& instrList = entryBlock->getInstList();
      while (instrList.begin() != instrList.end()) {
        instrList.begin()->eraseFromParent();
      }
      entryBlock->getInstList().clear();
      llvm::Type* retTy = func->getReturnType();
      if (retTy->isVoidTy()) {
        llvm::ReturnInst::Create(func->getContext(), entryBlock);
      } else {
        llvm::ReturnInst::Create(func->getContext(), llvm::UndefValue::get(retTy), entryBlock);
      }
    }
    // done with the dead function case
    return;
  }
  static DumpEventDecl<llvm::StringRef> AliveEvent([](llvm::raw_ostream& os, const EventData<llvm::StringRef> data) {
    os << "Function " << data.get<0>() << " is still alive\n";
  });
  PSAN_DEBUG(AliveEvent(func->getName()));

  // make sure Trivial DCE on the entry block is executed after pruning
  // in this way we can reap as many dead placeholders as possible
  TDCEGuard g(&func->getEntryBlock());

  if (getS2PrunePolicy() == S2PrunePolicy::P2) {
    return;
  }

  // convert all callonly blocks to used blocks
  state.usedblocks |= state.callonly_blocks;

  // before running the algorithm, make sure that the entry blocks and returning blocks are left unmodified
  if (state.blockIndexMap.find(&func->getEntryBlock())->second != 0) {
    psan_unreachable("Entry block having non-zero index");
  }
  state.usedblocks.set(0);
  for (int i = state.usedblocks.find_first_unset(); i >= 0; i = state.usedblocks.find_next_unset(i)) {
    llvm::BasicBlock* block = state.blockList[i];
    if (llvm::isa<llvm::ReturnInst>(block->getTerminator())) {
      state.usedblocks.set(i);
    }
  }

  // skip if no block to remove at all
  if (state.usedblocks.all()) {
    return;
  }

  // start to redirect empty blocks
  // step 1: for each empty block, compute the set of used blocks that "jump to current empty block" should be equivalent to "jump to any of these blocks"
  // we also update all affected outgoing edges from used blocks

  // states for algorithm
  CFGSimplifyHelper helper(func, state);

  // for creating dummy conditional branches and switches
  llvm::IntegerType* i1Ty = llvm::IntegerType::get(func->getContext(), 1);
  llvm::IntegerType* i32Ty = llvm::IntegerType::get(func->getContext(), 32);
  llvm::Value* dummycond = nullptr;
  auto getDummyCond = [&]() -> llvm::Value* {
    if (!dummycond)
      dummycond = placeholders.getPlaceholderValue(func, i1Ty);
    return dummycond;
  };
  llvm::Value* dummySwitchIndex = nullptr;
  auto getDummySwitchIndex = [&]() -> llvm::Value* {
    if (!dummySwitchIndex)
      dummySwitchIndex = placeholders.getPlaceholderValue(func, i32Ty);
    return dummySwitchIndex;
  };
  // iterate over all used blocks to check / replace outgoing edges
  for (int i = state.usedblocks.find_first(); i >= 0; i = state.usedblocks.find_next(i)) {
    llvm::BasicBlock* bb = state.blockList[i];
    llvm::Instruction* terminator = bb->getTerminator();
    if (llvm::isa<llvm::UnreachableInst>(terminator)
      || llvm::isa<llvm::ReturnInst>(terminator)) {
      // we don't need to correct the successor blocks for these terminators
      continue;
    }
    // when we replace switch instructions, if we have edges to another used block,
    // we need to preserve the number of edges (we may have duplicated edge to the same block)
    // so if we find an outgoing edge to a used block, we also track the edge count to the same block
    llvm::SmallVector<unsigned> newSuccessors;
    llvm::DenseMap<unsigned, unsigned> usedEdgeCounts;
    unsigned additionalEdgeCount = 0;
    bool isModified = false;
    auto addOutgoingEdge = [&](llvm::BasicBlock* successor) -> void {
      unsigned index = state.blockIndexMap.find(successor)->second;
      if (state.usedblocks.test(index)) {
        // jumping to a used block; pass through
        newSuccessors.push_back(index);
        auto iter = usedEdgeCounts.find(index);
        if (iter == usedEdgeCounts.end()) {
          usedEdgeCounts.insert(std::make_pair(index, 1));
        } else {
          iter->second += 1;
          additionalEdgeCount += 1;
        }
      } else {
        // jumping to an empty block; need to change the terminator
        isModified = true;
        helper.populateEmptyToUsedSuccessors(index, newSuccessors);
      }
    };
    if (llvm::BranchInst* branch = llvm::dyn_cast<llvm::BranchInst>(terminator)) {
      for (unsigned succIndex = 0, numSucc = branch->getNumSuccessors(); succIndex < numSucc; ++succIndex) {
        llvm::BasicBlock* succ = branch->getSuccessor(succIndex);
        addOutgoingEdge(succ);
      }
    } else if (llvm::SwitchInst* sw = llvm::dyn_cast<llvm::SwitchInst>(terminator)) {
      for (unsigned succIndex = 0, numSucc = sw->getNumSuccessors(); succIndex < numSucc; ++succIndex) {
        llvm::BasicBlock* succ = sw->getSuccessor(succIndex);
        addOutgoingEdge(succ);
      }
    } else {
      psan_unreachable("Unexpected terminator type");
    }
    if (isModified) {
      // need to update the terminator
      // first, sort and remove duplicates in the successors
      if (newSuccessors.size() > 1) {
        std::sort(newSuccessors.begin(), newSuccessors.end());
        auto end = std::unique(newSuccessors.begin(), newSuccessors.end());
        if (end != newSuccessors.end()) {
          newSuccessors.erase(end, newSuccessors.end());
        }
      }
      // then, remove the old terminator
      terminator->eraseFromParent();
      // lastly, create the new terminator
      if (additionalEdgeCount > 0 || newSuccessors.size() > 2) {
        // first, add the additional edges to new successors
        if (additionalEdgeCount > 0) {
          for (const auto& p : usedEdgeCounts) {
            if (p.second > 1) {
              newSuccessors.append(p.second-1, p.first);
            }
          }
        }
        llvm::SwitchInst* sw = llvm::SwitchInst::Create(getDummySwitchIndex(), state.blockList[newSuccessors.front()], newSuccessors.size()-1, bb);
        for (unsigned i = 1, n = newSuccessors.size(); i < n; ++i) {
          sw->addCase(llvm::ConstantInt::get(i32Ty, i, false), state.blockList[newSuccessors[i]]);
        }
      } else {
        switch (newSuccessors.size())
        {
        case 0:
          new llvm::UnreachableInst(func->getContext(), bb);
          break;
        case 1:
          llvm::BranchInst::Create(state.blockList[newSuccessors.front()], bb);
          break;
        case 2: {
          llvm::BranchInst::Create(state.blockList[newSuccessors.front()], state.blockList[newSuccessors.back()], getDummyCond(), bb);
        } break;
        default: psan_unreachable("Should not execute");
        }
      }
    }
  }

  // step 2: drop all the now-empty blocks
  // first drop all the terminators, then the blocks
  for (int i = state.usedblocks.find_first_unset(); i >= 0; i = state.usedblocks.find_next_unset(i)) {
    llvm::BasicBlock* block = state.blockList[i];
    block->dropAllReferences();
  }
  for (int i = state.usedblocks.find_first_unset(); i >= 0; i = state.usedblocks.find_next_unset(i)) {
    llvm::BasicBlock* block = state.blockList[i];
    if (!block->use_empty()) {
      psan_unreachable("Empty block still in use");
      // the line below would not work
      // block->replaceAllUsesWith(llvm::UndefValue::get(block->getType()));
    }
    block->eraseFromParent();
  }
  // done
}

void PSan::step2_pruning_entry(llvm::Module* dstModule, PreTransformResult& decisions, llvm::ValueToValueMapTy& mapping, llvm::DenseMap<llvm::Value*,llvm::Value*>& taintedClones, StaticStats& stats, PlaceholderFunctionManager& placeholders)
{
  if (getS2PrunePolicy() == S2PrunePolicy::P0) {
    return;
  }
  // first, cleanup some trivially dead instructions and build CFG info
  // we also record functions that are dead (no need to keep them at all) here in hope to remove more functions and blocks
  llvm::DenseMap<llvm::Function*, FunctionCFGPruneState> functionStates;
  SVF::FIFOWorkList<llvm::Function*> deadFunctionsWorklist;

  for (llvm::Function& F : dstModule->functions()) {
    if (F.getBasicBlockList().empty())
      continue;
    auto res = functionStates.insert(std::make_pair(&F, FunctionCFGPruneState()));
    if (!res.second) {
      psan_unreachable("Function state init failure");
    }
    // we drop functions without users (dead code)
    // functions whose addr is tainted are assumed to have callers
    if (F.use_empty() && (taintedClones.count(&F) == 0) && !step2_pruning_isFunctionHaveHiddenCalls(decisions.functionsWithHiddenCalls, &F)) {
      static DumpEventDecl<llvm::StringRef> DeadEvent([](llvm::raw_ostream& os, const EventData<llvm::StringRef> data) {
        os << "Function " << data.get<0>() << " dead early\n";
      });
      PSAN_DEBUG(DeadEvent(F.getName()));
      deadFunctionsWorklist.push(&F);
      res.first->second.isFunctionDead = true;
      continue;
    }
    step2_pruning_trivialDCE(&F);
    step2_pruning_buildFunctionInfo(&F, res.first->second);
    if (res.first->second.isFunctionDead) {
      static DumpEventDecl<llvm::StringRef> DeadEvent([](llvm::raw_ostream& os, const EventData<llvm::StringRef> data) {
        os << "Function " << data.get<0>() << " dead after building info\n";
      });
      PSAN_DEBUG(DeadEvent(F.getName()));
      deadFunctionsWorklist.push(&F);
    }
  }
  if (getS2PrunePolicy() == S2PrunePolicy::P1) {
    return;
  }

  // now we keep removing calls to functions in deadFunctionsWorklist and try to identify more blocks and functions that would be empty
  while (!deadFunctionsWorklist.empty()) {
    llvm::Function* func = deadFunctionsWorklist.pop();
    for (auto iter = func->use_begin(); iter != func->use_end();) {
      llvm::Use* u = &*iter;
      ++iter;
      llvm::CallBase* call = llvm::dyn_cast<llvm::CallBase>(u->getUser());
      if (!call)
        continue;
      if (call->isTerminator()) {
        psan_unreachable("Call as terminator is not supported yet");
      }
      if (call->isArgOperand(u)) {
        // keep it
        continue;
      }
      if (call->getCalledFunction() != func) {
        psan_unreachable("sanity check failed");
      }
      llvm::BasicBlock* parentBB = call->getParent();
      llvm::Function* caller = call->getFunction();
      if (!call->use_empty()) {
        if (!isNoDebugPrint()) {
          static DumpEventDecl<llvm::StringRef, llvm::Value*> CallStillInUseEvent([](llvm::raw_ostream& os, const EventData<llvm::StringRef, llvm::Value*>& data) {
            os << "Call still in use: in " << data.get<0>() << ": " << data.get<1>() << "\nUsers:\n";
          });
          PSAN_DEBUG(CallStillInUseEvent(caller->getName(), call));
          for (auto& u : call->uses()) {
            static DumpEventDecl<llvm::Value*> UserEvent([](llvm::raw_ostream& os, const EventData<llvm::Value*> data) {
              os << "  " << data.get<0>() << "\n";
            });
            PSAN_DEBUG(UserEvent(u.getUser()));
          }
        }
        psan_unreachable("Call value still in use");
      }
      call->eraseFromParent();
      // check if this block becomes empty
      auto iterCallerInfo = functionStates.find(caller);
      if (iterCallerInfo == functionStates.end()) {
        psan_unreachable("sanity check failed");
      }
      auto& callerState = iterCallerInfo->second;
      // skip functions that are already dead (e.g., no caller)
      // they may not have the blockIndexMap populated
      if (callerState.isFunctionDead) {
        continue;
      }
      unsigned parentBlockIndex = callerState.blockIndexMap.find(parentBB)->second;
      if (callerState.usedblocks.test(parentBlockIndex)) {
        // do nothing
      } else if (callerState.callonly_blocks.test(parentBlockIndex)) {
        // check if there is any other instructions left
        // if there is only a terminator left, mark it as empty
        if (parentBB->getInstList().front().isTerminator()) {
          callerState.callonly_blocks.flip(parentBlockIndex);
          callerState.numCallonlyBlocks -= 1;
          // if the caller becomes empty, enqueue it
          if (callerState.numCallonlyBlocks == 0 && callerState.numUsedBlocks == 0) {
            static DumpEventDecl<llvm::StringRef> CallerDeadEvent([](llvm::raw_ostream& os, const EventData<llvm::StringRef> data) {
              os << "Function " << data.get<0>() << " dead after removing call\n";
            });
            PSAN_DEBUG(CallerDeadEvent(caller->getName()));
            callerState.isFunctionDead = true;
            deadFunctionsWorklist.push(caller);
          }
        }
      } else {
        psan_unreachable("Removing a call from an empty block???");
      }
    }
  }

  // finally, go through all functions and prune basic blocks or the entire function
  for (auto iterFunc = dstModule->begin(); iterFunc!= dstModule->end();) {
    llvm::Function* func = &*iterFunc;
    ++iterFunc;
    if (func->getBasicBlockList().empty())
      continue;
    auto iter = functionStates.find(func);
    if (iter == functionStates.end()) {
      psan_unreachable("Missing function state");
    }
    step2_pruning_cleanup(func, iter->second, placeholders);
  }

  // before we finish, do a sanity check on the pruned IR
  // we should not have load/store/gep taking placeholder pointers
  if (!isNoDebugPrint()) {
    auto isPlaceholder = [](llvm::Value* v) -> bool {
      llvm::CallInst* call = llvm::dyn_cast<llvm::CallInst>(v);
      if (!call)
        return false;
      if (llvm::Function* callee = call->getCalledFunction()) {
        if (callee->getName().startswith(PSAN_PLACEHOLDER_NAME_PREFIX))
          return true;
      }
      return false;
    };
    for (auto iterFunc = dstModule->begin(); iterFunc!= dstModule->end();) {
      llvm::Function* func = &*iterFunc;
      ++iterFunc;
      if (func->getBasicBlockList().empty())
        continue;
      for (auto& BB : func->getBasicBlockList()) {
        for (auto& I : BB) {
          if (llvm::GetElementPtrInst* gep = llvm::dyn_cast<llvm::GetElementPtrInst>(&I)) {
            if (isPlaceholder(gep->getPointerOperand())) {
              psan_unreachable("Placeholder as GEP pointer operand");
            }
          } else if (llvm::LoadInst* load = llvm::dyn_cast<llvm::LoadInst>(&I)) {
            if (isPlaceholder(load->getPointerOperand())) {
              psan_unreachable("Placeholder as load pointer operand");
            }
          } else if (llvm::StoreInst* store = llvm::dyn_cast<llvm::StoreInst>(&I)) {
            if (isPlaceholder(store->getPointerOperand())) {
              psan_unreachable("Placeholder as store pointer operand");
            }
          }
        }
      }
    }
  }

  // go through all the placeholder functions and drop the now-unused ones
  for (auto iterFunc = dstModule->begin(); iterFunc!= dstModule->end();) {
    llvm::Function* func = &*iterFunc;
    ++iterFunc;
    if (!func->use_empty())
      continue;
    if (!func->getBasicBlockList().empty())
      continue;
    if (func->getName().startswith(PSAN_PLACEHOLDER_NAME_PREFIX)) {
      func->eraseFromParent();
    }
  }
}