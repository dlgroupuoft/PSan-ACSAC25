//===- wpa.cpp -- Whole program analysis -------------------------------------//
//
//                     SVF: Static Value-Flow Analysis
//
// Copyright (C) <2013-2017>  <Yulei Sui>
//

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.

// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//===-----------------------------------------------------------------------===//

/*
 // Whole Program Pointer Analysis
 //
 // Author: Yulei Sui,
 */

#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/Verifier.h"
#include "llvm/IRReader/IRReader.h"
#include <system_error>
#include <chrono>
#include <memory>
#include <algorithm>

#include "SVF-LLVM/LLVMUtil.h"
#include "SVF-LLVM/SVFIRBuilder.h"
#include "WPA/WPAPass.h"
#include "Util/CommandLine.h"
#include "Util/Options.h"
#include "psan.h"
#include "PPD/PSanPrintDebugger.h"
#include "FastDebugDumper.h"
#include "Instrumentation/MemoryUsageEvaluationInstrumenter.h"
#include "Instrumentation/MinimalSpatialSafetyInstrumenter.h"
#include "Instrumentation/MinimalTemporalSafetyInstrumenter.h"

using namespace llvm;
using namespace std;
using namespace SVF;
using namespace SVF::SVFUtil;
using namespace PSan;

static llvm::cl::opt<std::string> InputFilename(
  llvm::cl::Positional,
  llvm::cl::value_desc("<input IR file>")
);

static llvm::cl::opt<std::string> OutputFilename(
  "o",
  llvm::cl::desc("Specify output LLVM bitcode file"),
  llvm::cl::init("<auto>"),
  llvm::cl::value_desc("output")
);

static llvm::cl::opt<std::string> DumpNamePrefix(
  "psan-dump-name-prefix",
  llvm::cl::init("<auto>"),
  llvm::cl::desc("Override the name prefix for debug outputs (Graphviz DOT drawings, etc)")
);

static llvm::cl::opt<bool> DisableDumpOption(
  "psan-no-dump",
  llvm::cl::init(false),
  llvm::cl::desc("Disable all debug dumps")
);

static llvm::cl::opt<bool> DumpGraphsOption(
  "psan-dump-graphs",
  llvm::cl::init(false),
  llvm::cl::desc("Enable graph dump (SLOW for large programs)")
);

static llvm::cl::opt<bool> NoDebugOption(
  "psan-no-debug",
  llvm::cl::init(false),
  llvm::cl::desc("Disable all debug prints and valiations")
);

static llvm::cl::opt<std::string> DebugPrintFilenameOption(
  "psan-debug-print-filename",
  llvm::cl::init("psan_debug_prints.txt"),
  llvm::cl::desc("Specify the filename for debug prints")
);

static llvm::cl::opt<bool> NoStaticStatOption(
  "psan-no-static-stat",
  llvm::cl::init(false),
  llvm::cl::desc("Disable all static stats collection")
);

static llvm::cl::opt<bool> CollectRuntimeStatOption(
  "psan-collect-runtime-stat",
  llvm::cl::init(false),
  llvm::cl::desc("Enable runtime stats collection")
);

// to make it a standalone tool, the instrumentation will use the library functions but not link in the library
// we need to link in the runtime library separately after all the instrumentation is done
static llvm::cl::opt<bool> EnableRuntimePrintDebugOption(
  "psan-rt-print-debug",
  llvm::cl::init(false),
  llvm::cl::desc("Enable runtime debug prints")
);

static llvm::cl::opt<bool> EnableRuntimeMDStoreCheckDebugOption(
  "psan-rt-mdstorecheck-debug",
  llvm::cl::init(false),
  llvm::cl::desc("Enable checking pointer metadata at metadata store (for debugging)")
);

static llvm::cl::opt<bool> StopAfterPretransformOption(
  "psan-stop-after-pretransform",
  llvm::cl::init(false),
  llvm::cl::desc("Stop after pretransform (to get reference program for print debugging)")
);

static llvm::cl::opt<bool> DisableEPTGOption(
  "psan-disable-eptg",
  llvm::cl::init(false),
  llvm::cl::desc("Disable EPTG-based transform (Only use out-of-band metadata scheme)")
);

static llvm::cl::opt<bool> EnableExpensiveVerificationOption(
  "psan-enable-expensive-verification",
  llvm::cl::init(false),
  llvm::cl::desc("Enable expensive verification checks (SLOW!!! for developer debugging only)")
);

static llvm::cl::opt<bool> EnableConservativeOOB(
  "psan-enable-conservative-oob",
  llvm::cl::init(false),
  llvm::cl::desc("Enable conservative out-of-band metadata scheme (verify pointer on metadata load)")
);

static llvm::cl::opt<bool> UseNoopCheckOption(
  "psan-noop-check",
  llvm::cl::init(false),
  llvm::cl::desc("Use no-op checks instead of real checks; useful for evaluating metadata overhead")
);

static llvm::cl::opt<bool> VerifyOutputOption(
  "psan-verify-output",
  llvm::cl::init(false),
  llvm::cl::desc("Verify output file after writing it")
);

enum PtrToIntPolicyImpl {
  conservative, aggressive, automatic
};

static llvm::cl::opt<PtrToIntPolicyImpl> PtrToIntPolicyOption(
  llvm::cl::init(PtrToIntPolicyImpl::automatic),
  llvm::cl::desc("Choose policy for ptrtoint instruction"),
  llvm::cl::values(
    clEnumVal(conservative, "any ptrtoint makes the pointer escape and assigned to the opaque region"),
    clEnumVal(aggressive, "all ptrtoint is assumed not to cast back to pointers"),
    clEnumVal(automatic, "use conservative strategy if inttoptr is found, and use aggressive policy otherwise")
  )
);

enum S2PrunePolicyImpl {
  P0, P1, P2, P3
};

static llvm::cl::opt<S2PrunePolicyImpl> S2PrunePolicyOption(
  llvm::cl::init(S2PrunePolicyImpl::P2),
  llvm::cl::desc("Choose policy for code pruning before SVFG construction"),
  llvm::cl::values(
    clEnumVal(P0, "disable all pruning"),
    clEnumVal(P1, "prune with trivial Dead-Code Elimination"),
    clEnumVal(P2, "remove empty functions in addition to P1"),
    clEnumVal(P3, "remove empty basic blocks in addition to P2")
  )
);

bool PSan::isNoDebugPrint() {
  return NoDebugOption;
}

PtrToIntPolicy PSan::getPtrToIntPolicy()
{
  switch (PtrToIntPolicyOption)
  {
  case PtrToIntPolicyImpl::conservative:  return PtrToIntPolicy::CONSERVATIVE;
  case PtrToIntPolicyImpl::aggressive:    return PtrToIntPolicy::AGGRESSIVE;
  case PtrToIntPolicyImpl::automatic:     return PtrToIntPolicy::AUTO;
  }
  psan_unreachable("unexpected option value");
}

S2PrunePolicy PSan::getS2PrunePolicy()
{
  switch (S2PrunePolicyOption)
  {
  case S2PrunePolicyImpl::P0: return S2PrunePolicy::P0;
  case S2PrunePolicyImpl::P1: return S2PrunePolicy::P1;
  case S2PrunePolicyImpl::P2: return S2PrunePolicy::P2;
  case S2PrunePolicyImpl::P3: return S2PrunePolicy::P3;
  }
  psan_unreachable("unexpected option value");
}

std::unique_ptr<llvm::raw_fd_ostream> debugDumpOS;
llvm::raw_ostream& PSan::outs() {
  if (debugDumpOS.get()) {
    return *debugDumpOS.get();
  }
  return llvm::outs();
}
llvm::raw_ostream& PSan::errs() {
  return llvm::errs();
}

void PSan::flush_debug_outs()
{
  FastDebugDumper::flush();
  if (debugDumpOS.get()) {
    debugDumpOS->flush();
  } else {
    llvm::outs().flush();
    llvm::errs().flush();
  }
}

bool PSan::isNoStaticStats() {
  return NoStaticStatOption;
}

bool PSan::isCollectRuntimeStats() {
  return CollectRuntimeStatOption;
}

bool PSan::isEnableRuntimePrintDebug() {
  return EnableRuntimePrintDebugOption;
}

bool PSan::isEnableRuntimeMDStoreCheckDebug() {
  return EnableRuntimeMDStoreCheckDebugOption;
}

bool PSan::isConservativeOOB() {
  return EnableConservativeOOB;
}

bool PSan::isDisableEPTG() {
  return DisableEPTGOption;
}

bool PSan::isEnableExpensiveVerification() {
  return EnableExpensiveVerificationOption;
}

bool PSan::isNoopCheck() {
  return UseNoopCheckOption;
}

namespace {
void psan_verifyModule(const llvm::Module& module, const char* stage)
{
  std::string buf;
  bool isValidationFailed = false;
  {
    llvm::raw_string_ostream os(buf);
    isValidationFailed = llvm::verifyModule(module, &os);
  }
  if (isValidationFailed) {
    FastDebugDumper::flush();
    PSan::outs() << stage << " validation failed:\n";
    PSan::outs() << buf;
    psan_unreachable("IR validation failed");
  }
}
void dump_ir(llvm::Module* m, llvm::Twine name, const char* stage) {
  llvm::SmallVector<char> nameString;
  llvm::StringRef dumpNameRef = name.toStringRef(nameString);
  if (!DisableDumpOption) {
    FastDebugDumper::write_parallel_hint();
    std::error_code ec;
    llvm::raw_fd_ostream os(dumpNameRef, ec);
    if (!ec) {
      m->print(os, nullptr, false, true);
    } else {
      PSan::errs() << "Error " << ec.value() << " when opening " << dumpNameRef << ": " << ec.message() << "\n";
    }
    FastDebugDumper::flush();
    PSan::outs() << "IR dumped: " << dumpNameRef << "\n";
  }
  if (!NoDebugOption) {
    psan_verifyModule(*m, stage);
  }
}
__attribute__((unused))
void writeOutput(llvm::Module* m, llvm::StringRef name) {
  std::error_code ec;
  llvm::raw_fd_ostream os(name, ec);
  if (!ec) {
    FastDebugDumper::write_parallel_hint();
    if (name.endswith_insensitive(".bc")) {
      llvm::WriteBitcodeToFile(*m, os, false);
      FastDebugDumper::flush();
      PSan::outs() << "Bitcode written: " << name << "\n";
    } else {
      m->print(os, nullptr, false, true);
      FastDebugDumper::flush();
      PSan::outs() << "Text IR written: " << name << "\n";
    }
  } else {
    PSan::errs() << "Error " << ec.value() << " when opening " << name << ": " << ec.message() << "\n";
    exit(1);
  }
  if (!NoDebugOption) {
    psan_verifyModule(*m, "final");
  }
}
llvm::StringRef dumpNamePrefix;

struct AddInstrumenterHelper {
  llvm::LLVMContext& ctx;
  llvm::Module& srcModuleRef;
  PSan::InstrumentationListType& instrumentations;
  llvm::DenseMap<std::size_t, std::size_t>& instrumentID2GlobalInstrumentationID;
  llvm::SmallVector<std::string>& instrumentationNames;
  AddInstrumenterHelper(llvm::LLVMContext& ctx, llvm::Module& srcModuleRef, PSan::InstrumentationListType& instrumentations, llvm::DenseMap<std::size_t, std::size_t>& instrumentID2GlobalInstrumentationID, llvm::SmallVector<std::string>& instrumentationNames)
    : ctx(ctx), srcModuleRef(srcModuleRef), instrumentations(instrumentations), instrumentID2GlobalInstrumentationID(instrumentID2GlobalInstrumentationID), instrumentationNames(instrumentationNames) {}

  template<typename Instrumenter>
  void addInstrumenter(const char* name) {
    std::size_t globalIndex = instrumentationNames.size();
    instrumentationNames.push_back(name);
    if (Instrumenter::isEnabled()) {
      instrumentID2GlobalInstrumentationID[instrumentations.size()] = globalIndex;
      instrumentations.push_back(new Instrumenter(ctx, srcModuleRef));
    }
  }
};
} // end anonymous namespace

void PSan::dumpIR(llvm::Module* module, const char* stagename)
{
  std::string dumpName = dumpNamePrefix.str() + "_" + stagename + ".ll";
  dump_ir(module, dumpName, stagename);
}

int main(int argc, char** argv)
{
  llvm::cl::ParseCommandLineOptions(argc, argv, "PSAN Instrumenter\n");
  PSanPrintDebugger::unreachableCallBack = PSan::flush_debug_outs;

  std::unique_ptr<llvm::LLVMContext> ctx = std::make_unique<llvm::LLVMContext>();
  std::unique_ptr<llvm::Module> srcModule;
  std::error_code debugec;
  if (!NoDebugOption && !DebugPrintFilenameOption.empty()) {
    debugDumpOS.reset(new llvm::raw_fd_ostream(DebugPrintFilenameOption, debugec));
  }
  StaticStats stats;
  StaticStats::setTime(stats.initTime);
  {
    llvm::SMDiagnostic err;
    srcModule = llvm::parseIRFile(InputFilename, err, *ctx);
    if (!srcModule) {
      SVFUtil::errs() << "load module: " << InputFilename << "failed!!\n\n";
      err.print("SVFModuleLoader", PSan::errs());
      return 1;
    }
  }

  // initialize the list of instrumentations so that if none is selected, we can report the error earlier
  InstrumentationListType instrumentations;
  {
    AddInstrumenterHelper helper(*ctx, *srcModule.get(), instrumentations, stats.instrumentID2GlobalInstrumentationID, stats.instrumentationNames);
    helper.addInstrumenter<MinimalSpatialSafetyInstrumenter>("MinimalSpatialSafety");
    helper.addInstrumenter<MinimalTemporalSafetyInstrumenter>("MinimalTemporalSafety");

    // we are only interested in the stats for instrumentations before this point
    stats.maxGlobalInstrumentIDForRuntimeStats = stats.instrumentationNames.size();

    helper.addInstrumenter<MemoryUsageEvaluationInstrumenter>("MemoryUsageEvaluation");
  }
  stats.S4_RequestedChecks.init(stats.instrumentationNames);
  if (instrumentations.empty()) {
    psan_unreachable("No instrumentation selected");
  }

  dumpNamePrefix = DumpNamePrefix;
  bool isDefaultDumpNamePrefix = (DumpNamePrefix == DumpNamePrefix.getDefault().getValue());
  bool isDefaultOutputFilename = (OutputFilename == OutputFilename.getDefault().getValue());
  if (isDefaultDumpNamePrefix || isDefaultOutputFilename) {
    std::string fileName = InputFilename;
    // get the base name and add "_psan" suffix
    std::size_t lastSlash = fileName.find_last_of("\\/");
    std::size_t startPos = (lastSlash == std::string::npos)? 0 : lastSlash+1;
    std::size_t lastDot = fileName.rfind('.');
    if (lastDot != std::string::npos && lastDot <= startPos) {
      lastDot = std::string::npos;
    }
    std::size_t endPos = (lastDot == std::string::npos)? fileName.length() : lastDot;
    std::string basename = fileName.substr(startPos, endPos - startPos);
    std::replace(basename.begin(), basename.end(), '.', '_');
    basename += "_psan";
    if (isDefaultDumpNamePrefix) {
      // must assign dumpNamePrefix with something having longer lifetime than basename
      DumpNamePrefix = basename;
      dumpNamePrefix = DumpNamePrefix;
    }
    if (isDefaultOutputFilename) {
      OutputFilename = basename + ".ll";
    }
  }

  StaticStats::setTime(stats.loadFinishTime);

  PreTransformResult reduceInfo = step1_pretransform(srcModule.get(), stats);
  dump_ir(srcModule.get(), llvm::Twine(dumpNamePrefix, "_pretransform.ll"), "pretransform");
  StaticStats::setTime(stats.s1_dumpTime);

  if (StopAfterPretransformOption) {
    if (EnableRuntimePrintDebugOption) {
      PSanPrintDebugger ppd(*srcModule.get());
      ppd.init();
      ppd.instrument();
      linkInLibrary(srcModule.get(), PSAN_RTPATH_RT_PSanPrintDebugger);
    }
    writeOutput(srcModule.get(), OutputFilename);
    return 0;
  }

  GraphConstructionResults s3result;
  if (!DisableEPTGOption) {
    llvm::ValueToValueMapTy valueMap;
    llvm::DenseMap<llvm::Value*, llvm::Value*> taintedClones;
    llvm::Module* trimmed = step2_clone(srcModule.get(), reduceInfo, valueMap, taintedClones, stats);
    dump_ir(trimmed, llvm::Twine(dumpNamePrefix, "_trimmed.ll"), "trimming");
    StaticStats::setTime(stats.s2_dumpTime);
    s3result = step3_graph_construction(srcModule.get(), trimmed, valueMap, taintedClones, stats, dumpNamePrefix, !DisableDumpOption && DumpGraphsOption);
  }
  FastDebugDumper::write_parallel_hint();

  auto checkFilter = [&](llvm::Instruction* inst) {
    return reduceInfo.excludeValues.find(inst) == reduceInfo.excludeValues.end();
  };

  for (unsigned i = 0, n = instrumentations.size(); i < n; ++i) {
    InstrumentationBase* inst = instrumentations[i];
    inst->initInstrumentationID(i);
    inst->initInstrumentationFilterCallback(checkFilter);
    if (!DisableEPTGOption) {
      inst->initGraphAnalysisResults(&s3result.src2cloned, &s3result.cloned2src, s3result.svfir, s3result.pta, s3result.svfg, s3result.eptg);
    }
  }

  InstrumentationPlan s4result = step4_analysis(srcModule.get(), s3result, instrumentations, stats);
  FastDebugDumper::write_parallel_hint();
  if (!DisableEPTGOption && !DisableDumpOption && DumpGraphsOption) {
    // overwrite the one created in step 3
    s3result.eptg->dump(dumpNamePrefix.str() + "_eptg");
  }

  // if later on we use the fast dumper in step 5, we remove this flush
  FastDebugDumper::flush();

  InstrumentationOptions options;
  options.isCollectRuntimeStats = isCollectRuntimeStats();
  llvm::Module* instrumented = step5_instrument(srcModule.get(), s3result, instrumentations, options, s4result, stats);

  if (EnableRuntimePrintDebugOption) {
    linkInLibrary(instrumented, PSAN_RTPATH_RT_PSanPrintDebugger);
  }

  writeOutput(instrumented, OutputFilename);
  PSan::flush_debug_outs();

  if (!isNoStaticStats()) {
    stats.print(llvm::outs());
  }

  if (VerifyOutputOption) {
    llvm::SMDiagnostic err;
    std::unique_ptr<llvm::Module> loaded = llvm::parseIRFile(OutputFilename, err, *ctx);
    if (!loaded) {
      SVFUtil::errs() << "cannot load back module: " << OutputFilename << "\n";
      err.print("PSanVerifier", PSan::errs());
      return 1;
    }
    psan_verifyModule(*loaded, "final");
  }
  return 0;
}
