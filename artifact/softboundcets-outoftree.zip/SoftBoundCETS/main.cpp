#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/LegacyPassManager.h"
#include "llvm/Support/CommandLine.h"
#include "llvm/Support/InitLLVM.h"
#include "llvm/Support/MemoryBuffer.h"
#include "llvm/Support/SourceMgr.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Support/FileSystem.h"
#include "llvm/IRReader/IRReader.h"
#include "llvm/Analysis/Passes.h"
#include "llvm/InitializePasses.h"
#include "llvm/Linker/Linker.h"

#include "SoftBoundCETS.h"
#include "FixByValAttributes.h"

using namespace llvm;

static cl::opt<std::string> InputFilename(
    cl::Positional,
    cl::desc("<input LLVM IR file>"),
    cl::init("-"));

static cl::opt<std::string> OutputFilename(
    "o",
    cl::desc("Specify output filename"),
    cl::value_desc("filename"),
    cl::init("-"));

static cl::opt<bool> linkInSupportLibrary(
    "link-in-support-library",
    cl::desc("Link in the support library"),
    cl::init(true));

static cl::opt<bool> NoRecovery(
    "no-recovery",
    cl::desc("Link in the support library without recovery support"),
    cl::init(false));

void linkInLibrary(llvm::Module* destModule, llvm::StringRef path)
{
  llvm::LLVMContext& ctx = destModule->getContext();
  llvm::SMDiagnostic err;
  std::unique_ptr<llvm::Module> srcModule = llvm::parseIRFile(path, err, ctx);
  if (!srcModule) {
    llvm::errs() << "load module failed: " << path << "\n";
    err.print("softboundcets", llvm::errs());
    llvm_unreachable("linkInLibrary() failed to load the depended LLVM IR file; make sure the file (.ll/.bc) is present");
  }
  bool isFailed = llvm::Linker::linkModules(*destModule, std::move(srcModule));
  if (isFailed) {
    llvm_unreachable("linkInLibrary() failed to link the library IR file into the destination module");
  }
}

int main(int argc, char **argv) {
  InitLLVM X(argc, argv);
  cl::ParseCommandLineOptions(argc, argv, "SoftBoundCETS standalone runner\n");

  LLVMContext Context;
  SMDiagnostic Err;
  std::unique_ptr<Module> ModulePtr =
      parseIRFile(InputFilename, Err, Context);
  if (!ModulePtr) {
    Err.print(argv[0], errs());
    return 1;
  }

  // Initialize passes registry
  PassRegistry &Registry = *PassRegistry::getPassRegistry();
  initializeCore(Registry);
  initializeScalarOpts(Registry);
  initializeIPO(Registry);
  initializeAnalysis(Registry);
  initializeTransformUtils(Registry);
  initializeInstCombine(Registry);
  initializeAggressiveInstCombine(Registry);
  initializeVectorization(Registry);
  initializeLoopStrengthReducePass(Registry);
  //initializeSoftBoundCETSPassPass(Registry);
  //initializeFixByValAttributesPassPass(Registry);

  // Build and run legacy pass manager
  legacy::PassManager PM;
  PM.add(new FixByValAttributesPass());
  PM.add(new SoftBoundCETSPass());
  PM.run(*ModulePtr);

  if (linkInSupportLibrary) {
    linkInLibrary(ModulePtr.get(), NoRecovery? SOFTBOUNDCETS_SUPPORT_LIBDIR_NORECOVERY : SOFTBOUNDCETS_SUPPORT_LIBDIR);
  }

  // Output module
  std::error_code EC;
  raw_fd_ostream Out(OutputFilename, EC, sys::fs::OpenFlags::OF_None);
  if (EC) {
    errs() << "Error opening output file: " << EC.message() << "\n";
    return 1;
  }
  ModulePtr->print(Out, nullptr);
  return 0;
}
